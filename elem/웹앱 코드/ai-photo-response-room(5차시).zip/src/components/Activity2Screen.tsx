import React from 'react';
import {
  Sparkles,
  Send,
  MessageSquare,
  Share2,
  ArrowRight,
  HelpCircle,
  Ban,
  Users,
  CheckCircle2,
  RotateCcw,
} from 'lucide-react';

interface Activity2Props {
  currentSituation: 1 | 2;
  situation1View: 'continue' | 'stop' | null;
  situation2View: 'continue' | 'stop' | null;
  situation1ViewedContinue: boolean;
  situation1ViewedStop: boolean;
  situation2ViewedContinue: boolean;
  situation2ViewedStop: boolean;
  differenceThought: string;
  whyStopNeeded: string;
  onSelectSituation: (sit: 1 | 2) => void;
  onSetSituationView: (sit: 1 | 2, view: 'continue' | 'stop') => void;
  onChangeDifferenceThought: (val: string) => void;
  onChangeWhyStopNeeded: (val: string) => void;
  onNext: () => void;
}

export const Activity2Screen: React.FC<Activity2Props> = ({
  currentSituation,
  situation1View,
  situation2View,
  situation1ViewedContinue,
  situation1ViewedStop,
  situation2ViewedContinue,
  situation2ViewedStop,
  differenceThought,
  whyStopNeeded,
  onSelectSituation,
  onSetSituationView,
  onChangeDifferenceThought,
  onChangeWhyStopNeeded,
  onNext,
}) => {
  const steps = [
    {
      num: 1,
      title: '변형된 사진이 생김',
      sub: '생성 단계',
      icon: Sparkles,
    },
    {
      num: 2,
      title: '친구에게 전달됨',
      sub: '전달 단계',
      icon: Send,
    },
    {
      num: 3,
      title: '단체 대화방에 공유됨',
      sub: '공유 단계',
      icon: MessageSquare,
    },
    {
      num: 4,
      title: '다른 사람에게 다시 공유됨',
      sub: '재공유 단계',
      icon: Share2,
    },
  ];

  const isSituation1 = currentSituation === 1;
  const currentView = isSituation1 ? situation1View : situation2View;

  // In Situation 1:
  // - Happened so far: Steps 1 & 2 ('친구에게 전달됨')
  // - Stop is at boundary 2 (between Step 2 and Step 3)
  // In Situation 2:
  // - Happened so far: Steps 1, 2 & 3 ('단체 대화방에 공유됨')
  // - Stop is at boundary 3 (between Step 3 and Step 4)
  const initialHappenedStep = isSituation1 ? 2 : 3;
  const autoStopBoundary = isSituation1 ? 2 : 3;

  const isShowingStop = currentView === 'stop';

  // Completion flags
  const situation1Completed = situation1ViewedContinue && situation1ViewedStop;
  const situation2Completed = situation2ViewedContinue && situation2ViewedStop;
  const allViewsChecked = situation1Completed && situation2Completed;

  const hasDifferenceThought = differenceThought.trim().length > 0;
  const hasWhyStopNeeded = whyStopNeeded.trim().length > 0;
  const isValid = allViewsChecked && hasDifferenceThought && hasWhyStopNeeded;

  return (
    <div className="w-full max-w-[1060px] mx-auto space-y-8 animate-fade-in pb-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <span className="inline-block bg-[#e0f2fe] text-[#384953] px-4 py-1 rounded-full text-xs md:text-sm font-bold whitespace-nowrap nowrap-ko">
          활동 2
        </span>
        <h1 className="text-2xl md:text-4xl font-extrabold text-[#121c2a] tracking-tight balance-ko">
          멈추는 시점에 따른 결과 비교하기
        </h1>
        <div className="space-y-1">
          <p className="text-base md:text-lg font-medium text-[#121c2a] balance-ko">
            사진이 퍼진 시점이 다를 때, 그때부터 더 퍼지는 것을 멈추면 결과가 어떻게 달라지는지 살펴봅시다.
          </p>
          <p className="text-xs md:text-sm text-[#50616b] balance-ko">
            두 상황을 차례로 살펴보고 이미 퍼진 범위를 비교해 보세요.
          </p>
        </div>
      </div>

      {/* Situation Tabs */}
      <div className="flex items-center justify-center gap-3">
        <button
          type="button"
          onClick={() => onSelectSituation(1)}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm transition-all cursor-pointer border ${
            currentSituation === 1
              ? 'bg-[#121c2a] text-white border-[#121c2a] shadow-sm'
              : 'bg-white text-[#50616b] border-[#c3c7cb]/60 hover:bg-[#f0f4f9]'
          }`}
        >
          {situation1Completed && <CheckCircle2 className="w-4 h-4 text-[#4ade80]" />}
          <span>상황 1. 아직 많이 퍼지기 전</span>
        </button>

        <button
          type="button"
          disabled={!situation1Completed}
          onClick={() => {
            if (!situation1Completed) return;
            onSelectSituation(2);
          }}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm transition-all border ${
            currentSituation === 2
              ? 'bg-[#121c2a] text-white border-[#121c2a] shadow-sm cursor-pointer'
              : !situation1Completed
              ? 'bg-[#f0f4f9] text-[#73787b]/60 border-[#c3c7cb]/40 cursor-not-allowed opacity-60'
              : 'bg-white text-[#50616b] border-[#c3c7cb]/60 hover:bg-[#f0f4f9] cursor-pointer'
          }`}
        >
          {situation2Completed && <CheckCircle2 className="w-4 h-4 text-[#4ade80]" />}
          <span>상황 2. 이미 더 많이 퍼진 뒤</span>
        </button>
      </div>

      {/* Main Simulation Section */}
      <section className="bg-white rounded-2xl p-5 sm:p-6 md:p-8 soft-shadow border border-[#c3c7cb]/40 space-y-6">
        {/* Situation Description Box */}
        <div className="bg-[#f8faff] rounded-2xl p-5 border border-[#d9e3f7] space-y-2">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ba1a1a] shrink-0" />
              <h2 className="text-base sm:text-lg font-bold text-[#121c2a] balance-ko">
                {isSituation1
                  ? '상황 1. 아직 많이 퍼지기 전'
                  : '상황 2. 이미 더 많이 퍼진 뒤'}
              </h2>
            </div>
            <span className="text-xs text-[#50616b] font-medium hidden sm:inline-block">
              두 모습을 번갈아 비교해 보세요.
            </span>
          </div>
          <p className="text-xs sm:text-sm text-[#121c2a] font-medium leading-relaxed balance-ko">
            {isSituation1 ? (
              <>“변형된 사진이 친구에게 전달되었습니다. 아직 단체 대화방에는 올라오지 않았습니다.”</>
            ) : (
              <>“이번에는 변형된 사진이 이미 단체 대화방에 공유되었습니다.”</>
            )}
          </p>
        </div>

        {/* Diffusion Flow Pathway */}
        <div className="overflow-x-auto pb-4 pt-2 -mx-2 px-2">
          <div className="flex items-stretch min-w-[760px] lg:min-w-[960px] gap-1.5 sm:gap-2">
            {steps.map((step) => {
              const boundaryNum = step.num;
              const hasStopAtThisBoundary = isShowingStop && boundaryNum === autoStopBoundary;

              // Three distinct visual states:
              // A. blocked: in 'stop' view after stop boundary -> dimmed + grayscale
              const isBlockedByStop = isShowingStop && step.num > autoStopBoundary;
              // B. neutral-future: in initial (view === null) state for unselected future steps -> soft neutral, no grayscale
              const isNeutralFuture = currentView === null && step.num > initialHappenedStep;
              // C. past/current: clearly active
              const isPastOrCurrent = !isBlockedByStop && !isNeutralFuture;

              const Icon = step.icon;

              return (
                <React.Fragment key={step.num}>
                  {/* Step Card */}
                  <div
                    className={`flex-1 min-w-[130px] sm:min-w-[155px] rounded-2xl p-3.5 sm:p-4 border transition-all duration-300 flex flex-col justify-between select-none ${
                      isBlockedByStop
                        ? 'border-dashed border-[#c3c7cb]/50 bg-[#f9f9ff]/40 opacity-35 grayscale shadow-none'
                        : isNeutralFuture
                        ? 'border-dashed border-[#c3c7cb] bg-white opacity-80 shadow-none'
                        : 'border-[#c3c7cb]/70 bg-[#f9f9ff] shadow-sm'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div
                        className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors duration-300 shrink-0 ${
                          isBlockedByStop
                            ? 'bg-[#d9e3f7] text-[#73787b]'
                            : isNeutralFuture
                            ? 'bg-[#f0f4f9] text-[#73787b]'
                            : 'bg-[#e0f2fe] text-[#50616b]'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full transition-colors duration-300 ${
                          isBlockedByStop
                            ? 'bg-[#e2e4e8] text-[#73787b]'
                            : isNeutralFuture
                            ? 'bg-[#f0f4f9] text-[#73787b]'
                            : 'bg-[#eff3ff] text-[#50616b]'
                        }`}
                      >
                        {step.num}단계
                      </span>
                    </div>

                    <div className="space-y-1 my-1">
                      <h3
                        className={`font-bold text-xs sm:text-sm leading-snug break-keep keep-ko transition-colors duration-300 ${
                          isBlockedByStop
                            ? 'text-[#73787b]'
                            : isNeutralFuture
                            ? 'text-[#50616b]'
                            : 'text-[#121c2a]'
                        }`}
                      >
                        {step.title}
                      </h3>
                      <p
                        className={`text-[11px] transition-colors duration-300 ${
                          isBlockedByStop || isNeutralFuture ? 'text-[#73787b]' : 'text-[#50616b]'
                        }`}
                      >
                        {step.sub}
                      </p>
                    </div>

                    <div className="mt-2 pt-2 border-t border-transparent" />
                  </div>

                  {/* Boundary Connector & Auto STOP Indicator */}
                  <div className="flex flex-col items-center justify-center px-1 shrink-0 w-14 sm:w-16">
                    {/* Line Above */}
                    <div
                      className={`w-full h-0.5 mb-1 transition-colors duration-300 ${
                        hasStopAtThisBoundary
                          ? 'bg-[#50616b]'
                          : isShowingStop && boundaryNum > autoStopBoundary
                          ? 'border-t border-dashed border-[#c3c7cb]/60'
                          : currentView === null && boundaryNum >= initialHappenedStep
                          ? 'border-t border-dashed border-[#c3c7cb]'
                          : 'bg-[#50616b]'
                      }`}
                    />

                    {/* STOP Token or Dot */}
                    <div className="h-10 flex items-center justify-center">
                      {hasStopAtThisBoundary ? (
                        <div className="flex flex-col items-center justify-center bg-[#ba1a1a] text-white px-2.5 py-1 rounded-full shadow-md scale-105 animate-fade-in ring-4 ring-[#ba1a1a]/25">
                          <Ban className="w-4 h-4 text-white stroke-[2.5]" />
                          <span className="text-[8px] font-black leading-none tracking-tight mt-0.5">
                            STOP
                          </span>
                        </div>
                      ) : (
                        <div
                          className={`w-2.5 h-2.5 rounded-full transition-colors duration-300 ${
                            isShowingStop && boundaryNum > autoStopBoundary
                              ? 'bg-[#c3c7cb]/40'
                              : currentView === null && boundaryNum >= initialHappenedStep
                              ? 'bg-[#c3c7cb]'
                              : 'bg-[#50616b]'
                          }`}
                        />
                      )}
                    </div>

                    {/* Bottom Direction / Disconnect Indicator */}
                    <div className="mt-1 flex items-center justify-center w-full">
                      {hasStopAtThisBoundary ? (
                        <span className="text-[#ba1a1a] font-bold text-[11px] select-none tracking-tighter">
                          ✕
                        </span>
                      ) : isShowingStop && boundaryNum > autoStopBoundary ? (
                        <span className="text-[#c3c7cb] text-[11px] select-none">⇢</span>
                      ) : currentView === null && boundaryNum >= initialHappenedStep ? (
                        <span className="text-[#73787b] text-[11px] select-none">⇢</span>
                      ) : (
                        <span className="text-[#50616b] font-bold text-[11px] select-none">➔</span>
                      )}
                    </div>
                  </div>
                </React.Fragment>
              );
            })}

            {/* Extra Spread Auxiliary Area */}
            <div
              className={`w-28 sm:w-32 rounded-2xl p-3 sm:p-3.5 border transition-all duration-300 flex flex-col justify-between shrink-0 select-none ${
                isShowingStop
                  ? 'border-dashed border-[#c3c7cb]/40 bg-[#f9f9ff]/30 opacity-30 grayscale'
                  : currentView === 'continue'
                  ? 'border-dashed border-[#50616b]/80 bg-[#eff3ff] opacity-100 shadow-xs'
                  : 'border-dashed border-[#c3c7cb] bg-white opacity-80'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <div
                  className={`flex items-center gap-1 transition-colors duration-300 ${
                    currentView === 'continue' ? 'text-[#50616b]' : 'text-[#73787b]'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  <span className="text-[10px] tracking-widest">…</span>
                </div>
              </div>

              <div className="space-y-1 my-1">
                <p
                  className={`font-semibold text-xs leading-tight break-keep keep-ko transition-colors duration-300 ${
                    isShowingStop
                      ? 'text-[#73787b]'
                      : currentView === 'continue'
                      ? 'text-[#121c2a]'
                      : 'text-[#50616b]'
                  }`}
                >
                  더 퍼질 수 있음 …
                </p>
                <div
                  className={`flex gap-1 text-[10px] transition-colors duration-300 ${
                    isShowingStop
                      ? 'text-[#73787b]'
                      : currentView === 'continue'
                      ? 'text-[#50616b]'
                      : 'text-[#73787b]'
                  }`}
                >
                  <span>○</span>
                  <span>○</span>
                  <span>○</span>
                </div>
              </div>

              <div className="mt-1 pt-1 border-t border-transparent" />
            </div>
          </div>
        </div>

        {/* Action Controls: [계속 퍼진다면] & [이때 멈춘다면] Toggle Buttons */}
        <div className="bg-[#f0f7ff] rounded-xl p-4 sm:p-5 border border-[#c3c7cb]/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Button 1: 계속 퍼진다면 */}
            <button
              type="button"
              onClick={() => onSetSituationView(currentSituation, 'continue')}
              className={`px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm transition-all cursor-pointer border ${
                currentView === 'continue'
                  ? 'bg-[#121c2a] text-white border-[#121c2a] shadow-md ring-2 ring-[#121c2a]/20 scale-102'
                  : 'bg-white text-[#121c2a] border-[#c3c7cb] hover:bg-[#f0f4f9] shadow-xs'
              }`}
            >
              계속 퍼진다면
            </button>

            {/* Button 2: 이때 멈춘다면 */}
            <button
              type="button"
              onClick={() => onSetSituationView(currentSituation, 'stop')}
              className={`inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm transition-all cursor-pointer border ${
                currentView === 'stop'
                  ? 'bg-[#ba1a1a] text-white border-[#ba1a1a] shadow-md ring-2 ring-[#ba1a1a]/25 scale-102'
                  : 'bg-white text-[#ba1a1a] border-[#ba1a1a]/40 hover:bg-[#ffe4e6]/50 shadow-xs'
              }`}
            >
              <Ban className="w-3.5 h-3.5" />
              <span>이때 멈춘다면</span>
            </button>
          </div>

          {/* Navigation between Situation 1 and 2 */}
          {isSituation1 ? (
            <button
              type="button"
              disabled={!situation1Completed}
              onClick={() => onSelectSituation(2)}
              className={`inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm transition-all self-end sm:self-auto ${
                situation1Completed
                  ? 'bg-[#121c2a] text-white hover:bg-[#253244] cursor-pointer shadow-sm'
                  : 'bg-[#d9e3f7] text-[#73787b] cursor-not-allowed opacity-60'
              }`}
            >
              <span>다음 상황 보기</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onSelectSituation(1)}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm bg-white text-[#50616b] border border-[#c3c7cb] hover:bg-[#f0f4f9] transition-all cursor-pointer self-end sm:self-auto shadow-xs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>상황 1 다시 보기</span>
            </button>
          )}
        </div>
      </section>

      {/* Side-by-Side Visual Comparison Area (Displayed when all views in both situations have been checked) */}
      {allViewsChecked && (
        <section className="bg-white rounded-2xl p-5 sm:p-6 md:p-8 soft-shadow border border-[#c3c7cb]/40 space-y-4 animate-fade-in">
          <div className="flex items-center gap-2 border-b border-[#c3c7cb]/30 pb-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#121c2a] shrink-0" />
            <h2 className="text-base sm:text-lg font-bold text-[#121c2a] balance-ko">
              두 상황의 결과 한눈에 비교하기
            </h2>
          </div>

          <div className="space-y-3">
            {/* Situation 1 Compact Pathway */}
            <div className="bg-[#f8faff] rounded-xl p-3.5 border border-[#d9e3f7] flex flex-col md:flex-row md:items-center justify-between gap-3">
              <span className="text-xs font-bold text-[#121c2a] shrink-0 whitespace-nowrap">
                상황 1 (아직 많이 퍼지기 전)
              </span>
              <div className="flex items-center gap-1.5 text-xs overflow-x-auto py-1">
                <span className="bg-[#e0f2fe] text-[#121c2a] font-semibold px-2.5 py-1 rounded-lg shrink-0">
                  1단계: 변형 생성
                </span>
                <span className="text-[#50616b] font-bold">➔</span>
                <span className="bg-[#e0f2fe] text-[#121c2a] font-semibold px-2.5 py-1 rounded-lg shrink-0">
                  2단계: 친구 전달
                </span>
                <span className="bg-[#ba1a1a] text-white font-black px-2 py-0.5 rounded-full text-[10px] shrink-0">
                  ⛔ STOP
                </span>
                <span className="text-[#c3c7cb]">⇢</span>
                <span className="bg-[#f0f4f9] text-[#73787b] px-2 py-1 rounded-lg shrink-0 opacity-40 line-through">
                  단체 대화방 공유
                </span>
                <span className="text-[#c3c7cb]">⇢</span>
                <span className="bg-[#f0f4f9] text-[#73787b] px-2 py-1 rounded-lg shrink-0 opacity-40 line-through">
                  재공유
                </span>
              </div>
            </div>

            {/* Situation 2 Compact Pathway */}
            <div className="bg-[#f8faff] rounded-xl p-3.5 border border-[#d9e3f7] flex flex-col md:flex-row md:items-center justify-between gap-3">
              <span className="text-xs font-bold text-[#121c2a] shrink-0 whitespace-nowrap">
                상황 2 (이미 더 많이 퍼진 뒤)
              </span>
              <div className="flex items-center gap-1.5 text-xs overflow-x-auto py-1">
                <span className="bg-[#e0f2fe] text-[#121c2a] font-semibold px-2.5 py-1 rounded-lg shrink-0">
                  1단계: 변형 생성
                </span>
                <span className="text-[#50616b] font-bold">➔</span>
                <span className="bg-[#e0f2fe] text-[#121c2a] font-semibold px-2.5 py-1 rounded-lg shrink-0">
                  2단계: 친구 전달
                </span>
                <span className="text-[#50616b] font-bold">➔</span>
                <span className="bg-[#e0f2fe] text-[#121c2a] font-semibold px-2.5 py-1 rounded-lg shrink-0">
                  3단계: 단체 대화방 공유
                </span>
                <span className="bg-[#ba1a1a] text-white font-black px-2 py-0.5 rounded-full text-[10px] shrink-0">
                  ⛔ STOP
                </span>
                <span className="text-[#c3c7cb]">⇢</span>
                <span className="bg-[#f0f4f9] text-[#73787b] px-2 py-1 rounded-lg shrink-0 opacity-40 line-through">
                  재공유
                </span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Reflection Questions Area (Displayed once all 4 states have been checked) */}
      {allViewsChecked ? (
        <section className="bg-white rounded-2xl p-6 md:p-8 soft-shadow border border-[#c3c7cb]/40 space-y-6 animate-fade-in">
          <div className="flex items-center gap-2 border-b border-[#c3c7cb]/30 pb-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#ba1a1a] shrink-0" />
            <h2 className="text-lg md:text-xl font-bold text-[#121c2a] balance-ko">
              두 상황을 비교하고 생각해 보기
            </h2>
          </div>

          {/* Question 1 */}
          <div className="space-y-2">
            <label className="block text-sm md:text-base font-bold text-[#121c2a] flex items-center gap-2 balance-ko">
              <HelpCircle className="w-4 h-4 text-[#50616b] shrink-0" />
              <span>두 상황에서 사진이 이미 퍼진 범위는 어떻게 달랐나요?</span>
            </label>
            <textarea
              value={differenceThought}
              onChange={(e) => onChangeDifferenceThought(e.target.value)}
              placeholder="두 상황에서 어디까지 퍼졌는지 비교해 적어 보세요."
              className="w-full bg-[#f9f9ff] rounded-xl p-3.5 border border-[#c3c7cb]/60 focus:border-[#50616b] focus:bg-white focus:ring-2 focus:ring-[#e0f2fe] outline-none text-sm md:text-base text-[#121c2a] transition-all resize-none h-24 placeholder:text-[#73787b]/70 keep-ko"
            />
          </div>

          {/* Question 2 */}
          <div className="space-y-2">
            <label className="block text-sm md:text-base font-bold text-[#121c2a] flex items-center gap-2 balance-ko">
              <HelpCircle className="w-4 h-4 text-[#50616b] shrink-0" />
              <span>사진이 이미 여러 사람에게 퍼진 뒤에도 더 퍼지는 것을 멈추는 것이 필요한 까닭은 무엇일까요?</span>
            </label>
            <textarea
              value={whyStopNeeded}
              onChange={(e) => onChangeWhyStopNeeded(e.target.value)}
              placeholder="생각한 까닭을 적어 보세요."
              className="w-full bg-[#f9f9ff] rounded-xl p-3.5 border border-[#c3c7cb]/60 focus:border-[#50616b] focus:bg-white focus:ring-2 focus:ring-[#e0f2fe] outline-none text-sm md:text-base text-[#121c2a] transition-all resize-none h-24 placeholder:text-[#73787b]/70 keep-ko"
            />
          </div>
        </section>
      ) : (
        <div className="bg-[#eff3ff] rounded-2xl p-6 text-center text-[#50616b] border border-dashed border-[#c3c7cb]">
          <p className="text-sm md:text-base font-semibold balance-ko">
            상황 1과 상황 2에서 [계속 퍼진다면]과 [이때 멈춘다면]을 모두 확인하면 비교 질문이 나타납니다.
          </p>
        </div>
      )}

      {/* Activity 2 to Activity 3 Bridge Notice & Next Button (Only shown when activity 2 is fully completed) */}
      {isValid ? (
        <div className="space-y-6 pt-2 animate-fade-in">
          <section className="bg-[#e0f2fe]/40 rounded-2xl p-6 border border-[#d0daef] text-center space-y-2">
            <p className="text-sm md:text-base font-bold text-[#121c2a] leading-relaxed balance-ko">
              “그렇다면 실제 상황에서 확산과 피해를 줄이기 위해 우리는 무엇을 할 수 있을까요?”
            </p>
          </section>

          <div className="flex justify-end">
            <button
              type="button"
              onClick={onNext}
              className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full font-bold text-sm md:text-base bg-[#ffe24c] hover:bg-[#fcdf46] text-[#211b00] hover-lift cursor-pointer shadow-[0_4px_14px_0_rgba(253,224,71,0.39)] transition-all whitespace-nowrap nowrap-ko"
            >
              <span>다음: 대응 방법 만들기</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <div className="pt-2">
          <div className="text-xs text-[#73787b]">
            <span className="text-[#ba1a1a] font-medium keep-ko">
              {!situation1Completed
                ? '* 상황 1에서 [계속 퍼진다면]과 [이때 멈춘다면]을 모두 확인해 보세요.'
                : !situation2Completed
                ? '* 상황 2에서 [계속 퍼진다면]과 [이때 멈춘다면]을 모두 확인해 보세요.'
                : !hasDifferenceThought
                ? '* 두 상황에서 이미 퍼진 범위가 어떻게 달랐는지 적어주세요.'
                : '* 더 퍼지는 것을 멈추는 것이 필요한 까닭을 적어주세요.'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
