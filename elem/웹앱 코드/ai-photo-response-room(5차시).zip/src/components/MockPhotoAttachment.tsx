import React from 'react';
import { Sparkles, Camera, Image as ImageIcon } from 'lucide-react';

interface MockPhotoAttachmentProps {
  compact?: boolean;
}

export const MockPhotoAttachment: React.FC<MockPhotoAttachmentProps> = ({ compact = false }) => {
  if (compact) {
    return (
      <div
        className="flex items-center gap-3 bg-white/90 p-2.5 rounded-xl border border-[#c3c7cb]/60 shadow-xs"
        role="img"
        aria-label="AI로 얼굴이 장난스럽게 변형된 예시 사진 (전달됨)"
      >
        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#ffe4e6] to-[#dbeafe] border border-pink-200/70 relative overflow-hidden shrink-0 flex items-center justify-center">
          {/* Mini Cute Face with Rabbit Ears */}
          <svg viewBox="0 0 100 100" className="w-10 h-10 drop-shadow-xs">
            {/* Rabbit Ears */}
            <ellipse cx="38" cy="24" rx="6" ry="16" fill="#fbcfe8" stroke="#f472b6" strokeWidth="2" />
            <ellipse cx="38" cy="24" rx="3" ry="11" fill="#f472b6" />
            <ellipse cx="62" cy="24" rx="6" ry="16" fill="#fbcfe8" stroke="#f472b6" strokeWidth="2" />
            <ellipse cx="62" cy="24" rx="3" ry="11" fill="#f472b6" />
            
            {/* Face */}
            <circle cx="50" cy="58" r="28" fill="#fed7aa" stroke="#fb923c" strokeWidth="2" />
            {/* Hair */}
            <path d="M 28 50 Q 50 32 72 50 Q 66 38 50 36 Q 34 38 28 50 Z" fill="#78350f" />
            {/* Eyes (Winking & Happy) */}
            <path d="M 38 54 Q 43 50 48 54" stroke="#451a03" strokeWidth="2.5" fill="none" strokeLinecap="round" />
            <circle cx="60" cy="53" r="3" fill="#451a03" />
            {/* Cheeks */}
            <circle cx="36" cy="62" r="5" fill="#fb7185" opacity="0.6" />
            <circle cx="64" cy="62" r="5" fill="#fb7185" opacity="0.6" />
            {/* Smile */}
            <path d="M 46 63 Q 50 68 54 63" stroke="#451a03" strokeWidth="2" fill="none" strokeLinecap="round" />
            {/* Sparkle */}
            <circle cx="76" cy="38" r="2" fill="#eab308" />
          </svg>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1 text-[11px] font-bold text-[#e11d48]">
            <Sparkles className="w-3 h-3" />
            <span>AI 변형 사진</span>
          </div>
          <p className="text-xs text-[#50616b] truncate">
            (다른 단체 대화방으로 다시 전달된 사진)
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="w-full max-w-[280px] bg-white rounded-2xl p-3 border border-[#c3c7cb]/70 shadow-sm transition-all"
      role="img"
      aria-label="AI로 얼굴이 장난스럽게 변형된 예시 사진"
    >
      {/* Photo Frame Header */}
      <div className="flex items-center justify-between px-1 mb-2 text-[11px] font-semibold text-[#50616b]">
        <div className="flex items-center gap-1 text-[#db2777]">
          <Sparkles className="w-3.5 h-3.5" />
          <span className="font-bold">AI 변형 사진</span>
        </div>
        <div className="flex items-center gap-1 text-[#73787b] bg-[#f0f4f9] px-2 py-0.5 rounded-full text-[10px]">
          <Camera className="w-3 h-3" />
          <span>PHOTO</span>
        </div>
      </div>

      {/* Main Illustration Area */}
      <div className="relative w-full aspect-square rounded-xl bg-gradient-to-b from-[#fdf2f8] via-[#eff6ff] to-[#ecfeff] border border-pink-100 flex flex-col items-center justify-center overflow-hidden">
        {/* Soft Background Decor Elements */}
        <div className="absolute top-2 left-3 w-6 h-6 rounded-full bg-pink-200/50 blur-xs pointer-events-none" />
        <div className="absolute top-4 right-4 text-amber-400 text-xs font-bold pointer-events-none select-none">
          ✨
        </div>
        <div className="absolute bottom-3 left-4 text-pink-400 text-xs font-bold pointer-events-none select-none">
          💖
        </div>

        {/* Vector Character Illustration with Playful AI Props */}
        <svg viewBox="0 0 160 160" className="w-36 h-36 drop-shadow-sm select-none">
          <defs>
            {/* Gradients */}
            <linearGradient id="earGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f472b6" />
              <stop offset="100%" stopColor="#fda4af" />
            </linearGradient>
            <linearGradient id="faceGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ffedd5" />
              <stop offset="100%" stopColor="#fed7aa" />
            </linearGradient>
            <linearGradient id="shirtGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#bae6fd" />
              <stop offset="100%" stopColor="#7dd3fc" />
            </linearGradient>
          </defs>

          {/* Bunny Headband (AI Filter Effect) */}
          {/* Headband Ring */}
          <path d="M 45 65 Q 80 46 115 65" stroke="#f43f5e" strokeWidth="4" fill="none" strokeLinecap="round" />
          
          {/* Left Bunny Ear */}
          <g transform="rotate(-10 60 40)">
            <ellipse cx="60" cy="35" rx="10" ry="24" fill="#fdf2f8" stroke="#f472b6" strokeWidth="3" />
            <ellipse cx="60" cy="35" rx="5" ry="16" fill="url(#earGrad)" />
          </g>

          {/* Right Bunny Ear */}
          <g transform="rotate(12 100 40)">
            <ellipse cx="100" cy="35" rx="10" ry="24" fill="#fdf2f8" stroke="#f472b6" strokeWidth="3" />
            <ellipse cx="100" cy="35" rx="5" ry="16" fill="url(#earGrad)" />
          </g>

          {/* Body / Shirt */}
          <path d="M 38 150 C 38 120, 60 110, 80 110 C 100 110, 122 120, 122 150 Z" fill="url(#shirtGrad)" />
          <path d="M 70 110 Q 80 120 90 110" stroke="#38bdf8" strokeWidth="2" fill="none" />

          {/* Neck */}
          <rect x="72" y="98" width="16" height="15" rx="4" fill="#fed7aa" />

          {/* Head / Face */}
          <circle cx="80" cy="85" r="32" fill="url(#faceGrad)" stroke="#fdba74" strokeWidth="2" />

          {/* Hair */}
          <path
            d="M 48 80 Q 80 50 112 80 C 114 62, 105 52, 80 52 C 55 52, 46 62, 48 80 Z"
            fill="#451a03"
          />
          {/* Hair bangs */}
          <path d="M 58 68 Q 68 76 78 68" stroke="#451a03" strokeWidth="4" fill="none" strokeLinecap="round" />
          <path d="M 76 68 Q 88 77 98 69" stroke="#451a03" strokeWidth="4" fill="none" strokeLinecap="round" />

          {/* Playful Winking Eyes */}
          {/* Left Eye: Winking Arch */}
          <path d="M 60 80 Q 68 72 74 80" stroke="#1f2937" strokeWidth="3.5" fill="none" strokeLinecap="round" />
          {/* Right Eye: Big Round Cute Eye */}
          <circle cx="92" cy="78" r="4.5" fill="#1f2937" />
          <circle cx="94" cy="76" r="1.5" fill="#ffffff" />

          {/* Eyebrows */}
          <path d="M 58 72 Q 66 68 72 73" stroke="#451a03" strokeWidth="2" fill="none" strokeLinecap="round" />
          <path d="M 88 71 Q 94 67 100 71" stroke="#451a03" strokeWidth="2" fill="none" strokeLinecap="round" />

          {/* AI Filter Cute Whisker & Nose Effect */}
          <ellipse cx="80" cy="88" rx="3.5" ry="2.5" fill="#f43f5e" />
          {/* Whiskers */}
          <line x1="52" y1="87" x2="68" y2="88" stroke="#f472b6" strokeWidth="2" strokeLinecap="round" />
          <line x1="52" y1="92" x2="68" y2="91" stroke="#f472b6" strokeWidth="2" strokeLinecap="round" />
          <line x1="92" y1="88" x2="108" y2="87" stroke="#f472b6" strokeWidth="2" strokeLinecap="round" />
          <line x1="92" y1="91" x2="108" y2="92" stroke="#f472b6" strokeWidth="2" strokeLinecap="round" />

          {/* Rosy Cheeks (Blush) */}
          <ellipse cx="58" cy="91" rx="7" ry="4.5" fill="#fb7185" opacity="0.65" />
          <ellipse cx="102" cy="91" rx="7" ry="4.5" fill="#fb7185" opacity="0.65" />

          {/* Open Happy Smile with Tongue */}
          <path d="M 72 96 Q 80 107 88 96 Z" fill="#e11d48" />
          <path d="M 75 100 Q 80 105 85 100" fill="#fda4af" />
        </svg>

        {/* Filter Sticker Tag */}
        <div className="absolute bottom-2 right-2 bg-white/90 backdrop-blur-xs px-2 py-0.5 rounded-md border border-pink-200 text-[10px] font-bold text-pink-600 flex items-center gap-1 shadow-2xs">
          <span>🐰 AI Starlight</span>
        </div>
      </div>

      {/* Description Text Under Image */}
      <div className="mt-2.5 pt-2 border-t border-[#f1f5f9] text-center">
        <p className="text-[11px] sm:text-xs font-semibold text-[#50616b] leading-tight">
          (AI로 얼굴이 장난스럽게 합성·변형된 사진)
        </p>
      </div>
    </div>
  );
};
