import React from 'react';
import {
  Lightbulb,
  CheckSquare,
  Users,
  Plus,
  Edit3,
  ArrowRight,
  Trash2,
} from 'lucide-react';
import { IdeaItem } from '../types';

interface Activity3Props {
  ideas: IdeaItem[];
  groupMethod: string;
  groupMethodReason: string;
  onUpdateIdeaText: (id: string, text: string) => void;
  onAddIdea: () => void;
  onRemoveIdea: (id: string) => void;
  onSetIdeaCheck: (
    id: string,
    field: 'checkSpread' | 'checkFeasible',
    val: 'yes' | 'rethink'
  ) => void;
  onUpdateIdeaRevised: (id: string, revisedText: string) => void;
  onChangeGroupMethod: (val: string) => void;
  onChangeGroupMethodReason: (val: string) => void;
  onNext: () => void;
}

export const Activity3Screen: React.FC<Activity3Props> = ({
  ideas,
  groupMethod,
  groupMethodReason,
  onUpdateIdeaText,
  onAddIdea,
  onRemoveIdea,
  onSetIdeaCheck,
  onUpdateIdeaRevised,
  onChangeGroupMethod,
  onChangeGroupMethodReason,
  onNext,
}) => {
  // Filter valid ideas with non-empty text
  const validIdeas = ideas.filter((idea) => idea.text.trim().length > 0);

  // Condition 1: At least 1 valid idea
  const hasAtLeastOneIdea = validIdeas.length > 0;

  // Condition 2: All valid ideas have both checklist questions answered
  const allChecklistsCompleted =
    hasAtLeastOneIdea &&
    validIdeas.every(
      (i) =>
        (i.checkSpread === 'yes' || i.checkSpread === 'rethink') &&
        (i.checkFeasible === 'yes' || i.checkFeasible === 'rethink')
    );

  // Condition 3: Any idea requiring rethink must have non-empty revisedText
  const allRevisionsCompleted = validIdeas.every((i) => {
    const needsRethink =
      i.checkSpread === 'rethink' || i.checkFeasible === 'rethink';
    if (!needsRethink) return true;
    return (i.revisedText ?? '').trim().length > 0;
  });

  // Condition 4: Group method text must not be empty
  const hasGroupMethod = groupMethod.trim().length > 0;

  // Condition 5: Reason for choosing group method must not be empty
  const hasGroupMethodReason = groupMethodReason.trim().length > 0;

  // Final validation check
  const isValid =
    hasAtLeastOneIdea &&
    allChecklistsCompleted &&
    allRevisionsCompleted &&
    hasGroupMethod &&
    hasGroupMethodReason;

  const getValidationMessage = () => {
    if (!hasAtLeastOneIdea) {
      return '* 1단계에서 대응 방법 아이디어를 최소 1개 이상 적어주세요.';
    }
    if (!allChecklistsCompleted) {
      return '* 2단계에서 작성한 모든 아이디어의 점검 항목 2가지를 모두 확인해 주세요.';
    }
    if (!allRevisionsCompleted) {
      return '* 2단계에서 "다시 생각해 보기"를 선택한 아이디어의 수정 방법을 적어주세요.';
    }
    if (!hasGroupMethod) {
      return '* 3단계 "우리 모둠의 대응 방법"을 작성해 주세요.';
    }
    if (!hasGroupMethodReason) {
      return '* 3단계에서 대응 방법을 정한 까닭을 적어주세요.';
    }
    return '';
  };

  return (
    <div className="w-full max-w-[1000px] mx-auto space-y-8 animate-fade-in pb-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <span className="inline-block bg-[#e0f2fe] text-[#384953] px-4 py-1 rounded-full text-xs md:text-sm font-bold whitespace-nowrap nowrap-ko">
          활동 3
        </span>
        <h1 className="text-2xl md:text-4xl font-extrabold text-[#121c2a] tracking-tight balance-ko">
          상황에 맞는 대응 방법 만들기
        </h1>
        <p className="text-sm md:text-base text-[#50616b] balance-ko">
          피해를 줄이기 위한 아이디어를 내고, 점검하며 우리 모둠만의 실천 방법을 만들어 보세요.
        </p>
      </div>

      {/* STEP 1: 피해를 줄이기 위해 무엇을 할 수 있을까요? */}
      <section className="bg-white rounded-2xl p-5 sm:p-6 md:p-8 soft-shadow border border-[#c3c7cb]/40">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-8 h-8 rounded-lg bg-[#e0f2fe] flex items-center justify-center text-[#50616b] shrink-0">
            <Lightbulb className="w-5 h-5 text-[#50616b]" />
          </div>
          <h2 className="text-lg md:text-xl font-bold text-[#121c2a] balance-ko">
            1단계: 피해를 줄이기 위해 무엇을 할 수 있을까요?
          </h2>
        </div>
        <p className="text-xs md:text-sm text-[#50616b] mb-6">
          다양한 아이디어를 자유롭게 적어 보세요.
        </p>

        {/* Ideas Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          {ideas.map((idea, index) => (
            <div
              key={idea.id}
              className="bg-[#f9f9ff] rounded-xl p-4 md:p-5 border border-[#c3c7cb]/60 focus-within:border-[#50616b] focus-within:ring-2 focus-within:ring-[#e0f2fe] transition-all relative flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-bold text-[#121c2a] whitespace-nowrap nowrap-ko">
                    아이디어 {index + 1}
                  </label>
                  {ideas.length > 1 && (
                    <button
                      type="button"
                      onClick={() => onRemoveIdea(idea.id)}
                      className="text-[#73787b] hover:text-[#ba1a1a] p-1 rounded transition-colors cursor-pointer"
                      title="아이디어 삭제"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
                <textarea
                  value={idea.text}
                  onChange={(e) => onUpdateIdeaText(idea.id, e.target.value)}
                  placeholder="대응 방법을 적어 보세요."
                  className="w-full bg-transparent border-none focus:outline-none text-sm md:text-base text-[#121c2a] resize-none h-24 placeholder:text-[#73787b]/70 keep-ko"
                />
              </div>
            </div>
          ))}
        </div>

        {/* Add Idea Button */}
        <button
          type="button"
          onClick={onAddIdea}
          className="inline-flex items-center gap-1.5 text-sm font-bold text-[#50616b] hover:text-[#121c2a] hover:bg-[#eff3ff] px-3.5 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap nowrap-ko"
        >
          <Plus className="w-4 h-4" />
          <span>아이디어 추가하기</span>
        </button>
      </section>

      {/* STEP 2: 생각한 대응 방법을 점검해 볼까요? */}
      <section className="bg-white rounded-2xl p-5 sm:p-6 md:p-8 soft-shadow border border-[#c3c7cb]/40">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-8 h-8 rounded-lg bg-[#e0f2fe] flex items-center justify-center text-[#50616b] shrink-0">
            <CheckSquare className="w-5 h-5 text-[#50616b]" />
          </div>
          <h2 className="text-lg md:text-xl font-bold text-[#121c2a] balance-ko">
            2단계: 생각한 대응 방법을 점검해 볼까요?
          </h2>
        </div>
        <p className="text-xs md:text-sm text-[#50616b] mb-6">
          1단계에서 작성한 대응 방법이 피해를 줄이는 데 도움이 되고 실제로 할 수 있는 방법인지 점검해 보세요.
        </p>

        {validIdeas.length === 0 ? (
          <div className="p-6 bg-[#eff3ff] rounded-xl text-center text-sm text-[#50616b] border border-dashed border-[#c3c7cb] balance-ko">
            1단계에 아이디어를 입력하면 여기에 점검 카드가 자동으로 생성됩니다.
          </div>
        ) : (
          <div className="space-y-5">
            {validIdeas.map((idea, index) => {
              const needsRethink =
                idea.checkSpread === 'rethink' || idea.checkFeasible === 'rethink';

              return (
                <div
                  key={idea.id}
                  className="bg-[#f9f9ff] rounded-xl p-5 border border-[#c3c7cb]/50 space-y-4"
                >
                  {/* Idea Header & Text */}
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                    <div className="flex-grow">
                      <span className="text-xs font-bold text-[#50616b] bg-[#e0f2fe] px-2.5 py-0.5 rounded-full inline-block mb-1.5 whitespace-nowrap nowrap-ko">
                        아이디어 {index + 1}
                      </span>
                      <p className="text-base font-semibold text-[#121c2a] leading-relaxed keep-ko">
                        "{idea.text}"
                      </p>
                    </div>

                    {/* Checklist Questions */}
                    <div className="flex flex-col space-y-3 min-w-[320px] w-full md:w-auto shrink-0 bg-white p-4 rounded-xl border border-[#c3c7cb]/30">
                      {/* Check 1 */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs md:text-sm">
                        <span className="text-[#384953] font-medium keep-ko">
                          ① 이 방법은 확산과 피해를 줄이는 데 도움이 되나요?
                        </span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => onSetIdeaCheck(idea.id, 'checkSpread', 'yes')}
                            className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer whitespace-nowrap nowrap-ko ${
                              idea.checkSpread === 'yes'
                                ? 'bg-[#50616b] text-white'
                                : 'bg-[#eff3ff] text-[#43474b] hover:bg-[#d9e3f7]'
                            }`}
                          >
                            예
                          </button>
                          <button
                            type="button"
                            onClick={() => onSetIdeaCheck(idea.id, 'checkSpread', 'rethink')}
                            className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer whitespace-nowrap nowrap-ko ${
                              idea.checkSpread === 'rethink'
                                ? 'bg-[#ffdad6] text-[#93000a] border border-[#ba1a1a]'
                                : 'bg-[#eff3ff] text-[#43474b] hover:bg-[#ffdad6]/60'
                            }`}
                          >
                            다시 생각해 보기
                          </button>
                        </div>
                      </div>

                      {/* Check 2 */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs md:text-sm">
                        <span className="text-[#384953] font-medium keep-ko">
                          ② 이 방법은 실제 생활에서 할 수 있나요?
                        </span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => onSetIdeaCheck(idea.id, 'checkFeasible', 'yes')}
                            className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer whitespace-nowrap nowrap-ko ${
                              idea.checkFeasible === 'yes'
                                ? 'bg-[#50616b] text-white'
                                : 'bg-[#eff3ff] text-[#43474b] hover:bg-[#d9e3f7]'
                            }`}
                          >
                            예
                          </button>
                          <button
                            type="button"
                            onClick={() => onSetIdeaCheck(idea.id, 'checkFeasible', 'rethink')}
                            className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer whitespace-nowrap nowrap-ko ${
                              idea.checkFeasible === 'rethink'
                                ? 'bg-[#ffdad6] text-[#93000a] border border-[#ba1a1a]'
                                : 'bg-[#eff3ff] text-[#43474b] hover:bg-[#ffdad6]/60'
                            }`}
                          >
                            다시 생각해 보기
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Revision Box if "다시 생각해 보기" is clicked */}
                  {needsRethink && (
                    <div className="p-4 bg-[#ffdad6]/30 rounded-xl border border-[#ffdad6] animate-fade-in space-y-1.5">
                      <label className="block text-xs md:text-sm font-bold text-[#93000a] flex items-center gap-1.5 whitespace-nowrap nowrap-ko">
                        <Edit3 className="w-4 h-4 text-[#ba1a1a]" />
                        <span>어떻게 수정하면 좋을까요?</span>
                      </label>
                      <textarea
                        value={idea.revisedText ?? ''}
                        onChange={(e) => onUpdateIdeaRevised(idea.id, e.target.value)}
                        placeholder="수정된 대응 방법을 적어 보세요."
                        className="w-full bg-white border border-[#c3c7cb]/70 rounded-lg p-3 text-sm text-[#121c2a] focus:ring-2 focus:ring-[#ffdad6] focus:border-[#ba1a1a] outline-none resize-none h-20 placeholder:text-[#73787b]/70 keep-ko"
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* STEP 3: 우리 모둠의 대응 방법 */}
      <section className="bg-[#e0f2fe]/30 rounded-2xl p-5 sm:p-6 md:p-8 soft-shadow border border-[#e0f2fe]">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-8 h-8 rounded-lg bg-[#50616b] flex items-center justify-center text-white shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <h2 className="text-lg md:text-xl font-bold text-[#121c2a] balance-ko">
            우리 모둠의 대응 방법
          </h2>
        </div>
        <p className="text-xs md:text-sm text-[#50616b] mb-5">
          점검한 내용을 보고 우리 모둠의 대응 방법을 정해 보세요.
        </p>

        <div className="space-y-4">
          <div className="bg-white rounded-xl p-4 border border-[#c3c7cb]/60 focus-within:border-[#50616b] focus-within:ring-2 focus-within:ring-[#e0f2fe] transition-all">
            <textarea
              value={groupMethod}
              onChange={(e) => onChangeGroupMethod(e.target.value)}
              placeholder="우리 모둠에서 정한 대응 방법을 자유롭게 적어 보세요."
              className="w-full bg-transparent border-none focus:outline-none text-base text-[#121c2a] resize-none h-28 placeholder:text-[#73787b]/70 keep-ko"
            />
          </div>

          <div className="bg-white rounded-xl p-4 border border-[#c3c7cb]/60 focus-within:border-[#50616b] focus-within:ring-2 focus-within:ring-[#e0f2fe] transition-all">
            <label className="block text-xs md:text-sm font-bold text-[#50616b] mb-1.5 whitespace-nowrap nowrap-ko">
              왜 이런 방법을 정했나요?
            </label>
            <textarea
              value={groupMethodReason}
              onChange={(e) => onChangeGroupMethodReason(e.target.value)}
              placeholder="이 방법을 정한 까닭을 간단히 적어 주세요."
              className="w-full bg-transparent border-none focus:outline-none text-sm md:text-base text-[#121c2a] resize-none h-20 placeholder:text-[#73787b]/70 keep-ko"
            />
          </div>
        </div>
      </section>

      {/* Next Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <div className="text-xs text-[#73787b]">
          {!isValid && (
            <span className="text-[#ba1a1a] font-medium keep-ko">
              {getValidationMessage()}
            </span>
          )}
        </div>
        <button
          type="button"
          disabled={!isValid}
          onClick={onNext}
          className={`inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full font-bold text-sm md:text-base transition-all shadow-sm whitespace-nowrap nowrap-ko ${
            isValid
              ? 'bg-[#ffe24c] hover:bg-[#fcdf46] text-[#211b00] hover-lift cursor-pointer shadow-[0_4px_14px_0_rgba(253,224,71,0.39)]'
              : 'bg-[#d9e3f7] text-[#73787b] cursor-not-allowed opacity-70'
          }`}
        >
          <span>다음: 새로운 상황에 적용하기</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
