import React from 'react';
import { Shield, Check } from 'lucide-react';
import { StepId, STEPS } from '../types';

interface HeaderProps {
  currentStep: StepId;
  completedSteps: StepId[];
  visitedSteps: StepId[];
  onNavigate: (step: StepId) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentStep,
  completedSteps,
  visitedSteps,
  onNavigate,
}) => {
  const currentStepIndex = STEPS.findIndex((s) => s.id === currentStep);

  const isStepAccessible = (stepId: StepId, stepIndex: number) => {
    // Step is accessible if visited or completed or is the next immediate step after completed
    return visitedSteps.includes(stepId) || stepIndex <= currentStepIndex;
  };

  return (
    <header className="sticky top-0 z-50 bg-[#f9f9ff]/95 backdrop-blur-sm border-b border-[#c3c7cb]/30">
      <div className="w-full max-w-[1120px] mx-auto px-4 sm:px-6 h-18 sm:h-20 flex items-center justify-between gap-4">
        {/* Logo */}
        <div
          onClick={() => onNavigate('start')}
          className="flex items-center gap-2 sm:gap-2.5 shrink-0 min-w-fit cursor-pointer select-none group"
        >
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#e0f2fe] flex items-center justify-center text-[#50616b] shadow-sm group-hover:scale-105 transition-transform shrink-0">
            <Shield className="w-5 h-5 text-[#50616b]" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl md:text-2xl font-bold tracking-tight text-[#121c2a] whitespace-nowrap nowrap-ko">
              AI 사진·영상 대응실
            </h1>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-0.5 sm:gap-1.5 md:gap-2 overflow-x-auto no-scrollbar py-1 shrink">
          {STEPS.map((step, idx) => {
            const isActive = step.id === currentStep;
            const isCompleted = completedSteps.includes(step.id);
            const accessible = isStepAccessible(step.id, idx);

            return (
              <button
                key={step.id}
                type="button"
                disabled={!accessible}
                onClick={() => accessible && onNavigate(step.id)}
                className={`relative px-2 sm:px-3 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all whitespace-nowrap nowrap-ko flex items-center gap-1 sm:gap-1.5 ${
                  isActive
                    ? 'text-[#6d5e00] font-bold'
                    : accessible
                    ? 'text-[#43474b] hover:text-[#121c2a] hover:bg-[#eff3ff]/70 cursor-pointer'
                    : 'text-[#c3c7cb] cursor-not-allowed opacity-60'
                }`}
              >
                {isCompleted && !isActive && (
                  <span className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-[#e0f2fe] text-[#50616b] flex items-center justify-center text-[10px] font-bold shrink-0">
                    <Check className="w-2.5 h-2.5 sm:w-3 sm:h-3 stroke-[3]" />
                  </span>
                )}
                <span className="whitespace-nowrap nowrap-ko">{step.label}</span>
                {isActive && (
                  <span className="absolute bottom-0 left-1.5 right-1.5 sm:left-2 sm:right-2 h-1 bg-[#fcdf46] rounded-full shadow-sm" />
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Mini Progress Indicator for Activity Stages */}
      {currentStepIndex > 0 && currentStepIndex <= 3 && (
        <div className="w-full bg-[#eff3ff]/60 border-t border-[#c3c7cb]/20 py-2.5 px-6">
          <div className="max-w-[640px] mx-auto flex items-center justify-between text-xs font-semibold text-[#43474b]">
            {[1, 2, 3].map((actNum, i) => {
              const actStepId: StepId = `activity${actNum}` as StepId;
              const isPast = completedSteps.includes(actStepId) || currentStepIndex > actNum;
              const isCurrent = currentStep === actStepId;

              return (
                <React.Fragment key={actNum}>
                  <div
                    onClick={() => {
                      if (visitedSteps.includes(actStepId) || isPast || isCurrent) {
                        onNavigate(actStepId);
                      }
                    }}
                    className={`flex items-center gap-2 cursor-pointer transition-all ${
                      isCurrent
                        ? 'text-[#121c2a] font-bold'
                        : isPast
                        ? 'text-[#50616b]'
                        : 'text-[#c3c7cb]'
                    }`}
                  >
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                        isCurrent
                          ? 'bg-[#ffe24c] border-2 border-[#121c2a] text-[#211b00]'
                          : isPast
                          ? 'bg-[#e0f2fe] text-[#50616b]'
                          : 'bg-[#d9e3f7] text-[#73787b]'
                      }`}
                    >
                      {isPast ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : actNum}
                    </span>
                    <span>활동 {actNum}</span>
                  </div>
                  {i < 2 && (
                    <div
                      className={`flex-1 h-[2px] mx-4 transition-colors ${
                        currentStepIndex > i + 1 ? 'bg-[#50616b]' : 'bg-[#d9e3f7]'
                      }`}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
