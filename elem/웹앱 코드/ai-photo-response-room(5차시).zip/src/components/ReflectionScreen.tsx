import React, { useState } from 'react';
import { CheckCircle2, Home, RotateCcw } from 'lucide-react';

interface ReflectionProps {
  newLearnings: string;
  attitudeChange: string;
  onChangeNewLearnings: (val: string) => void;
  onChangeAttitudeChange: (val: string) => void;
  onResetAll: () => void;
}

export const ReflectionScreen: React.FC<ReflectionProps> = ({
  newLearnings,
  attitudeChange,
  onChangeNewLearnings,
  onChangeAttitudeChange,
  onResetAll,
}) => {
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  return (
    <div className="w-full max-w-[800px] mx-auto space-y-8 animate-fade-in pb-12">
      {/* Header */}
      <div className="text-center space-y-2">
        <span className="inline-block bg-[#e0f2fe] text-[#384953] px-4 py-1 rounded-full text-xs md:text-sm font-bold whitespace-nowrap nowrap-ko">
          돌아보기
        </span>
        <h1 className="text-2xl md:text-4xl font-extrabold text-[#121c2a] tracking-tight balance-ko">
          오늘의 활동을 돌아봐요
        </h1>
      </div>

      {/* Question 1 Card */}
      <section className="bg-[#eff3ff]/70 rounded-2xl p-6 md:p-8 soft-shadow border border-[#d9e3f7]">
        <h2 className="text-base md:text-lg font-bold text-[#121c2a] mb-3 leading-snug balance-ko">
          변형된 사진·영상의 확산과 대응에 대해 새롭게 알게 된 점은 무엇인가요?
        </h2>
        <textarea
          value={newLearnings}
          onChange={(e) => onChangeNewLearnings(e.target.value)}
          placeholder="새롭게 알게 된 점을 적어 보세요."
          className="w-full bg-white rounded-xl p-4 border border-[#c3c7cb]/60 focus:border-[#50616b] focus:ring-2 focus:ring-[#e0f2fe] outline-none text-sm md:text-base text-[#121c2a] transition-all resize-none h-28 placeholder:text-[#73787b]/70 keep-ko"
        />
      </section>

      {/* Question 2 Card */}
      <section className="bg-[#eff3ff]/70 rounded-2xl p-6 md:p-8 soft-shadow border border-[#d9e3f7]">
        <h2 className="text-base md:text-lg font-bold text-[#121c2a] mb-3 leading-snug balance-ko">
          사진이나 영상을 공유하고 받아들이는 나의 생각이나 태도는 어떻게 달라졌나요?
        </h2>
        <textarea
          value={attitudeChange}
          onChange={(e) => onChangeAttitudeChange(e.target.value)}
          placeholder="달라진 생각이나 태도를 적어 보세요."
          className="w-full bg-white rounded-xl p-4 border border-[#c3c7cb]/60 focus:border-[#50616b] focus:ring-2 focus:ring-[#e0f2fe] outline-none text-sm md:text-base text-[#121c2a] transition-all resize-none h-28 placeholder:text-[#73787b]/70 keep-ko"
        />
      </section>

      {/* Completion Banner */}
      <section className="bg-[#e0f2fe]/60 rounded-2xl p-8 md:p-10 border border-[#d0daef] text-center space-y-3 soft-shadow">
        <div className="w-14 h-14 rounded-full bg-white text-[#50616b] mx-auto flex items-center justify-center shadow-sm">
          <CheckCircle2 className="w-9 h-9 text-[#50616b]" />
        </div>
        <h3 className="text-xl md:text-2xl font-extrabold text-[#121c2a] balance-ko">
          딥페이크 대응 활동 완료!
        </h3>
        <p className="text-sm md:text-base text-[#50616b] font-medium balance-ko">
          "멈추고, 생각하고, 책임 있게 행동해요."
        </p>
      </section>

      {/* Home / Reset Button */}
      <div className="flex justify-center pt-2">
        <button
          type="button"
          onClick={() => setShowConfirmModal(true)}
          className="inline-flex items-center gap-2 bg-[#384953] hover:bg-[#121c2a] text-white font-bold text-sm md:text-base px-8 py-3.5 rounded-full shadow-sm hover-lift cursor-pointer transition-all active:scale-95 whitespace-nowrap nowrap-ko"
        >
          <Home className="w-4 h-4" />
          <span>처음으로</span>
        </button>
      </div>

      {/* Confirmation Modal for Reset */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl space-y-4 border border-[#c3c7cb]">
            <div className="flex items-center gap-2 text-[#ba1a1a]">
              <RotateCcw className="w-5 h-5" />
              <h4 className="font-bold text-base text-[#121c2a]">처음으로 돌아가기</h4>
            </div>
            <p className="text-sm text-[#50616b] leading-relaxed">
              활동을 처음부터 다시 시작할까요? 입력한 활동 데이터가 초기화되고 시작 화면으로 이동합니다.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 text-sm font-semibold text-[#50616b] hover:bg-[#eff3ff] rounded-lg transition-colors cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowConfirmModal(false);
                  onResetAll();
                }}
                className="px-5 py-2 text-sm font-bold text-white bg-[#ba1a1a] hover:bg-[#93000a] rounded-lg transition-colors cursor-pointer shadow-sm"
              >
                초기화 후 처음으로
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
