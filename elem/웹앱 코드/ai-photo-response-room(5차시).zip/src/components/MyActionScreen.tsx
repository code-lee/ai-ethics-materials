import React from 'react';
import { UserCheck, ArrowRight, Sparkles } from 'lucide-react';

interface MyActionProps {
  actionSentence: string;
  onChangeActionSentence: (val: string) => void;
  onNext: () => void;
}

export const MyActionScreen: React.FC<MyActionProps> = ({
  actionSentence,
  onChangeActionSentence,
  onNext,
}) => {
  const isValid = actionSentence.trim().length > 0;

  return (
    <div className="w-full max-w-[760px] mx-auto space-y-8 animate-fade-in pb-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <span className="inline-block bg-[#e0f2fe] text-[#384953] px-4 py-1 rounded-full text-xs md:text-sm font-bold whitespace-nowrap nowrap-ko">
          나의 대응
        </span>
        <h1 className="text-2xl md:text-4xl font-extrabold text-[#121c2a] tracking-tight balance-ko">
          나는 어떻게 행동할까요?
        </h1>
        <p className="text-sm md:text-base text-[#50616b] balance-ko">
          변형된 사진이나 영상을 만났을 때, 내가 실천할 다짐과 행동을 한 문장으로 적어 보세요.
        </p>
      </div>

      {/* Action Promise Card */}
      <section className="bg-white rounded-2xl p-6 md:p-10 soft-shadow border border-[#c3c7cb]/40 space-y-6">
        <div className="flex items-center gap-3 border-b border-[#c3c7cb]/30 pb-4">
          <div className="w-10 h-10 rounded-xl bg-[#e0f2fe] flex items-center justify-center text-[#50616b] shrink-0">
            <UserCheck className="w-6 h-6 text-[#50616b]" />
          </div>
          <div>
            <h2 className="text-lg md:text-xl font-bold text-[#121c2a] balance-ko">
              나의 실천 다짐 문장 만들기
            </h2>
            <p className="text-xs text-[#50616b]">
              내가 할 행동이 드러나도록 한 문장으로 적어 보세요.
            </p>
          </div>
        </div>

        {/* Natural Sentence Container */}
        <div className="bg-[#f9f9ff] rounded-2xl p-6 md:p-8 border border-[#c3c7cb]/50 space-y-4">
          <div className="text-base md:text-lg font-bold text-[#121c2a] flex items-center gap-2 balance-ko">
            <span className="w-2 h-2 rounded-full bg-[#50616b] shrink-0" />
            <span>AI로 변형된 사진이나 영상을 보게 되면</span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#50616b] whitespace-nowrap nowrap-ko">
              <span>나는</span>
            </div>
            <textarea
              value={actionSentence}
              onChange={(e) => onChangeActionSentence(e.target.value)}
              placeholder="내가 실천할 다짐과 행동을 적어 보세요."
              className="w-full bg-white rounded-xl p-4 border border-[#c3c7cb]/70 focus:border-[#50616b] focus:ring-2 focus:ring-[#e0f2fe] outline-none text-base md:text-lg text-[#121c2a] leading-relaxed transition-all resize-none h-32 placeholder:text-[#73787b]/60 keep-ko"
            />
          </div>
        </div>
      </section>

      {/* Next Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <div className="text-xs text-[#73787b]">
          {!isValid && (
            <span className="text-[#ba1a1a] font-medium keep-ko">
              * 나의 실천 다짐 문장을 작성해 주세요.
            </span>
          )}
        </div>
        <button
          type="button"
          disabled={!isValid}
          onClick={onNext}
          className={`inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full font-bold text-sm md:text-base transition-all shadow-sm whitespace-nowrap nowrap-ko ${
            isValid
              ? 'bg-[#ffe24c] hover:bg-[#fcdf46] text-[#211b00] hover-lift cursor-pointer shadow-[0_4px_14px_0_rgba(253,224,71,0.39)]'
              : 'bg-[#d9e3f7] text-[#73787b] cursor-not-allowed opacity-70'
          }`}
        >
          <span>다음: 오늘의 활동 돌아보기</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
