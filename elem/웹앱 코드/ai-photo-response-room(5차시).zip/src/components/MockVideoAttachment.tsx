import React from 'react';
import { Play, Volume2, Sparkles, Music } from 'lucide-react';

export const MockVideoAttachment: React.FC = () => {
  return (
    <div
      className="w-full max-w-[280px] bg-[#1e293b] rounded-2xl p-2.5 sm:p-3 text-white shadow-md border border-[#334155] transition-all"
      role="region"
      aria-label="AI로 목소리와 얼굴이 변형된 짧은 춤 영상 예시"
    >
      {/* Video Top Bar Info */}
      <div className="flex items-center justify-between px-1 mb-2 text-[10px] sm:text-[11px] font-medium text-slate-300">
        <div className="flex items-center gap-1.5 bg-red-500/20 text-red-400 px-2 py-0.5 rounded-full border border-red-500/30">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="font-bold tracking-wider">AI VIDEO</span>
        </div>
        <div className="flex items-center gap-1 bg-slate-800/80 px-2 py-0.5 rounded-full text-slate-300 font-mono text-[10px]">
          <span>0:05</span>
          <span className="text-slate-500">/ 0:15</span>
        </div>
      </div>

      {/* Main Video Viewport with CSS Dance Animation */}
      <div className="relative w-full aspect-[4/3] rounded-xl bg-gradient-to-b from-[#312e81] via-[#1e1b4b] to-[#0f172a] overflow-hidden flex items-center justify-center border border-indigo-500/30">
        {/* Floating Musical Notes Animation */}
        <div className="absolute top-3 left-4 text-indigo-300 text-xs select-none pointer-events-none animate-float-note-1">
          🎵
        </div>
        <div className="absolute top-5 right-5 text-pink-300 text-xs select-none pointer-events-none animate-float-note-2">
          🎶
        </div>
        <div className="absolute bottom-6 left-6 text-amber-300 text-[10px] select-none pointer-events-none">
          ✨
        </div>

        {/* Dancing Character Vector (AI Synthesized Mock Dance) */}
        <div className="relative w-28 h-28 flex items-end justify-center">
          <svg
            viewBox="0 0 120 120"
            className="w-full h-full select-none animate-dance-sway drop-shadow-[0_4px_10px_rgba(99,102,241,0.4)]"
          >
            <defs>
              <linearGradient id="dancerShirt" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#d97706" />
              </linearGradient>
              <linearGradient id="dancerSkin" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#fed7aa" />
                <stop offset="100%" stopColor="#fdba74" />
              </linearGradient>
              <linearGradient id="dancerPants" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#0284c7" />
              </linearGradient>
            </defs>

            {/* Stage Light Spotlight Effect */}
            <ellipse cx="60" cy="112" rx="36" ry="6" fill="#6366f1" opacity="0.25" />

            {/* Legs with rhythmic step */}
            <rect x="48" y="85" width="8" height="24" rx="4" fill="url(#dancerPants)" />
            <rect x="64" y="83" width="8" height="26" rx="4" fill="url(#dancerPants)" />
            {/* Shoes */}
            <ellipse cx="50" cy="110" rx="6" ry="3.5" fill="#f8fafc" />
            <ellipse cx="68" cy="110" rx="6" ry="3.5" fill="#f8fafc" />

            {/* Left Dancing Arm */}
            <g className="animate-dance-arm-l origin-[42px_60px]">
              <path
                d="M 42 62 Q 26 50 30 38"
                stroke="url(#dancerShirt)"
                strokeWidth="7"
                strokeLinecap="round"
                fill="none"
              />
              <circle cx="30" cy="38" r="4.5" fill="url(#dancerSkin)" />
            </g>

            {/* Right Dancing Arm */}
            <g className="animate-dance-arm-r origin-[78px_60px]">
              <path
                d="M 78 62 Q 94 50 90 38"
                stroke="url(#dancerShirt)"
                strokeWidth="7"
                strokeLinecap="round"
                fill="none"
              />
              <circle cx="90" cy="38" r="4.5" fill="url(#dancerSkin)" />
            </g>

            {/* Torso / Cool Hoodie */}
            <path
              d="M 42 58 C 42 58 50 56 60 56 C 70 56 78 58 78 58 L 76 88 C 76 88 68 90 60 90 C 52 90 44 88 44 88 Z"
              fill="url(#dancerShirt)"
            />
            {/* Hoodie strings */}
            <line x1="56" y1="60" x2="56" y2="72" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="64" y1="60" x2="64" y2="72" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />

            {/* Neck */}
            <rect x="54" y="48" width="12" height="10" rx="3" fill="url(#dancerSkin)" />

            {/* Head */}
            <circle cx="60" cy="38" r="18" fill="url(#dancerSkin)" />

            {/* AI Synthesized Hair */}
            <path
              d="M 42 36 Q 60 18 78 36 C 80 24 74 18 60 18 C 46 18 40 24 42 36 Z"
              fill="#1e293b"
            />
            {/* Bangs */}
            <path d="M 48 30 Q 56 36 62 30" stroke="#1e293b" strokeWidth="3" fill="none" strokeLinecap="round" />
            <path d="M 60 30 Q 68 36 73 31" stroke="#1e293b" strokeWidth="3" fill="none" strokeLinecap="round" />

            {/* Sparkly Fun Sunglasses (AI Stage Prop) */}
            <rect x="47" y="32" width="11" height="8" rx="2" fill="#ec4899" stroke="#be185d" strokeWidth="1" />
            <rect x="62" y="32" width="11" height="8" rx="2" fill="#ec4899" stroke="#be185d" strokeWidth="1" />
            <line x1="58" y1="36" x2="62" y2="36" stroke="#be185d" strokeWidth="2" />
            {/* Glasses highlight */}
            <line x1="49" y1="34" x2="52" y2="38" stroke="#fbcfe8" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="64" y1="34" x2="67" y2="38" stroke="#fbcfe8" strokeWidth="1.5" strokeLinecap="round" />

            {/* Cheerful Singing Smile */}
            <path d="M 54 44 Q 60 52 66 44" fill="#991b1b" />
            {/* White Teeth */}
            <path d="M 56 45 Q 60 48 64 45" fill="#ffffff" />
          </svg>
        </div>

        {/* Sound Equalizer & AI Music Tag Overlay */}
        <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1.5 bg-black/60 backdrop-blur-xs px-2 py-1 rounded-md border border-white/10 text-[10px] text-indigo-200">
          <div className="flex items-end gap-0.5 h-3">
            <span className="w-1 bg-indigo-400 rounded-full animate-music-bar-1" />
            <span className="w-1 bg-pink-400 rounded-full animate-music-bar-2" />
            <span className="w-1 bg-amber-400 rounded-full animate-music-bar-3" />
          </div>
          <span className="font-semibold truncate max-w-[110px]">AI Voice Beat 🎶</span>
        </div>

        {/* Autoplay Loop Pill Indicator */}
        <div className="absolute top-2.5 right-2.5 bg-indigo-500/80 backdrop-blur-xs text-white text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 shadow-xs">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <span>재생 중</span>
        </div>
      </div>

      {/* Description Text Under Video */}
      <div className="mt-2 text-center">
        <p className="text-[11px] sm:text-xs font-semibold text-slate-300 leading-tight">
          (AI로 목소리와 얼굴이 변형된 짧은 춤 영상)
        </p>
      </div>
    </div>
  );
};
