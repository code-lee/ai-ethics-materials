import React from 'react';
import {
  Sparkles,
  Send,
  MessageSquare,
  Share2,
  Check,
  User,
  Users,
  School,
  HeartHandshake,
  BookOpen,
  ArrowRight,
} from 'lucide-react';

interface Activity1Props {
  damagePoints: number[];
  affectedTargets: string[];
  impactThought: string;
  showConceptCard: boolean;
  onToggleDamagePoint: (point: number) => void;
  onToggleAffectedTarget: (target: string) => void;
  onChangeImpactThought: (thought: string) => void;
  onShowConceptCard: () => void;
  onNext: () => void;
}

export const Activity1Screen: React.FC<Activity1Props> = ({
  damagePoints,
  affectedTargets,
  impactThought,
  showConceptCard,
  onToggleDamagePoint,
  onToggleAffectedTarget,
  onChangeImpactThought,
  onShowConceptCard,
  onNext,
}) => {
  const steps = [
    {
      num: 1,
      title: '1. AI로 사진이 변형됨',
      desc: '생성형 AI 기술로 친구의 얼굴이나 모습을 다르게 바꿈',
      icon: Sparkles,
    },
    {
      num: 2,
      title: '2. 친구에게 전달됨',
      desc: '장난 삼아 1:1 대화방 등으로 친구에게 처음 보냄',
      icon: Send,
    },
    {
      num: 3,
      title: '3. 단체 대화방에 공유됨',
      desc: '많은 친구들이 있는 단체 대화방에 사진이 올라옴',
      icon: MessageSquare,
    },
    {
      num: 4,
      title: '4. 다른 사람에게 다시 공유됨',
      desc: '다른 반 친구나 SNS 등 외부로 사진이 다시 퍼져 나감',
      icon: Share2,
    },
  ];

  const targets = [
    { id: '사진 속 사람', label: '사진 속 사람 (당사자)', icon: User },
    { id: '친구들', label: '친구들', icon: Users },
    { id: '우리 반', label: '우리 반', icon: School },
    { id: '가족', label: '가족', icon: HeartHandshake },
  ];

  const hasSelections = damagePoints.length >= 1 && affectedTargets.length >= 1;
  const hasImpactThought = impactThought.trim().length > 0;
  const canShowConcept = hasSelections && hasImpactThought;
  const isValid = hasSelections && hasImpactThought && showConceptCard;

  return (
    <div className="w-full max-w-[960px] mx-auto space-y-8 animate-fade-in pb-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <span className="inline-block bg-[#e0f2fe] text-[#384953] px-4 py-1 rounded-full text-xs md:text-sm font-bold whitespace-nowrap nowrap-ko">
          활동 1
        </span>
        <h1 className="text-2xl md:text-4xl font-extrabold text-[#121c2a] tracking-tight balance-ko">
          변형 사진·영상의 확산과 영향 살펴보기
        </h1>
        <p className="text-sm md:text-base text-[#50616b] balance-ko">
          사진이 퍼지는 과정을 살펴보고, 피해가 발생하거나 커지는 지점을 생각해 보세요.
        </p>
      </div>

      {/* Section 1: Diffusion Stages & Damage Point Selection */}
      <section className="bg-white rounded-2xl p-6 md:p-8 soft-shadow border border-[#c3c7cb]/40">
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-[#50616b] shrink-0" />
            <h2 className="text-lg md:text-xl font-bold text-[#121c2a] balance-ko">
              피해가 생기거나 커진다고 생각하는 지점을 선택해 보세요.
            </h2>
          </div>
          <p className="text-xs md:text-sm text-[#50616b] ml-4.5">
            자유롭게 생각되는 지점을 하나 이상 선택할 수 있어요.
          </p>
        </div>

        {/* 4 Steps Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map((step) => {
            const isSelected = damagePoints.includes(step.num);
            const Icon = step.icon;

            return (
              <div
                key={step.num}
                onClick={() => onToggleDamagePoint(step.num)}
                className={`relative rounded-xl p-5 border-2 transition-all cursor-pointer flex flex-col justify-between select-none ${
                  isSelected
                    ? 'border-[#50616b] bg-[#e0f2fe]/40 shadow-sm scale-[1.02]'
                    : 'border-[#c3c7cb]/60 bg-[#f9f9ff] hover:border-[#50616b]/40 hover:bg-[#eff3ff]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div
                      className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                        isSelected ? 'bg-[#50616b] text-white' : 'bg-[#d9e3f7] text-[#50616b]'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>

                    <div
                      className={`w-6 h-6 rounded-full border flex items-center justify-center transition-colors shrink-0 ${
                        isSelected
                          ? 'border-[#50616b] bg-[#50616b] text-white'
                          : 'border-[#c3c7cb] bg-white text-transparent'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                  </div>

                  <h3 className="font-bold text-sm md:text-base text-[#121c2a] mb-1 balance-ko">
                    {step.title}
                  </h3>
                  <p className="text-xs text-[#50616b] leading-relaxed keep-ko">
                    {step.desc}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#c3c7cb]/20 text-[11px] font-semibold text-[#50616b] flex items-center gap-1 whitespace-nowrap nowrap-ko">
                  {isSelected ? (
                    <span className="text-[#0c1e26] font-bold">✓ 선택된 지점</span>
                  ) : (
                    <span>클릭하여 선택</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Section 2: Affected Targets Selection */}
      <section className="bg-white rounded-2xl p-6 md:p-8 soft-shadow border border-[#c3c7cb]/40">
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-[#50616b] shrink-0" />
            <h2 className="text-lg md:text-xl font-bold text-[#121c2a] balance-ko">
              자료가 퍼지면 누구에게 영향을 줄 수 있을까요?
            </h2>
          </div>
          <p className="text-xs md:text-sm text-[#50616b] ml-4.5">
            영향을 받을 수 있다고 생각되는 사람을 모두 골라 보세요.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 mb-6">
          {targets.map((t) => {
            const isSelected = affectedTargets.includes(t.id);
            const Icon = t.icon;

            return (
              <button
                key={t.id}
                type="button"
                onClick={() => onToggleAffectedTarget(t.id)}
                className={`p-4 rounded-xl border-2 flex flex-col items-center justify-center gap-2 text-center transition-all cursor-pointer ${
                  isSelected
                    ? 'border-[#50616b] bg-[#e0f2fe]/40 text-[#121c2a] font-bold shadow-sm'
                    : 'border-[#c3c7cb]/60 bg-[#f9f9ff] text-[#43474b] hover:bg-[#eff3ff]'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-[#50616b] text-white' : 'bg-[#d9e3f7] text-[#50616b]'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-sm font-semibold whitespace-nowrap nowrap-ko">{t.label}</span>
                {isSelected && (
                  <span className="text-[11px] font-bold text-[#50616b] flex items-center gap-0.5 whitespace-nowrap nowrap-ko">
                    <Check className="w-3 h-3 stroke-[3]" /> 선택됨
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Section 3: Thoughts (No Example Answers) */}
        <div className="pt-4 border-t border-[#c3c7cb]/30">
          <label className="block text-sm md:text-base font-bold text-[#121c2a] mb-2 balance-ko">
            어떤 영향이 생길 수 있을까요?
          </label>
          <textarea
            value={impactThought}
            onChange={(e) => onChangeImpactThought(e.target.value)}
            placeholder="생길 수 있는 영향을 적어 보세요."
            className="w-full bg-[#f9f9ff] rounded-xl p-3.5 border border-[#c3c7cb]/60 focus:border-[#50616b] focus:bg-white focus:ring-2 focus:ring-[#e0f2fe] outline-none text-sm md:text-base text-[#121c2a] transition-all resize-none h-24 placeholder:text-[#73787b]/70 keep-ko"
          />
        </div>
      </section>

      {/* Section 4: Concept Card (Only shown after clicking button) */}
      {!showConceptCard ? (
        <div className="text-center py-2">
          <button
            type="button"
            disabled={!canShowConcept}
            onClick={onShowConceptCard}
            className={`inline-flex items-center gap-2 px-6 py-3 rounded-full font-bold text-sm md:text-base transition-all whitespace-nowrap nowrap-ko ${
              canShowConcept
                ? 'bg-[#384953] hover:bg-[#121c2a] text-white cursor-pointer shadow-sm hover-lift'
                : 'bg-[#d9e3f7] text-[#73787b] cursor-not-allowed opacity-70'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>개념 정리 보기</span>
          </button>
          {!canShowConcept && (
            <p className="text-xs text-[#73787b] mt-2">
              * 피해 지점과 영향 대상을 선택하고 영향을 작성하면 개념 정리를 열어 볼 수 있어요.
            </p>
          )}
        </div>
      ) : (
        <section className="bg-[#e0f2fe]/40 rounded-2xl p-6 md:p-7 border border-[#d0daef] flex items-start gap-4 animate-fade-in soft-shadow">
          <div className="w-11 h-11 rounded-xl bg-white text-[#50616b] flex items-center justify-center shrink-0 shadow-sm mt-0.5">
            <BookOpen className="w-6 h-6 text-[#50616b]" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#50616b] bg-white px-2.5 py-0.5 rounded-full border border-[#d0daef] whitespace-nowrap nowrap-ko">
                개념 정리
              </span>
              <h3 className="font-extrabold text-base md:text-lg text-[#121c2a] whitespace-nowrap nowrap-ko">
                딥페이크란?
              </h3>
            </div>
            <p className="text-sm md:text-base text-[#384953] leading-relaxed keep-ko">
              딥페이크는 AI를 이용해 실제 사람의 모습이나 목소리 등을 진짜처럼 보이거나 들리게 바꾼 사진·영상·음성을 말해요.
              <br />
              이렇게 만든 자료를 다른 사람을 속이거나 놀리기 위해 사용하거나 퍼뜨리면 피해가 생길 수 있어요.
            </p>
          </div>
        </section>
      )}

      {/* Next Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <div className="text-xs text-[#73787b]">
          {!isValid && (
            <span className="text-[#ba1a1a] font-medium keep-ko">
              * 피해 지점과 영향 대상을 선택하고, 영향을 작성한 뒤 [개념 정리 보기]를 확인해 주세요.
            </span>
          )}
        </div>
        <button
          type="button"
          disabled={!isValid}
          onClick={onNext}
          className={`inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full font-bold text-sm md:text-base transition-all shadow-sm whitespace-nowrap nowrap-ko ${
            isValid
              ? 'bg-[#ffe24c] hover:bg-[#fcdf46] text-[#211b00] hover-lift cursor-pointer shadow-[0_4px_14px_0_rgba(253,224,71,0.39)]'
              : 'bg-[#d9e3f7] text-[#73787b] cursor-not-allowed opacity-70'
          }`}
        >
          <span>다음: 멈추는 시점에 따른 결과 비교하기</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
