import React from 'react';
import { Users, Share2, ArrowRight } from 'lucide-react';
import { MockPhotoAttachment } from './MockPhotoAttachment';

interface StartScreenProps {
  startConcern: string;
  onChangeConcern: (val: string) => void;
  onNext: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  startConcern,
  onChangeConcern,
  onNext,
}) => {
  return (
    <div className="w-full max-w-[720px] mx-auto flex flex-col items-center animate-fade-in">
      {/* Title Section */}
      <div className="text-center mb-8">
        <span className="inline-block bg-[#e0f2fe] text-[#384953] px-4 py-1 rounded-full text-xs md:text-sm font-bold tracking-tight mb-3 whitespace-nowrap nowrap-ko">
          시작 화면
        </span>
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-[#121c2a] tracking-tight mb-2 balance-ko">
          AI 사진·영상 대응실
        </h1>
        <h2 className="text-lg md:text-xl font-medium text-[#50616b] balance-ko">
          사진과 영상이 달라졌어요
        </h2>
      </div>

      {/* Simulated Chat UI */}
      <div className="w-full bg-white rounded-2xl p-5 sm:p-6 soft-shadow border border-[#c3c7cb]/40 mb-8">
        {/* Chat Room Top Bar */}
        <div className="flex items-center gap-2.5 border-b border-[#c3c7cb]/30 pb-3.5 mb-5 text-[#121c2a]">
          <div className="w-8 h-8 rounded-full bg-[#e0f2fe] flex items-center justify-center text-[#50616b]">
            <Users className="w-4 h-4" />
          </div>
          <span className="font-bold text-sm md:text-base">친구들 (4)</span>
        </div>

        {/* Chat Bubbles */}
        <div className="space-y-4">
          {/* Chat 1 - Friend A */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-full bg-[#d9e3f7] flex items-center justify-center text-sm font-bold text-[#384953] shrink-0">
              A
            </div>
            <div className="bg-[#eff3ff] p-3.5 rounded-2xl rounded-tl-sm max-w-[88%] border border-[#d9e3f7]/50">
              <p className="text-sm md:text-base text-[#121c2a] font-medium mb-3">
                야, 이거 봐! 대박이지?
              </p>
              <MockPhotoAttachment />
            </div>
          </div>

          {/* Chat 2 - Friend B */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-full bg-[#d9e3f7] flex items-center justify-center text-sm font-bold text-[#384953] shrink-0">
              B
            </div>
            <div className="bg-[#eff3ff] px-4 py-2.5 rounded-2xl rounded-tl-sm border border-[#d9e3f7]/50">
              <p className="text-sm md:text-base text-[#121c2a] font-medium">
                헐 진짜 웃기다 ㅋㅋㅋ
              </p>
            </div>
          </div>

          {/* Chat 3 - Friend C */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-full bg-[#d9e3f7] flex items-center justify-center text-sm font-bold text-[#384953] shrink-0">
              C
            </div>
            <div className="bg-[#eff3ff] px-4 py-2.5 rounded-2xl rounded-tl-sm border border-[#d9e3f7]/50">
              <p className="text-sm md:text-base text-[#121c2a] font-medium">
                다른 애들한테도 보내줘야지
              </p>
            </div>
          </div>

          {/* Chat 4 - Friend D */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-full bg-[#d9e3f7] flex items-center justify-center text-sm font-bold text-[#384953] shrink-0">
              D
            </div>
            <div className="bg-[#eff3ff] p-3 rounded-2xl rounded-tl-sm border border-[#d9e3f7]/50 max-w-[88%]">
              <div className="flex items-center gap-1.5 text-xs text-[#50616b] font-medium mb-2">
                <Share2 className="w-3.5 h-3.5 text-[#50616b]" />
                <span>다른 단체 대화방으로 전달</span>
              </div>
              <MockPhotoAttachment compact />
            </div>
          </div>
        </div>
      </div>

      {/* Question & Input Area */}
      <div className="w-full bg-[#e0f2fe]/30 rounded-2xl p-6 md:p-8 border border-[#e0f2fe] soft-shadow text-center">
        <h3 className="text-lg md:text-xl font-bold text-[#121c2a] mb-2 balance-ko">
          이 상황에서 어떤 점이 걱정되나요?
        </h3>
        <p className="text-xs md:text-sm text-[#50616b] mb-4 balance-ko">
          자유롭게 나의 생각이나 걱정되는 점을 적어 보세요.
        </p>

        <textarea
          value={startConcern}
          onChange={(e) => onChangeConcern(e.target.value)}
          placeholder="생각이나 걱정되는 점을 적어 보세요."
          className="w-full bg-white rounded-xl p-3.5 border border-[#c3c7cb]/60 focus:border-[#50616b] focus:ring-2 focus:ring-[#e0f2fe] outline-none text-sm md:text-base text-[#121c2a] transition-all resize-none h-24 mb-6 placeholder:text-[#73787b]/70 keep-ko"
        />

        <button
          type="button"
          onClick={onNext}
          className="inline-flex items-center justify-center gap-2 bg-[#ffe24c] hover:bg-[#fcdf46] text-[#211b00] font-bold text-base md:text-lg px-8 md:px-12 py-3.5 rounded-full shadow-[0_4px_14px_0_rgba(253,224,71,0.39)] hover-lift cursor-pointer transition-all active:scale-95 whitespace-nowrap nowrap-ko"
        >
          <span>활동 시작하기</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
