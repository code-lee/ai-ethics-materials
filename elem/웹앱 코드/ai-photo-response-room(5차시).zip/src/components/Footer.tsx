import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-auto border-t border-[#c3c7cb]/40 bg-[#eff3ff]/50">
      <div className="w-full max-w-[1120px] mx-auto px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs md:text-sm text-[#50616b]">
        <div className="font-semibold">
          © 2026 AI Ethics Education. All rights reserved.
        </div>
        <div className="flex items-center gap-4 text-[#73787b]">
          <span className="hover:text-[#121c2a] cursor-default transition-colors">도움말</span>
          <span>•</span>
          <span className="hover:text-[#121c2a] cursor-default transition-colors">개인정보처리방침</span>
        </div>
      </div>
    </footer>
  );
};
