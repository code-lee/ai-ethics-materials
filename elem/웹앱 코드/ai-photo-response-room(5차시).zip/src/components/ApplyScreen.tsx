import React from 'react';
import {
  Users,
  MessageCircle,
  MessageSquare,
  Activity,
  ArrowRight,
  HelpCircle,
} from 'lucide-react';
import { MockVideoAttachment } from './MockVideoAttachment';

interface ApplyProps {
  howToApply: string;
  groupMethod: string;
  actualSpeech: string;
  actualAction: string;
  onChangeHowToApply: (val: string) => void;
  onChangeActualSpeech: (val: string) => void;
  onChangeActualAction: (val: string) => void;
  onNext: () => void;
}

export const ApplyScreen: React.FC<ApplyProps> = ({
  howToApply,
  groupMethod,
  actualSpeech,
  actualAction,
  onChangeHowToApply,
  onChangeActualSpeech,
  onChangeActualAction,
  onNext,
}) => {
  const isValid =
    howToApply.trim().length > 0 &&
    actualSpeech.trim().length > 0 &&
    actualAction.trim().length > 0;

  return (
    <div className="w-full max-w-[860px] mx-auto space-y-8 animate-fade-in pb-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <span className="inline-block bg-[#e0f2fe] text-[#384953] px-4 py-1 rounded-full text-xs md:text-sm font-bold whitespace-nowrap nowrap-ko">
          적용하기
        </span>
        <h1 className="text-2xl md:text-4xl font-extrabold text-[#121c2a] tracking-tight balance-ko">
          새로운 상황에서는 어떻게 해 볼까요?
        </h1>
        <p className="text-sm md:text-base text-[#50616b] balance-ko">
          앞에서 만든 모둠의 대응 방법을 바탕으로, 이 상황에서 내가 실제로 할 말과 행동을 정해 보세요.
        </p>
      </div>

      {/* 1. New Virtual Scenario Card */}
      <section className="bg-white rounded-2xl p-6 md:p-8 soft-shadow border border-[#c3c7cb]/40 space-y-6">
        <div className="flex items-center gap-2 text-xs md:text-sm font-bold text-[#50616b]">
          <MessageCircle className="w-4 h-4 text-[#50616b]" />
          <span>새로운 가상 단체 대화방 상황</span>
        </div>

        {/* Chat UI */}
        <div className="bg-[#f9f9ff] rounded-xl p-5 border border-[#c3c7cb]/40 space-y-3.5">
          <div className="flex items-center gap-2 border-b border-[#c3c7cb]/30 pb-2.5 text-xs font-bold text-[#50616b]">
            <Users className="w-3.5 h-3.5" />
            <span>동아리 단체 대화방 (5)</span>
          </div>

          <div className="space-y-3 text-sm">
            {/* Friend 1 */}
            <div className="flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-full bg-[#d9e3f7] flex items-center justify-center text-xs font-bold text-[#384953] shrink-0">
                민수
              </div>
              <div className="bg-[#eff3ff] p-3.5 rounded-2xl rounded-tl-none max-w-[88%] border border-[#d9e3f7]/50">
                <p className="text-[#121c2a] mb-3 font-medium text-xs sm:text-sm">
                  얘들아 이거 봐봐! AI로 영호 목소리랑 춤추는 모습 합성했는데 대박 웃겨 ㅋㅋㅋ
                </p>
                <MockVideoAttachment />
              </div>
            </div>

            {/* Friend 2 */}
            <div className="flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-full bg-[#d9e3f7] flex items-center justify-center text-xs font-bold text-[#384953] shrink-0">
                서연
              </div>
              <div className="bg-[#eff3ff] px-3.5 py-2 rounded-2xl rounded-tl-none border border-[#d9e3f7]/50">
                <p className="text-[#121c2a]">ㅋㅋㅋ 진짜 영호가 춘 줄 알았네</p>
              </div>
            </div>

            {/* Friend 3 */}
            <div className="flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-full bg-[#d9e3f7] flex items-center justify-center text-xs font-bold text-[#384953] shrink-0">
                준우
              </div>
              <div className="bg-[#eff3ff] px-3.5 py-2 rounded-2xl rounded-tl-none border border-[#d9e3f7]/50">
                <p className="text-[#121c2a]">이거 다른 반 애들 단톡방에도 공유해볼까?</p>
              </div>
            </div>
          </div>
        </div>

        <p className="text-xs text-[#50616b] leading-relaxed">
          * 친구가 만든 변형 영상이 다른 단체 대화방으로 더 퍼지기 직전인 상황입니다.
        </p>
      </section>

      {/* 2. Reference Card: Group Method from Activity 3 */}
      <section className="bg-[#e0f2fe]/40 rounded-2xl p-5 md:p-6 border border-[#d0daef] soft-shadow">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-7 h-7 rounded-lg bg-[#50616b] flex items-center justify-center text-white shrink-0">
            <Users className="w-4 h-4" />
          </div>
          <h2 className="text-sm md:text-base font-bold text-[#121c2a] balance-ko">
            앞에서 만든 우리 모둠의 대응 방법
          </h2>
        </div>
        <div className="bg-white rounded-xl p-4 border border-[#c3c7cb]/40">
          <p className="text-sm md:text-base font-medium text-[#121c2a] leading-relaxed keep-ko">
            {groupMethod.trim().length > 0
              ? `"${groupMethod}"`
              : '(앞 단계에서 작성된 모둠 대응 방법이 없습니다)'}
          </p>
        </div>
      </section>

      {/* 3. Concrete Action & Speech Execution Section */}
      <section className="bg-white rounded-2xl p-6 md:p-8 soft-shadow border border-[#c3c7cb]/40 space-y-6">
        {/* Question: How to utilize previous group method in this situation */}
        <div className="space-y-2">
          <label className="block text-sm md:text-base font-bold text-[#121c2a] flex items-center gap-2 balance-ko">
            <HelpCircle className="w-4 h-4 text-[#50616b] shrink-0" />
            <span>이번 상황에서는 앞에서 만든 대응 방법을 어떻게 활용하면 좋을까요?</span>
          </label>
          <textarea
            value={howToApply}
            onChange={(e) => onChangeHowToApply(e.target.value)}
            placeholder="이번 상황에 맞게 어떻게 활용할지 적어 보세요."
            className="w-full bg-[#f9f9ff] rounded-xl p-3.5 border border-[#c3c7cb]/60 focus:border-[#50616b] focus:bg-white focus:ring-2 focus:ring-[#e0f2fe] outline-none text-sm md:text-base text-[#121c2a] transition-all resize-none h-24 placeholder:text-[#73787b]/70 keep-ko"
          />
        </div>

        {/* Actual Speech */}
        <div className="space-y-2">
          <label className="block text-sm md:text-base font-bold text-[#121c2a] flex items-center gap-2 balance-ko">
            <MessageSquare className="w-4 h-4 text-[#50616b] shrink-0" />
            <span>이 단체 대화방에서 나는 뭐라고 말할까요?</span>
          </label>
          <textarea
            value={actualSpeech}
            onChange={(e) => onChangeActualSpeech(e.target.value)}
            placeholder="실제로 보낼 말을 적어 보세요."
            className="w-full bg-[#f9f9ff] rounded-xl p-3.5 border border-[#c3c7cb]/60 focus:border-[#50616b] focus:bg-white focus:ring-2 focus:ring-[#e0f2fe] outline-none text-sm md:text-base text-[#121c2a] transition-all resize-none h-24 placeholder:text-[#73787b]/70 keep-ko"
          />
        </div>

        {/* Actual Action */}
        <div className="space-y-2">
          <label className="block text-sm md:text-base font-bold text-[#121c2a] flex items-center gap-2 balance-ko">
            <Activity className="w-4 h-4 text-[#50616b] shrink-0" />
            <span>이 상황에서 나는 어떤 행동을 할까요?</span>
          </label>
          <textarea
            value={actualAction}
            onChange={(e) => onChangeActualAction(e.target.value)}
            placeholder="내가 실제로 할 행동을 적어 보세요."
            className="w-full bg-[#f9f9ff] rounded-xl p-3.5 border border-[#c3c7cb]/60 focus:border-[#50616b] focus:bg-white focus:ring-2 focus:ring-[#e0f2fe] outline-none text-sm md:text-base text-[#121c2a] transition-all resize-none h-24 placeholder:text-[#73787b]/70 keep-ko"
          />
        </div>
      </section>

      {/* Next Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <div className="text-xs text-[#73787b]">
          {!isValid && (
            <span className="text-[#ba1a1a] font-medium keep-ko">
              * 대응 방법 활용 방안과 내가 보낼 말, 실제로 할 행동을 모두 작성해 주세요.
            </span>
          )}
        </div>
        <button
          type="button"
          disabled={!isValid}
          onClick={onNext}
          className={`inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full font-bold text-sm md:text-base transition-all shadow-sm whitespace-nowrap nowrap-ko ${
            isValid
              ? 'bg-[#ffe24c] hover:bg-[#fcdf46] text-[#211b00] hover-lift cursor-pointer shadow-[0_4px_14px_0_rgba(253,224,71,0.39)]'
              : 'bg-[#d9e3f7] text-[#73787b] cursor-not-allowed opacity-70'
          }`}
        >
          <span>다음: 나의 대응</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
