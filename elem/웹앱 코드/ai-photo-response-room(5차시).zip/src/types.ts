export type StepId =
  | 'start'
  | 'activity1'
  | 'activity2'
  | 'activity3'
  | 'apply'
  | 'my_action'
  | 'reflection';

export interface StepInfo {
  id: StepId;
  label: string;
  badge: string;
  order: number;
}

export interface IdeaItem {
  id: string;
  title: string;
  text: string;
  checkSpread?: 'yes' | 'rethink' | null;
  checkFeasible?: 'yes' | 'rethink' | null;
  revisedText?: string;
}

export interface AppState {
  currentStep: StepId;
  completedSteps: StepId[];
  visitedSteps: StepId[];
  // 1. Start
  startConcern: string;
  // 2. Activity 1
  activity1: {
    selectedDamagePoints: number[];
    selectedAffectedTargets: string[];
    impactThought: string;
    showConceptCard: boolean;
  };
  // 3. Activity 2 (Comparing results based on stopping timing)
  activity2: {
    currentSituation: 1 | 2;
    situation1View: 'continue' | 'stop' | null;
    situation2View: 'continue' | 'stop' | null;
    situation1ViewedContinue: boolean;
    situation1ViewedStop: boolean;
    situation2ViewedContinue: boolean;
    situation2ViewedStop: boolean;
    differenceThought: string;
    whyStopNeeded: string;
  };
  // 4. Activity 3
  activity3: {
    ideas: IdeaItem[];
    groupMethod: string;
    groupMethodReason: string;
  };
  // 5. Apply
  apply: {
    howToApply: string;
    differentPoint?: string;
    actualSpeech: string;
    actualAction: string;
  };
  // 6. My Action
  myAction: {
    actionSentence: string;
  };
  // 7. Reflection
  reflection: {
    newLearnings: string;
    attitudeChange: string;
  };
}

export const STEPS: StepInfo[] = [
  { id: 'start', label: '시작', badge: '시작 화면', order: 0 },
  { id: 'activity1', label: '활동 1', badge: '활동 1', order: 1 },
  { id: 'activity2', label: '활동 2', badge: '활동 2', order: 2 },
  { id: 'activity3', label: '활동 3', badge: '활동 3', order: 3 },
  { id: 'apply', label: '적용하기', badge: '적용하기', order: 4 },
  { id: 'my_action', label: '나의 대응', badge: '나의 대응', order: 5 },
  { id: 'reflection', label: '돌아보기', badge: '돌아보기', order: 6 },
];

export const INITIAL_APP_STATE: AppState = {
  currentStep: 'start',
  completedSteps: [],
  visitedSteps: ['start'],
  startConcern: '',
  activity1: {
    selectedDamagePoints: [],
    selectedAffectedTargets: [],
    impactThought: '',
    showConceptCard: false,
  },
  activity2: {
    currentSituation: 1,
    situation1View: null,
    situation2View: null,
    situation1ViewedContinue: false,
    situation1ViewedStop: false,
    situation2ViewedContinue: false,
    situation2ViewedStop: false,
    differenceThought: '',
    whyStopNeeded: '',
  },
  activity3: {
    ideas: [
      { id: 'idea-1', title: '아이디어 1', text: '' },
      { id: 'idea-2', title: '아이디어 2', text: '' },
    ],
    groupMethod: '',
    groupMethodReason: '',
  },
  apply: {
    howToApply: '',
    differentPoint: '',
    actualSpeech: '',
    actualAction: '',
  },
  myAction: {
    actionSentence: '',
  },
  reflection: {
    newLearnings: '',
    attitudeChange: '',
  },
};
