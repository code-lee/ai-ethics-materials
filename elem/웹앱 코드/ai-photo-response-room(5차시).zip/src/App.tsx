import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { StartScreen } from './components/StartScreen';
import { Activity1Screen } from './components/Activity1Screen';
import { Activity2Screen } from './components/Activity2Screen';
import { Activity3Screen } from './components/Activity3Screen';
import { ApplyScreen } from './components/ApplyScreen';
import { MyActionScreen } from './components/MyActionScreen';
import { ReflectionScreen } from './components/ReflectionScreen';
import { AppState, INITIAL_APP_STATE, StepId } from './types';

const STORAGE_KEY = 'ai_media_ethics_state_v2';

export default function App() {
  const [state, setState] = useState<AppState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_APP_STATE,
          ...parsed,
          activity2: {
            ...INITIAL_APP_STATE.activity2,
            ...(parsed.activity2 || {}),
            currentSituation:
              parsed.activity2?.currentSituation === 2 &&
              !!parsed.activity2?.situation1ViewedContinue &&
              !!parsed.activity2?.situation1ViewedStop
                ? 2
                : 1,
            situation1View:
              parsed.activity2?.situation1View === 'stop' || parsed.activity2?.situation1View === 'continue'
                ? parsed.activity2.situation1View
                : null,
            situation2View:
              parsed.activity2?.situation2View === 'stop' || parsed.activity2?.situation2View === 'continue'
                ? parsed.activity2.situation2View
                : null,
            situation1ViewedContinue: !!parsed.activity2?.situation1ViewedContinue,
            situation1ViewedStop: !!parsed.activity2?.situation1ViewedStop,
            situation2ViewedContinue: !!parsed.activity2?.situation2ViewedContinue,
            situation2ViewedStop: !!parsed.activity2?.situation2ViewedStop,
            differenceThought: parsed.activity2?.differenceThought || parsed.activity2?.comparisonAnswer || '',
            whyStopNeeded: parsed.activity2?.whyStopNeeded || parsed.activity2?.lateStopReason || '',
          },
          activity3: {
            ...INITIAL_APP_STATE.activity3,
            ...(parsed.activity3 || {}),
          },
          apply: {
            ...INITIAL_APP_STATE.apply,
            ...(parsed.apply || {}),
            howToApply: parsed.apply?.howToApply || parsed.apply?.differentPoint || '',
          },
        };
      }
    } catch (e) {
      console.error('Failed to load state from localStorage:', e);
    }
    return INITIAL_APP_STATE;
  });

  // Sync state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.error('Failed to save state to localStorage:', e);
    }
  }, [state]);

  // Navigate to a specific step
  const navigateToStep = (targetStep: StepId) => {
    setState((prev) => ({
      ...prev,
      currentStep: targetStep,
      visitedSteps: prev.visitedSteps.includes(targetStep)
        ? prev.visitedSteps
        : [...prev.visitedSteps, targetStep],
    }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Complete current step and move to next
  const handleProceedToNext = (nextStep: StepId) => {
    setState((prev) => {
      const isCompleted = prev.completedSteps.includes(prev.currentStep);
      const newCompleted = isCompleted
        ? prev.completedSteps
        : [...prev.completedSteps, prev.currentStep];
      const isVisited = prev.visitedSteps.includes(nextStep);
      const newVisited = isVisited ? prev.visitedSteps : [...prev.visitedSteps, nextStep];

      return {
        ...prev,
        currentStep: nextStep,
        completedSteps: newCompleted,
        visitedSteps: newVisited,
      };
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Reset all state and clear localStorage
  const handleResetAll = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.error('Failed to remove state from localStorage:', e);
    }
    setState(INITIAL_APP_STATE);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Activity 1 Handlers
  const handleToggleDamagePoint = (point: number) => {
    setState((prev) => {
      const current = prev.activity1.selectedDamagePoints;
      const next = current.includes(point)
        ? current.filter((p) => p !== point)
        : [...current, point];
      return {
        ...prev,
        activity1: {
          ...prev.activity1,
          selectedDamagePoints: next,
        },
      };
    });
  };

  const handleToggleAffectedTarget = (target: string) => {
    setState((prev) => {
      const current = prev.activity1.selectedAffectedTargets;
      const next = current.includes(target)
        ? current.filter((t) => t !== target)
        : [...current, target];
      return {
        ...prev,
        activity1: {
          ...prev.activity1,
          selectedAffectedTargets: next,
        },
      };
    });
  };

  const handleShowConceptCard = () => {
    setState((prev) => ({
      ...prev,
      activity1: {
        ...prev.activity1,
        showConceptCard: true,
      },
    }));
  };

  // Activity 2 Handlers (Situation-based toggle & viewed tracking)
  const handleSelectSituation = (sit: 1 | 2) => {
    if (
      sit === 2 &&
      !(state.activity2.situation1ViewedContinue && state.activity2.situation1ViewedStop)
    ) {
      return;
    }
    setState((prev) => ({
      ...prev,
      activity2: {
        ...prev.activity2,
        currentSituation: sit,
      },
    }));
  };

  const handleSetSituationView = (sit: 1 | 2, view: 'continue' | 'stop') => {
    setState((prev) => ({
      ...prev,
      activity2: {
        ...prev.activity2,
        ...(sit === 1
          ? {
              situation1View: view,
              situation1ViewedContinue: prev.activity2.situation1ViewedContinue || view === 'continue',
              situation1ViewedStop: prev.activity2.situation1ViewedStop || view === 'stop',
            }
          : {
              situation2View: view,
              situation2ViewedContinue: prev.activity2.situation2ViewedContinue || view === 'continue',
              situation2ViewedStop: prev.activity2.situation2ViewedStop || view === 'stop',
            }),
      },
    }));
  };

  // Activity 3 Handlers
  const handleUpdateIdeaText = (id: string, text: string) => {
    setState((prev) => ({
      ...prev,
      activity3: {
        ...prev.activity3,
        ideas: prev.activity3.ideas.map((idea) =>
          idea.id === id ? { ...idea, text } : idea
        ),
      },
    }));
  };

  const handleAddIdea = () => {
    setState((prev) => {
      const newId = `idea-${Date.now()}`;
      const newIndex = prev.activity3.ideas.length + 1;
      return {
        ...prev,
        activity3: {
          ...prev.activity3,
          ideas: [
            ...prev.activity3.ideas,
            { id: newId, title: `아이디어 ${newIndex}`, text: '' },
          ],
        },
      };
    });
  };

  const handleRemoveIdea = (id: string) => {
    setState((prev) => ({
      ...prev,
      activity3: {
        ...prev.activity3,
        ideas: prev.activity3.ideas.filter((i) => i.id !== id),
      },
    }));
  };

  const handleSetIdeaCheck = (
    id: string,
    field: 'checkSpread' | 'checkFeasible',
    val: 'yes' | 'rethink'
  ) => {
    setState((prev) => ({
      ...prev,
      activity3: {
        ...prev.activity3,
        ideas: prev.activity3.ideas.map((idea) =>
          idea.id === id ? { ...idea, [field]: val } : idea
        ),
      },
    }));
  };

  const handleUpdateIdeaRevised = (id: string, revisedText: string) => {
    setState((prev) => ({
      ...prev,
      activity3: {
        ...prev.activity3,
        ideas: prev.activity3.ideas.map((idea) =>
          idea.id === id ? { ...idea, revisedText } : idea
        ),
      },
    }));
  };

  // Get the latest resolved group method from Activity 3
  const resolvedGroupMethod = state.activity3.groupMethod;

  return (
    <div className="min-h-screen flex flex-col bg-[#f9f9ff] text-[#121c2a]">
      {/* Header Navigation */}
      <Header
        currentStep={state.currentStep}
        completedSteps={state.completedSteps}
        visitedSteps={state.visitedSteps}
        onNavigate={navigateToStep}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-[1120px] mx-auto px-4 sm:px-6 py-8 md:py-12">
        {state.currentStep === 'start' && (
          <StartScreen
            startConcern={state.startConcern}
            onChangeConcern={(val) =>
              setState((prev) => ({ ...prev, startConcern: val }))
            }
            onNext={() => handleProceedToNext('activity1')}
          />
        )}

        {state.currentStep === 'activity1' && (
          <Activity1Screen
            damagePoints={state.activity1.selectedDamagePoints}
            affectedTargets={state.activity1.selectedAffectedTargets}
            impactThought={state.activity1.impactThought}
            showConceptCard={state.activity1.showConceptCard}
            onToggleDamagePoint={handleToggleDamagePoint}
            onToggleAffectedTarget={handleToggleAffectedTarget}
            onChangeImpactThought={(val) =>
              setState((prev) => ({
                ...prev,
                activity1: { ...prev.activity1, impactThought: val },
              }))
            }
            onShowConceptCard={handleShowConceptCard}
            onNext={() => handleProceedToNext('activity2')}
          />
        )}

        {state.currentStep === 'activity2' && (
          <Activity2Screen
            currentSituation={state.activity2.currentSituation}
            situation1View={state.activity2.situation1View}
            situation2View={state.activity2.situation2View}
            situation1ViewedContinue={state.activity2.situation1ViewedContinue}
            situation1ViewedStop={state.activity2.situation1ViewedStop}
            situation2ViewedContinue={state.activity2.situation2ViewedContinue}
            situation2ViewedStop={state.activity2.situation2ViewedStop}
            differenceThought={state.activity2.differenceThought}
            whyStopNeeded={state.activity2.whyStopNeeded}
            onSelectSituation={handleSelectSituation}
            onSetSituationView={handleSetSituationView}
            onChangeDifferenceThought={(val) =>
              setState((prev) => ({
                ...prev,
                activity2: { ...prev.activity2, differenceThought: val },
              }))
            }
            onChangeWhyStopNeeded={(val) =>
              setState((prev) => ({
                ...prev,
                activity2: { ...prev.activity2, whyStopNeeded: val },
              }))
            }
            onNext={() => handleProceedToNext('activity3')}
          />
        )}

        {state.currentStep === 'activity3' && (
          <Activity3Screen
            ideas={state.activity3.ideas}
            groupMethod={state.activity3.groupMethod}
            groupMethodReason={state.activity3.groupMethodReason}
            onUpdateIdeaText={handleUpdateIdeaText}
            onAddIdea={handleAddIdea}
            onRemoveIdea={handleRemoveIdea}
            onSetIdeaCheck={handleSetIdeaCheck}
            onUpdateIdeaRevised={handleUpdateIdeaRevised}
            onChangeGroupMethod={(val) =>
              setState((prev) => ({
                ...prev,
                activity3: { ...prev.activity3, groupMethod: val },
              }))
            }
            onChangeGroupMethodReason={(val) =>
              setState((prev) => ({
                ...prev,
                activity3: { ...prev.activity3, groupMethodReason: val },
              }))
            }
            onNext={() => handleProceedToNext('apply')}
          />
        )}

        {state.currentStep === 'apply' && (
          <ApplyScreen
            howToApply={state.apply.howToApply}
            groupMethod={resolvedGroupMethod}
            actualSpeech={state.apply.actualSpeech}
            actualAction={state.apply.actualAction}
            onChangeHowToApply={(val) =>
              setState((prev) => ({
                ...prev,
                apply: { ...prev.apply, howToApply: val },
              }))
            }
            onChangeActualSpeech={(val) =>
              setState((prev) => ({
                ...prev,
                apply: { ...prev.apply, actualSpeech: val },
              }))
            }
            onChangeActualAction={(val) =>
              setState((prev) => ({
                ...prev,
                apply: { ...prev.apply, actualAction: val },
              }))
            }
            onNext={() => handleProceedToNext('my_action')}
          />
        )}

        {state.currentStep === 'my_action' && (
          <MyActionScreen
            actionSentence={state.myAction.actionSentence}
            onChangeActionSentence={(val) =>
              setState((prev) => ({
                ...prev,
                myAction: { ...prev.myAction, actionSentence: val },
              }))
            }
            onNext={() => handleProceedToNext('reflection')}
          />
        )}

        {state.currentStep === 'reflection' && (
          <ReflectionScreen
            newLearnings={state.reflection.newLearnings}
            attitudeChange={state.reflection.attitudeChange}
            onChangeNewLearnings={(val) =>
              setState((prev) => ({
                ...prev,
                reflection: { ...prev.reflection, newLearnings: val },
              }))
            }
            onChangeAttitudeChange={(val) =>
              setState((prev) => ({
                ...prev,
                reflection: { ...prev.reflection, attitudeChange: val },
              }))
            }
            onResetAll={handleResetAll}
          />
        )}
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
