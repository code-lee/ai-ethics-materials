# AI 사진·영상 대응실

초등학교 5~6학년 실과/도덕/정보 연계 AI 미디어 윤리 학습 웹 애플리케이션입니다.

## 실행 방법

```bash
npm install
npm run dev
```

## 빌드

```bash
npm run build
```
