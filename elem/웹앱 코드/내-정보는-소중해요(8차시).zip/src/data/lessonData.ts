import { Activity2Scenario, StepInfo, TextSegment } from '../types';

export const STEPS: StepInfo[] = [
  { id: 'start', title: '시작', stepNumber: 1, subtitle: '생각 열기' },
  { id: 'activity1', title: '활동1', stepNumber: 2, subtitle: '이대로 보내도 될까?' },
  { id: 'activity2', title: '활동2', stepNumber: 3, subtitle: '개인정보 편집실' },
  { id: 'activity3', title: '활동3', stepNumber: 4, subtitle: '안전한 AI 요청문 만들기' },
  { id: 'application', title: '생활 속 적용', stepNumber: 5, subtitle: '전송하기 전에 3초!' },
  { id: 'reflection', title: '돌아보기', stepNumber: 6, subtitle: '나의 배움 정리' },
];

export const START_VIRTUAL_REQUEST = '안녕 AI야! 나는 한빛초등학교 3학년 1반 김철수라고 해. 우리 집은 한빛시 햇살구 새봄동 123번지인데, 내일 날씨에 맞춰서 어떤 옷을 입고 학교에 가면 좋을까? 알려줘!';

export const INITIAL_OPTIONS = [
  { id: 'opt1', text: '① 알려 줘도 괜찮을 것 같아요' },
  { id: 'opt2', text: '② 조금 조심해야 할 것 같아요' },
  { id: 'opt3', text: '③ 잘 모르겠어요' },
];

// Activity 1 Data
export const ACTIVITY1_REQUEST = {
  originalText: `안녕하세요! 저는 한빛초등학교 3학년 1반 김철수입니다. 우리 동네 탐구 숙제를 하려고 하는데요, 한빛시 햇살구 새봄동 123번지 주변에 있는 역사적인 장소에 대해 알려주세요.`,
  segments: [
    { id: 'a1-seg-1', text: '안녕하세요! 저는', isPrivacy: false },
    { id: 'a1-seg-2', text: '한빛초등학교', isPrivacy: true },
    { id: 'a1-seg-3', text: '3학년 1반', isPrivacy: true },
    { id: 'a1-seg-4', text: '김철수', isPrivacy: true },
    { id: 'a1-seg-5', text: '입니다.', isPrivacy: false },
    { id: 'a1-seg-6', text: '우리 동네 탐구 숙제를 하려고 하는데요,', isPrivacy: false },
    { id: 'a1-seg-7', text: '한빛시 햇살구 새봄동 123번지', isPrivacy: true },
    { id: 'a1-seg-8', text: '주변에 있는 역사적인 장소에 대해 알려주세요.', isPrivacy: false },
  ],
};

// Activity 2 Initial Scenarios
export const INITIAL_ACTIVITY2_SCENARIOS: Activity2Scenario[] = [
  {
    id: 'scenario-1',
    title: '상황 ① 숙제 도움 요청',
    category: '숙제 도움',
    description: '주말 가족 체험 활동 숙제를 위해 AI에게 놀이 아이디어를 물어보려고 해요.',
    stepThought: '',
    isChecked: false,
    isCompleted: false,
    segments: [
      {
        id: 's1-1',
        originalText: '우리 아빠는 별빛전자에 다니고',
        action: 'none',
        isPrivacySensitive: true,
        acceptableActions: ['remove', 'change'],
        questionHint: '한 번 더 생각해 봐요. 아빠의 회사 정보가 없어도 재미있는 놀이를 추천받을 수 있을까요?'
      },
      {
        id: 's1-2',
        originalText: '이름은 김도윤이야.',
        action: 'none',
        isPrivacySensitive: true,
        acceptableActions: ['remove'],
        questionHint: '가족의 실명까지 알려 주지 않아도 AI에게 원하는 도움을 받을 수 있을까요?'
      },
      {
        id: 's1-3',
        originalText: '우리 집 주소는 해오름아파트인데,',
        action: 'none',
        isPrivacySensitive: true,
        acceptableActions: ['remove', 'change'],
        questionHint: '이렇게 자세한 아파트 이름 대신 집 근처나 실내 활동으로 바꾸거나 빼도 되지 않을까요?'
      },
      {
        id: 's1-4',
        originalText: '이번 주말에 아빠랑 같이 할 재미있는 놀이를 추천해 줘!',
        action: 'none',
        isPrivacySensitive: false,
        acceptableActions: ['keep'],
        questionHint: '이 부분을 빼면 AI가 어떤 도움을 주어야 할지 알 수 있을까요?'
      }
    ]
  },
  {
    id: 'scenario-2',
    title: '상황 ② 그림·이야기 아이디어 요청',
    category: '아이디어 요청',
    description: '미술 시간에 친구와 함께 그릴 만화 캐릭터 아이디어를 AI에게 요청하려고 해요.',
    stepThought: '',
    isChecked: false,
    isCompleted: false,
    segments: [
      {
        id: 's2-1',
        originalText: '내 친구 박서진(전화번호 010-1234-5678)이랑',
        action: 'none',
        isPrivacySensitive: true,
        acceptableActions: ['remove', 'change'],
        questionHint: '이 정보는 나만의 정보일까요? 다른 사람의 소중한 정보도 함께 들어 있지는 않을까요?'
      },
      {
        id: 's2-2',
        originalText: '한빛초등학교 4학년 2반 교실에서 그릴 건데,',
        action: 'none',
        isPrivacySensitive: true,
        acceptableActions: ['remove', 'change'],
        questionHint: '학교와 학급 정보 대신 초등학생 눈높이처럼 바꾸거나 빼도 아이디어를 얻을 수 있을까요?'
      },
      {
        id: 's2-3',
        originalText: '초능력을 가진 귀여운 동물 만화 캐릭터 아이디어를',
        action: 'none',
        isPrivacySensitive: false,
        acceptableActions: ['keep'],
        questionHint: '이 부분을 빼면 어떤 만화 캐릭터를 원하는지 AI가 알 수 있을까요?'
      },
      {
        id: 's2-4',
        originalText: '재미있게 3가지 추천해 줘!',
        action: 'none',
        isPrivacySensitive: false,
        acceptableActions: ['keep'],
        questionHint: '원하는 추천 방식을 AI에게 명확히 전달하기 위해 필요한 내용이 아닐까요?'
      }
    ]
  },
  {
    id: 'scenario-3',
    title: '상황 ③ 생활 정보 및 활동 추천 요청',
    category: '활동 추천',
    description: '방학 동안 가족과 함께 갈 만한 자연 체험 장소를 AI에게 추천받으려고 해요.',
    stepThought: '',
    isChecked: false,
    isCompleted: false,
    segments: [
      {
        id: 's3-1',
        originalText: '우리 집은 한빛시 햇살구 새봄동 123번지이고,',
        action: 'none',
        isPrivacySensitive: true,
        acceptableActions: ['change'],
        questionHint: '가까운 생태 공원이나 식물원을 추천받으려면 위치 정보가 필요해요. 상세 번지수를 완전히 빼기보다는 대략적인 동네나 구 이름(예: 햇살구 근처)으로 안전하게 바꾸어 보는 건 어떨까요?'
      },
      {
        id: 's3-2',
        originalText: '엄마 자동차 번호는 12가 3456이야.',
        action: 'none',
        isPrivacySensitive: true,
        acceptableActions: ['remove'],
        questionHint: '한 번 더 생각해 봐요. 차량 번호가 없어도 자연 체험 장소를 추천받을 수 있을까요?'
      },
      {
        id: 's3-3',
        originalText: '이번 주말에 신비한 곤충과 식물을 관찰할 수 있는',
        action: 'none',
        isPrivacySensitive: false,
        acceptableActions: ['keep'],
        questionHint: '어떤 장소를 가고 싶은지 AI에게 알려 주기 위해 필요한 정보가 아닐까요?'
      },
      {
        id: 's3-4',
        originalText: '가까운 생태 공원이나 식물원을 알려줘!',
        action: 'none',
        isPrivacySensitive: false,
        acceptableActions: ['keep'],
        questionHint: '이 부분을 빼면 AI가 어떤 목적지를 찾아주어야 할지 알 수 있을까요?'
      }
    ]
  }
];

// Life Application Segments
export const INITIAL_APPLICATION_SEGMENTS: TextSegment[] = [
  {
    id: 'app-1',
    originalText: '안녕 AI! 나는 한빛초등학교 4학년 김민수야.',
    action: 'none',
    isPrivacySensitive: true,
    acceptableActions: ['remove', 'change'],
    questionHint: '길 찾기 질문에 학교명과 이름이 꼭 필요할까요?'
  },
  {
    id: 'app-2',
    originalText: '내일 별빛전자 본사로 견학을 가는데,',
    action: 'none',
    isPrivacySensitive: false,
    acceptableActions: ['keep'],
    questionHint: '도착할 목적지 정보는 길 찾기에 필요한 정보가 아닐까요?'
  },
  {
    id: 'app-3',
    originalText: '우리 집(한빛시 햇살구 새봄동 123-45)에서',
    action: 'none',
    isPrivacySensitive: true,
    acceptableActions: ['change'],
    questionHint: '가장 빠른 대중교통 길을 찾으려면 출발 위치가 필요해요. 상세 번지수를 완전히 삭제하기보다는 대략적인 동네나 출발역(예: 새봄동 쪽에서)으로 바꾸어 보는 건 어떨까요?'
  },
  {
    id: 'app-4',
    originalText: '별빛전자 본사까지 대중교통으로 가는 가장 빠른 길을 알려줘.',
    action: 'none',
    isPrivacySensitive: false,
    acceptableActions: ['keep'],
    questionHint: '이동 수단과 경로를 묻는 핵심 요청문이 아닐까요?'
  }
];
