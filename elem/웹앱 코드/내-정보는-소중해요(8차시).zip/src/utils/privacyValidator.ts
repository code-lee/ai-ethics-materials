/**
 * Privacy evaluation utility for Elementary AI Ethics education.
 * Checks whether user edited text is sufficiently generalized or still contains
 * overly specific personal information (real names, phone numbers, exact addresses,
 * apartment names, school names with grade/class, company/institution names, etc.).
 */

export interface ValidationResult {
  isValid: boolean;
  reason?: string;
  suggestedHint?: string;
}

/**
 * Common Korean surnames (single-character and two-character surnames)
 */
const SURNAMES_PREFIX_REGEX = /^(?:남궁|황보|제갈|선우|독고|사공|김|이|박|최|정|강|조|윤|장|임|한|오|서|신|권|황|안|송|류|전|홍|고|문|양|손|배|백|허|유|남|심|노|하|곽|성|차|주|우|구|민|진|지|엄|채|원|천|방|공|현|함|변|염|여|추|도|소|석|선|설|마|길|연|위|표|명|기|반|왕|금|옥|육|인|맹|제|모|탁|국|어|은|편|용)/;

/**
 * Common Korean given names (2 characters)
 */
const GIVEN_NAMES_REGEX = /^(?:서진|도윤|영희|철수|민수|하늘|우진|민재|서준|하준|도현|건우|예준|시우|주원|유준|수아|지아|서윤|서연|민서|채원|다은|유나|윤서|지유|채은|지민|예은|지원|수빈|예린|유진|은서|수현|민지|소율|하은|소은|다인|시은|서현|태희|준우|준서|은우|진우|승우|지호|승민|시윤|현우|민혁|서우|지안|하린)$/;

/**
 * Korean postpositions (조사) to strip from words for matching
 */
const KOREAN_POSTPOSITIONS = /(?:과|와|이랑|랑|이|가|는|은|의|에게|한테|라고|야|이야|입니다|이에요|예요|도|을|를|로서|로써|하고|에서|부터|까지|에게서|한테서|이랑은|와는|과는|에게는|에게도|한테도|이라고|이라는|이란|이나|나|이랑도|랑도)$/;

/**
 * Known safe relational & non-name nouns
 */
const SAFE_RELATIONAL_NOUNS = new Set([
  '친구', '친구들', '반친구', '모둠원', '팀원', '짝꿍', '가족', '가족들', '가족과', '부모님', '부모',
  '아빠', '엄마', '아버지', '어머니', '형', '누나', '오빠', '동생', '삼촌', '이모', '고모', '친척', '이웃',
  '선생님', '교사', '학생', '학생들', '초등학생', '중학생', '고등학생', '어린이', '아이', '아이들',
  '사람', '사람들', '누군가', '누구', '아무개', '모두', '다같이', '서로', '우리', '우리반', '우리들',
  '저희', '나', '너', '당신', '혼자', '둘이서', '셋이서', '넷이서', '다섯이서', '직접', '스스로', '누구나'
]);

/**
 * Comprehensive set of safe general vocabulary and educational terms
 */
const SAFE_GENERAL_WORDS = new Set([
  // Roles / General references
  '친구', '친구들', '반친구', '모둠원', '팀원', '짝꿍', '가족', '가족들', '가족과', '부모님', '부모', '아빠', '엄마', '아버지', '어머니', '형', '누나', '오빠', '동생', '삼촌', '이모', '고모', '친척', '이웃', '선생님', '교사', '학생', '학생들', '어린이', '아이', '아이들', '사람', '사람들', '누군가', '누구', '아무개', '초등학생', '중학생', '고등학생', '초등', '모두', '다같이', '서로', '우리', '우리반', '우리들', '저희', '나', '너', '당신', '혼자', '둘이서', '셋이서', '넷이서', '다섯이서', '직접', '스스로', '누구나', '둘', '셋', '넷', '다섯',
  // School / Education
  '학교', '초등학교', '중학교', '고등학교', '교실', '복도', '운동장', '강당', '체육관', '급식실', '도서관', '과학실', '음악실', '미술실', '컴퓨터실', '수업', '수업시간', '공부', '숙제', '과제', '활동', '놀이', '게임', '보드게임', '아이디어', '생각', '질문', '답변', '추천', '안내', '설명', '정보', '내용', '표어', '문구', '포스터', '캠페인', '행사', '축제', '체험', '학습', '미술시간', '방과후', '실내', '야외', '실외', '정문', '후문', '교문',
  // Environment / Nature
  '환경', '지구', '보호', '분리배출', '재활용', '쓰레기', '절약', '실천', '자연', '생태', '식물', '곤충', '동물', '나무', '꽃', '하늘', '바람', '구름', '비', '눈', '햇빛', '햇살', '별빛', '달빛', '공기', '물', '숲', '들판', '산', '바다', '강',
  // Location / General regions & administrative terms
  '동네', '우리동네', '지역', '장소', '위치', '근처', '주변', '부근', '인근', '거리', '골목', '길', '광장', '방향', '센터', '주민센터', '구청', '시청', '복지관', '공원', '생태공원', '놀이터', '박물관', '미술관', '과학관', '식물원', '수목원', '체험관', '전시관', '지하철', '지하철역', '전철역', '기차역', '역', '버스', '버스정류장', '정류장', '대중교통', '교통', '자동차', '차량', '자전거', '킥보드', '도보', '걸어서', '집', '우리집', '출발지', '도착지', '목적지',
  '서구', '동구', '남구', '북구', '중구', '강남구', '강서구', '강북구', '강동구', '광산구', '달서구', '수성구', '유성구', '해운대구', '영등포구', '마포구', '송파구', '종로구', '서초구', '한빛시', '서울시', '부산시', '대구시', '인천시', '광주시', '대전시', '울산시', '세종시', '새봄동', '햇살구', '상무역', '시내', '도심', '마을', '도시',
  // Time / Calendar / Weather
  '주말', '평일', '휴일', '방학', '오늘', '내일', '어제', '모레', '이번', '다음', '지난', '아침', '점심', '저녁', '밤', '새벽', '낮', '오전', '오후', '하루', '시간', '날씨', '옷차림', '기온', '계절', '봄', '여름', '가을', '겨울',
  // Modifiers / Adverbs / Pronouns / Common phrases
  '대략', '대충', '조금', '약간', '많이', '아주', '너무', '정말', '진짜', '최고', '최선', '최대', '최소', '최근', '최신', '최대한', '일반', '보통', '대체로', '함께', '같이', '다양한', '재미있는', '멋진', '안전한', '소중한', '새로운', '어떤', '이런', '저런', '어떻게', '무엇', '어디', '언제', '왜', '이렇게', '저렇게', '그렇게', '바꿀게', '바꿔', '가까운', '가까이', '가까운곳', '가까운곳에',
  // Action Greetings / Verbs
  '안녕', '안녕하세요', '부탁', '부탁해', '알려줘', '도와줘', '추천해줘', '말해줘', '설명해줘', '찾아줘', '만들어줘', '써줘', '제시해줘', '작성해줘', '가르쳐줘', '안내해줘', '찾고', '찾기', '있어요', '있어', '없음', '삭제'
]);

/**
 * Specific Name Detector for name-related segments (s1-2, s2-1, app-1).
 * Detects whether the text still contains specific names like "최하늘", "정우진", "정우진이랑", "친구 최하늘", "내 친구 이서준" etc.
 * Operates on independent tokens and prefix-anchored candidates only, never on arbitrary substrings.
 */
function containsSpecificName(text: string): boolean {
  const cleaned = text.trim();
  if (!cleaned) return false;

  // Prefix pattern to match relational context like "내 친구 최하늘", "친구 정우진", "아빠 김도윤", "이름은 최하늘", "나는 최하늘"
  const prefixRegex = /^(?:내\s*친구|우리\s*친구|친한\s*친구|소중한\s*친구|친구|아빠|엄마|가족|동생|형|누나|오빠|짝꿍|이름은|나는|저는|저의|나의)\s*/;

  // Split sentence into word tokens (어절)
  const rawTokens = cleaned.split(/[\s,./~!?()'"\[\]+&<>-]+/).filter(t => t.length > 0);

  for (const rawToken of rawTokens) {
    const candidates: string[] = [];

    // 1. Token stripped of postpositions
    const tokenNoPost = rawToken.replace(KOREAN_POSTPOSITIONS, '');
    candidates.push(tokenNoPost);

    // 2. If token starts with prefix (e.g., "친구최하늘이랑", "내친구정우진")
    if (prefixRegex.test(rawToken)) {
      const stripped = rawToken.replace(prefixRegex, '').replace(KOREAN_POSTPOSITIONS, '');
      if (stripped) candidates.push(stripped);
    }

    for (const candidate of candidates) {
      if (!candidate || candidate.length < 2 || candidate.length > 4) continue;

      // If recognized as a safe general word (e.g. "친구", "가족", "학생", "아빠", "서구", "안녕하세요", "부탁해"), skip
      if (SAFE_GENERAL_WORDS.has(candidate)) continue;

      // Safe relational nouns
      if (SAFE_RELATIONAL_NOUNS.has(candidate)) continue;

      // Common verb/predicate endings that shouldn't be names
      if (/(?:하다|해요|했다|해줘|알려줘|도와줘|있어|있어요|찾고|찾아|찾기|부탁|부탁해|바꿀게|바꿔|갈게|가요|봐요|안녕|어때|좋아|할래|하세요|갑니다|합니다)$/.test(candidate)) {
        continue;
      }

      // Check if candidate matches standard Korean Name: [Surname (1-2 chars)][Given name (1-2 chars)] (total 2~4 chars)
      if (SURNAMES_PREFIX_REGEX.test(candidate)) {
        return true;
      }

      // Standalone given name (2 chars)
      if (GIVEN_NAMES_REGEX.test(candidate)) {
        return true;
      }
    }
  }

  // Check multi-token combinations like "친구 최하늘", "내 친구 정우진", "아빠 김도윤", "이름은 최하늘이야"
  const multiTokenRegex = /(?:내\s*친구|우리\s*친구|친구|아빠|엄마|동생|짝꿍|이름은|나는|저는)\s+([가-힣]{2,4})(?:과|와|이랑|랑|이|가|는|은|의|에게|한테|라고|야|이야|입니다|이에요|예요|$)/g;
  let match: RegExpExecArray | null;
  while ((match = multiTokenRegex.exec(cleaned)) !== null) {
    const candidate = match[1].replace(KOREAN_POSTPOSITIONS, '');
    if (candidate.length >= 2 && candidate.length <= 4) {
      if (!SAFE_GENERAL_WORDS.has(candidate) && !SAFE_RELATIONAL_NOUNS.has(candidate)) {
        if (SURNAMES_PREFIX_REGEX.test(candidate) || GIVEN_NAMES_REGEX.test(candidate)) {
          return true;
        }
      }
    }
  }

  return false;
}

/**
 * Checks whether a location string is multi-tier or overly specific rather than safely generalized.
 * Rejects multi-tier administrative divisions (e.g. "별빛시 달빛구 해님동", "한빛시 햇살구"),
 * road numbers/bunji, house numbers, or specific building/apartment names.
 */
export function isMultiTierOrDetailedLocation(text: string): boolean {
  const cleaned = text.trim();
  if (!cleaned) return false;

  // 1. Any digits (bunji, house number, road number, floor, building number)
  if (/\d/.test(cleaned)) {
    return true;
  }

  // 2. Specific residential building / complex keywords (아파트, 빌라, 오피스텔, 타운, 맨션, 단지, 빌딩 등)
  if (/(아파트|빌라|오피스텔|타운|맨션|단지|빌딩|상가|주택)/.test(cleaned)) {
    return true;
  }

  // 3. Multi-tier administrative division check
  // (e.g., "별빛시 달빛구 해님동", "한빛시 햇살구", "달빛구 해님동", "서울시 강남구 역삼동")
  const tokens = cleaned.split(/[\s,./~-]+/).filter(t => t.length > 0);
  let adminUnitCount = 0;

  for (const token of tokens) {
    // Exclude safe general location words like "우리동네", "동네", "도시", "지하철역", "전철역", "기차역", "역", "근처", "주변"
    const cleanedToken = token.replace(/[에서으로에게와과랑이랑쪽부근근처]/g, '');
    const isSafeLocationNoun = /^(우리동네|동네|도시|시골|근처|주변|인근|부근|가까운|지하철역|전철역|기차역|역|역근처|역에서|역쪽|역주변|동네에서|동네근처|상무역|강남역|서울역)$/.test(
      cleanedToken
    );

    if (!isSafeLocationNoun) {
      if (/(?:특별시|광역시|특별자치시|자치구|[가-힣]{1,4}시|[가-힣]{1,4}도|[가-힣]{1,4}군|[가-힣]{1,4}구|[가-힣]{1,4}읍|[가-힣]{1,4}면|[가-힣]{1,4}동|[가-힣]{1,4}리|[가-힣]{1,4}로|[가-힣]{1,4}길)$/.test(token)) {
        adminUnitCount++;
      }
    }
  }

  if (adminUnitCount >= 2) {
    return true; // 2 or more administrative tiers (e.g., "별빛시 달빛구 해님동", "한빛시 햇살구")
  }

  // Also check unspaced combined administrative units: e.g. "별빛시달빛구", "햇살구새봄동"
  if (/[가-힣]+(?:시|도|군)\s*[가-힣]+(?:구|군|동|읍|면|리)/.test(cleaned) ||
      /[가-힣]+(?:구|군)\s*[가-힣]+(?:동|읍|면|리)/.test(cleaned)) {
    return true;
  }

  return false;
}

/**
 * Checks whether the text actually contains an approximate location or departure area.
 * Returns true if general area keywords exist (e.g. "우리 동네 근처", "집 근처", "햇살구 근처", "새봄동 쪽에서", "서구 근처", "상무역 근처에서", "가까운 지하철역에서").
 */
export function hasApproximateLocation(text: string): boolean {
  const cleaned = text.trim();
  if (!cleaned) return false;

  // Patterns indicating approximate area, distance, transport hub, or administrative region
  const locationKeywords = /(?:근처|주변|인근|부근|쪽에서|쪽으로|쪽|방향|동네|우리\s*동네|집|우리\s*집|지하철역|전철역|기차역|버스정류장|정류장|역\s*근처|역\s*주변|[가-힣]+역|출발|도착|위치|지역|장소|가까운|[가-힣]{1,4}구|[가-힣]{1,4}동|[가-힣]{1,4}시|[가-힣]{1,4}읍|[가-힣]{1,4}면|[가-힣]{1,4}리)/;

  return locationKeywords.test(cleaned);
}

/**
 * Checks if the text changed by the student contains specific private information.
 * Returns { isValid: true } if safely generalized, or { isValid: false, reason, suggestedHint } if still too specific or inadequate.
 */
export function evaluateChangedText(
  originalText: string,
  changedText: string | undefined,
  segmentId?: string
): ValidationResult {
  if (!changedText || changedText.trim().length === 0) {
    return {
      isValid: false,
      reason: '내용이 입력되지 않았어요.',
      suggestedHint: '어떻게 안전하게 바꿀지 내용을 입력해 보세요.'
    };
  }

  const trimmed = changedText.trim();
  const normalized = trimmed.replace(/\s+/g, ' ');

  // 1. Phone numbers check (010, digits with hyphens, 7-11 digits)
  const phonePattern = /(01[016789][-.\s]?\d{3,4}[-.\s]?\d{4}|\d{2,3}[-.\s]?\d{3,4}[-.\s]?\d{4}|\b\d{7,11}\b)/;
  if (phonePattern.test(normalized)) {
    return {
      isValid: false,
      reason: '전화번호나 상세 번호가 포함되어 있어요.',
      suggestedHint: '전화번호 같은 구체적인 연락처는 삭제하거나 "친구와 함께"처럼 일반적인 표현으로 바꿔 볼까요?'
    };
  }

  // 2. Specific house address numbers / bunji (123번지, 123-45, 101호, 102동 등)
  const specificAddressPattern = /(\d+번지|\d+-\d+|\d+동\s*\d+호|\d+호|\d+층)/;
  if (specificAddressPattern.test(normalized)) {
    return {
      isValid: false,
      reason: '상세 번지수나 동·호수 정보가 남아 있어요.',
      suggestedHint: '상세한 번지수 대신 "우리 동네 근처" 또는 "집 근처"처럼 덜 구체적으로 바꿔 볼까요?'
    };
  }

  // 3. Vehicle license plate numbers (12가 3456, 123가 4567, etc.)
  const carPlatePattern = /(\d{2,3}\s*[가-힣]\s*\d{4})/;
  if (carPlatePattern.test(normalized)) {
    return {
      isValid: false,
      reason: '자동차 번호판 정보가 남아 있어요.',
      suggestedHint: '자동차 번호는 특정 차량을 알 수 있는 정보예요. 차량 번호 대신 "자동차로" 또는 "대중교통으로"처럼 바꿔 볼까요?'
    };
  }

  // 4. Specific apartment / residential building names (아파트, 빌라, 오피스텔, 타운, 단지)
  const apartmentPattern = /([가-힣A-Za-z0-9]+아파트|[가-힣A-Za-z0-9]+빌라|[가-힣A-Za-z0-9]+오피스텔|[가-힣A-Za-z0-9]+타운|[가-힣A-Za-z0-9]+마을\s*\d+단지)/;
  if (apartmentPattern.test(normalized)) {
    return {
      isValid: false,
      reason: '구체적인 아파트나 건물 이름이 남아 있어요.',
      suggestedHint: '특정 아파트 이름 대신 "우리 동네에서" 또는 "집 근처 실내에서"처럼 덜 구체적으로 표현해 볼까요?'
    };
  }

  // 5. School name + Grade / Class or specific school names (한빛초등학교, 햇살초 3학년 1반, OO초등학교, OO초 4학년 2반 등)
  const schoolClassPattern = /([가-힣]+초(등학교)?\s*\d+학년(\s*\d+반)?|\d+학년\s*\d+반|[가-힣]{2,}초등학교|[가-힣]{2,}초교|[가-힣]{2,}중학교|[가-힣]{2,}고등학교)/;
  if (schoolClassPattern.test(normalized)) {
    // Only generic words like "학교에서", "초등학교에서", "교실에서" are acceptable
    const isOnlyGenericSchool = /^(학교에서|학교|초등학교에서|초등학교|교실에서|교실|실내에서|실내|수업시간에|미술시간에|방과후에)$/.test(normalized.replace(/[\s.,!?]/g, ''));
    if (!isOnlyGenericSchool) {
      return {
        isValid: false,
        reason: '구체적인 학교 이름이나 학년·반 정보가 포함되어 있어요.',
        suggestedHint: '구체적인 학교명과 학급 대신 "학교에서" 또는 "초등학교 교실에서"처럼 일반화해 볼까요?'
      };
    }
  }

  // 6. Specific Company / Bank / Institution / Store names (별빛전자, 행복은행, 삼성, LG, 현대, 카카오, 네이버, OO상사, OO기업, OO마트 등)
  const companyPattern = /(별빛전자|[가-힣A-Za-z]+전자|[가-힣A-Za-z]+은행|[가-힣A-Za-z]+기업|[가-힣A-Za-z]+상사|[가-힣A-Za-z]+증권|[가-힣A-Za-z]+카드|[가-힣A-Za-z]+마트|[가-힣A-Za-z]+백화점|[가-힣A-Za-z]+회사|삼성|LG|현대|SK|카카오|네이버|쿠팡|회사이름)/;
  if (companyPattern.test(normalized)) {
    // Allow pure generic words like "회사", "직장" only if no specific name attached
    const isGenericWorkplace = /^(회사|직장|회사에|직장에|아빠와|아빠랑|가족과|가족이랑|주말에)$/.test(normalized.replace(/[\s.,!?]/g, ''));
    if (!isGenericWorkplace) {
      return {
        isValid: false,
        reason: '구체적인 회사나 기관 이름이 포함되어 있어요.',
        suggestedHint: '특정 회사나 기관 이름 대신 "아빠와 함께" 또는 "주말에"처럼 덜 구체적으로 바꿔 볼까요?'
      };
    }
  }

  // 7. Location segments specific validation (s3-1, app-3)
  // Evaluated via location specificity check, NOT by name check, preventing false positives like "서구 근처", "남구 근처"
  if (segmentId === 's3-1' || segmentId === 'app-3') {
    // Condition 1: Must NOT have overly specific or multi-tier detailed location info
    if (isMultiTierOrDetailedLocation(normalized)) {
      return {
        isValid: false,
        reason: '상세 위치(시·구·동 등 여러 단계 나열 또는 상세 번호)가 남아 있어요.',
        suggestedHint: '상세한 지역명을 나열하기보다 "햇살구 근처", "새봄동 쪽에서", "우리 동네 근처"처럼 위치의 구체성을 낮추어 볼까요?'
      };
    }

    // Condition 2: MUST actually contain an approximate location / departure area expression
    if (!hasApproximateLocation(normalized)) {
      return {
        isValid: false,
        reason: '대략적인 출발 위치나 지역 정보가 없어요.',
        suggestedHint: '가까운 장소나 길을 찾으려면 대략적인 위치는 필요해요. 상세 주소 대신 동네나 구, 가까운 역 정도로 바꿔 볼까요?'
      };
    }

    return { isValid: true };
  }

  // 8. Scenario-specific target validations & Name evaluations for segments containing personal names
  if (segmentId === 's1-1') {
    // Original: 우리 아빠는 별빛전자에 다니고
    // Target: Generalization to "아빠와 함께", "주말에", "가족과 함께", etc.
    if (/(전자|은행|상사|기업|증권|회사|다니고|근무)/.test(normalized)) {
      const isClean = /^(아빠와\s*함께|아빠랑|가족과\s*함께|가족과|주말에|아빠와)$/.test(normalized.replace(/[\s.,!?]/g, ''));
      if (!isClean) {
        return {
          isValid: false,
          reason: '아빠의 직장이나 회사 정보가 아직 남아 있어요.',
          suggestedHint: '직장 정보를 다른 회사로 바꾸기보다 "아빠와 함께" 또는 "가족과"처럼 바꿔 볼까요?'
        };
      }
    }
    return { isValid: true };
  }

  if (segmentId === 's1-2') {
    // Original: 이름은 김도윤이야.
    // Contains personal name: check if real names or replacements (e.g. 최하늘) exist
    if (containsSpecificName(normalized) || /(이름은|도윤|철수|영희|민수)/.test(normalized)) {
      return {
        isValid: false,
        reason: '가족의 실명 정보가 여전히 남아 있어요.',
        suggestedHint: '가족의 이름은 놀이 추천에 필요 없으므로 삭제하는 것이 좋아요.'
      };
    }
    return { isValid: true };
  }

  if (segmentId === 's1-3') {
    // Original: 우리 집 주소는 해오름아파트인데,
    // Should be generalized to "집 근처에서", "실내에서", "우리 동네에서", "집에서"
    if (/(아파트|빌라|오피스텔|단지|\d+동|\d+호)/.test(normalized)) {
      return {
        isValid: false,
        reason: '여전히 거주지 형태나 건물 이름이 구체적이에요.',
        suggestedHint: '"집에서", "실내에서", "집 근처에서"처럼 덜 구체적으로 바꿔 볼까요?'
      };
    }
    return { isValid: true };
  }

  if (segmentId === 's2-1') {
    // Original: 내 친구 박서진(전화번호 010-1234-5678)이랑
    // Contains personal name & phone: check if real names or replacements exist
    if (containsSpecificName(normalized) || /\d/.test(normalized)) {
      return {
        isValid: false,
        reason: '친구의 실명이나 전화번호가 아직 포함되어 있어요.',
        suggestedHint: '친구의 이름이나 전화번호 대신 "친구와 함께" 또는 "친구랑"처럼 일반화해 볼까요?'
      };
    }
    return { isValid: true };
  }

  if (segmentId === 's2-2') {
    // Original: 한빛초등학교 4학년 2반 교실에서 그릴 건데,
    // Should be generalized to "학교에서", "교실에서", "미술 시간에", "초등학교 교실에서"
    if (/\d+학년|\d+반|[가-힣]{2,}초등학교|[가-힣]{2,}초/.test(normalized)) {
      return {
        isValid: false,
        reason: '구체적인 학교 이름이나 학년·반 정보가 남아 있어요.',
        suggestedHint: '"학교에서", "교실에서", "미술 시간에"처럼 덜 구체적으로 표현해 볼까요?'
      };
    }
    return { isValid: true };
  }

  if (segmentId === 'app-1') {
    // Original: 안녕 AI! 나는 한빛초등학교 4학년 김민수야.
    // Contains personal name: check if real names or replacements exist
    if (containsSpecificName(normalized) || /\d+학년|[가-힣]{2,}초등학교/.test(normalized)) {
      return {
        isValid: false,
        reason: '학교나 학년, 이름이 아직 구체적으로 남아 있어요.',
        suggestedHint: '"안녕하세요" 또는 "길을 찾고 있어요"처럼 간단한 인사로 바꾸거나 아예 빼 볼까요?'
      };
    }
    return { isValid: true };
  }

  // Fallback check for any other segments that originally contained names
  if (containsSpecificName(normalized)) {
    return {
      isValid: false,
      reason: '사람의 구체적인 이름(실명)이 포함되어 있어요.',
      suggestedHint: '특정 인물의 실명을 다른 이름으로 바꾸지 않고 "친구와 함께", "가족과", "한 학생"처럼 일반적인 표현으로 바꿔 볼까요?'
    };
  }

  return { isValid: true };
}
