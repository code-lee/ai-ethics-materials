import { useState, useEffect } from 'react';
import { LessonState, StepId, ActionType, Activity3Checks } from '../types';
import { INITIAL_ACTIVITY2_SCENARIOS, INITIAL_APPLICATION_SEGMENTS } from '../data/lessonData';

const STORAGE_KEY = 'ai_privacy_lesson_state_v2';

const DEFAULT_STATE: LessonState = {
  currentStep: 'start',
  completedSteps: [],
  
  // Step 1: Start
  initialThought: '',
  
  // Step 2: Activity 1
  activity1SelectedIds: [],
  activity1Reason: '',
  activity1Completed: false,
  
  // Step 3: Activity 2
  activity2Scenarios: INITIAL_ACTIVITY2_SCENARIOS,
  activity2CurrentScenarioIndex: 0,
  activity2Thought: '',
  activity2Completed: false,
  
  // Step 4: Activity 3
  activity3GroupRequest: '',
  activity3Checks: {
    hasRequiredContent: null,
    noExcessPrivacy: null,
    isClearAndSafe: null,
  },
  activity3PeerFeedback: '',
  activity3Completed: false,
  
  // Step 5: Application
  applicationSegments: INITIAL_APPLICATION_SEGMENTS,
  applicationCompleted: false,
  
  // Step 6: Reflection
  reflectionHowToChangeNow: '',
  reflectionThoughtNow: '',
  reflectionMostImportant: '',
  reflectionCompleted: false,
};

export const STEP_ORDER: StepId[] = [
  'start',
  'activity1',
  'activity2',
  'activity3',
  'application',
  'reflection',
];

export const invalidateFromStep = (completedSteps: StepId[], step: StepId): StepId[] => {
  const index = STEP_ORDER.indexOf(step);
  if (index === -1) return completedSteps;

  return completedSteps.filter(
    completedStep => STEP_ORDER.indexOf(completedStep) < index
  );
};

export function useLessonStorage() {
  const [state, setState] = useState<LessonState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        const scenarios = (parsed.activity2Scenarios || INITIAL_ACTIVITY2_SCENARIOS).map((sc: any) => ({
          ...sc,
          isChecked: typeof sc.isChecked === 'boolean' ? sc.isChecked : false,
        }));
        return {
          ...DEFAULT_STATE,
          ...parsed,
          // Ensure scenarios and application segments exist if old structure
          activity2Scenarios: scenarios,
          applicationSegments: parsed.applicationSegments || INITIAL_APPLICATION_SEGMENTS,
        };
      }
    } catch (e) {
      console.warn('Failed to load lesson state from localStorage', e);
    }
    return DEFAULT_STATE;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('Failed to save lesson state to localStorage', e);
    }
  }, [state]);

  const goToStep = (stepId: StepId) => {
    setState(prev => ({
      ...prev,
      currentStep: stepId,
    }));
  };

  const markStepComplete = (stepId: StepId) => {
    setState(prev => {
      const updatedCompleted = prev.completedSteps.includes(stepId)
        ? prev.completedSteps
        : [...prev.completedSteps, stepId];
      return {
        ...prev,
        completedSteps: updatedCompleted,
      };
    });
  };

  // Step 1: Initial Thought (locked after start is completed)
  const setInitialThought = (thought: string) => {
    setState(prev => {
      if (prev.completedSteps.includes('start')) {
        return prev;
      }
      return {
        ...prev,
        initialThought: thought,
      };
    });
  };

  // Step 2: Activity 1
  const toggleActivity1Segment = (id: string) => {
    setState(prev => {
      const exists = prev.activity1SelectedIds.includes(id);
      const updated = exists
        ? prev.activity1SelectedIds.filter(item => item !== id)
        : [...prev.activity1SelectedIds, id];
      return {
        ...prev,
        activity1SelectedIds: updated,
        activity1Completed: false,
        completedSteps: invalidateFromStep(prev.completedSteps, 'activity1'),
      };
    });
  };

  const setActivity1Reason = (reason: string) => {
    setState(prev => ({
      ...prev,
      activity1Reason: reason,
      activity1Completed: false,
      completedSteps: invalidateFromStep(prev.completedSteps, 'activity1'),
    }));
  };

  const completeActivity1 = () => {
    setState(prev => ({
      ...prev,
      activity1Completed: true,
      completedSteps: prev.completedSteps.includes('activity1') ? prev.completedSteps : [...prev.completedSteps, 'activity1'],
      currentStep: 'activity2',
    }));
  };

  // Step 3: Activity 2
  const setActivity2ScenarioIndex = (index: number) => {
    setState(prev => ({
      ...prev,
      activity2CurrentScenarioIndex: Math.max(0, Math.min(prev.activity2Scenarios.length - 1, index)),
    }));
  };

  const updateActivity2Segment = (scenarioIndex: number, segmentId: string, action: ActionType, changedText?: string) => {
    setState(prev => {
      const newScenarios = [...prev.activity2Scenarios];
      const targetScenario = { ...newScenarios[scenarioIndex] };
      // Modifying choices or changed text resets isChecked to false
      targetScenario.isChecked = false;
      targetScenario.segments = targetScenario.segments.map(seg => {
        if (seg.id === segmentId) {
          return {
            ...seg,
            action,
            changedText: action === 'change' ? (changedText !== undefined ? changedText : seg.changedText || '') : undefined,
          };
        }
        return seg;
      });
      newScenarios[scenarioIndex] = targetScenario;
      return {
        ...prev,
        activity2Scenarios: newScenarios,
        activity2Completed: false,
        completedSteps: invalidateFromStep(prev.completedSteps, 'activity2'),
      };
    });
  };

  const setActivity2ScenarioChecked = (scenarioIndex: number, isChecked: boolean) => {
    setState(prev => {
      const newScenarios = [...prev.activity2Scenarios];
      if (!newScenarios[scenarioIndex]) return prev;
      newScenarios[scenarioIndex] = {
        ...newScenarios[scenarioIndex],
        isChecked,
      };
      return {
        ...prev,
        activity2Scenarios: newScenarios,
      };
    });
  };

  const setActivity2ScenarioThought = (scenarioIndex: number, thought: string) => {
    setState(prev => {
      const newScenarios = [...prev.activity2Scenarios];
      if (!newScenarios[scenarioIndex]) return prev;
      newScenarios[scenarioIndex] = {
        ...newScenarios[scenarioIndex],
        stepThought: thought,
      };
      return {
        ...prev,
        activity2Scenarios: newScenarios,
        activity2Completed: false,
        completedSteps: invalidateFromStep(prev.completedSteps, 'activity2'),
      };
    });
  };

  const setActivity2Thought = (thought: string) => {
    setState(prev => ({
      ...prev,
      activity2Thought: thought,
      activity2Completed: false,
      completedSteps: invalidateFromStep(prev.completedSteps, 'activity2'),
    }));
  };

  const completeActivity2 = () => {
    setState(prev => ({
      ...prev,
      activity2Completed: true,
      completedSteps: prev.completedSteps.includes('activity2') ? prev.completedSteps : [...prev.completedSteps, 'activity2'],
      currentStep: 'activity3',
    }));
  };

  // Step 4: Activity 3
  const setActivity3GroupRequest = (text: string) => {
    setState(prev => ({
      ...prev,
      activity3GroupRequest: text,
      activity3Completed: false,
      completedSteps: invalidateFromStep(prev.completedSteps, 'activity3'),
    }));
  };

  const setActivity3Check = (key: keyof Activity3Checks, value: boolean) => {
    setState(prev => ({
      ...prev,
      activity3Checks: {
        ...prev.activity3Checks,
        [key]: value,
      },
    }));
  };

  const setActivity3PeerFeedback = (feedback: string) => {
    setState(prev => ({
      ...prev,
      activity3PeerFeedback: feedback,
    }));
  };

  const completeActivity3 = () => {
    setState(prev => ({
      ...prev,
      activity3Completed: true,
      completedSteps: prev.completedSteps.includes('activity3') ? prev.completedSteps : [...prev.completedSteps, 'activity3'],
    }));
  };

  // Step 5: Application
  const updateApplicationSegment = (segmentId: string, action: ActionType, changedText?: string) => {
    setState(prev => {
      const newSegments = prev.applicationSegments.map(seg => {
        if (seg.id === segmentId) {
          return {
            ...seg,
            action,
            changedText: action === 'change' ? (changedText !== undefined ? changedText : seg.changedText || '') : undefined,
          };
        }
        return seg;
      });
      return {
        ...prev,
        applicationSegments: newSegments,
        applicationCompleted: false,
        completedSteps: invalidateFromStep(prev.completedSteps, 'application'),
      };
    });
  };

  const completeApplication = () => {
    setState(prev => ({
      ...prev,
      applicationCompleted: true,
      completedSteps: prev.completedSteps.includes('application') ? prev.completedSteps : [...prev.completedSteps, 'application'],
      currentStep: 'reflection',
    }));
  };

  // Step 6: Reflection
  const setReflectionField = (field: 'reflectionHowToChangeNow' | 'reflectionThoughtNow' | 'reflectionMostImportant', value: string) => {
    setState(prev => ({
      ...prev,
      [field]: value,
      reflectionCompleted: false,
      completedSteps: invalidateFromStep(prev.completedSteps, 'reflection'),
    }));
  };

  const completeReflection = () => {
    setState(prev => ({
      ...prev,
      reflectionCompleted: true,
      completedSteps: prev.completedSteps.includes('reflection') ? prev.completedSteps : [...prev.completedSteps, 'reflection'],
      currentStep: 'summary',
    }));
  };

  const resetAll = () => {
    localStorage.removeItem(STORAGE_KEY);
    setState(DEFAULT_STATE);
  };

  return {
    state,
    goToStep,
    markStepComplete,
    setInitialThought,
    toggleActivity1Segment,
    setActivity1Reason,
    completeActivity1,
    setActivity2ScenarioIndex,
    updateActivity2Segment,
    setActivity2ScenarioChecked,
    setActivity2ScenarioThought,
    setActivity2Thought,
    completeActivity2,
    setActivity3GroupRequest,
    setActivity3Check,
    setActivity3PeerFeedback,
    completeActivity3,
    updateApplicationSegment,
    completeApplication,
    setReflectionField,
    completeReflection,
    resetAll,
  };
}
