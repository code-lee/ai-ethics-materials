import React from 'react';
import { 
  PlayCircle, 
  Eye, 
  FileEdit, 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  Lock 
} from 'lucide-react';
import { StepId } from '../types';
import { STEPS } from '../data/lessonData';

interface StepNavigationProps {
  currentStep: StepId;
  completedSteps: StepId[];
  onSelectStep: (stepId: StepId) => void;
}

const STEP_ICONS: Record<StepId, React.ElementType> = {
  start: PlayCircle,
  activity1: Eye,
  activity2: FileEdit,
  activity3: Sparkles,
  application: ShieldCheck,
  reflection: CheckCircle2,
  summary: CheckCircle2,
};

export const StepNavigation: React.FC<StepNavigationProps> = ({
  currentStep,
  completedSteps,
  onSelectStep,
}) => {
  // Check if a step is accessible (either completed or is the current step, or is immediately after a completed step)
  const isAccessible = (stepId: StepId, index: number) => {
    if (stepId === currentStep) return true;
    if (completedSteps.includes(stepId)) return true;
    if (index === 0) return true;
    const prevStep = STEPS[index - 1];
    return prevStep && completedSteps.includes(prevStep.id);
  };

  return (
    <div className="w-full bg-white border-b border-[#e1e3e4] px-2.5 sm:px-4 py-2 sm:py-2.5">
      <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-center sm:justify-between gap-1 sm:gap-1.5">
        {STEPS.map((step, idx) => {
          const Icon = STEP_ICONS[step.id];
          const isActive = currentStep === step.id;
          const isCompleted = completedSteps.includes(step.id);
          const accessible = isAccessible(step.id, idx);

          return (
            <React.Fragment key={step.id}>
              <button
                disabled={!accessible}
                onClick={() => onSelectStep(step.id)}
                className={`flex items-center gap-1.5 sm:gap-2 px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap break-keep ${
                  isActive
                    ? 'bg-[#cde5ff] text-[#004b75] shadow-xs font-bold ring-2 ring-[#6cbdfe]/60'
                    : isCompleted
                    ? 'text-[#006398] hover:bg-[#f3f4f5] cursor-pointer'
                    : accessible
                    ? 'text-[#4e616a] hover:bg-[#f3f4f5] cursor-pointer'
                    : 'text-[#d0c6ae] cursor-not-allowed opacity-60'
                }`}
                title={accessible ? `${step.title}로 이동` : '이전 활동을 먼저 완료해 주세요'}
              >
                <div className="relative shrink-0">
                  {accessible ? (
                    <Icon className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isActive ? 'text-[#004b75]' : isCompleted ? 'text-[#006398]' : 'text-[#4e616a]'}`} />
                  ) : (
                    <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#d0c6ae]" />
                  )}
                </div>
                <span className="break-keep">{step.title}</span>
                {isCompleted && !isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#006398] shrink-0"></span>
                )}
              </button>

              {idx < STEPS.length - 1 && (
                <div
                  className={`hidden md:block h-0.5 flex-1 min-w-2 max-w-6 mx-1 transition-colors ${
                    completedSteps.includes(step.id) ? 'bg-[#6cbdfe]' : 'bg-[#e1e3e4]'
                  }`}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};
