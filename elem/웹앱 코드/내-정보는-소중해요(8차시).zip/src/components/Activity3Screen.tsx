import React, { useState } from 'react';
import { 
  Edit3, 
  CheckCircle2, 
  RotateCcw, 
  ArrowRight, 
  ArrowLeft,
  Sparkles, 
  ShieldCheck, 
  AlertCircle,
  FileCheck,
  Users,
  MessageSquareQuote,
  Repeat
} from 'lucide-react';
import { Activity3Checks } from '../types';
import { SchoolPosterIllustration } from './Illustrations';

interface Activity3ScreenProps {
  groupRequest: string;
  checks: Activity3Checks;
  peerFeedback?: string;
  isCompleted: boolean;
  onChangeRequest: (text: string) => void;
  onChangeCheck: (key: keyof Activity3Checks, value: boolean) => void;
  onChangePeerFeedback?: (feedback: string) => void;
  onComplete: () => void;
  onNext: () => void;
}

type Activity3SubStage = 'write' | 'peer_check' | 'revise';

export const Activity3Screen: React.FC<Activity3ScreenProps> = ({
  groupRequest,
  checks,
  peerFeedback = '',
  isCompleted,
  onChangeRequest,
  onChangeCheck,
  onChangePeerFeedback,
  onComplete,
  onNext,
}) => {
  const [subStage, setSubStage] = useState<Activity3SubStage>(() => {
    if (isCompleted) return 'revise';
    // If checks already exist and text exists, allow direct stage
    if (checks.hasRequiredContent !== null && checks.noExcessPrivacy !== null && checks.isClearAndSafe !== null) {
      return 'revise';
    }
    return 'write';
  });

  const [handoverSnapshot, setHandoverSnapshot] = useState<string>(() => groupRequest.trim());
  const [isEditingAfterComplete, setIsEditingAfterComplete] = useState(false);

  // Validation
  const hasRequestText = groupRequest.trim().length > 0;
  const allChecksAnswered = 
    checks.hasRequiredContent !== null &&
    checks.noExcessPrivacy !== null &&
    checks.isClearAndSafe !== null;

  const allChecksYes = 
    checks.hasRequiredContent === true &&
    checks.noExcessPrivacy === true &&
    checks.isClearAndSafe === true;

  const hasAnyReconsider = 
    checks.hasRequiredContent === false ||
    checks.noExcessPrivacy === false ||
    checks.isClearAndSafe === false;

  // Requirement: Normalize whitespace and punctuation to evaluate real text edits
  const normalizeForComparison = (str: string) => {
    return str
      .replace(/[\s.,!?'"~()\[\]{}·_+-]+/g, '')
      .trim();
  };

  // Requirement: If any check is "다시 생각해 보기", must actually modify request after handover (ignoring trivial punctuation/spaces)
  const isModifiedAfterHandover = 
    normalizeForComparison(groupRequest) !== normalizeForComparison(handoverSnapshot) && 
    groupRequest.trim().length > 0;

  const canComplete = hasRequestText && (!hasAnyReconsider || isModifiedAfterHandover);

  const handleStartPeerCheck = () => {
    if (hasRequestText) {
      setHandoverSnapshot(groupRequest.trim());
      setSubStage('peer_check');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleFinishPeerCheck = () => {
    if (allChecksAnswered) {
      setSubStage('revise');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleBackToWrite = () => {
    setSubStage('write');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToPeerCheck = () => {
    setSubStage('peer_check');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCompleteClick = () => {
    if (canComplete) {
      onComplete();
      setIsEditingAfterComplete(false);
    }
  };

  const handleEditAgain = () => {
    setIsEditingAfterComplete(true);
    setHandoverSnapshot(groupRequest.trim());
    setSubStage('revise');
  };

  // If completed and not in active revision mode, show final read-only presentation card
  if (isCompleted && !isEditingAfterComplete) {
    return (
      <div className="w-full max-w-3xl mx-auto py-6 px-4 sm:px-6 flex flex-col items-center animate-in fade-in duration-300">
        <div className="w-full text-center mb-6">
          <div className="inline-flex items-center gap-2 bg-[#cde5ff] text-[#004b75] px-4 py-1.5 rounded-full text-xs sm:text-sm font-bold mb-3">
            <Sparkles className="w-4 h-4 text-[#006398]" />
            <span>활동 3 완성</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#191c1d]">
            우리 모둠의 안전한 AI 요청문
          </h2>
        </div>

        {/* Read-Only Result Card */}
        <div className="w-full bg-white rounded-3xl p-6 sm:p-8 card-shadow border-2 border-[#6cbdfe] mb-8 relative">
          <div className="flex items-center justify-between border-b border-[#e1e3e4] pb-4 mb-6">
            <div className="flex items-center gap-3 text-[#006398]">
              <ShieldCheck className="w-7 h-7 text-[#006398]" />
              <h3 className="font-bold text-lg sm:text-xl text-[#191c1d]">
                우리 모둠이 완성한 요청문
              </h3>
            </div>
            <span className="text-xs font-bold text-[#004b75] bg-[#cde5ff] px-3 py-1 rounded-full">
              모둠 점검 및 수정 완료
            </span>
          </div>

          <div className="bg-[#f8f9fa] rounded-2xl p-6 border border-[#d0c6ae]/40 mb-6">
            <p className="text-base sm:text-xl text-[#191c1d] leading-relaxed font-medium break-keep">
              "{groupRequest}"
            </p>
          </div>

          {/* Feedback note preview if available */}
          {peerFeedback.trim().length > 0 && (
            <div className="bg-[#fff9db] rounded-2xl p-4 border border-[#ffd54f] mb-6 flex items-start gap-3">
              <MessageSquareQuote className="w-5 h-5 text-[#735c00] shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-[#735c00] block mb-1">
                  다른 모둠이 남겨준 점검 의견
                </span>
                <p className="text-xs sm:text-sm text-[#191c1d]">
                  "{peerFeedback}"
                </p>
              </div>
            </div>
          )}

          <div className="flex justify-center">
            <button
              onClick={handleEditAgain}
              className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#4e616a] hover:bg-[#f3f4f5] border border-[#d0c6ae] transition-colors flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>다시 수정하기</span>
            </button>
          </div>
        </div>

        {/* Next Step Action */}
        <div className="w-full flex justify-end">
          <button
            onClick={onNext}
            className="min-h-[56px] px-8 rounded-full font-bold text-base sm:text-lg bg-[#006398] text-white hover:bg-[#004b75] transition-all flex items-center gap-3 shadow-md hover:scale-102 cursor-pointer"
          >
            <span>생활 속에 적용해 보기</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-3xl mx-auto py-6 px-4 sm:px-6 flex flex-col items-center">
      {/* Title & Guidance */}
      <div className="w-full text-center mb-6">
        <span className="text-xs font-bold text-[#006398] bg-[#cde5ff] px-3 py-1 rounded-full inline-block mb-1.5">
          활동 3
        </span>
        <h2 className="text-xl sm:text-2xl font-bold text-[#191c1d] mb-1.5">
          안전한 AI 요청문 만들기
        </h2>
        <p className="text-sm sm:text-base text-[#4d4634] font-medium leading-relaxed break-keep">
          모둠 친구들과 함께 작성하고, 다른 모둠과 서로 점검하며 안전한 요청문을 완성해 보세요.
        </p>
      </div>

      {/* 3-Step Process Indicator */}
      <div className="w-full bg-white rounded-2xl p-3 sm:p-4 border border-[#e1e3e4] card-shadow mb-6">
        <div className="grid grid-cols-3 gap-2 text-center">
          {/* Step 1 */}
          <div
            onClick={() => setSubStage('write')}
            className={`cursor-pointer rounded-xl p-2.5 transition-all flex flex-col items-center justify-center ${
              subStage === 'write'
                ? 'bg-[#cde5ff] text-[#004b75] font-bold shadow-xs'
                : 'text-[#4d4634] hover:bg-[#f8f9fa]'
            }`}
          >
            <span className="text-[11px] sm:text-xs opacity-75">1단계</span>
            <span className="text-xs sm:text-sm font-semibold">우리 모둠 작성</span>
          </div>

          {/* Step 2 */}
          <div
            onClick={() => hasRequestText && setSubStage('peer_check')}
            className={`rounded-xl p-2.5 transition-all flex flex-col items-center justify-center ${
              subStage === 'peer_check'
                ? 'bg-[#ffe087] text-[#735c00] font-bold shadow-xs'
                : hasRequestText
                ? 'cursor-pointer text-[#4d4634] hover:bg-[#f8f9fa]'
                : 'text-[#7f7662]/60 cursor-not-allowed'
            }`}
          >
            <span className="text-[11px] sm:text-xs opacity-75">2단계</span>
            <span className="text-xs sm:text-sm font-semibold">다른 모둠 점검</span>
          </div>

          {/* Step 3 */}
          <div
            onClick={() => allChecksAnswered && setSubStage('revise')}
            className={`rounded-xl p-2.5 transition-all flex flex-col items-center justify-center ${
              subStage === 'revise'
                ? 'bg-[#cde5ff] text-[#004b75] font-bold shadow-xs'
                : allChecksAnswered
                ? 'cursor-pointer text-[#4d4634] hover:bg-[#f8f9fa]'
                : 'text-[#7f7662]/60 cursor-not-allowed'
            }`}
          >
            <span className="text-[11px] sm:text-xs opacity-75">3단계</span>
            <span className="text-xs sm:text-sm font-semibold">의견 확인 및 수정</span>
          </div>
        </div>
      </div>

      {/* Scenario Context Card with Large Top School Poster Illustration */}
      <div className="w-full bg-white rounded-3xl p-6 sm:p-7 card-shadow border border-[#e1e3e4] mb-6 flex flex-col items-center">
        {/* Situation Representative Illustration at Top */}
        <div className="w-full flex justify-center mb-4">
          <SchoolPosterIllustration className="w-full max-w-md h-36 sm:h-44" />
        </div>

        <div className="w-full text-center">
          <div className="inline-flex items-center gap-1.5 bg-[#ffe087]/50 text-[#735c00] px-3.5 py-1 rounded-full text-xs font-bold mb-2">
            <FileCheck className="w-4 h-4" />
            <span>상황: 학급 행사 포스터 표어 및 안내문 만들기</span>
          </div>
          <h3 className="font-bold text-lg sm:text-xl text-[#191c1d] mb-1.5">
            지구를 지키는 분리배출 캠페인 포스터 만들기
          </h3>
          <p className="text-sm sm:text-base text-[#4d4634] font-medium leading-relaxed max-w-xl mx-auto break-keep">
            우리 반 친구들과 함께 교내 환경 캠페인 포스터를 만들려고 해요. AI에게 표어와 안내 문구 만들기를 도와 달라고 요청하려고 해요. 필요한 내용은 넣고 불필요한 개인정보는 뺀 안전한 요청문을 만들어 보세요.
          </p>
        </div>
      </div>

      {/* ================= STAGE 1: 우리 모둠 요청문 작성 ================= */}
      {subStage === 'write' && (
        <div className="w-full bg-[#f3f4f5] rounded-3xl p-6 sm:p-8 card-shadow border border-[#d0c6ae]/40 mb-6 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-xs border border-[#e1e3e4] mb-6">
            <label htmlFor="groupRequestInput" className="block text-base sm:text-lg font-bold text-[#191c1d] mb-3 flex items-center gap-2">
              <Edit3 className="w-5 h-5 text-[#006398]" />
              <span>우리 모둠의 AI 요청문 작성하기</span>
            </label>
            <textarea
              id="groupRequestInput"
              rows={5}
              value={groupRequest}
              onChange={(e) => onChangeRequest(e.target.value)}
              placeholder="예시: 다음 주에 우리 학교에서 분리배출 환경 보호 캠페인을 열어요. 친구들이 쉽게 실천할 수 있는 재미있는 포스터 표어 3가지와 안내 문구를 만들어 줘."
              className="w-full p-4 rounded-xl border-2 border-[#d0c6ae] bg-[#f8f9fa] text-[#191c1d] focus:outline-none focus:border-[#ffd54f] focus:ring-4 focus:ring-[#ffd54f]/30 transition-all text-sm sm:text-base resize-none"
            />
            <p className="text-xs text-[#7f7662] mt-2">
              * 작성을 마친 후 아래 버튼을 눌러 다른 모둠 친구와 기기를 바꾸어 점검을 받아 보세요.
            </p>
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              disabled={!hasRequestText}
              onClick={handleStartPeerCheck}
              className={`min-h-[52px] px-7 rounded-full font-bold text-sm sm:text-base transition-all flex items-center gap-2 shadow-md ${
                hasRequestText
                  ? 'bg-[#006398] text-white hover:bg-[#004b75] hover:scale-102 cursor-pointer'
                  : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-70'
              }`}
            >
              <span>다른 모둠과 바꾸어 점검하기</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ================= STAGE 2: 다른 모둠 상호 점검 ================= */}
      {subStage === 'peer_check' && (
        <div className="w-full bg-[#f3f4f5] rounded-3xl p-6 sm:p-8 card-shadow border border-[#d0c6ae]/40 mb-6 animate-in fade-in duration-200">
          {/* Device Handover Notice Banner */}
          <div className="bg-[#ffe087]/40 border-2 border-[#ffd54f] rounded-2xl p-4 sm:p-5 mb-6 flex items-start gap-3.5">
            <Repeat className="w-6 h-6 text-[#735c00] shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm sm:text-base text-[#735c00] mb-1">
                기기를 다른 모둠 친구에게 건네주세요!
              </h4>
              <p className="text-xs sm:text-sm text-[#4d4634] leading-relaxed break-keep">
                다른 모둠이 작성한 요청문을 꼼꼼히 읽고, 아래 3가지 기준으로 점검한 뒤 따뜻한 조언이나 의견을 남겨 주세요.
              </p>
            </div>
          </div>

          {/* Target Group Request Display */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#e1e3e4] shadow-xs mb-6">
            <div className="flex items-center gap-2 mb-3 text-[#006398]">
              <Users className="w-5 h-5" />
              <h4 className="font-bold text-sm sm:text-base text-[#191c1d]">
                점검할 다른 모둠의 요청문
              </h4>
            </div>
            <div className="bg-[#f8f9fa] rounded-xl p-4 border border-[#d0c6ae]/40">
              <p className="text-sm sm:text-base text-[#191c1d] leading-relaxed font-medium break-keep">
                "{groupRequest}"
              </p>
            </div>
          </div>

          {/* 3 Inspection Check Items */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#e1e3e4] shadow-xs mb-6">
            <h4 className="font-bold text-sm sm:text-base text-[#191c1d] mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[#006398]" />
              <span>3가지 기준으로 점검하기</span>
            </h4>

            <div className="space-y-4">
              {/* Check 1 */}
              <div className="p-3.5 rounded-xl bg-[#f8f9fa] border border-[#e1e3e4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span className="text-sm sm:text-base text-[#191c1d] font-medium">
                  ① 요청에 필요한 내용이 잘 들어 있나요?
                </span>
                <div className="flex gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => onChangeCheck('hasRequiredContent', true)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                      checks.hasRequiredContent === true
                        ? 'bg-[#006398] text-white shadow-xs'
                        : 'bg-white text-[#4d4634] border border-[#d0c6ae] hover:bg-[#e7e8e9]'
                    }`}
                  >
                    그래요
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeCheck('hasRequiredContent', false)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                      checks.hasRequiredContent === false
                        ? 'bg-[#ffe087] text-[#735c00] border border-[#ffd54f] shadow-xs'
                        : 'bg-white text-[#4d4634] border border-[#d0c6ae] hover:bg-[#e7e8e9]'
                    }`}
                  >
                    다시 생각해 보기
                  </button>
                </div>
              </div>

              {/* Check 2 */}
              <div className="p-3.5 rounded-xl bg-[#f8f9fa] border border-[#e1e3e4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span className="text-sm sm:text-base text-[#191c1d] font-medium">
                  ② 나 또는 다른 사람의 개인정보가 불필요하게 들어 있지 않나요?
                </span>
                <div className="flex gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => onChangeCheck('noExcessPrivacy', true)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                      checks.noExcessPrivacy === true
                        ? 'bg-[#006398] text-white shadow-xs'
                        : 'bg-white text-[#4d4634] border border-[#d0c6ae] hover:bg-[#e7e8e9]'
                    }`}
                  >
                    그래요
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeCheck('noExcessPrivacy', false)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                      checks.noExcessPrivacy === false
                        ? 'bg-[#ffe087] text-[#735c00] border border-[#ffd54f] shadow-xs'
                        : 'bg-white text-[#4d4634] border border-[#d0c6ae] hover:bg-[#e7e8e9]'
                    }`}
                  >
                    다시 생각해 보기
                  </button>
                </div>
              </div>

              {/* Check 3 */}
              <div className="p-3.5 rounded-xl bg-[#f8f9fa] border border-[#e1e3e4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span className="text-sm sm:text-base text-[#191c1d] font-medium">
                  ③ 개인정보를 줄이거나 바꾸어도 요청이 잘 전달되나요?
                </span>
                <div className="flex gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => onChangeCheck('isClearAndSafe', true)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                      checks.isClearAndSafe === true
                        ? 'bg-[#006398] text-white shadow-xs'
                        : 'bg-white text-[#4d4634] border border-[#d0c6ae] hover:bg-[#e7e8e9]'
                    }`}
                  >
                    그래요
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeCheck('isClearAndSafe', false)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                      checks.isClearAndSafe === false
                        ? 'bg-[#ffe087] text-[#735c00] border border-[#ffd54f] shadow-xs'
                        : 'bg-white text-[#4d4634] border border-[#d0c6ae] hover:bg-[#e7e8e9]'
                    }`}
                  >
                    다시 생각해 보기
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Feedback Text Input Area */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#e1e3e4] shadow-xs mb-6">
            <label htmlFor="peerFeedbackInput" className="block text-sm sm:text-base font-bold text-[#191c1d] mb-2 flex items-center gap-2">
              <MessageSquareQuote className="w-5 h-5 text-[#735c00]" />
              <span>다른 모둠 친구를 위한 한 줄 의견 남기기 (선택)</span>
            </label>
            <textarea
              id="peerFeedbackInput"
              rows={3}
              value={peerFeedback}
              onChange={(e) => onChangePeerFeedback && onChangePeerFeedback(e.target.value)}
              placeholder="예시: 캠페인의 목적은 잘 전달돼! 학교 이름이나 친구 이름처럼 꼭 필요하지 않은 정보는 빼도 좋을 것 같아."
              className="w-full p-3.5 rounded-xl border border-[#d0c6ae] bg-[#f8f9fa] text-[#191c1d] focus:outline-none focus:border-[#ffd54f] focus:ring-4 focus:ring-[#ffd54f]/30 transition-all text-xs sm:text-sm resize-none"
            />
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleBackToWrite}
              className="px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-[#4e616a] hover:bg-white border border-[#d0c6ae] transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>작성 화면으로</span>
            </button>

            <button
              type="button"
              disabled={!allChecksAnswered}
              onClick={handleFinishPeerCheck}
              className={`min-h-[52px] px-7 rounded-full font-bold text-sm sm:text-base transition-all flex items-center gap-2 shadow-md ${
                allChecksAnswered
                  ? 'bg-[#006398] text-white hover:bg-[#004b75] hover:scale-102 cursor-pointer'
                  : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-70'
              }`}
            >
              <span>기기 돌려주고 의견 전달하기</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {!allChecksAnswered && (
            <p className="text-xs text-[#7f7662] mt-3 text-center">
              위 3가지 점검 항목에 모두 답하면 기기를 돌려주고 의견을 전달할 수 있어요.
            </p>
          )}
        </div>
      )}

      {/* ================= STAGE 3: 의견 확인 및 요청문 수정 ================= */}
      {subStage === 'revise' && (
        <div className="w-full bg-[#f3f4f5] rounded-3xl p-6 sm:p-8 card-shadow border border-[#d0c6ae]/40 mb-6 animate-in fade-in duration-200">
          {/* Handover Back Banner */}
          <div className="bg-[#cde5ff]/60 border-2 border-[#6cbdfe] rounded-2xl p-4 sm:p-5 mb-6 flex items-start gap-3.5">
            <Users className="w-6 h-6 text-[#004b75] shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm sm:text-base text-[#004b75] mb-1">
                기기를 우리 모둠으로 돌려받았어요!
              </h4>
              <p className="text-xs sm:text-sm text-[#191c1d] leading-relaxed break-keep">
                다른 모둠 친구들이 남겨준 점검 결과와 의견을 확인하고, 우리 모둠의 요청문을 더 안전하게 수정해 보세요.
              </p>
            </div>
          </div>

          {/* Peer Feedback Summary Card */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#e1e3e4] shadow-xs mb-6">
            <h4 className="font-bold text-sm sm:text-base text-[#191c1d] mb-3.5 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[#006398]" />
              <span>다른 모둠의 점검 결과</span>
            </h4>

            {/* 3 Checks Summary */}
            <div className="space-y-2.5 mb-4">
              <div className="p-3 rounded-xl bg-[#f8f9fa] border border-[#e1e3e4] flex items-center justify-between text-xs sm:text-sm">
                <span className="text-[#191c1d] font-medium">
                  ① 꼭 필요한 내용이 들어 있나요?
                </span>
                <span className={`px-2.5 py-1 rounded-md font-bold text-xs ${
                  checks.hasRequiredContent === true
                    ? 'bg-[#cde5ff] text-[#004b75]'
                    : checks.hasRequiredContent === false
                    ? 'bg-[#ffe087] text-[#735c00]'
                    : 'bg-[#e1e3e4] text-[#7f7662]'
                }`}>
                  {checks.hasRequiredContent === true ? '그래요 👍' : checks.hasRequiredContent === false ? '다시 생각해 보기 💡' : '미점검'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-[#f8f9fa] border border-[#e1e3e4] flex items-center justify-between text-xs sm:text-sm">
                <span className="text-[#191c1d] font-medium">
                  ② 불필요한 개인정보가 없나요?
                </span>
                <span className={`px-2.5 py-1 rounded-md font-bold text-xs ${
                  checks.noExcessPrivacy === true
                    ? 'bg-[#cde5ff] text-[#004b75]'
                    : checks.noExcessPrivacy === false
                    ? 'bg-[#ffe087] text-[#735c00]'
                    : 'bg-[#e1e3e4] text-[#7f7662]'
                }`}>
                  {checks.noExcessPrivacy === true ? '그래요 👍' : checks.noExcessPrivacy === false ? '다시 생각해 보기 💡' : '미점검'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-[#f8f9fa] border border-[#e1e3e4] flex items-center justify-between text-xs sm:text-sm">
                <span className="text-[#191c1d] font-medium">
                  ③ 줄이거나 바꾸어도 잘 전달되나요?
                </span>
                <span className={`px-2.5 py-1 rounded-md font-bold text-xs ${
                  checks.isClearAndSafe === true
                    ? 'bg-[#cde5ff] text-[#004b75]'
                    : checks.isClearAndSafe === false
                    ? 'bg-[#ffe087] text-[#735c00]'
                    : 'bg-[#e1e3e4] text-[#7f7662]'
                }`}>
                  {checks.isClearAndSafe === true ? '그래요 👍' : checks.isClearAndSafe === false ? '다시 생각해 보기 💡' : '미점검'}
                </span>
              </div>
            </div>

            {/* Friend's Custom Comment if exists */}
            {peerFeedback.trim().length > 0 && (
              <div className="p-4 rounded-xl bg-[#fff9db] border border-[#ffd54f]">
                <span className="text-xs font-bold text-[#735c00] block mb-1 flex items-center gap-1.5">
                  <MessageSquareQuote className="w-4 h-4" />
                  <span>친구 모둠의 한 줄 조언:</span>
                </span>
                <p className="text-xs sm:text-sm text-[#191c1d] font-medium leading-relaxed break-keep">
                  "{peerFeedback}"
                </p>
              </div>
            )}
          </div>

          {/* Reconsideration Guidance Note if any check was false */}
          {hasAnyReconsider && (
            <div className={`mb-6 p-4 rounded-2xl border flex items-start gap-3 transition-colors ${
              isModifiedAfterHandover 
                ? 'bg-[#e8f5e9] border-[#a5d6a7]' 
                : 'bg-[#ffe087]/40 border-[#ffd54f]'
            }`}>
              {isModifiedAfterHandover ? (
                <CheckCircle2 className="w-5 h-5 text-[#2e7d32] shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-[#735c00] shrink-0 mt-0.5" />
              )}
              <div>
                <p className={`text-xs sm:text-sm font-semibold leading-relaxed ${
                  isModifiedAfterHandover ? 'text-[#2e7d32]' : 'text-[#735c00]'
                }`}>
                  {isModifiedAfterHandover
                    ? '다른 모둠의 의견을 반영하여 요청문이 수정되었어요! 아래 「완성하기」 버튼을 눌러 다음 단계로 이동하세요.'
                    : '다른 모둠의 의견을 반영하여 요청문을 한 번 수정해 주세요.'}
                </p>
              </div>
            </div>
          )}

          {/* Revised Request Input Area */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-xs border border-[#e1e3e4] mb-6">
            <label htmlFor="groupRequestEditInput" className="block text-base sm:text-lg font-bold text-[#191c1d] mb-3 flex items-center gap-2">
              <Edit3 className="w-5 h-5 text-[#006398]" />
              <span>우리 모둠 요청문 고치기</span>
            </label>
            <textarea
              id="groupRequestEditInput"
              rows={5}
              value={groupRequest}
              onChange={(e) => onChangeRequest(e.target.value)}
              placeholder="친구 모둠의 의견을 반영하여 안전하게 수정한 요청문을 작성해 보세요."
              className="w-full p-4 rounded-xl border-2 border-[#d0c6ae] bg-[#f8f9fa] text-[#191c1d] focus:outline-none focus:border-[#ffd54f] focus:ring-4 focus:ring-[#ffd54f]/30 transition-all text-sm sm:text-base resize-none"
            />
            <p className="text-xs text-[#7f7662] mt-2">
              * 요청문을 고친 뒤 아래 「완성하기」 버튼을 누르면 활동3이 완료됩니다.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleBackToPeerCheck}
                className="px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-[#4e616a] hover:bg-white border border-[#d0c6ae] transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>점검 화면 다시 보기</span>
              </button>

              <button
                type="button"
                disabled={!canComplete}
                onClick={handleCompleteClick}
                className={`min-h-[56px] px-8 rounded-full font-bold text-base sm:text-lg transition-all flex items-center gap-3 shadow-md ${
                  canComplete
                    ? 'bg-[#006398] text-white hover:bg-[#004b75] hover:scale-102 cursor-pointer'
                    : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-70'
                }`}
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>완성하기</span>
              </button>
            </div>

            {!canComplete && hasAnyReconsider && !isModifiedAfterHandover && (
              <p className="text-xs text-[#735c00] font-medium text-right">
                * 다른 모둠의 의견을 반영하여 요청문을 한 번 수정한 후 완성할 수 있어요.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
