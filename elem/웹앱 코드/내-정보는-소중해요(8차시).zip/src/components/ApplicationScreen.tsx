import React, { useState } from 'react';
import { 
  Clock, 
  HelpCircle, 
  Users, 
  CheckCircle, 
  Send, 
  Check, 
  X, 
  Edit2, 
  Sparkles,
  ArrowRight,
  SearchCheck,
  AlertCircle
} from 'lucide-react';
import { TextSegment, ActionType } from '../types';
import { PreSendCheckIllustration } from './Illustrations';
import { evaluateChangedText } from '../utils/privacyValidator';

interface ApplicationScreenProps {
  segments: TextSegment[];
  isCompleted: boolean;
  onUpdateSegment: (segmentId: string, action: ActionType, changedText?: string) => void;
  onComplete: () => void;
  onNext: () => void;
}

export const ApplicationScreen: React.FC<ApplicationScreenProps> = ({
  segments,
  isCompleted,
  onUpdateSegment,
  onComplete,
  onNext,
}) => {
  const [selectedSegmentId, setSelectedSegmentId] = useState<string | null>(null);
  const [editingInputText, setEditingInputText] = useState<string>('');
  const [showHintForSelected, setShowHintForSelected] = useState<boolean>(false);
  const [isChecked, setIsChecked] = useState<boolean>(false);

  const selectedSegment = segments.find(s => s.id === selectedSegmentId);

  // Rigorous segment acceptability check:
  // 1. Action must be in acceptableActions (or default rules)
  // 2. If action is 'change', the changedText must NOT contain specific private information
  const checkSegmentDetailed = (seg: TextSegment) => {
    const acceptable = seg.acceptableActions || (seg.isPrivacySensitive ? ['remove', 'change'] : ['keep']);
    const isActionOk = acceptable.includes(seg.action);
    if (!isActionOk) {
      return {
        isAcceptable: false,
        hint: seg.questionHint || '이 정보가 꼭 필요한지 한 번 더 생각해 볼까요?'
      };
    }
    if (seg.action === 'change') {
      const valRes = evaluateChangedText(seg.originalText, seg.changedText, seg.id);
      if (!valRes.isValid) {
        return {
          isAcceptable: false,
          hint: valRes.suggestedHint || '덜 구체적으로 바꿔 볼까요? 이 정보가 여전히 너무 구체적이지 않을까요?'
        };
      }
    }
    return { isAcceptable: true };
  };

  const isSegmentAcceptable = (seg: TextSegment) => {
    return checkSegmentDetailed(seg).isAcceptable;
  };

  const handleSelectSegment = (id: string) => {
    setSelectedSegmentId(id);
    setShowHintForSelected(false);
    const seg = segments.find(s => s.id === id);
    if (seg && seg.changedText) {
      setEditingInputText(seg.changedText);
    } else {
      setEditingInputText('');
    }
  };

  const handleActionClick = (action: ActionType) => {
    if (!selectedSegmentId) return;
    setIsChecked(false);
    if (action === 'change') {
      const textToSet = editingInputText.trim() ? editingInputText : (selectedSegment?.changedText || '');
      onUpdateSegment(selectedSegmentId, 'change', textToSet);
    } else {
      onUpdateSegment(selectedSegmentId, action);
    }
  };

  const handleApplyChange = () => {
    if (!selectedSegmentId) return;
    setIsChecked(false);
    onUpdateSegment(selectedSegmentId, 'change', editingInputText);
  };

  // Build sentences
  const originalSentence = segments.map(s => s.originalText).join(' ');
  const editedSentence = segments
    .filter(s => s.action !== 'remove')
    .map(s => (s.action === 'change' && s.changedText?.trim() ? s.changedText.trim() : s.originalText))
    .join(' ');

  // Completion criteria for Life Application:
  // 1. All segments judged ('keep' | 'remove' | 'change')
  // 2. All 'change' segments have non-empty changedText (after trim()) and pass privacy evaluation
  // 3. Checked via 점검하기
  // 4. All segments acceptable
  const allSegmentsJudged = segments.every(s => s.action === 'keep' || s.action === 'remove' || s.action === 'change');
  const allChangesValid = segments.every(s => s.action !== 'change' || (s.changedText !== undefined && s.changedText.trim().length > 0));
  const canPerformCheck = allSegmentsJudged && allChangesValid;
  const allAcceptable = segments.every(isSegmentAcceptable);

  const handleCheck = () => {
    if (!canPerformCheck) return;
    setIsChecked(true);
    setSelectedSegmentId(null);
  };

  const reconsiderationSegments = isChecked
    ? segments
        .map(seg => ({ seg, check: checkSegmentDetailed(seg) }))
        .filter(item => !item.check.isAcceptable)
    : [];

  const canFinish = isChecked && allAcceptable;

  const handleFinish = () => {
    onComplete();
    onNext();
  };

  return (
    <div className="w-full max-w-4xl mx-auto py-6 px-4 sm:px-6 flex flex-col items-center">
      {/* Step Header */}
      <div className="text-center mb-6 max-w-2xl">
        <span className="text-xs font-bold text-[#006398] bg-[#cde5ff] px-3 py-1 rounded-full inline-block mb-1.5">
          생활 속 적용
        </span>
        <h2 className="text-2xl sm:text-3xl font-bold text-[#191c1d] mb-1.5">
          전송하기 전에 3초!
        </h2>
        <p className="text-sm sm:text-base text-[#4d4634] font-medium leading-relaxed break-keep">
          일상 속에서 AI에게 질문을 보낼 때, 불필요한 개인정보가 들어 있지 않은지 점검해 봅시다.
        </p>
      </div>

      {/* Hero Visual & Inspection Overview Card with Large Top Illustration */}
      <div className="w-full bg-white rounded-3xl p-6 sm:p-8 card-shadow border border-[#e1e3e4] mb-6 flex flex-col items-center">
        {/* Top Representative Illustration */}
        <div className="w-full flex justify-center mb-5">
          <PreSendCheckIllustration className="w-full max-w-md h-40 sm:h-48" />
        </div>

        <div className="w-full text-center">
          <div className="inline-flex items-center gap-1.5 bg-[#cde5ff] text-[#004b75] px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-bold mb-4">
            <Clock className="w-4 h-4" />
            <span>전송 전 3초 점검 원칙</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-[#191c1d] text-left">
            <div className="bg-[#f8f9fa] p-3.5 rounded-2xl border border-[#e1e3e4]">
              <span className="font-bold text-[#735c00] text-sm block mb-1">① 꼭 필요한가?</span>
              <span className="text-[#4d4634] text-xs leading-relaxed">이 질문에 꼭 필요한 내용인지 생각해요.</span>
            </div>
            <div className="bg-[#f8f9fa] p-3.5 rounded-2xl border border-[#e1e3e4]">
              <span className="font-bold text-[#006398] text-sm block mb-1">② 개인정보인가?</span>
              <span className="text-[#4d4634] text-xs leading-relaxed">나 또는 다른 사람의 개인정보가 불필요하게 들어 있는지 살펴봐요.</span>
            </div>
            <div className="bg-[#f8f9fa] p-3.5 rounded-2xl border border-[#e1e3e4]">
              <span className="font-bold text-[#241a00] text-sm block mb-1">③ 안전하게 바꿀까?</span>
              <span className="text-[#4d4634] text-xs leading-relaxed">줄이거나 바꾸어도 뜻이 잘 통하는지 확인해요.</span>
            </div>
          </div>
        </div>
      </div>

      {/* Practical Scenario Practice */}
      <div className="w-full bg-[#f3f4f5] rounded-3xl p-6 sm:p-8 card-shadow border border-[#d0c6ae]/40 mb-8">
        <div className="flex items-center gap-2 mb-2">
          <Clock className="w-5 h-5 text-[#006398]" />
          <h3 className="text-base sm:text-lg font-bold text-[#191c1d]">
            실전 요청문 점검하기
          </h3>
        </div>
        <p className="text-xs sm:text-sm text-[#4d4634] mb-6">
          전송하기 전에 아래 요청문을 살펴보고 [남기기], [빼기], [바꾸기]로 안전하게 고쳐 보세요.
        </p>

        {/* Clickable Segments Box */}
        <div className="bg-white rounded-2xl p-6 shadow-xs border border-[#e1e3e4] text-center mb-6">
          <div className="text-base sm:text-lg text-[#191c1d] leading-relaxed flex flex-wrap justify-center items-center gap-2">
            {segments.map((seg) => {
              const isSelected = selectedSegmentId === seg.id;
              let badgeColor = '';
              let actionLabel = '';

              if (seg.action === 'keep') {
                badgeColor = 'bg-[#cde5ff] text-[#004b75] border-[#6cbdfe]';
                actionLabel = '남김';
              } else if (seg.action === 'remove') {
                badgeColor = 'bg-[#f3f4f5] text-[#7f7662] line-through border-[#d0c6ae] opacity-60';
                actionLabel = '뺌';
              } else if (seg.action === 'change') {
                badgeColor = 'bg-[#ffe087] text-[#241a00] border-[#ffd54f] font-semibold';
                actionLabel = '바꿈';
              }

              return (
                <button
                  key={seg.id}
                  onClick={() => handleSelectSegment(seg.id)}
                  className={`relative inline-flex flex-col items-center p-2.5 rounded-xl cursor-pointer transition-all border-2 ${
                    isSelected
                      ? 'bg-[#fff9db] border-[#ffd54f] shadow-md scale-103 ring-2 ring-[#ffd54f]/50'
                      : seg.action !== 'none'
                      ? `${badgeColor} border-solid`
                      : 'bg-[#f8f9fa] border-dashed border-[#d0c6ae] hover:bg-[#e7e8e9] hover:border-[#735c00]'
                  }`}
                >
                  <span className="text-sm sm:text-base text-[#191c1d]">
                    {seg.action === 'change' && seg.changedText ? (
                      <span className="font-bold text-[#735c00]">
                        "{seg.changedText}"
                      </span>
                    ) : (
                      seg.originalText
                    )}
                  </span>
                  {seg.action !== 'none' && (
                    <span className="text-[10px] font-bold mt-1 px-1.5 py-0.5 rounded bg-white/80">
                      {actionLabel}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Action buttons */}
          {selectedSegment && (
            <div className="mt-6 pt-5 border-t border-[#f3f4f5] animate-in fade-in duration-200">
              <p className="text-xs text-[#4e616a] mb-3">
                선택한 부분: <strong className="text-[#191c1d]">"{selectedSegment.originalText}"</strong>
              </p>

              <div className="flex flex-wrap justify-center gap-3">
                <button
                  type="button"
                  onClick={() => handleActionClick('keep')}
                  className={`px-5 py-2.5 rounded-full flex items-center gap-1.5 font-bold text-sm transition-all ${
                    selectedSegment.action === 'keep'
                      ? 'bg-[#006398] text-white shadow-md'
                      : 'bg-[#cde5ff] text-[#004b75] hover:bg-[#94ccff]'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>남기기</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleActionClick('remove')}
                  className={`px-5 py-2.5 rounded-full flex items-center gap-1.5 font-bold text-sm transition-all border ${
                    selectedSegment.action === 'remove'
                      ? 'bg-[#4e616a] text-white border-[#4e616a] shadow-md'
                      : 'bg-white text-[#4d4634] border-[#d0c6ae] hover:bg-[#f3f4f5]'
                  }`}
                >
                  <X className="w-4 h-4" />
                  <span>빼기</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleActionClick('change')}
                  className={`px-5 py-2.5 rounded-full flex items-center gap-1.5 font-bold text-sm transition-all ${
                    selectedSegment.action === 'change'
                      ? 'bg-[#ffd54f] text-[#735c00] border-2 border-[#735c00] shadow-md'
                      : 'bg-[#ffe087] text-[#241a00] hover:bg-[#ffd54f]'
                  }`}
                >
                  <Edit2 className="w-4 h-4" />
                  <span>바꾸기</span>
                </button>
              </div>

              {/* Optional Question Hint Toggle */}
              {(selectedSegment.questionHint || selectedSegment.hint) && (
                <div className="mt-4 flex flex-col items-center">
                  <button
                    type="button"
                    onClick={() => setShowHintForSelected(prev => !prev)}
                    className="inline-flex items-center gap-1 text-xs text-[#735c00] bg-[#fff9db] px-3 py-1.5 rounded-full border border-[#ffd54f]/70 hover:bg-[#fffae8] transition-colors"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span>{showHintForSelected ? '힌트 접기' : '생각 힌트 보기'}</span>
                  </button>

                  {showHintForSelected && (
                    <div className="mt-2 p-3 bg-[#fff9db] rounded-xl border border-[#ffd54f] text-xs text-[#735c00] max-w-md animate-in fade-in duration-150">
                      💡 {selectedSegment.questionHint || selectedSegment.hint}
                    </div>
                  )}
                </div>
              )}

              {selectedSegment.action === 'change' && (
                <div className="mt-4 max-w-md mx-auto bg-[#fff9db] p-3.5 rounded-2xl border border-[#ffd54f] text-left">
                  <label htmlFor="appChangeInput" className="block text-xs font-bold text-[#735c00] mb-1.5">
                    개인정보가 드러나지 않게 바꾸어 적어 보세요:
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="appChangeInput"
                      type="text"
                      value={editingInputText}
                      onChange={(e) => setEditingInputText(e.target.value)}
                      placeholder="개인정보가 드러나지 않게 바꾸어 적어 보세요."
                      className="flex-1 rounded-xl border border-[#d0c6ae] bg-white px-3 py-2 text-sm text-[#191c1d] focus:outline-none focus:ring-2 focus:ring-[#ffd54f]"
                    />
                    <button
                      type="button"
                      onClick={handleApplyChange}
                      className="bg-[#735c00] text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-[#574500]"
                    >
                      적용
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* 내 선택 점검하기 Button */}
        <div className="flex flex-col items-center mb-6">
          <button
            type="button"
            disabled={!canPerformCheck}
            onClick={handleCheck}
            className={`min-h-[50px] px-8 rounded-full font-bold text-sm sm:text-base transition-all flex items-center gap-2 shadow-xs ${
              canPerformCheck
                ? 'bg-[#735c00] text-white hover:bg-[#574500] hover:scale-102 cursor-pointer'
                : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-60'
            }`}
          >
            <SearchCheck className="w-5 h-5" />
            <span>내 선택 점검하기</span>
          </button>
        </div>

        {/* Reconsideration Guidance */}
        {isChecked && reconsiderationSegments.length > 0 && (
          <div className="mb-6 space-y-3 animate-in fade-in duration-200">
            <div className="bg-[#fff9db] border border-[#ffd54f] rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3 text-[#735c00]">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <h4 className="font-bold text-sm sm:text-base">
                  한 번 더 생각해 봐요
                </h4>
              </div>
              <p className="text-xs sm:text-sm text-[#4d4634] mb-3">
                아래 정보 조각을 누르고 질문을 생각하며 선택을 다시 고민해 보세요.
              </p>
              <div className="space-y-2.5">
                {reconsiderationSegments.map(({ seg, check }) => (
                  <button
                    key={seg.id}
                    type="button"
                    onClick={() => handleSelectSegment(seg.id)}
                    className="w-full text-left bg-white p-3.5 rounded-xl border border-[#ffd54f]/80 hover:bg-[#fffdf5] transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div>
                      <span className="text-xs font-bold text-[#735c00] block mb-0.5">
                        "{seg.action === 'change' && seg.changedText ? seg.changedText : seg.originalText}"
                      </span>
                      <p className="text-xs sm:text-sm text-[#191c1d]">
                        {check.hint}
                      </p>
                    </div>
                    <span className="text-xs font-bold text-[#006398] underline shrink-0">
                      다시 선택하기
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Success confirmation banner */}
        {isChecked && reconsiderationSegments.length === 0 && (
          <div className="mb-6 p-5 rounded-2xl bg-[#e8f5e9] border-2 border-[#4caf50] card-shadow flex flex-col sm:flex-row items-start sm:items-center gap-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-10 h-10 rounded-full bg-[#2e7d32] text-white flex items-center justify-center shrink-0 shadow-xs">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-[#1b5e20] bg-[#c8e6c9] px-2.5 py-0.5 rounded-full">
                  점검 완료!
                </span>
                <h4 className="font-bold text-sm sm:text-base text-[#1b5e20]">
                  잘했어요! 필요한 정보는 남기고, 개인정보는 빼거나 안전하게 바꾸었어요.
                </h4>
              </div>
              <p className="text-xs sm:text-sm text-[#2e7d32] font-medium leading-relaxed">
                고친 요청문을 확인하고 아래 [전송 준비 완료] 버튼을 눌러 다음 단계로 이동하세요.
              </p>
            </div>
          </div>
        )}

        {/* Live Comparison Box */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-2xl p-4 border border-[#e1e3e4]">
            <span className="text-xs font-bold text-[#ba1a1a] bg-[#ffdad6] px-2.5 py-1 rounded-full inline-block mb-2">
              편집 전 요청문
            </span>
            <p className="text-xs sm:text-sm text-[#4d4634] leading-relaxed">
              "{originalSentence}"
            </p>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-[#6cbdfe]">
            <span className="text-xs font-bold text-[#006398] bg-[#cde5ff] px-2.5 py-1 rounded-full inline-block mb-2 flex items-center gap-1 w-fit">
              <Check className="w-3 h-3" />
              <span>내가 고친 요청문</span>
            </span>
            <p className="text-xs sm:text-sm text-[#191c1d] font-semibold leading-relaxed">
              "{editedSentence}"
            </p>
          </div>
        </div>
      </div>

      {/* Action Ready Button */}
      <div className="w-full flex justify-end">
        <button
          disabled={!canFinish}
          onClick={handleFinish}
          className={`min-h-[56px] px-8 rounded-full font-bold text-base sm:text-lg transition-all flex items-center gap-3 shadow-md ${
            canFinish
              ? 'bg-[#006398] text-white hover:bg-[#004b75] hover:scale-102 cursor-pointer'
              : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-70'
          }`}
        >
          <span>전송 준비 완료</span>
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
