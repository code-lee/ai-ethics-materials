import React from 'react';
import { 
  History, 
  MessageSquare, 
  Lightbulb, 
  Brain, 
  CheckCircle,
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { START_VIRTUAL_REQUEST } from '../data/lessonData';
import { ReflectionCompareIllustration } from './Illustrations';

interface ReflectionScreenProps {
  initialThought: string;
  howToChangeNow: string;
  thoughtNow: string;
  mostImportant: string;
  onChangeHowToChangeNow: (val: string) => void;
  onChangeThoughtNow: (val: string) => void;
  onChangeMostImportant: (val: string) => void;
  onComplete: () => void;
}

export const ReflectionScreen: React.FC<ReflectionScreenProps> = ({
  initialThought,
  howToChangeNow,
  thoughtNow,
  mostImportant,
  onChangeHowToChangeNow,
  onChangeThoughtNow,
  onChangeMostImportant,
  onComplete,
}) => {
  const canComplete =
    howToChangeNow.trim().length > 0 &&
    thoughtNow.trim().length > 0 &&
    mostImportant.trim().length > 0;

  return (
    <div className="w-full max-w-4xl mx-auto py-6 px-4 sm:px-6 flex flex-col items-center">
      {/* Title */}
      <div className="w-full text-center mb-6">
        <span className="text-xs font-bold text-[#006398] bg-[#cde5ff] px-3 py-1 rounded-full inline-block mb-1.5">
          돌아보기
        </span>
        <h2 className="text-2xl sm:text-3xl font-bold text-[#191c1d] mb-1.5">
          나의 생각 돌아보기
        </h2>
        <p className="text-sm sm:text-base text-[#4d4634] font-medium leading-relaxed break-keep">
          활동을 마치며 배운 점을 돌아보고, 앞으로 AI를 사용할 때 지킬 나의 다짐을 적어 보세요.
        </p>
      </div>

      {/* Hero Visual Banner: Thought Growth Comparison */}
      <div className="w-full bg-white rounded-3xl p-5 sm:p-7 card-shadow border border-[#e1e3e4] mb-6 flex flex-col sm:flex-row items-center gap-5 sm:gap-7">
        <div className="shrink-0">
          <ReflectionCompareIllustration className="w-28 h-28 sm:w-36 sm:h-36" />
        </div>
        <div className="flex-1 text-center sm:text-left">
          <span className="text-xs font-bold text-[#735c00] bg-[#fff9db] border border-[#ffd54f] px-3 py-1 rounded-full inline-block mb-2">
            배움과 성장의 시간
          </span>
          <h3 className="text-lg sm:text-xl font-bold text-[#191c1d] mb-1.5">
            처음 생각과 지금의 생각 비교하기
          </h3>
          <p className="text-xs sm:text-sm text-[#4d4634] leading-relaxed break-keep">
            수업을 시작할 때 가졌던 생각과 여러 편집 활동을 거치며 달라진 나의 생각을 차분하게 비교하고, 앞으로 AI를 사용할 때 지킬 다짐을 완성해 봅시다.
          </p>
        </div>
      </div>

      {/* Main Desk Container */}
      <div className="w-full bg-[#f3f4f5] rounded-3xl p-6 sm:p-8 card-shadow border border-[#d0c6ae]/40 mb-8">
        {/* Section 1: 수업을 시작할 때 */}
        <section className="mb-8">
          <h3 className="text-base sm:text-lg font-bold text-[#735c00] mb-3.5 flex items-center gap-2">
            <History className="w-5 h-5 text-[#735c00]" />
            <span>수업을 시작할 때</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Initial Prompt */}
            <div className="bg-white rounded-2xl p-5 border border-[#e1e3e4] flex flex-col shadow-xs">
              <span className="text-xs font-bold text-[#006398] mb-2 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>처음 마주한 가상 요청문</span>
              </span>
              <p className="text-sm text-[#4d4634] leading-relaxed flex-1 break-keep">
                "{START_VIRTUAL_REQUEST}"
              </p>
            </div>

            {/* Initial Thought */}
            <div className="bg-[#ffe087]/30 rounded-2xl p-5 border border-[#ffd54f]/60 flex flex-col shadow-xs">
              <span className="text-xs font-bold text-[#735c00] mb-2 flex items-center gap-1.5">
                <Lightbulb className="w-3.5 h-3.5" />
                <span>수업을 시작할 때 나는 이렇게 생각했어요</span>
              </span>
              <div className="flex-1 flex items-center">
                <p className="text-sm sm:text-base font-bold text-[#735c00] bg-white/90 p-3 rounded-xl w-full border border-[#ffd54f]/40">
                  {initialThought || '선택한 답변이 여기에 표시됩니다.'}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Section 2: 최종 돌아보기 질문들 */}
        <section className="space-y-5">
          <h3 className="text-base sm:text-lg font-bold text-[#191c1d] mb-3 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#006398]" />
            <span>오늘의 배움 정리하기</span>
          </h3>

          {/* Question 1 */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#e1e3e4] shadow-xs">
            <label htmlFor="howToChangeInput" className="block text-sm sm:text-base font-bold text-[#191c1d] mb-2.5">
              1. 처음 마주했던 요청문을 지금 다시 본다면 어떤 부분을 고치고 싶나요?
            </label>
            <textarea
              id="howToChangeInput"
              rows={3}
              value={howToChangeNow}
              onChange={(e) => onChangeHowToChangeNow(e.target.value)}
              placeholder="지금 생각을 적어 보세요."
              className="w-full p-4 text-sm sm:text-base rounded-xl border border-[#d0c6ae] bg-[#f8f9fa] text-[#191c1d] focus:outline-none focus:border-[#ffd54f] focus:ring-4 focus:ring-[#ffd54f]/30 transition-all resize-none"
            />
          </div>

          {/* Question 2 */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#e1e3e4] shadow-xs">
            <label htmlFor="thoughtNowInput" className="block text-sm sm:text-base font-bold text-[#191c1d] mb-2.5">
              2. "AI에게 도움을 받으려면 내 정보를 모두 알려 줘야 할까?"에 대해 지금은 어떻게 생각하나요?
            </label>
            <textarea
              id="thoughtNowInput"
              rows={3}
              value={thoughtNow}
              onChange={(e) => onChangeThoughtNow(e.target.value)}
              placeholder="지금 생각을 적어 보세요."
              className="w-full p-4 text-sm sm:text-base rounded-xl border border-[#d0c6ae] bg-[#f8f9fa] text-[#191c1d] focus:outline-none focus:border-[#ffd54f] focus:ring-4 focus:ring-[#ffd54f]/30 transition-all resize-none"
            />
          </div>

          {/* Question 3 */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#e1e3e4] shadow-xs">
            <label htmlFor="mostImportantInput" className="block text-sm sm:text-base font-bold text-[#191c1d] mb-2.5">
              3. AI에게 정보를 입력하거나 공유할 때 가장 중요하다고 생각하는 것은 무엇인가요?
            </label>
            <textarea
              id="mostImportantInput"
              rows={3}
              value={mostImportant}
              onChange={(e) => onChangeMostImportant(e.target.value)}
              placeholder="가장 중요하다고 생각한 점을 적어 보세요."
              className="w-full p-4 text-sm sm:text-base rounded-xl border border-[#d0c6ae] bg-[#f8f9fa] text-[#191c1d] focus:outline-none focus:border-[#ffd54f] focus:ring-4 focus:ring-[#ffd54f]/30 transition-all resize-none"
            />
          </div>
        </section>
      </div>

      {/* Action Button */}
      <div className="w-full flex flex-col items-end gap-2">
        <button
          disabled={!canComplete}
          onClick={onComplete}
          className={`min-h-[56px] px-10 rounded-full font-bold text-base sm:text-lg transition-all flex items-center gap-3 shadow-md ${
            canComplete
              ? 'bg-[#006398] text-white hover:bg-[#004b75] hover:scale-102 cursor-pointer'
              : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-70'
          }`}
        >
          <CheckCircle className="w-5 h-5" />
          <span>활동 마치기</span>
        </button>

        {!canComplete && (
          <p className="text-xs text-[#7f7662]">
            3가지 질문에 생각을 모두 적으면 학습을 마칠 수 있어요.
          </p>
        )}
      </div>
    </div>
  );
};
