import React, { useState } from 'react';
import { 
  Bot, 
  Check, 
  X, 
  Edit2, 
  ArrowRight, 
  ArrowLeft, 
  Sparkles, 
  CheckCircle, 
  HelpCircle,
  SearchCheck,
  AlertCircle
} from 'lucide-react';
import { Activity2Scenario, ActionType, TextSegment } from '../types';
import { FamilyPlayIllustration, CharacterQuizIllustration, NatureTripIllustration } from './Illustrations';
import { evaluateChangedText } from '../utils/privacyValidator';

interface Activity2ScreenProps {
  scenarios: Activity2Scenario[];
  currentScenarioIndex: number;
  overallThought: string;
  onSetScenarioIndex: (index: number) => void;
  onUpdateSegment: (scenarioIndex: number, segmentId: string, action: ActionType, changedText?: string) => void;
  onSetScenarioChecked: (scenarioIndex: number, isChecked: boolean) => void;
  onSetScenarioThought: (scenarioIndex: number, thought: string) => void;
  onSetOverallThought: (thought: string) => void;
  onCompleteActivity2: () => void;
}

export const Activity2Screen: React.FC<Activity2ScreenProps> = ({
  scenarios,
  currentScenarioIndex,
  overallThought,
  onSetScenarioIndex,
  onUpdateSegment,
  onSetScenarioChecked,
  onSetScenarioThought,
  onSetOverallThought,
  onCompleteActivity2,
}) => {
  const [selectedSegmentId, setSelectedSegmentId] = useState<string | null>(null);
  const [editingInputText, setEditingInputText] = useState<string>('');
  const [showFinalSummary, setShowFinalSummary] = useState<boolean>(false);

  const scenario = scenarios[currentScenarioIndex] || scenarios[0];
  const selectedSegment = scenario.segments.find(s => s.id === selectedSegmentId);
  const isCurrentScenarioChecked = Boolean(scenario.isChecked);

  // Helper to build the final edited sentence for a scenario
  const getEditedSentence = (sc: Activity2Scenario) => {
    const parts: string[] = [];
    sc.segments.forEach(seg => {
      if (seg.action === 'remove') {
        // Excluded
      } else if (seg.action === 'change') {
        const text = seg.changedText?.trim() || seg.originalText;
        parts.push(text);
      } else {
        // keep or none
        parts.push(seg.originalText);
      }
    });
    return parts.join(' ');
  };

  const getOriginalSentence = (sc: Activity2Scenario) => {
    return sc.segments.map(s => s.originalText).join(' ');
  };

  // Rigorous segment acceptability check:
  // 1. Action must be in acceptableActions (or default rules)
  // 2. If action is 'change', the changedText must NOT contain specific private information
  const checkSegmentDetailed = (seg: TextSegment) => {
    const acceptable = seg.acceptableActions || (seg.isPrivacySensitive ? ['remove', 'change'] : ['keep']);
    const isActionOk = acceptable.includes(seg.action);
    if (!isActionOk) {
      return {
        isAcceptable: false,
        hint: seg.questionHint || '이 정보가 꼭 필요한지 한 번 더 생각해 볼까요?'
      };
    }
    if (seg.action === 'change') {
      const valRes = evaluateChangedText(seg.originalText, seg.changedText, seg.id);
      if (!valRes.isValid) {
        return {
          isAcceptable: false,
          hint: valRes.suggestedHint || '덜 구체적으로 바꿔 볼까요? 이 정보가 여전히 너무 구체적이지 않을까요?'
        };
      }
    }
    return { isAcceptable: true };
  };

  const isSegmentAcceptable = (seg: TextSegment) => {
    return checkSegmentDetailed(seg).isAcceptable;
  };

  const handleSelectSegment = (id: string) => {
    setSelectedSegmentId(id);
    const seg = scenario.segments.find(s => s.id === id);
    if (seg && seg.changedText) {
      setEditingInputText(seg.changedText);
    } else {
      setEditingInputText('');
    }
  };

  const handleActionClick = (action: ActionType) => {
    if (!selectedSegmentId) return;
    // Reset checked status when user modifies a choice
    onSetScenarioChecked(currentScenarioIndex, false);
    
    if (action === 'change') {
      const textToSet = editingInputText.trim() ? editingInputText : (selectedSegment?.changedText || '');
      onUpdateSegment(currentScenarioIndex, selectedSegmentId, 'change', textToSet);
    } else {
      onUpdateSegment(currentScenarioIndex, selectedSegmentId, action);
    }
  };

  const handleApplyChangeText = () => {
    if (!selectedSegmentId) return;
    onSetScenarioChecked(currentScenarioIndex, false);
    onUpdateSegment(currentScenarioIndex, selectedSegmentId, 'change', editingInputText);
  };

  const allSegmentsJudged = scenario.segments.every(s => s.action === 'keep' || s.action === 'remove' || s.action === 'change');
  const allChangesValid = scenario.segments.every(s => s.action !== 'change' || (s.changedText !== undefined && s.changedText.trim().length > 0));
  const canPerformCheck = allSegmentsJudged && allChangesValid;

  const handleCheckChoices = () => {
    if (!canPerformCheck) return;
    onSetScenarioChecked(currentScenarioIndex, true);
    setSelectedSegmentId(null);
  };

  const reconsiderationSegments = isCurrentScenarioChecked
    ? scenario.segments
        .map(seg => ({ seg, check: checkSegmentDetailed(seg) }))
        .filter(item => !item.check.isAcceptable)
    : [];
  const isScenarioAllAcceptable = scenario.segments.every(isSegmentAcceptable);

  // Check completion criteria for a scenario:
  // 1. All segments have action selected ('keep' | 'remove' | 'change')
  // 2. All 'change' segments have non-empty changedText (after trim())
  // 3. All selections are acceptable according to privacy rules (isSegmentAcceptable)
  // 4. [내 선택 점검하기] has been executed (sc.isChecked === true)
  // 5. Scenario step thought is not empty (after trim())
  const isScenarioComplete = (sc: Activity2Scenario) => {
    if (!sc) return false;
    const isChecked = Boolean(sc.isChecked);
    const allJudged = sc.segments.every(s => s.action === 'keep' || s.action === 'remove' || s.action === 'change');
    const allChangedFilled = sc.segments.every(s => s.action !== 'change' || (s.changedText !== undefined && s.changedText.trim().length > 0));
    const allAcceptable = sc.segments.every(isSegmentAcceptable);
    const thoughtValid = Boolean(sc.stepThought && sc.stepThought.trim().length > 0);
    return isChecked && allJudged && allChangedFilled && allAcceptable && thoughtValid;
  };

  const scenario1Complete = scenarios[0] ? isScenarioComplete(scenarios[0]) : false;
  const scenario2Complete = scenarios[1] ? isScenarioComplete(scenarios[1]) : false;
  const scenario3Complete = scenarios[2] ? isScenarioComplete(scenarios[2]) : false;

  const allScenariosComplete = scenario1Complete && scenario2Complete && scenario3Complete;
  const canProceedCurrentScenario = isScenarioComplete(scenario);

  // On the last scenario, proceeding means entering the final summary, which strictly requires ALL scenarios complete
  const isLastScenario = currentScenarioIndex === scenarios.length - 1;
  const canProceedButton = isLastScenario ? allScenariosComplete : canProceedCurrentScenario;

  const getDisabledReason = (): string | null => {
    if (canProceedButton) return null;

    if (!allSegmentsJudged) {
      return '모든 문장 조각의 [남기기], [빼기], [바꾸기]를 먼저 선택해 주세요.';
    }
    if (!allChangesValid) {
      return '[바꾸기]를 선택한 문장 조각에 바꿀 내용을 입력해 주세요.';
    }
    if (!scenario.isChecked) {
      return '현재 상황의 선택을 먼저 점검해 주세요.';
    }
    if (!isScenarioAllAcceptable || reconsiderationSegments.length > 0) {
      return '한 번 더 생각해 볼 정보가 남아 있어요. 힌트를 확인하고 다시 선택해 보세요.';
    }
    if (!scenario.stepThought || scenario.stepThought.trim().length === 0) {
      return '내 생각을 한 문장으로 적어 주세요.';
    }

    if (isLastScenario) {
      const incompleteList: string[] = [];
      if (!scenario1Complete) incompleteList.push('상황 ①');
      if (!scenario2Complete) incompleteList.push('상황 ②');
      if (incompleteList.length > 0) {
        return `아직 완료하지 않은 상황(${incompleteList.join(', ')})이 있어요.`;
      }
    }

    return '모든 단계를 완료하면 다음으로 넘어갈 수 있어요.';
  };

  const handleNextScenario = () => {
    if (isLastScenario) {
      if (!allScenariosComplete) return;
      setShowFinalSummary(true);
    } else {
      if (!canProceedCurrentScenario) return;
      onSetScenarioIndex(currentScenarioIndex + 1);
      setSelectedSegmentId(null);
      setEditingInputText('');
    }
  };

  const handlePrevScenario = () => {
    if (currentScenarioIndex > 0) {
      onSetScenarioIndex(currentScenarioIndex - 1);
      setSelectedSegmentId(null);
      setEditingInputText('');
    }
  };

  if (showFinalSummary) {
    const canComplete = scenario1Complete && scenario2Complete && scenario3Complete && overallThought.trim().length > 0;

    return (
      <div className="w-full max-w-3xl mx-auto py-6 px-4 sm:px-6 flex flex-col items-center">
        <div className="w-full text-center mb-6">
          <div className="inline-flex items-center gap-2 bg-[#cde5ff] text-[#004b75] px-4 py-1.5 rounded-full text-xs sm:text-sm font-bold mb-3">
            <Sparkles className="w-4 h-4" />
            <span>활동 2 정리</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#191c1d] mb-2">
            개인정보 편집실을 마치며
          </h2>
          <p className="text-sm sm:text-base text-[#4d4634]">
            3가지 가상 상황을 모두 살펴보았어요. 우리가 알게 된 점을 정리해 봅시다.
          </p>
        </div>

        {/* 3 Key Takeaways */}
        <div className="w-full space-y-3 mb-8">
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#e1e3e4] shadow-xs flex items-start gap-3.5">
            <div className="w-8 h-8 rounded-full bg-[#ffe087]/50 text-[#735c00] flex items-center justify-center font-bold text-sm shrink-0">
              1
            </div>
            <p className="text-sm sm:text-base text-[#191c1d] leading-relaxed">
              AI에게 질문할 때는 <strong>요청에 꼭 필요한 정보인지</strong> 먼저 생각해요.
            </p>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#e1e3e4] shadow-xs flex items-start gap-3.5">
            <div className="w-8 h-8 rounded-full bg-[#cde5ff] text-[#006398] flex items-center justify-center font-bold text-sm shrink-0">
              2
            </div>
            <p className="text-sm sm:text-base text-[#191c1d] leading-relaxed">
              나의 개인정보뿐 아니라 <strong>친구와 가족의 소중한 정보</strong>도 신중하게 다루어야 해요.
            </p>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#e1e3e4] shadow-xs flex items-start gap-3.5">
            <div className="w-8 h-8 rounded-full bg-[#ffd54f]/50 text-[#735c00] flex items-center justify-center font-bold text-sm shrink-0">
              3
            </div>
            <p className="text-sm sm:text-base text-[#191c1d] leading-relaxed">
              개인정보를 <strong>빼거나 안전하게 바꾸어도</strong> 내가 원하는 도움을 충분히 받을 수 있어요.
            </p>
          </div>
        </div>

        {/* Synthesis Question Card */}
        <div className="w-full bg-[#f3f4f5] rounded-3xl p-6 sm:p-8 card-shadow border border-[#d0c6ae]/40 mb-8">
          <label htmlFor="overallThoughtInput" className="block text-base sm:text-lg font-bold text-[#191c1d] mb-3">
            💭 AI에게 정보를 입력할 때 무엇을 살펴봐야 한다고 생각하나요?
          </label>
          <textarea
            id="overallThoughtInput"
            rows={3}
            value={overallThought}
            onChange={(e) => onSetOverallThought(e.target.value)}
            placeholder="활동하면서 알게 된 점을 적어 보세요."
            className="w-full p-4 rounded-xl border-2 border-[#d0c6ae] bg-white text-[#191c1d] focus:outline-none focus:border-[#ffd54f] focus:ring-4 focus:ring-[#ffd54f]/30 transition-all text-sm sm:text-base resize-none"
          />
        </div>

        {/* Buttons */}
        <div className="w-full flex flex-col items-end gap-2.5">
          <div className="w-full flex justify-between items-center">
            <button
              onClick={() => setShowFinalSummary(false)}
              className="px-5 py-3 rounded-full text-sm font-semibold text-[#4e616a] hover:bg-[#e7e8e9] transition-colors flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>다시 상황 편집하기</span>
            </button>

            <button
              disabled={!canComplete}
              onClick={onCompleteActivity2}
              className={`min-h-[56px] px-8 rounded-full font-bold text-base sm:text-lg transition-all flex items-center gap-3 shadow-md ${
                canComplete
                  ? 'bg-[#006398] text-white hover:bg-[#004b75] hover:scale-102 cursor-pointer'
                  : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-70'
              }`}
            >
              <span>활동 3으로 이동하기</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>

          {!canComplete && (
            <div className="flex items-center gap-1.5 text-xs text-[#735c00] bg-[#fff9db] px-3.5 py-1.5 rounded-xl border border-[#ffd54f]/60 self-center sm:self-end">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>
                {overallThought.trim().length === 0
                  ? '알게 된 점(마무리 생각)을 적어 주세요.'
                  : '모든 상황의 편집 및 점검을 완료해 주세요.'}
              </span>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto py-6 px-4 sm:px-6 flex flex-col items-center">
      {/* Title & Task Guidance */}
      <div className="text-center mb-6 max-w-2xl">
        <span className="text-xs font-bold text-[#006398] bg-[#cde5ff] px-3 py-1 rounded-full inline-block mb-1.5">
          활동 2
        </span>
        <h2 className="text-2xl sm:text-3xl font-bold text-[#191c1d] mb-1.5">
          개인정보 편집실
        </h2>
        <p className="text-sm sm:text-base text-[#4d4634] font-medium leading-relaxed break-keep">
          요청문을 부분별로 살펴보고, 각 정보를 남길지, 뺄지, 덜 구체적으로 바꿀지 결정해 보세요.
        </p>
      </div>

      {/* 1. 편집 기준 안내 카드 */}
      <div className="w-full bg-white rounded-3xl p-5 sm:p-6 card-shadow border border-[#d0c6ae]/40 mb-6">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-full bg-[#ffe087] text-[#735c00] flex items-center justify-center font-bold text-sm shrink-0">
            💡
          </div>
          <h3 className="text-base sm:text-lg font-bold text-[#191c1d]">
            편집할 때 두 가지만 생각해요
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4 text-xs sm:text-sm text-[#191c1d]">
          <div className="bg-[#f8f9fa] p-3.5 rounded-2xl border border-[#e1e3e4] flex items-start gap-2.5">
            <span className="w-5 h-5 rounded-full bg-[#cde5ff] text-[#004b75] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
              1
            </span>
            <p className="leading-relaxed font-medium">
              이 정보가 없어도 내가 원하는 도움을 받을 수 있을까?
            </p>
          </div>
          <div className="bg-[#f8f9fa] p-3.5 rounded-2xl border border-[#e1e3e4] flex items-start gap-2.5">
            <span className="w-5 h-5 rounded-full bg-[#ffe087] text-[#735c00] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
              2
            </span>
            <p className="leading-relaxed font-medium">
              이 정보가 필요하다면, 너무 자세하게 알려 주고 있지는 않을까?
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-3 border-t border-[#f3f4f5]">
          <div className="bg-[#cde5ff]/30 p-2.5 rounded-xl border border-[#6cbdfe]/30">
            <span className="font-bold text-[#004b75] text-xs block mb-0.5">남기기</span>
            <p className="text-[#4d4634] text-[11px] sm:text-xs">요청에 필요하고 그대로 사용해도 되는 정보</p>
          </div>
          <div className="bg-[#f3f4f5] p-2.5 rounded-xl border border-[#d0c6ae]/40">
            <span className="font-bold text-[#4e616a] text-xs block mb-0.5">빼기</span>
            <p className="text-[#4d4634] text-[11px] sm:text-xs">요청하는 데 필요하지 않은 정보</p>
          </div>
          <div className="bg-[#ffe087]/30 p-2.5 rounded-xl border border-[#ffd54f]/50">
            <span className="font-bold text-[#735c00] text-xs block mb-0.5">바꾸기</span>
            <p className="text-[#4d4634] text-[11px] sm:text-xs">요청에는 필요하지만 너무 자세해서 덜 구체적으로 표현할 정보</p>
          </div>
        </div>
      </div>

      {/* Scenario Progress Tabs */}
      <div className="flex gap-2 mb-6 w-full max-w-lg justify-center">
        {scenarios.map((sc, idx) => {
          const isActive = idx === currentScenarioIndex;
          const isDone = isScenarioComplete(sc);
          return (
            <button
              key={sc.id}
              onClick={() => {
                onSetScenarioIndex(idx);
                setSelectedSegmentId(null);
              }}
              className={`flex-1 py-2 px-3 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-1.5 ${
                isActive
                  ? 'bg-[#ffe087] text-[#241a00] border-2 border-[#ffd54f] shadow-xs font-bold'
                  : isDone
                  ? 'bg-white text-[#006398] border border-[#6cbdfe]/40 hover:bg-[#f3f4f5]'
                  : 'bg-[#f3f4f5] text-[#7f7662] border border-[#e1e3e4] hover:bg-[#e7e8e9]'
              }`}
            >
              <span>상황 {idx + 1}</span>
              {isDone && <CheckCircle className="w-3.5 h-3.5 text-[#006398]" />}
            </button>
          );
        })}
      </div>

      {/* Desk Workspace Container */}
      <div className="w-full bg-[#f3f4f5] rounded-3xl p-6 sm:p-8 card-shadow border border-[#d0c6ae]/40 mb-6 relative">
        {/* Scenario Header with Educational Illustration placed Prominently on Top */}
        <div className="flex flex-col items-center mb-6 bg-white p-6 sm:p-7 rounded-2xl border border-[#e1e3e4] card-shadow">
          {/* Situation Representative Illustration at Top */}
          <div className="w-full flex justify-center mb-4">
            {currentScenarioIndex === 0 && <FamilyPlayIllustration className="w-full max-w-md h-36 sm:h-44" />}
            {currentScenarioIndex === 1 && <CharacterQuizIllustration className="w-full max-w-md h-36 sm:h-44" />}
            {currentScenarioIndex === 2 && <NatureTripIllustration className="w-full max-w-md h-36 sm:h-44" />}
          </div>

          <div className="w-full text-center">
            <div className="inline-flex items-center gap-2 mb-2">
              <span className="text-xs font-bold text-[#735c00] bg-[#fff9db] border border-[#ffd54f] px-3 py-1 rounded-full">
                {scenario.title}
              </span>
              <span className="text-xs font-semibold text-[#006398] bg-[#cde5ff] px-3 py-1 rounded-full">
                {scenario.category}
              </span>
            </div>
            <p className="text-sm sm:text-base text-[#191c1d] font-medium leading-relaxed max-w-xl mx-auto break-keep">
              {scenario.description}
            </p>
          </div>
        </div>

        {/* Interactive Editing Request Card */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-xs border border-[#e1e3e4] text-center mb-6">
          <p className="text-xs text-[#7f7662] mb-4">
            문장 조각을 누르고 [남기기], [빼기], [바꾸기] 중 알맞은 것을 선택해 보세요.
          </p>

          <div className="text-base sm:text-xl text-[#191c1d] leading-relaxed flex flex-wrap justify-center items-center gap-2">
            {scenario.segments.map((seg) => {
              const isSelected = selectedSegmentId === seg.id;
              let badgeColor = '';
              let actionLabel = '';

              if (seg.action === 'keep') {
                badgeColor = 'bg-[#cde5ff] text-[#004b75] border-[#6cbdfe]';
                actionLabel = '남김';
              } else if (seg.action === 'remove') {
                badgeColor = 'bg-[#f3f4f5] text-[#7f7662] line-through border-[#d0c6ae] opacity-60';
                actionLabel = '뺌';
              } else if (seg.action === 'change') {
                badgeColor = 'bg-[#ffe087] text-[#241a00] border-[#ffd54f] font-semibold';
                actionLabel = '바꿈';
              }

              return (
                <button
                  key={seg.id}
                  onClick={() => handleSelectSegment(seg.id)}
                  className={`relative inline-flex flex-col items-center p-2.5 rounded-xl cursor-pointer transition-all border-2 ${
                    isSelected
                      ? 'bg-[#fff9db] border-[#ffd54f] shadow-md scale-103 ring-2 ring-[#ffd54f]/50'
                      : seg.action !== 'none'
                      ? `${badgeColor} border-solid`
                      : 'bg-[#f8f9fa] border-dashed border-[#d0c6ae] hover:bg-[#e7e8e9] hover:border-[#735c00]'
                  }`}
                >
                  <span className="text-sm sm:text-lg text-[#191c1d]">
                    {seg.action === 'change' && seg.changedText ? (
                      <span className="font-bold text-[#735c00]">
                        "{seg.changedText}"
                      </span>
                    ) : (
                      seg.originalText
                    )}
                  </span>

                  {seg.action !== 'none' && (
                    <span className="text-[10px] font-bold mt-1 px-1.5 py-0.5 rounded bg-white/80">
                      {actionLabel}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Action Control Panel (Shown when a segment is selected) */}
          {selectedSegment && (
            <div className="mt-8 pt-6 border-t border-[#f3f4f5] animate-in fade-in duration-200">
              <p className="text-xs sm:text-sm text-[#4e616a] mb-3">
                선택한 정보 조각: <strong className="text-[#191c1d]">"{selectedSegment.originalText}"</strong>
              </p>

              {/* Keep / Remove / Change Action Buttons */}
              <div className="flex flex-wrap justify-center gap-3 sm:gap-4">
                {/* Keep */}
                <button
                  type="button"
                  onClick={() => handleActionClick('keep')}
                  className={`px-6 py-3 min-h-[50px] rounded-full flex items-center gap-2 font-bold text-sm sm:text-base transition-all ${
                    selectedSegment.action === 'keep'
                      ? 'bg-[#006398] text-white shadow-md scale-103'
                      : 'bg-[#cde5ff] text-[#004b75] hover:bg-[#94ccff]'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>남기기</span>
                </button>

                {/* Remove */}
                <button
                  type="button"
                  onClick={() => handleActionClick('remove')}
                  className={`px-6 py-3 min-h-[50px] rounded-full flex items-center gap-2 font-bold text-sm sm:text-base transition-all border ${
                    selectedSegment.action === 'remove'
                      ? 'bg-[#4e616a] text-white border-[#4e616a] shadow-md scale-103'
                      : 'bg-white text-[#4d4634] border-[#d0c6ae] hover:bg-[#f3f4f5]'
                  }`}
                >
                  <X className="w-4 h-4" />
                  <span>빼기</span>
                </button>

                {/* Change */}
                <button
                  type="button"
                  onClick={() => handleActionClick('change')}
                  className={`px-6 py-3 min-h-[50px] rounded-full flex items-center gap-2 font-bold text-sm sm:text-base transition-all ${
                    selectedSegment.action === 'change'
                      ? 'bg-[#ffd54f] text-[#735c00] border-2 border-[#735c00] shadow-md scale-103'
                      : 'bg-[#ffe087] text-[#241a00] hover:bg-[#ffd54f]'
                  }`}
                >
                  <Edit2 className="w-4 h-4" />
                  <span>바꾸기</span>
                </button>
              </div>

              {/* Change Input Box */}
              {selectedSegment.action === 'change' && (
                <div className="mt-5 max-w-md mx-auto bg-[#fff9db] p-4 rounded-2xl border border-[#ffd54f] text-left">
                  <label htmlFor="changeInput" className="block text-xs font-bold text-[#735c00] mb-2">
                    개인정보가 드러나지 않게 바꾸어 적어 보세요:
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="changeInput"
                      type="text"
                      value={editingInputText || (selectedSegment.changedText ?? '')}
                      onChange={(e) => {
                        setEditingInputText(e.target.value);
                        onUpdateSegment(currentScenarioIndex, selectedSegment.id, 'change', e.target.value);
                      }}
                      placeholder="개인정보가 드러나지 않게 바꾸어 적어 보세요."
                      className="flex-1 rounded-xl border border-[#d0c6ae] bg-white px-3.5 py-2 text-sm text-[#191c1d] focus:outline-none focus:ring-2 focus:ring-[#ffd54f]"
                    />
                    <button
                      type="button"
                      onClick={handleApplyChangeText}
                      className="bg-[#735c00] text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-[#574500] transition-colors"
                    >
                      적용
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* 내 선택 점검하기 Button */}
        <div className="flex flex-col items-center mb-6">
          <button
            type="button"
            disabled={!canPerformCheck}
            onClick={handleCheckChoices}
            className={`min-h-[50px] px-8 rounded-full font-bold text-sm sm:text-base transition-all flex items-center gap-2 shadow-xs ${
              canPerformCheck
                ? 'bg-[#735c00] text-white hover:bg-[#574500] hover:scale-102 cursor-pointer'
                : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-60'
            }`}
          >
            <SearchCheck className="w-5 h-5" />
            <span>내 선택 점검하기</span>
          </button>
          {!canPerformCheck && (
            <p className="text-xs text-[#7f7662] mt-2">
              모든 문장 조각의 선택을 완료하면 점검할 수 있어요.
            </p>
          )}
        </div>

        {/* Question-Type Hints for Reconsideration */}
        {isCurrentScenarioChecked && reconsiderationSegments.length > 0 && (
          <div className="mb-6 space-y-3 animate-in fade-in duration-200">
            <div className="bg-[#fff9db] border border-[#ffd54f] rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3 text-[#735c00]">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <h4 className="font-bold text-sm sm:text-base">
                  한 번 더 생각해 봐요
                </h4>
              </div>
              <p className="text-xs sm:text-sm text-[#4d4634] mb-3">
                아래 정보 조각을 누르고 질문을 생각하며 선택을 다시 고민해 보세요.
              </p>
              <div className="space-y-2.5">
                {reconsiderationSegments.map(({ seg, check }) => (
                  <button
                    key={seg.id}
                    type="button"
                    onClick={() => handleSelectSegment(seg.id)}
                    className="w-full text-left bg-white p-3.5 rounded-xl border border-[#ffd54f]/80 hover:bg-[#fffdf5] transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div>
                      <span className="text-xs font-bold text-[#735c00] block mb-0.5">
                        "{seg.action === 'change' && seg.changedText ? seg.changedText : seg.originalText}"
                      </span>
                      <p className="text-xs sm:text-sm text-[#191c1d]">
                        {check.hint}
                      </p>
                    </div>
                    <span className="text-xs font-bold text-[#006398] underline shrink-0">
                      다시 선택하기
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Confirmation banner if all acceptable */}
        {isCurrentScenarioChecked && isScenarioAllAcceptable && (
          <div className="mb-6 p-5 rounded-2xl bg-[#e8f5e9] border-2 border-[#4caf50] card-shadow flex flex-col sm:flex-row items-start sm:items-center gap-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-10 h-10 rounded-full bg-[#2e7d32] text-white flex items-center justify-center shrink-0 shadow-xs">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-[#1b5e20] bg-[#c8e6c9] px-2.5 py-0.5 rounded-full">
                  점검 완료!
                </span>
                <h4 className="font-bold text-sm sm:text-base text-[#1b5e20]">
                  잘했어요! 필요한 정보는 남기고, 개인정보는 빼거나 안전하게 바꾸었어요.
                </h4>
              </div>
              <p className="text-xs sm:text-sm text-[#2e7d32] font-medium leading-relaxed">
                이제 아래에서 내가 고친 요청문을 확인하고 내 생각을 정리해 보세요.
              </p>
            </div>
          </div>
        )}

        {/* Live Before & After Comparison */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Before */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#e1e3e4] shadow-xs">
            <span className="text-xs font-bold text-[#ba1a1a] bg-[#ffdad6] px-2.5 py-1 rounded-full inline-block mb-2.5">
              편집 전 요청문
            </span>
            <p className="text-sm sm:text-base text-[#4d4634] leading-relaxed">
              "{getOriginalSentence(scenario)}"
            </p>
          </div>

          {/* After */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#6cbdfe] shadow-xs">
            <span className="text-xs font-bold text-[#006398] bg-[#cde5ff] px-2.5 py-1 rounded-full inline-block mb-2.5 flex items-center gap-1 w-fit">
              <Check className="w-3 h-3" />
              <span>내가 고친 요청문</span>
            </span>
            <p className="text-sm sm:text-base text-[#191c1d] font-medium leading-relaxed">
              "{getEditedSentence(scenario)}"
            </p>
          </div>
        </div>

        {/* Reflection question for this scenario */}
        <div className="mt-5 bg-white p-4 rounded-2xl border border-[#d0c6ae]/40">
          <label htmlFor={`thought-${scenario.id}`} className="block text-xs sm:text-sm font-bold text-[#191c1d] mb-2">
            🤔 정보를 줄이거나 바꾸어도 AI에게 내가 원하는 도움을 요청할 수 있나요?
          </label>
          <input
            id={`thought-${scenario.id}`}
            type="text"
            value={scenario.stepThought || ''}
            onChange={(e) => onSetScenarioThought(currentScenarioIndex, e.target.value)}
            placeholder="내 생각을 한 문장으로 적어 보세요."
            className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#d0c6ae] bg-[#f8f9fa] text-[#191c1d] focus:outline-none focus:border-[#ffd54f]"
          />
        </div>
      </div>

      {/* Navigation Buttons between Scenarios */}
      <div className="w-full flex flex-col items-end gap-2.5">
        <div className="w-full flex justify-between items-center">
          <button
            disabled={currentScenarioIndex === 0}
            onClick={handlePrevScenario}
            className={`px-5 py-3 rounded-full text-sm font-semibold transition-colors flex items-center gap-2 ${
              currentScenarioIndex > 0
                ? 'text-[#4e616a] hover:bg-[#e7e8e9] cursor-pointer'
                : 'text-[#d0c6ae] cursor-not-allowed opacity-40'
            }`}
          >
            <ArrowLeft className="w-4 h-4" />
            <span>이전 상황</span>
          </button>

          <button
            disabled={!canProceedButton}
            onClick={handleNextScenario}
            className={`min-h-[52px] px-8 rounded-full font-bold text-sm sm:text-base transition-all flex items-center gap-2 shadow-md ${
              canProceedButton
                ? 'bg-[#006398] text-white hover:bg-[#004b75] hover:scale-102 cursor-pointer'
                : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-70'
            }`}
          >
            <span>
              {currentScenarioIndex < scenarios.length - 1 ? '다음 상황으로' : '편집실 마무리하기'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Disabled Reason Guidance */}
        {!canProceedButton && (
          <div className="flex items-center gap-1.5 text-xs text-[#735c00] bg-[#fff9db] px-3.5 py-1.5 rounded-xl border border-[#ffd54f]/60 self-center sm:self-end">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{getDisabledReason()}</span>
          </div>
        )}
      </div>
    </div>
  );
};
