import React from 'react';
import { 
  ShieldCheck, 
  Printer, 
  RotateCcw, 
  Sparkles, 
  Lightbulb, 
  FileText, 
  Send,
  Heart
} from 'lucide-react';
import { LessonState } from '../types';

interface SummaryScreenProps {
  state: LessonState;
  onRestart: () => void;
}

export const SummaryScreen: React.FC<SummaryScreenProps> = ({ state, onRestart }) => {
  // Get edited sentence for application step
  const appEditedSentence = state.applicationSegments
    .filter(s => s.action !== 'remove')
    .map(s => (s.action === 'change' && s.changedText?.trim() ? s.changedText.trim() : s.originalText))
    .join(' ');

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="w-full max-w-4xl mx-auto py-8 px-4 sm:px-6 flex flex-col items-center print:py-0 print:px-0">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-[#ffd54f]/30 border border-[#ffd54f] text-[#735c00] px-4 py-1.5 rounded-full text-xs sm:text-sm font-bold mb-3">
          <ShieldCheck className="w-4 h-4 text-[#735c00]" />
          <span>나의 AI 윤리 배움 기록장</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold text-[#191c1d]">
          내 정보는 소중해요
        </h2>
        <p className="text-sm sm:text-base text-[#4d4634] mt-1">
          수업을 통해 내가 직접 생각하고 편집한 소중한 기록입니다.
        </p>
      </div>

      {/* Main Portfolio Printable Card */}
      <div className="w-full bg-white rounded-3xl p-6 sm:p-10 card-shadow border border-[#e1e3e4] mb-8 space-y-6 print:border-none print:shadow-none print:p-2">
        {/* Item 1: 시작 vs 지금 생각 */}
        <div className="bg-[#f8f9fa] rounded-2xl p-5 sm:p-6 border border-[#e1e3e4]">
          <h3 className="text-sm sm:text-base font-bold text-[#006398] mb-3 flex items-center gap-2">
            <Lightbulb className="w-4 h-4" />
            <span>1. 수업 시작 때의 생각과 지금 달라진 생각</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-white p-3.5 rounded-xl border border-[#d0c6ae]/40">
              <span className="text-xs text-[#7f7662] block mb-1">처음의 생각:</span>
              <p className="text-sm font-semibold text-[#735c00]">
                {state.initialThought || '선택 기록 없음'}
              </p>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-[#6cbdfe]/40">
              <span className="text-xs text-[#006398] block mb-1">지금의 생각:</span>
              <p className="text-sm text-[#191c1d]">
                {state.reflectionThoughtNow || '작성된 내용이 없습니다.'}
              </p>
            </div>
          </div>
        </div>

        {/* Item 2: 활동 2에서 정리한 생각 */}
        <div className="bg-[#f8f9fa] rounded-2xl p-5 sm:p-6 border border-[#e1e3e4]">
          <h3 className="text-sm sm:text-base font-bold text-[#006398] mb-2 flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            <span>2. 개인정보 편집실에서 정리한 생각</span>
          </h3>
          <div className="bg-white p-4 rounded-xl border border-[#d0c6ae]/40">
            <p className="text-sm text-[#191c1d] leading-relaxed">
              {state.activity2Thought || '작성된 내용이 없습니다.'}
            </p>
          </div>
        </div>

        {/* Item 3: 우리 모둠이 만든 안전한 AI 요청문 */}
        <div className="bg-[#f8f9fa] rounded-2xl p-5 sm:p-6 border border-[#e1e3e4]">
          <h3 className="text-sm sm:text-base font-bold text-[#006398] mb-2 flex items-center gap-2">
            <FileText className="w-4 h-4" />
            <span>3. 우리 모둠이 만든 안전한 AI 요청문</span>
          </h3>
          <div className="bg-white p-4 rounded-xl border-2 border-[#cde5ff]">
            <p className="text-sm sm:text-base font-semibold text-[#004b75] leading-relaxed">
              "{state.activity3GroupRequest || '작성된 요청문이 없습니다.'}"
            </p>
          </div>
        </div>

        {/* Item 4: 생활 속 적용에서 내가 고친 요청문 */}
        <div className="bg-[#f8f9fa] rounded-2xl p-5 sm:p-6 border border-[#e1e3e4]">
          <h3 className="text-sm sm:text-base font-bold text-[#006398] mb-2 flex items-center gap-2">
            <Send className="w-4 h-4" />
            <span>4. 생활 속 적용에서 내가 고친 요청문</span>
          </h3>
          <div className="bg-white p-4 rounded-xl border border-[#d0c6ae]/40">
            <p className="text-sm sm:text-base text-[#191c1d] leading-relaxed">
              "{appEditedSentence}"
            </p>
          </div>
        </div>

        {/* Item 5: 가장 중요하다고 생각한 개인정보 보호 방법 */}
        <div className="bg-[#f8f9fa] rounded-2xl p-5 sm:p-6 border border-[#e1e3e4]">
          <h3 className="text-sm sm:text-base font-bold text-[#735c00] mb-2 flex items-center gap-2">
            <Heart className="w-4 h-4 text-[#ba1a1a]" />
            <span>5. 가장 중요하다고 생각한 개인정보 보호 방법</span>
          </h3>
          <div className="bg-[#fff9db] p-4 rounded-xl border border-[#ffd54f]">
            <p className="text-sm sm:text-base text-[#191c1d] font-medium leading-relaxed">
              {state.reflectionMostImportant || '작성된 내용이 없습니다.'}
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons (Hidden on Print) */}
      <div className="flex flex-wrap gap-4 justify-center w-full print:hidden">
        <button
          onClick={handlePrint}
          className="min-h-[52px] px-8 rounded-full font-bold text-sm sm:text-base bg-[#006398] text-white hover:bg-[#004b75] transition-all flex items-center gap-2 shadow-md hover:scale-102 cursor-pointer"
        >
          <Printer className="w-4 h-4" />
          <span>기록장 인쇄하기</span>
        </button>

        <button
          onClick={onRestart}
          className="min-h-[52px] px-6 rounded-full font-semibold text-sm sm:text-base bg-[#f3f4f5] text-[#4d4634] hover:bg-[#e7e8e9] transition-all flex items-center gap-2 border border-[#d0c6ae]"
        >
          <RotateCcw className="w-4 h-4" />
          <span>처음부터 다시하기</span>
        </button>
      </div>
    </div>
  );
};
