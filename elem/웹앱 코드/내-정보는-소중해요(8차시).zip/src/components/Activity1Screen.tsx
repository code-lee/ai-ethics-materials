import React from 'react';
import { Bot, Edit3, ArrowRight, Lightbulb, Check } from 'lucide-react';
import { ACTIVITY1_REQUEST } from '../data/lessonData';
import { ConcernedMessageIllustration } from './Illustrations';

interface Activity1ScreenProps {
  selectedIds: string[];
  reason: string;
  onToggleSegment: (id: string) => void;
  onChangeReason: (reason: string) => void;
  onNext: () => void;
}

export const Activity1Screen: React.FC<Activity1ScreenProps> = ({
  selectedIds,
  reason,
  onToggleSegment,
  onChangeReason,
  onNext,
}) => {
  const canProceed = selectedIds.length > 0 && reason.trim().length > 0;

  return (
    <div className="w-full max-w-3xl mx-auto py-6 px-4 sm:px-6 flex flex-col items-center">
      {/* Header & Illustration */}
      <div className="w-full flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 mb-6">
        <ConcernedMessageIllustration className="w-20 h-20 sm:w-24 sm:h-24 shrink-0" />
        <div className="text-center sm:text-left">
          <span className="text-xs font-bold text-[#006398] bg-[#cde5ff] px-3 py-1 rounded-full inline-block mb-1.5">
            활동 1
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-[#191c1d] mb-1.5 break-keep">
            이대로 AI에게 보내도 될까요?
          </h2>
          <p className="text-sm sm:text-base text-[#4d4634] font-medium leading-relaxed break-keep">
            AI에게 보내려는 요청문을 읽고, 굳이 알려 주지 않아도 될 것 같은 정보를 찾아보세요.
          </p>
        </div>
      </div>

      {/* The Workspace Desk */}
      <div className="w-full bg-[#f3f4f5] rounded-3xl p-6 sm:p-8 card-shadow border border-[#d0c6ae]/40 mb-6">
        {/* Clickable AI Request Card */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-[#e1e3e4] mb-6">
          <div className="flex items-center justify-between mb-4 border-b border-[#f3f4f5] pb-3">
            <span className="text-xs font-bold text-[#006398] bg-[#cde5ff] px-3 py-1 rounded-full">
              가상의 AI 요청문
            </span>
            <span className="text-xs text-[#7f7662]">
              선택한 항목: <strong className="text-[#006398]">{selectedIds.length}</strong>개
            </span>
          </div>

          <div className="text-base sm:text-xl text-[#191c1d] leading-relaxed flex flex-wrap items-center gap-y-2.5">
            <span className="mr-1.5 text-[#4d4634]">"</span>
            {ACTIVITY1_REQUEST.segments.map((seg) => {
              const isSelected = selectedIds.includes(seg.id);
              return (
                <button
                  key={seg.id}
                  onClick={() => onToggleSegment(seg.id)}
                  type="button"
                  className={`inline-block px-2.5 py-1 mx-1 rounded-lg text-base sm:text-lg font-medium transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#ffe087] border-2 border-[#ffd54f] text-[#241a00] shadow-sm font-semibold scale-103'
                      : 'bg-[#f8f9fa] border-b-2 border-dashed border-[#7f7662]/40 text-[#191c1d] hover:bg-[#e1e3e4] hover:border-[#735c00]'
                  }`}
                >
                  <span className="flex items-center gap-1">
                    {seg.text}
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#735c00] stroke-[3]" />}
                  </span>
                </button>
              );
            })}
            <span className="ml-1 text-[#4d4634]">"</span>
          </div>

          <p className="text-xs text-[#7f7662] mt-4 text-right">
            * 마음에 걸리는 문장 조각을 하나 이상 자유롭게 눌러 보세요.
          </p>
        </div>

        {/* Thought Input Section */}
        <div className="w-full bg-[#e1e3e4]/60 rounded-2xl p-5 sm:p-6 border border-[#d0c6ae]/50">
          <p className="text-xs sm:text-sm text-[#735c00] font-semibold mb-3">
            ※ 실제 이름, 학교, 전화번호, 집 주소는 입력하지 마세요. 이 활동에서는 가상 정보만 사용해요.
          </p>
          <label htmlFor="reasonInput" className="block text-sm sm:text-base font-bold text-[#191c1d] mb-2.5 flex items-center gap-2">
            <Edit3 className="w-4 h-4 text-[#735c00]" />
            <span>왜 이 부분이 마음에 걸렸나요?</span>
          </label>
          <input
            id="reasonInput"
            type="text"
            value={reason}
            onChange={(e) => onChangeReason(e.target.value)}
            placeholder="왜 이 부분이 마음에 걸렸는지 적어 보세요."
            className="w-full min-h-[52px] px-4 py-3 rounded-xl border-2 border-[#d0c6ae] bg-white text-[#191c1d] focus:outline-none focus:border-[#ffd54f] focus:ring-4 focus:ring-[#ffd54f]/30 transition-all text-sm sm:text-base placeholder:text-[#7f7662]/50"
          />
        </div>
      </div>

      {/* Educational Concept Card */}
      <div className="w-full bg-[#c8dce7]/30 border border-[#6cbdfe]/40 rounded-2xl p-5 mb-8 flex items-start gap-3.5">
        <div className="w-9 h-9 rounded-xl bg-[#6cbdfe]/40 text-[#004b75] flex items-center justify-center shrink-0 mt-0.5">
          <Lightbulb className="w-5 h-5" />
        </div>
        <div className="text-sm text-[#004b75] leading-relaxed">
          <strong className="font-bold block mb-0.5 text-[#001d32]">잠깐! 개인정보란 무엇일까요?</strong>
          개인정보는 나를 알아볼 수 있게 하는 소중한 정보예요. 이름, 학교, 전화번호, 집 주소뿐만 아니라 친구와 가족의 정보도 안전하게 지켜주어야 해요.
        </div>
      </div>

      {/* Action Button */}
      <div className="w-full flex justify-end">
        <button
          disabled={!canProceed}
          onClick={onNext}
          className={`min-h-[56px] px-8 rounded-full font-bold text-base sm:text-lg transition-all flex items-center gap-3 shadow-md ${
            canProceed
              ? 'bg-[#006398] text-white hover:bg-[#004b75] hover:scale-102 cursor-pointer'
              : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-70'
          }`}
        >
          <span>다음 활동으로</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
      
      {!canProceed && (
        <p className="text-xs text-[#7f7662] mt-3">
          고민되는 정보를 선택하고 마음에 걸린 이유를 적으면 다음으로 갈 수 있어요.
        </p>
      )}
    </div>
  );
};
