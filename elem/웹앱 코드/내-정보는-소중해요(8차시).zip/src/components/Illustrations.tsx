import React from 'react';

/**
 * Educational Vector Illustrations for Elementary 3-4th Grade AI Ethics
 * High visual clarity, friendly student characters, soft blues (#006398, #CDE5FF),
 * warm golds (#FFE087, #735C00, #FFAE00), and fresh green/neutral accents.
 */

// 1. Start Screen: Student asking AI about tomorrow's weather & school clothes outfit
export const StudentWeatherAiIllustration: React.FC<{ className?: string }> = ({ className = "w-full max-w-sm h-40 sm:h-48" }) => (
  <svg viewBox="0 0 360 180" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-label="내일 날씨와 학교 옷차림을 AI에게 물어보는 학생 일러스트">
    {/* Soft Room & Desk Background */}
    <rect width="360" height="180" rx="20" fill="#F0F7FF" />
    <path d="M0 130H360V180H0V130Z" fill="#E2EDF8" />
    <line x1="0" y1="130" x2="360" y2="130" stroke="#C3D9EE" strokeWidth="2" />

    {/* Room Window with Weather Sky */}
    <g transform="translate(24, 18)">
      <rect width="84" height="96" rx="10" fill="#CDE5FF" stroke="#006398" strokeWidth="2.5" />
      {/* Window panes */}
      <line x1="42" y1="0" x2="42" y2="96" stroke="#006398" strokeWidth="2" />
      <line x1="0" y1="48" x2="84" y2="48" stroke="#006398" strokeWidth="2" />
      {/* Sun & Cloud inside window */}
      <circle cx="26" cy="24" r="12" fill="#FFAE00" />
      <circle cx="26" cy="24" r="16" stroke="#FFE087" strokeWidth="2" strokeDasharray="3 3" />
      {/* Small Cloud */}
      <path d="M42 36C42 31 46 27 51 27C55 27 58.5 29.8 59.5 33.5C60.2 33.3 60.8 33.2 61.5 33.2C65 33.2 68 36.2 68 39.8C68 43.4 65 46.2 61.5 46.2H48C44.7 46.2 42 43.5 42 40.2V36Z" fill="#FFFFFF" opacity="0.95" />
      {/* Rain drops falling */}
      <line x1="48" y1="56" x2="46" y2="64" stroke="#006398" strokeWidth="2" strokeLinecap="round" />
      <line x1="58" y1="58" x2="56" y2="66" stroke="#006398" strokeWidth="2" strokeLinecap="round" />
      <line x1="68" y1="56" x2="66" y2="64" stroke="#006398" strokeWidth="2" strokeLinecap="round" />
    </g>

    {/* School Outfit (Yellow Raincoat / Jacket & Umbrella on stand) */}
    <g transform="translate(120, 26)">
      {/* Umbrella */}
      <path d="M12 28C12 16 22 8 34 8C46 8 56 16 56 28H12Z" fill="#FFE087" stroke="#735C00" strokeWidth="2" />
      <line x1="34" y1="8" x2="34" y2="48" stroke="#735C00" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M34 48C34 52 30 55 26 55" stroke="#735C00" strokeWidth="2.5" strokeLinecap="round" fill="none" />
      {/* Jacket on hanger */}
      <path d="M34 56L22 68H46L34 56Z" fill="#FFAE00" />
      <rect x="24" y="68" width="20" height="34" rx="4" fill="#FFAE00" stroke="#735C00" strokeWidth="1.5" />
      <circle cx="34" cy="76" r="2" fill="#735C00" />
      <circle cx="34" cy="86" r="2" fill="#735C00" />
    </g>

    {/* Student at desk using tablet to ask AI */}
    <g transform="translate(180, 40)">
      {/* Body */}
      <path d="M40 100C40 76 52 68 70 68C88 68 100 76 100 100H40Z" fill="#006398" />
      <path d="M60 68L70 80L80 68" stroke="#FFE087" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

      {/* Head */}
      <circle cx="70" cy="42" r="20" fill="#FFE087" />
      {/* Hair */}
      <path d="M50 38C50 24 60 16 70 16C80 16 90 24 90 38C90 40 88 42 85 42C83 36 78 32 70 32C62 32 57 36 55 42C52 42 50 40 50 38Z" fill="#4D4634" />
      {/* Curious eyes */}
      <ellipse cx="64" cy="42" rx="2" ry="3" fill="#241A00" />
      <ellipse cx="76" cy="42" rx="2" ry="3" fill="#241A00" />
      {/* Smile */}
      <path d="M66 50C68 53 72 53 74 50" stroke="#735C00" strokeWidth="2" strokeLinecap="round" />

      {/* Tablet Device */}
      <rect x="18" y="72" width="38" height="28" rx="4" fill="#191C1D" stroke="#FFE087" strokeWidth="1.5" />
      <rect x="21" y="75" width="32" height="22" rx="2" fill="#FFFFFF" />
      <line x1="24" y1="80" x2="44" y2="80" stroke="#6CBDFE" strokeWidth="2" strokeLinecap="round" />
      <line x1="24" y1="85" x2="48" y2="85" stroke="#FFE087" strokeWidth="2" strokeLinecap="round" />
      <line x1="24" y1="90" x2="38" y2="90" stroke="#006398" strokeWidth="2" strokeLinecap="round" />
    </g>

    {/* AI Assistant Chat Cloud with Sparkles */}
    <g transform="translate(250, 18)">
      <rect x="0" y="0" width="94" height="60" rx="14" fill="#006398" />
      <polygon points="18,60 10,70 30,60" fill="#006398" />
      {/* Bot face */}
      <circle cx="24" cy="28" r="14" fill="#CDE5FF" />
      <circle cx="20" cy="26" r="2.5" fill="#004B75" />
      <circle cx="28" cy="26" r="2.5" fill="#004B75" />
      <path d="M21 33C23 35 25 35 27 33" stroke="#004B75" strokeWidth="2" strokeLinecap="round" />
      {/* Dialogue text lines */}
      <rect x="44" y="18" width="40" height="4" rx="2" fill="#FFFFFF" />
      <rect x="44" y="27" width="34" height="4" rx="2" fill="#CDE5FF" />
      <rect x="44" y="36" width="28" height="4" rx="2" fill="#FFE087" />
      {/* AI Antenna */}
      <line x1="24" y1="14" x2="24" y2="8" stroke="#CDE5FF" strokeWidth="2" strokeLinecap="round" />
      <circle cx="24" cy="6" r="3" fill="#FFE087" />
    </g>
  </svg>
);

// 2. Activity 1: Student pondering if a message is safe to send
export const ConcernedMessageIllustration: React.FC<{ className?: string }> = ({ className = "w-full max-w-sm h-36 sm:h-44" }) => (
  <svg viewBox="0 0 360 180" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-label="메시지를 보낼지 고민하는 학생 일러스트">
    <rect width="360" height="180" rx="20" fill="#FBF8F2" />
    <path d="M0 135H360V180H0V135Z" fill="#F0ECE1" />
    <line x1="0" y1="135" x2="360" y2="135" stroke="#DCD5C5" strokeWidth="2" />

    {/* Student at laptop looking doubtful */}
    <g transform="translate(36, 32)">
      {/* Student Body */}
      <path d="M30 102C30 78 42 70 60 70C78 70 90 78 90 102H30Z" fill="#6CBDFE" />
      <circle cx="60" cy="46" r="20" fill="#FFE087" />
      <path d="M40 42C40 28 50 20 60 20C70 20 80 28 80 42C80 44 78 46 75 46C73 40 68 36 60 36C52 36 47 40 45 46C42 46 40 44 40 42Z" fill="#4D4634" />
      <ellipse cx="54" cy="45" rx="2" ry="3" fill="#241A00" />
      <ellipse cx="68" cy="44" rx="2" ry="3" fill="#241A00" />
      <path d="M58 54C61 52 65 53 67 56" stroke="#735C00" strokeWidth="2" strokeLinecap="round" />

      {/* Laptop */}
      <path d="M72 102L80 72H134L126 102H72Z" fill="#E1E3E4" stroke="#4D4634" strokeWidth="2" />
      <rect x="84" y="76" width="42" height="20" rx="2" fill="#006398" />
      <rect x="64" y="102" width="76" height="8" rx="3" fill="#4D4634" />
    </g>

    {/* Question Mark & Magnifying Glass on Request Message */}
    <g transform="translate(180, 24)">
      <rect width="150" height="96" rx="14" fill="#FFFFFF" stroke="#D0C6AE" strokeWidth="2" />
      <rect x="12" y="14" width="60" height="6" rx="3" fill="#6CBDFE" />
      <rect x="12" y="26" width="126" height="6" rx="3" fill="#BA1A1A" opacity="0.6" />
      <rect x="12" y="38" width="100" height="6" rx="3" fill="#BA1A1A" opacity="0.6" />
      <rect x="12" y="50" width="116" height="6" rx="3" fill="#FFE087" />
      <rect x="12" y="62" width="80" height="6" rx="3" fill="#6CBDFE" />

      {/* Caution Badge */}
      <g transform="translate(100, 52)">
        <circle cx="20" cy="20" r="18" fill="#FFE087" stroke="#735C00" strokeWidth="2" />
        <text x="20" y="26" fill="#735C00" fontSize="20" fontWeight="bold" textAnchor="middle">?</text>
      </g>
    </g>
  </svg>
);

// 3. Activity 2 Scenario 1: Rich Family Play & Weekend Activity Discussion Scene
export const FamilyPlayIllustration: React.FC<{ className?: string }> = ({ className = "w-full max-w-sm h-40 sm:h-48" }) => (
  <svg viewBox="0 0 360 180" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-label="가족과 함께 주말 실내 놀이를 의논하는 장면 일러스트">
    {/* Cozy Warm Living Room Background */}
    <rect width="360" height="180" rx="20" fill="#FFFDF2" />
    <path d="M0 135H360V180H0V135Z" fill="#FDF3CF" />
    <line x1="0" y1="135" x2="360" y2="135" stroke="#EED888" strokeWidth="2" />

    {/* Living room window & clock */}
    <g transform="translate(24, 20)">
      <rect width="64" height="64" rx="8" fill="#FFFFFF" stroke="#735C00" strokeWidth="2" />
      <line x1="32" y1="0" x2="32" y2="64" stroke="#735C00" strokeWidth="1.5" />
      <line x1="0" y1="32" x2="64" y2="32" stroke="#735C00" strokeWidth="1.5" />
      <circle cx="16" cy="16" r="6" fill="#FFE087" />
    </g>

    {/* Dad (Left) */}
    <g transform="translate(104, 38)">
      {/* Dad Body */}
      <path d="M16 98C16 70 32 60 52 60C72 60 88 70 88 98H16Z" fill="#006398" />
      <circle cx="52" cy="36" r="22" fill="#FFE087" />
      <path d="M30 32C30 18 40 12 52 12C64 12 74 18 74 32C74 34 70 36 68 36C65 30 58 26 52 26C46 26 40 30 36 36C33 36 30 34 30 32Z" fill="#4D4634" />
      {/* Friendly Eyes & Smile */}
      <circle cx="45" cy="36" r="2.5" fill="#241A00" />
      <circle cx="59" cy="36" r="2.5" fill="#241A00" />
      <path d="M47 44C50 48 54 48 57 44" stroke="#735C00" strokeWidth="2" strokeLinecap="round" />
      {/* Glasses */}
      <rect x="40" y="32" width="10" height="8" rx="2" stroke="#735C00" strokeWidth="1.5" fill="none" />
      <rect x="54" y="32" width="10" height="8" rx="2" stroke="#735C00" strokeWidth="1.5" fill="none" />
      <line x1="50" y1="36" x2="54" y2="36" stroke="#735C00" strokeWidth="1.5" />
    </g>

    {/* Child Student (Right) discussing board game */}
    <g transform="translate(196, 52)">
      {/* Child Body */}
      <path d="M12 84C12 62 24 54 40 54C56 54 68 62 68 84H12Z" fill="#FFAE00" />
      <circle cx="40" cy="32" r="18" fill="#FFE087" />
      <path d="M22 28C22 16 30 10 40 10C50 10 58 16 58 28C58 30 56 32 54 32C52 26 47 22 40 22C33 22 28 26 26 32C24 32 22 30 22 28Z" fill="#4D4634" />
      <ellipse cx="35" cy="32" rx="2" ry="3" fill="#241A00" />
      <ellipse cx="45" cy="32" rx="2" ry="3" fill="#241A00" />
      <path d="M37 40C39 42 41 42 43 40" stroke="#735C00" strokeWidth="1.5" strokeLinecap="round" />
    </g>

    {/* Center Table with Board Game & Dice */}
    <g transform="translate(148, 98)">
      <rect width="64" height="38" rx="6" fill="#D0C6AE" stroke="#735C00" strokeWidth="2" />
      {/* Board Game Grid */}
      <rect x="8" y="6" width="48" height="24" rx="3" fill="#FFFFFF" stroke="#735C00" strokeWidth="1" />
      {/* Dice */}
      <rect x="22" y="10" width="10" height="10" rx="2" fill="#BA1A1A" />
      <circle cx="27" cy="15" r="1.2" fill="#FFFFFF" />
      {/* Pawn */}
      <circle cx="42" cy="14" r="3" fill="#006398" />
      <path d="M39 20H45L43 14H41L39 20Z" fill="#006398" />
    </g>

    {/* Thought bubble about weekend fun */}
    <g transform="translate(268, 16)">
      <rect width="76" height="52" rx="12" fill="#006398" />
      <polygon points="12,52 6,60 20,52" fill="#006398" />
      <text x="38" y="24" fill="#FFE087" fontSize="11" fontWeight="bold" textAnchor="middle">주말 실내 놀이</text>
      <text x="38" y="40" fill="#FFFFFF" fontSize="10" fontWeight="medium" textAnchor="middle">보드게임 추천!</text>
    </g>
  </svg>
);

// 4. Activity 2 Scenario 2: Rich Comic Character & Creative Drawing Scene
export const CharacterQuizIllustration: React.FC<{ className?: string }> = ({ className = "w-full max-w-sm h-40 sm:h-48" }) => (
  <svg viewBox="0 0 360 180" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-label="친구와 함께 만화 캐릭터 아이디어를 구상하는 장면 일러스트">
    {/* Studio / Art Classroom Background */}
    <rect width="360" height="180" rx="20" fill="#F0F8FF" />
    <path d="M0 135H360V180H0V135Z" fill="#E2EDF8" />
    <line x1="0" y1="135" x2="360" y2="135" stroke="#C3D9EE" strokeWidth="2" />

    {/* Art Easel / Drawing Tablet with Superhero Animal Character */}
    <g transform="translate(130, 20)">
      <rect width="100" height="110" rx="10" fill="#FFFFFF" stroke="#006398" strokeWidth="2.5" />
      {/* Canvas Top Clip */}
      <rect x="36" y="-6" width="28" height="10" rx="3" fill="#735C00" />
      
      {/* Cute Superhero Animal Character Drawing */}
      {/* Ears */}
      <polygon points="34,42 24,24 44,32" fill="#FFE087" stroke="#735C00" strokeWidth="1.5" />
      <polygon points="66,42 76,24 56,32" fill="#FFE087" stroke="#735C00" strokeWidth="1.5" />
      {/* Head */}
      <circle cx="50" cy="52" r="22" fill="#FFE087" stroke="#735C00" strokeWidth="2" />
      {/* Superhero Mask */}
      <path d="M34 50C42 44 58 44 66 50C70 56 64 62 50 62C36 62 30 56 34 50Z" fill="#006398" />
      <circle cx="42" cy="52" r="3" fill="#FFFFFF" />
      <circle cx="58" cy="52" r="3" fill="#FFFFFF" />
      <circle cx="50" cy="62" r="2" fill="#BA1A1A" />
      {/* Superhero Cape */}
      <path d="M36 74L20 100H80L64 74Z" fill="#BA1A1A" opacity="0.85" />
      {/* Character body */}
      <path d="M38 74C38 68 44 66 50 66C56 66 62 68 62 74V96H38V74Z" fill="#FFE087" stroke="#735C00" strokeWidth="1.5" />
      <polygon points="50,72 53,78 60,78 55,82 57,88 50,84 43,88 45,82 40,78 47,78" fill="#FFAE00" />
    </g>

    {/* Student 1 (Left) holding paintbrush */}
    <g transform="translate(30, 42)">
      <path d="M16 94C16 70 30 62 48 62C66 62 80 70 80 94H16Z" fill="#6CBDFE" />
      <circle cx="48" cy="34" r="20" fill="#FFE087" />
      <path d="M28 30C28 16 38 10 48 10C58 10 68 16 68 30C68 32 65 34 62 34C60 28 55 24 48 24C41 24 36 28 34 34C31 34 28 32 28 30Z" fill="#4D4634" />
      <ellipse cx="43" cy="34" rx="2" ry="3" fill="#241A00" />
      <ellipse cx="55" cy="34" rx="2" ry="3" fill="#241A00" />
      <path d="M46 42C48 45 51 45 53 42" stroke="#735C00" strokeWidth="1.5" strokeLinecap="round" />
      {/* Paintbrush in hand */}
      <path d="M72 68L92 50L86 44L66 62L72 68Z" fill="#FFAE00" stroke="#735C00" strokeWidth="1.5" />
      <polygon points="92,50 98,44 92,38 86,44" fill="#006398" />
    </g>

    {/* Student 2 (Right) giving creative idea thumbs up */}
    <g transform="translate(250, 42)">
      <path d="M16 94C16 70 30 62 48 62C66 62 80 70 80 94H16Z" fill="#FFAE00" />
      <circle cx="48" cy="34" r="20" fill="#FFE087" />
      <path d="M28 30C28 16 38 10 48 10C58 10 68 16 68 30C68 32 65 34 62 34C60 28 55 24 48 24C41 24 36 28 34 34C31 34 28 32 28 30Z" fill="#4D4634" />
      <ellipse cx="43" cy="34" rx="2" ry="3" fill="#241A00" />
      <ellipse cx="55" cy="34" rx="2" ry="3" fill="#241A00" />
      <path d="M46 42C48 45 51 45 53 42" stroke="#735C00" strokeWidth="1.5" strokeLinecap="round" />
      {/* Idea Sparkle Bulb */}
      <g transform="translate(28, -20)">
        <circle cx="20" cy="20" r="14" fill="#FFE087" stroke="#735C00" strokeWidth="2" />
        <path d="M16 28H24" stroke="#735C00" strokeWidth="2" strokeLinecap="round" />
        <circle cx="20" cy="18" r="4" fill="#FFAE00" />
      </g>
    </g>
  </svg>
);

// 5. Activity 2 Scenario 3: Rich Nature Trip & Outdoor Ecological Park Scene
export const NatureTripIllustration: React.FC<{ className?: string }> = ({ className = "w-full max-w-sm h-40 sm:h-48" }) => (
  <svg viewBox="0 0 360 180" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-label="가족과 함께 생태 공원 및 식물원 자연 탐방을 계획하는 장면 일러스트">
    {/* Outdoor Nature Sky Background */}
    <rect width="360" height="180" rx="20" fill="#E8F8F0" />
    
    {/* Rolling Green Hills & Mountains */}
    <path d="M0 130C60 100 120 110 180 125C240 140 300 115 360 120V180H0V130Z" fill="#8CE0AB" />
    <path d="M0 145C80 130 160 150 240 140C300 130 340 145 360 150V180H0V145Z" fill="#4CAF50" />

    {/* Bright Sun & Clouds */}
    <circle cx="310" cy="36" r="18" fill="#FFAE00" stroke="#FFE087" strokeWidth="3" />
    <path d="M40 36C40 28 46 22 54 22C60 22 65 26 67 31C68 30 70 30 72 30C78 30 82 34 82 40C82 46 78 50 72 50H48C43.5 50 40 46.5 40 42V36Z" fill="#FFFFFF" opacity="0.9" />

    {/* Pine Trees & Botanical Greenhouse */}
    {/* Big Pine Tree (Left) */}
    <g transform="translate(48, 56)">
      <polygon points="30,10 12,40 48,40" fill="#2E8B57" />
      <polygon points="30,30 8,62 52,62" fill="#227044" />
      <polygon points="30,50 4,84 56,84" fill="#1B5E20" />
      <rect x="26" y="84" width="8" height="18" fill="#4D4634" />
    </g>

    {/* Botanical Dome / Greenhouse in the background */}
    <g transform="translate(130, 68)">
      <path d="M20 62C20 28 46 12 80 12C114 12 140 28 140 62H20Z" fill="#CDE5FF" stroke="#006398" strokeWidth="2.5" />
      {/* Dome grid lines */}
      <line x1="80" y1="12" x2="80" y2="62" stroke="#006398" strokeWidth="1.5" />
      <path d="M42 62C42 36 58 20 80 20C102 20 118 36 118 62" stroke="#006398" strokeWidth="1.5" fill="none" />
      <line x1="26" y1="42" x2="134" y2="42" stroke="#006398" strokeWidth="1.5" />
      {/* Tropical Plants inside Dome */}
      <circle cx="65" cy="50" r="8" fill="#4CAF50" />
      <circle cx="95" cy="48" r="10" fill="#2E8B57" />
    </g>

    {/* Student Explorer with Magnifying Glass looking at Beetle/Butterfly */}
    <g transform="translate(250, 68)">
      <path d="M20 72C20 54 30 46 44 46C58 46 68 54 68 72H20Z" fill="#006398" />
      <circle cx="44" cy="24" r="16" fill="#FFE087" />
      {/* Explorer Hat */}
      <path d="M22 18H66L58 6H30L22 18Z" fill="#D0C6AE" stroke="#735C00" strokeWidth="1.5" />
      <line x1="16" y1="18" x2="72" y2="18" stroke="#735C00" strokeWidth="2" strokeLinecap="round" />
      {/* Face */}
      <ellipse cx="40" cy="24" rx="2" ry="2.5" fill="#241A00" />
      <ellipse cx="50" cy="24" rx="2" ry="2.5" fill="#241A00" />
      <path d="M42 30C44 32 46 32 48 30" stroke="#735C00" strokeWidth="1.5" strokeLinecap="round" />

      {/* Magnifying Glass */}
      <circle cx="20" cy="38" r="10" stroke="#735C00" strokeWidth="2" fill="#FFFFFF" fillOpacity="0.6" />
      <line x1="13" y1="45" x2="4" y2="54" stroke="#735C00" strokeWidth="3" strokeLinecap="round" />
      {/* Cute Ladybug */}
      <circle cx="20" cy="38" r="4" fill="#BA1A1A" />
      <circle cx="19" cy="37" r="1" fill="#FFFFFF" />
    </g>

    {/* Location Pin Badge */}
    <g transform="translate(190, 20)">
      <rect width="84" height="34" rx="17" fill="#006398" />
      <circle cx="17" cy="17" r="9" fill="#FFE087" />
      <circle cx="17" cy="17" r="4" fill="#735C00" />
      <text x="50" y="22" fill="#FFFFFF" fontSize="11" fontWeight="bold" textAnchor="middle">생태 공원</text>
    </g>
  </svg>
);

// 6. Activity 3: School Event Poster & Campaign Slogan Creation Scene
export const SchoolPosterIllustration: React.FC<{ className?: string }> = ({ className = "w-full max-w-sm h-40 sm:h-48" }) => (
  <svg viewBox="0 0 360 180" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-label="학급 친구들과 함께 환경 캠페인 포스터를 만드는 장면 일러스트">
    <rect width="360" height="180" rx="20" fill="#F4F9FF" />
    <path d="M0 135H360V180H0V135Z" fill="#E5F0FC" />
    <line x1="0" y1="135" x2="360" y2="135" stroke="#C8DEF7" strokeWidth="2" />

    {/* Large Campaign Poster Board in Center */}
    <g transform="translate(115, 14)">
      <rect width="130" height="126" rx="10" fill="#FFFFFF" stroke="#006398" strokeWidth="3" />
      {/* Wooden Easel Legs */}
      <line x1="10" y1="126" x2="-6" y2="155" stroke="#735C00" strokeWidth="3" strokeLinecap="round" />
      <line x1="120" y1="126" x2="136" y2="155" stroke="#735C00" strokeWidth="3" strokeLinecap="round" />
      
      {/* Poster Header */}
      <rect x="12" y="12" width="106" height="24" rx="5" fill="#FFE087" />
      <text x="65" y="28" fill="#735C00" fontSize="12" fontWeight="bold" textAnchor="middle">🌱 지구 살리기 캠페인</text>
      
      {/* Recycling Symbols & Earth graphic on poster */}
      <circle cx="65" cy="62" r="18" fill="#CDE5FF" stroke="#006398" strokeWidth="2" />
      <path d="M57 60C61 54 69 54 73 60" stroke="#4CAF50" strokeWidth="3" strokeLinecap="round" fill="none" />
      <path d="M73 64C69 70 61 70 57 64" stroke="#4CAF50" strokeWidth="3" strokeLinecap="round" fill="none" />
      <polygon points="76,60 74,54 70,58" fill="#4CAF50" />
      <polygon points="54,64 56,70 60,66" fill="#4CAF50" />

      {/* Slogan Lines */}
      <rect x="20" y="90" width="90" height="6" rx="3" fill="#6CBDFE" />
      <rect x="28" y="102" width="74" height="6" rx="3" fill="#FFAE00" />
    </g>

    {/* Group Member 1 (Left) holding clipboard */}
    <g transform="translate(24, 40)">
      <path d="M16 94C16 70 30 62 48 62C66 62 80 70 80 94H16Z" fill="#006398" />
      <circle cx="48" cy="34" r="20" fill="#FFE087" />
      <path d="M28 30C28 16 38 10 48 10C58 10 68 16 68 30C68 32 65 34 62 34C60 28 55 24 48 24C41 24 36 28 34 34C31 34 28 32 28 30Z" fill="#4D4634" />
      <ellipse cx="43" cy="34" rx="2" ry="3" fill="#241A00" />
      <ellipse cx="55" cy="34" rx="2" ry="3" fill="#241A00" />
      <path d="M46 42C48 45 51 45 53 42" stroke="#735C00" strokeWidth="1.5" strokeLinecap="round" />
      {/* Clipboard */}
      <rect x="58" y="60" width="24" height="32" rx="3" fill="#D0C6AE" stroke="#735C00" strokeWidth="1.5" />
      <rect x="64" y="56" width="12" height="6" rx="2" fill="#735C00" />
      <line x1="62" y1="68" x2="78" y2="68" stroke="#006398" strokeWidth="1.5" />
      <line x1="62" y1="74" x2="76" y2="74" stroke="#006398" strokeWidth="1.5" />
    </g>

    {/* Group Member 2 (Right) painting poster */}
    <g transform="translate(260, 40)">
      <path d="M16 94C16 70 30 62 48 62C66 62 80 70 80 94H16Z" fill="#FFAE00" />
      <circle cx="48" cy="34" r="20" fill="#FFE087" />
      <path d="M28 30C28 16 38 10 48 10C58 10 68 16 68 30C68 32 65 34 62 34C60 28 55 24 48 24C41 24 36 28 34 34C31 34 28 32 28 30Z" fill="#4D4634" />
      <ellipse cx="43" cy="34" rx="2" ry="3" fill="#241A00" />
      <ellipse cx="55" cy="34" rx="2" ry="3" fill="#241A00" />
      <path d="M46 42C48 45 51 45 53 42" stroke="#735C00" strokeWidth="1.5" strokeLinecap="round" />
      {/* Paint Brush */}
      <path d="M24 72L4 52L10 46L30 66L24 72Z" fill="#006398" />
      <polygon points="4,52 -2,46 4,40 10,46" fill="#4CAF50" />
    </g>
  </svg>
);

// 7. Application Screen: Pausing 3 seconds before sending AI request
export const PreSendCheckIllustration: React.FC<{ className?: string }> = ({ className = "w-full max-w-sm h-40 sm:h-48" }) => (
  <svg viewBox="0 0 360 180" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-label="전송 전 3초 동안 멈추고 개인정보를 확인하는 장면 일러스트">
    <rect width="360" height="180" rx="20" fill="#F8F9FA" />
    <path d="M0 135H360V180H0V135Z" fill="#EAECEE" />
    <line x1="0" y1="135" x2="360" y2="135" stroke="#D5D8DC" strokeWidth="2" />

    {/* 3-Second Pause Timer Clock (Left) */}
    <g transform="translate(36, 30)">
      <circle cx="50" cy="50" r="46" fill="#FFF9DB" stroke="#FFE087" strokeWidth="4" />
      <circle cx="50" cy="50" r="38" fill="#FFFFFF" stroke="#735C00" strokeWidth="2" />
      {/* Clock Hands pointing to 3 seconds */}
      <line x1="50" y1="50" x2="50" y2="24" stroke="#006398" strokeWidth="3" strokeLinecap="round" />
      <line x1="50" y1="50" x2="72" y2="50" stroke="#BA1A1A" strokeWidth="3" strokeLinecap="round" />
      <circle cx="50" cy="50" r="4" fill="#735C00" />
      {/* 3-Sec Badge */}
      <rect x="22" y="80" width="56" height="20" rx="10" fill="#FFE087" stroke="#735C00" strokeWidth="1.5" />
      <text x="50" y="94" fill="#735C00" fontSize="11" fontWeight="bold" textAnchor="middle">3초 생각!</text>
    </g>

    {/* Student pausing hand before pressing Send */}
    <g transform="translate(150, 24)">
      {/* Message Chat Screen */}
      <rect width="180" height="110" rx="14" fill="#FFFFFF" stroke="#006398" strokeWidth="2.5" />
      {/* Header bar */}
      <rect x="0" y="0" width="180" height="26" rx="14" fill="#CDE5FF" />
      <text x="90" y="17" fill="#004B75" fontSize="11" fontWeight="bold" textAnchor="middle">AI 전송 전 안전 점검</text>
      
      {/* Message Bubble */}
      <rect x="14" y="38" width="152" height="42" rx="8" fill="#F0F7FF" stroke="#6CBDFE" strokeWidth="1" />
      <line x1="24" y1="50" x2="110" y2="50" stroke="#006398" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="24" y1="62" x2="140" y2="62" stroke="#4CAF50" strokeWidth="2.5" strokeLinecap="round" />

      {/* Stop & Check Shield Icon */}
      <g transform="translate(68, 86)">
        <rect width="44" height="20" rx="6" fill="#4CAF50" />
        <text x="22" y="14" fill="#FFFFFF" fontSize="10" fontWeight="bold" textAnchor="middle">안전 확인</text>
      </g>
      
      {/* Send Button with Pause Hand */}
      <circle cx="150" cy="96" r="14" fill="#006398" />
      <polygon points="146,90 156,96 146,102" fill="#FFFFFF" />
    </g>
  </svg>
);

// 8. Reflection Screen: High-Clarity Thought Growth Comparison Illustration
export const ReflectionCompareIllustration: React.FC<{ className?: string }> = ({ className = "w-full max-w-sm h-40 sm:h-48" }) => (
  <svg viewBox="0 0 360 180" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-label="처음 생각과 지금 생각의 성장을 비교하는 학생 일러스트">
    {/* Clean Warm Background */}
    <rect width="360" height="180" rx="20" fill="#FFFDF8" />
    <path d="M0 135H360V180H0V135Z" fill="#F8F3E6" />
    <line x1="0" y1="135" x2="360" y2="135" stroke="#E6DDC8" strokeWidth="2" />

    {/* Left Thought Box: Start of Class (Uncertain) */}
    <g transform="translate(18, 24)">
      <rect width="100" height="76" rx="12" fill="#F3F4F5" stroke="#A8A29E" strokeWidth="2" />
      <polygon points="60,76 70,88 68,76" fill="#F3F4F5" />
      <rect x="14" y="10" width="72" height="18" rx="6" fill="#E1E3E4" />
      <text x="50" y="23" fill="#5F6368" fontSize="10" fontWeight="bold" textAnchor="middle">수업 전 생각</text>
      <text x="50" y="46" fill="#4D4634" fontSize="11" fontWeight="bold" textAnchor="middle">"모두 알려주면</text>
      <text x="50" y="62" fill="#4D4634" fontSize="11" fontWeight="bold" textAnchor="middle">더 잘 도와줄까?"</text>
    </g>

    {/* Connecting Growth Evolution Arrow */}
    <g transform="translate(122, 50)">
      <path d="M6 16C18 6 36 6 48 16" stroke="#006398" strokeWidth="3" strokeLinecap="round" strokeDasharray="4 4" fill="none" />
      <polygon points="52,18 42,12 44,22" fill="#006398" />
      <text x="28" y="32" fill="#006398" fontSize="10" fontWeight="bold" textAnchor="middle">배움의 성장</text>
    </g>

    {/* Student in the center proud & enlightened */}
    <g transform="translate(142, 64)">
      <path d="M18 70C18 50 28 42 40 42C52 42 62 50 62 70H18Z" fill="#006398" />
      <circle cx="40" cy="24" r="16" fill="#FFE087" />
      <path d="M24 20C24 10 32 6 40 6C48 6 56 10 56 20C56 22 54 24 52 24C50 18 45 15 40 15C35 15 30 18 28 24C26 24 24 22 24 20Z" fill="#4D4634" />
      <ellipse cx="36" cy="24" rx="2" ry="2.5" fill="#241A00" />
      <ellipse cx="44" cy="24" rx="2" ry="2.5" fill="#241A00" />
      <path d="M37 30C39 33 41 33 43 30" stroke="#735C00" strokeWidth="1.5" strokeLinecap="round" />
      {/* Lightbulb of insight */}
      <circle cx="40" cy="-4" r="9" fill="#FFE087" stroke="#735C00" strokeWidth="1.5" />
      <path d="M37 2H43" stroke="#735C00" strokeWidth="1.5" strokeLinecap="round" />
    </g>

    {/* Right Thought Box: Now (Wise & Safe AI Ethics) */}
    <g transform="translate(242, 20)">
      <rect width="100" height="82" rx="12" fill="#FFF9DB" stroke="#735C00" strokeWidth="2.5" />
      <polygon points="30,82 22,96 38,82" fill="#FFF9DB" />
      <rect x="14" y="10" width="72" height="18" rx="6" fill="#FFE087" />
      <text x="50" y="23" fill="#735C00" fontSize="10" fontWeight="bold" textAnchor="middle">수업 후 다짐</text>
      <text x="50" y="46" fill="#191C1D" fontSize="11" fontWeight="bold" textAnchor="middle">"개인정보는 빼고,</text>
      <text x="50" y="62" fill="#006398" fontSize="11" fontWeight="bold" textAnchor="middle">안전하게 바꿔요!"</text>
    </g>
  </svg>
);
