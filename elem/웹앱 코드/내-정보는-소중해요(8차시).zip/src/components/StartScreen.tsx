import React from 'react';
import { User, Bot, Edit3, Lock, ArrowRight, CloudSun } from 'lucide-react';
import { INITIAL_OPTIONS, START_VIRTUAL_REQUEST } from '../data/lessonData';
import { StudentWeatherAiIllustration } from './Illustrations';

interface StartScreenProps {
  initialThought: string;
  isLocked?: boolean;
  onSelectThought: (thought: string) => void;
  onNext: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  initialThought,
  isLocked = false,
  onSelectThought,
  onNext,
}) => {
  return (
    <div className="w-full max-w-3xl mx-auto py-6 px-4 sm:px-6 flex flex-col items-center">
      {/* Visual Context Card: Large Representative Illustration at Top */}
      <div className="flex flex-col items-center justify-center w-full mb-6 bg-white p-6 sm:p-8 rounded-3xl border border-[#e1e3e4] card-shadow">
        {/* Big Top Situation Illustration */}
        <div className="w-full flex justify-center mb-5">
          <StudentWeatherAiIllustration className="w-full max-w-md h-40 sm:h-48" />
        </div>
        
        {/* Situation Badge, Title, & Description */}
        <div className="text-center max-w-xl">
          <div className="inline-flex items-center gap-1.5 bg-[#cde5ff] text-[#004b75] px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-bold mb-2.5">
            <CloudSun className="w-4 h-4 text-[#006398]" />
            <span>상황: 내일 날씨와 등교 옷차림 질문하기</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#191c1d] leading-snug mb-2">
            AI에게 도움을 받으려면<br className="hidden sm:inline" />
            내 정보를 모두 알려 줘야 할까요?
          </h2>
          <p className="text-xs sm:text-sm text-[#4d4634] leading-relaxed break-keep">
            철수가 내일 학교에 입고 갈 옷차림을 AI에게 물어보려고 가상의 요청문을 작성하고 있어요.
          </p>
        </div>
      </div>

      {/* Simulated Chat Request Card */}
      <div className="w-full bg-[#f3f4f5] rounded-3xl p-6 sm:p-8 relative card-shadow border border-[#d0c6ae]/40 mb-6">
        <div className="absolute -top-4 left-8 sm:left-12 bg-white text-[#735c00] border border-[#ffd54f] px-5 py-1.5 rounded-full text-xs sm:text-sm font-bold shadow-xs flex items-center gap-1.5">
          <Edit3 className="w-4 h-4 text-[#735c00]" />
          <span>가상의 AI 요청문 작성 중...</span>
        </div>

        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-xs border-2 border-transparent relative mt-2">
          <p className="text-base sm:text-lg text-[#191c1d] leading-relaxed break-keep">
            "{START_VIRTUAL_REQUEST}"
          </p>
        </div>
      </div>

      {/* Core Question & Interactive Options Card */}
      <div className="w-full bg-white p-6 sm:p-8 rounded-3xl card-shadow border border-[#e1e3e4] flex flex-col items-center">
        <p className="text-sm sm:text-base font-semibold text-center text-[#4d4634] mb-5 break-keep">
          위의 요청문을 보았을 때, 나의 생각은 어떤가요?
        </p>

        {/* 3 Option Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 w-full justify-center mb-8">
          {INITIAL_OPTIONS.map((option) => {
            const isSelected = initialThought === option.text;
            return (
              <button
                key={option.id}
                disabled={isLocked}
                onClick={() => !isLocked && onSelectThought(option.text)}
                className={`flex-1 py-4 px-5 rounded-2xl text-sm sm:text-base font-semibold transition-all text-center flex items-center justify-center min-h-[56px] border-2 ${
                  isSelected
                    ? `bg-[#ffe087] border-[#735c00] text-[#241a00] shadow-md scale-102 ring-2 ring-[#ffd54f]/50 ${isLocked ? 'cursor-default' : ''}`
                    : isLocked
                    ? 'bg-[#f8f9fa] border-transparent text-[#7f7662] opacity-50 cursor-not-allowed'
                    : 'bg-[#f8f9fa] border-transparent text-[#4d4634] hover:bg-[#e7e8e9] hover:border-[#d0c6ae]'
                }`}
              >
                <span>{option.text}</span>
              </button>
            );
          })}
        </div>

        {/* Submit Action Button */}
        <button
          disabled={!initialThought}
          onClick={onNext}
          className={`min-h-[56px] px-10 rounded-full font-bold text-base sm:text-lg transition-all flex items-center gap-3 shadow-md ${
            initialThought
              ? 'bg-[#006398] text-white hover:bg-[#004b75] hover:scale-102 cursor-pointer'
              : 'bg-[#e1e3e4] text-[#7f7662] cursor-not-allowed opacity-70'
          }`}
        >
          <span>{isLocked ? '활동 1로 이동하기' : '살펴보러 가기'}</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        {!initialThought && (
          <p className="text-xs text-[#7f7662] mt-3">
            위의 3가지 선택지 중 나의 생각을 하나 골라 보세요!
          </p>
        )}
      </div>
    </div>
  );
};
