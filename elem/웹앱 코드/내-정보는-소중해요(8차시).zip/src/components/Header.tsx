import React, { useState } from 'react';
import { Shield, RotateCcw, HelpCircle } from 'lucide-react';
import { StepId } from '../types';
import { STEPS } from '../data/lessonData';

interface HeaderProps {
  currentStep: StepId;
  onReset: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentStep, onReset }) => {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);

  const currentStepObj = STEPS.find(s => s.id === currentStep);
  const stepNumber = currentStepObj ? currentStepObj.stepNumber : 1;

  return (
    <>
      <header className="sticky top-0 w-full z-40 bg-white/95 backdrop-blur-md border-b border-[#e1e3e4] shadow-xs px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#ffd54f]/30 border border-[#ffd54f] flex items-center justify-center text-[#735c00]">
            <Shield className="w-6 h-6 fill-[#ffd54f]" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-[#735c00] tracking-tight leading-tight">
              내 정보는 소중해요
            </h1>
            <p className="text-xs text-[#4e616a] hidden sm:block">
              초등학교 3~4학년 AI 윤리 수업
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          {currentStep !== 'summary' && (
            <div className="bg-[#f3f4f5] text-[#4d4634] text-xs sm:text-sm font-semibold px-3 py-1.5 rounded-full border border-[#d0c6ae]/40 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#006398] animate-pulse"></span>
              <span>총 6단계 중 {stepNumber}단계</span>
            </div>
          )}

          <button
            onClick={() => setShowGoalModal(true)}
            className="p-2 text-[#4e616a] hover:text-[#006398] hover:bg-[#c8dce7]/30 rounded-xl transition-colors"
            title="학습 목표 보기"
            aria-label="학습 목표"
          >
            <HelpCircle className="w-5 h-5" />
          </button>

          <button
            onClick={() => setShowResetConfirm(true)}
            className="p-2 text-[#4e616a] hover:text-[#ba1a1a] hover:bg-[#ffdad6]/40 rounded-xl transition-colors flex items-center gap-1 text-xs font-medium"
            title="처음부터 다시하기"
            aria-label="학습 초기화"
          >
            <RotateCcw className="w-4 h-4" />
            <span className="hidden md:inline">다시 시작</span>
          </button>
        </div>
      </header>

      {/* Goal Modal */}
      {showGoalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-[#e1e3e4] animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4 text-[#735c00]">
              <Shield className="w-6 h-6 fill-[#ffd54f]" />
              <h3 className="text-xl font-bold text-[#191c1d]">오늘의 학습 목표</h3>
            </div>
            
            <div className="space-y-3 text-sm text-[#4d4634] mb-6 leading-relaxed">
              <div className="bg-[#f8f9fa] p-3 rounded-xl border border-[#e1e3e4]">
                <strong className="text-[#006398] block mb-1">1. 개인정보 소중함 알기</strong>
                개인정보의 의미를 알고, AI를 사용할 때 내 정보가 노출될 수 있음을 이해해요.
              </div>
              <div className="bg-[#f8f9fa] p-3 rounded-xl border border-[#e1e3e4]">
                <strong className="text-[#006398] block mb-1">2. 안전한 편집 경험하기</strong>
                AI에게 보낼 요청문에서 불필요한 개인정보를 빼거나 바꾸어 안전하게 고쳐요.
              </div>
              <div className="bg-[#f8f9fa] p-3 rounded-xl border border-[#e1e3e4]">
                <strong className="text-[#006398] block mb-1">3. 생활 속 3초 점검 습관 기르기</strong>
                나와 다른 사람의 개인정보를 소중히 여기며 신중하게 입력하는 태도를 길러요.
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setShowGoalModal(false)}
                className="px-5 py-2.5 bg-[#006398] text-white text-sm font-semibold rounded-xl hover:bg-[#004b75] transition-colors"
              >
                확인했어요
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-[#e1e3e4] text-center">
            <div className="w-12 h-12 rounded-full bg-[#ffdad6] text-[#ba1a1a] flex items-center justify-center mx-auto mb-4">
              <RotateCcw className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-[#191c1d] mb-2">
              처음부터 다시 시작할까요?
            </h3>
            <p className="text-sm text-[#4d4634] mb-6">
              지금까지 작성한 모든 내용이 초기화됩니다.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 px-4 py-2.5 bg-[#f3f4f5] text-[#191c1d] font-semibold rounded-xl hover:bg-[#e7e8e9] transition-colors text-sm"
              >
                취소
              </button>
              <button
                onClick={() => {
                  onReset();
                  setShowResetConfirm(false);
                }}
                className="flex-1 px-4 py-2.5 bg-[#ba1a1a] text-white font-semibold rounded-xl hover:bg-[#93000a] transition-colors text-sm"
              >
                다시 시작하기
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
