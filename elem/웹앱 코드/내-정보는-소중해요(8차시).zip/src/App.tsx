import React from 'react';
import { useLessonStorage } from './hooks/useLessonStorage';
import { Header } from './components/Header';
import { StepNavigation } from './components/StepNavigation';
import { StartScreen } from './components/StartScreen';
import { Activity1Screen } from './components/Activity1Screen';
import { Activity2Screen } from './components/Activity2Screen';
import { Activity3Screen } from './components/Activity3Screen';
import { ApplicationScreen } from './components/ApplicationScreen';
import { ReflectionScreen } from './components/ReflectionScreen';
import { SummaryScreen } from './components/SummaryScreen';
import { StepId } from './types';

export default function App() {
  const {
    state,
    goToStep,
    markStepComplete,
    setInitialThought,
    toggleActivity1Segment,
    setActivity1Reason,
    completeActivity1,
    setActivity2ScenarioIndex,
    updateActivity2Segment,
    setActivity2ScenarioChecked,
    setActivity2ScenarioThought,
    setActivity2Thought,
    completeActivity2,
    setActivity3GroupRequest,
    setActivity3Check,
    setActivity3PeerFeedback,
    completeActivity3,
    updateApplicationSegment,
    completeApplication,
    setReflectionField,
    completeReflection,
    resetAll,
  } = useLessonStorage();

  const handleStartNext = () => {
    markStepComplete('start');
    goToStep('activity1');
  };

  const handleActivity1Next = () => {
    completeActivity1();
  };

  const handleActivity3Next = () => {
    goToStep('application');
  };

  const handleApplicationNext = () => {
    goToStep('reflection');
  };

  return (
    <div className="min-h-screen bg-[#f8f9fa] text-[#191c1d] flex flex-col font-sans selection:bg-[#ffd54f] selection:text-[#735c00]">
      {/* Top Application Header */}
      <Header
        currentStep={state.currentStep}
        onReset={resetAll}
      />

      {/* Steps Navigation Bar */}
      <StepNavigation
        currentStep={state.currentStep}
        completedSteps={state.completedSteps}
        onSelectStep={(stepId: StepId) => goToStep(stepId)}
      />

      {/* Main Learning Content Area */}
      <main className="flex-1 w-full flex flex-col items-center justify-start py-4 px-2 sm:px-4">
        {state.currentStep === 'start' && (
          <StartScreen
            initialThought={state.initialThought}
            isLocked={state.completedSteps.includes('start')}
            onSelectThought={setInitialThought}
            onNext={handleStartNext}
          />
        )}

        {state.currentStep === 'activity1' && (
          <Activity1Screen
            selectedIds={state.activity1SelectedIds}
            reason={state.activity1Reason}
            onToggleSegment={toggleActivity1Segment}
            onChangeReason={setActivity1Reason}
            onNext={handleActivity1Next}
          />
        )}

        {state.currentStep === 'activity2' && (
          <Activity2Screen
            scenarios={state.activity2Scenarios}
            currentScenarioIndex={state.activity2CurrentScenarioIndex}
            overallThought={state.activity2Thought}
            onSetScenarioIndex={setActivity2ScenarioIndex}
            onUpdateSegment={updateActivity2Segment}
            onSetScenarioChecked={setActivity2ScenarioChecked}
            onSetScenarioThought={setActivity2ScenarioThought}
            onSetOverallThought={setActivity2Thought}
            onCompleteActivity2={completeActivity2}
          />
        )}

        {state.currentStep === 'activity3' && (
          <Activity3Screen
            groupRequest={state.activity3GroupRequest}
            checks={state.activity3Checks}
            peerFeedback={state.activity3PeerFeedback}
            isCompleted={state.activity3Completed}
            onChangeRequest={setActivity3GroupRequest}
            onChangeCheck={setActivity3Check}
            onChangePeerFeedback={setActivity3PeerFeedback}
            onComplete={completeActivity3}
            onNext={handleActivity3Next}
          />
        )}

        {state.currentStep === 'application' && (
          <ApplicationScreen
            segments={state.applicationSegments}
            isCompleted={state.applicationCompleted}
            onUpdateSegment={updateApplicationSegment}
            onComplete={completeApplication}
            onNext={handleApplicationNext}
          />
        )}

        {state.currentStep === 'reflection' && (
          <ReflectionScreen
            initialThought={state.initialThought}
            howToChangeNow={state.reflectionHowToChangeNow}
            thoughtNow={state.reflectionThoughtNow}
            mostImportant={state.reflectionMostImportant}
            onChangeHowToChangeNow={(val) => setReflectionField('reflectionHowToChangeNow', val)}
            onChangeThoughtNow={(val) => setReflectionField('reflectionThoughtNow', val)}
            onChangeMostImportant={(val) => setReflectionField('reflectionMostImportant', val)}
            onComplete={completeReflection}
          />
        )}

        {state.currentStep === 'summary' && (
          <SummaryScreen
            state={state}
            onRestart={resetAll}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="w-full py-6 px-4 border-t border-[#e1e3e4] bg-[#f8f9fa] text-center text-xs text-[#7f7662] print:hidden">
        <p className="font-semibold text-[#4e616a]">
          초등학교 3~4학년을 위한 AI 윤리 교육 웹앱 · 내 정보는 소중해요
        </p>
        <p className="mt-1 text-[11px] text-[#7f7662]/80">
          * 본 프로그램에 제시된 모든 인물, 학교, 지역명은 교육용 가상 정보입니다.
        </p>
      </footer>
    </div>
  );
}
