export type StepId = 
  | 'start' 
  | 'activity1' 
  | 'activity2' 
  | 'activity3' 
  | 'application' 
  | 'reflection' 
  | 'summary';

export interface StepInfo {
  id: StepId;
  title: string;
  stepNumber: number;
  subtitle: string;
}

export type ActionType = 'none' | 'keep' | 'remove' | 'change';

export interface TextSegment {
  id: string;
  originalText: string;
  action: ActionType;
  changedText?: string;
  isPrivacySensitive: boolean;
  acceptableActions?: ActionType[];
  questionHint?: string;
  hint?: string;
}

export interface Activity2Scenario {
  id: string;
  title: string;
  category: string;
  description: string;
  segments: TextSegment[];
  stepThought: string;
  isChecked: boolean;
  isCompleted?: boolean;
}

export interface Activity3Checks {
  hasRequiredContent: boolean | null;
  noExcessPrivacy: boolean | null;
  isClearAndSafe: boolean | null;
}

export interface LessonState {
  currentStep: StepId;
  completedSteps: StepId[];
  
  // Step 1: Start
  initialThought: string; // '① 알려 줘도 괜찮을 것 같아요' | '② 조금 조심해야 할 것 같아요' | '③ 잘 모르겠어요' | ''
  
  // Step 2: Activity 1
  activity1SelectedIds: string[];
  activity1Reason: string;
  activity1Completed: boolean;
  
  // Step 3: Activity 2
  activity2Scenarios: Activity2Scenario[];
  activity2CurrentScenarioIndex: number;
  activity2Thought: string;
  activity2Completed: boolean;
  
  // Step 4: Activity 3
  activity3GroupRequest: string;
  activity3Checks: Activity3Checks;
  activity3PeerFeedback: string;
  activity3Completed: boolean;
  
  // Step 5: Life Application
  applicationSegments: TextSegment[];
  applicationCompleted: boolean;
  
  // Step 6: Reflection
  reflectionHowToChangeNow: string;
  reflectionThoughtNow: string;
  reflectionMostImportant: string;
  reflectionCompleted: boolean;
}
