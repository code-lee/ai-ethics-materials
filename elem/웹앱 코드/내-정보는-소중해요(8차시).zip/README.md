# 내 정보는 소중해요

초등학교 3~4학년을 위한 AI 윤리 수업 웹앱입니다.
AI 요청문 속 개인정보를 발견하고 안전하게 편집하는 학습 경험을 제공합니다.

## 기술 스택
- React 19
- TypeScript
- Tailwind CSS
- Vite

## 실행 방법

### 개발 모드 실행
```bash
npm run dev
```

### 프로덕션 빌드
```bash
npm run build
```
