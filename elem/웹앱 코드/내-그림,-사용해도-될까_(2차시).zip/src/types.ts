export type StepNumber = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

export type PeriodNumber = 1 | 2;

export type ScenarioId = 'lion';

export type RoleType = 'creator' | 'user' | 'friend' | 'observer';

export interface ScriptTemplate {
  title: string;
  line1: string;
  line2?: string;
}

export interface RoleInfo {
  id: RoleType;
  name: string;
  characterName: string;
  avatar: string;
  badgeColor: string;
  description: string;
  thought: string;
  scriptTemplate: ScriptTemplate;
}

export type ActionChoiceId = 'permission_and_credit' | 'no_permission' | 'name_only' | 'changed_so_ok';

export interface CharacterReaction {
  expression: string;
  emotion: string;
  dialogue: string;
}

export interface ChoiceResult {
  id: ActionChoiceId;
  title: string;
  description: string;
  isRecommended: boolean;
  creatorReaction: CharacterReaction;
  userReaction: CharacterReaction;
  friendReaction: CharacterReaction;
  observerAdvice: string;
}

export interface Step4EvaluationState {
  permissionCheck: boolean;
  creditCheck: boolean;
  aiCheck: boolean;
}

export interface Step5RoleSwitchState {
  creatorEmotions: string[];
  userEmotions: string[];
  groupDiscussed: boolean;
}

export type Step9ChoiceId = 'share_immediately' | 'name_only' | 'ask_permission' | 'no_share_if_denied';

export interface Step9ChoiceResult {
  id: Step9ChoiceId;
  title: string;
  description: string;
  isDesirable: boolean;
  creatorReaction: CharacterReaction;
  userReaction: CharacterReaction;
  groupChatReaction: CharacterReaction;
}

export interface ReflectionState {
  learned: string;
  felt: string;
  action: string;
  customSentence: string;
}

export interface ScenarioData {
  id: ScenarioId;
  title: string;
  subtitle: string;
  creatorName: string;
  userName: string;
  friendName: string;
  originalArtworkTitle: string;
  aiArtworkTitle: string;
  contextText: string;
  choices: ChoiceResult[];
}
