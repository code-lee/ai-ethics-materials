import { RoleInfo, ScenarioData, Step9ChoiceResult } from '../types';

export const ROLES: Record<string, RoleInfo> = {
  creator: {
    id: 'creator',
    name: '그림을 만든 사람',
    characterName: '민우',
    avatar: '🎨',
    badgeColor: 'bg-amber-100 text-amber-900 border-amber-300',
    description: '시간과 정성을 들여 소중한 그림 작품을 직접 그린 어린이',
    thought: '내가 정성껏 그린 그림을 내 허락 없이 사용한 상황입니다. 내 마음과 바라는 행동을 이야기해 봅시다.',
    scriptTemplate: {
      title: '그림을 만든 사람 (민우)',
      line1: '“내가 정성껏 그린 그림을 __________했는데, 나는 __________한 마음이 들어.”',
      line2: '“네가 __________________해 주었으면 좋겠어.”',
    },
  },
  user: {
    id: 'user',
    name: '그림을 AI로 바꾸어 게시한 사람',
    characterName: '수진',
    avatar: '🤖',
    badgeColor: 'bg-blue-100 text-blue-900 border-blue-300',
    description: '친구의 그림을 AI 프로그램으로 바꾸어 게시한 어린이',
    thought: '그림을 게시한 나의 솔직한 생각과 이유를 이야기해 봅시다.',
    scriptTemplate: {
      title: '그림을 사용한 사람 (수진)',
      line1: '“나는 그림을 AI로 __________했어.”',
      line2: '“나는 __________라고 생각해서 그림을 게시했어.”',
    },
  },
  friend: {
    id: 'friend',
    name: '게시물을 본 반 친구',
    characterName: '동현',
    avatar: '🧒',
    badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    description: '게시물을 보고 생각과 궁금한 점을 이야기하는 학급 친구',
    thought: '게시물을 보고 궁금한 점과 드는 생각을 이야기해 봅시다.',
    scriptTemplate: {
      title: '게시물을 본 반 친구',
      line1: '“두 그림을 보니 __________________가 궁금해.”',
      line2: '“나는 이 게시물을 보고 __________한 생각이 들었어.”',
    },
  },
  observer: {
    id: 'observer',
    name: '관찰자',
    characterName: '관찰자',
    avatar: '🔍',
    badgeColor: 'bg-purple-100 text-purple-900 border-purple-300',
    description: '인물의 말과 행동, 표정과 마음을 살펴보는 역할',
    thought: '친구들의 말과 행동, 각 인물의 마음을 유심히 살펴봅시다.',
    scriptTemplate: {
      title: '관찰자',
      line1: '• 인물의 말, 행동, 표정, 마음을 살피며 두 그림의 관계를 관찰하세요.',
    },
  },
};

export const CREATOR_EMOTIONS = [
  '속상한',
  '당황한',
  '존중받지 못한',
  '억울한',
  '답답한',
  '미안한',
  '이해하게 된',
  '조심해야겠다고 느낀',
];

export const USER_EMOTIONS = [
  '미안한',
  '당황한',
  '이해하게 된',
  '조심해야겠다고 느낀',
  '속상한',
  '존중받지 못한',
];

// Helper words for Step 2
export const ROLE_HINTS: Record<string, string[]> = {
  creator: ['속상한', '당황한', '억울한', '놀란', '정성껏 그린', '아끼는'],
  user: ['그림이 멋지다고 생각한', '친구들과 나누고 싶은', '재미있게 바꾸고 싶은', '문제가 없다고 생각한'],
  friend: ['궁금한', '헷갈리는', '두 그림의 관계', '누가 그린 그림인지'],
  observer: ['인물의 말', '행동', '표정', '마음', '두 그림의 관계'],
};

// Re-enactment scripts for Step 6
export const REENACTMENT_SCRIPTS = {
  user: {
    title: '그림을 사용하려는 사람 (수진)',
    line1: '“네 그림을 __________에 사용해도 될까?”',
    line2: '“게시할 때 ______________________________을 밝힐게.”',
    line3: '“AI로 ______________________________ 사실도 알릴게.”',
  },
  creator: {
    title: '그림을 만든 사람 (민우)',
    line1: '“나는 __________________한다면 사용해도 괜찮아.”',
    line2: '또는: “나는 사용을 허락하기 어려워. 대신 __________________해 줬으면 좋겠어.”',
  },
  friend: {
    title: '게시물을 본 반 친구',
    line1: '“처음 그림을 만든 사람과 __________________을 알 수 있어서 좋아.”',
    line2: '“허락받지 못했다면 __________________하는 것이 좋겠어.”',
  },
  observer: {
    title: '관찰자',
    line1: '“처음과 달라진 말이나 행동은 __________________이다.”',
    line2: '“그림을 만든 사람의 마음은 __________________해졌을 것 같다.”',
  },
};

export const SCENARIO_1: ScenarioData = {
  id: 'lion',
  title: '사례: 민우의 무지개 사자 그림과 수진이의 AI 우주 사자',
  subtitle: '학급 게시판에 친구 그림을 AI로 바꾸어 올릴 때의 예절',
  creatorName: '민우',
  userName: '수진',
  friendName: '동현',
  originalArtworkTitle: '무지개 사자 (손그림)',
  aiArtworkTitle: '우주 사자 (AI로 바꾼 그림)',
  contextText:
    '수진이는 민우가 그린 그림을 저장한 뒤 AI로 색과 배경을 바꾸어 자신의 그림처럼 게시했습니다.',
  choices: [
    {
      id: 'permission_and_credit',
      title: '1. 사용할 수 있는지 먼저 확인하고, 그림을 만든 사람과 출처, AI로 바꾼 사실을 밝힌다.',
      description: '민우에게 사용할 수 있는지 확인하고, 민우가 만든 원래 그림과 출처, AI로 바꾼 사실을 명확히 알리고 올린다.',
      isRecommended: true,
      creatorReaction: {
        expression: '😊',
        emotion: '안심되고 존중받는 마음',
        dialogue: '미리 사용할 수 있는지 물어봐 주고 내 이름과 출처, AI 활용 사실도 잘 알려줘서 마음이 안심되고 고마워!',
      },
      userReaction: {
        expression: '😄',
        emotion: '당당함과 뿌듯함',
        dialogue: '민우에게 사용하기 전에 허락을 구하고 바른 방법으로 표시하여 올리니 당당하고 마음이 뿌듯해!',
      },
      friendReaction: {
        expression: '👍',
        emotion: '기쁨과 명확한 정보',
        dialogue: '누가 처음 만들었고 어떻게 AI로 바뀌었는지 정확히 알 수 있어서 아주 좋아!',
      },
      observerAdvice: '사용 가능 여부 확인, 그림을 만든 사람과 출처 밝히기, AI로 바꾼 사실 알리기를 모두 올바르게 실천했습니다.',
    },
    {
      id: 'no_permission',
      title: '2. 허락 없이 바로 게시한다.',
      description: '민우에게 사용할 수 있는지 확인하지 않고, AI로 바꾼 그림을 그대로 올린다.',
      isRecommended: false,
      creatorReaction: {
        expression: '😢',
        emotion: '속상함과 억울함',
        dialogue: '내가 직접 만든 그림인데 나에게 확인하지 않고 사용해서 내 그림을 빼앗긴 것 같아 속상해.',
      },
      userReaction: {
        expression: '😰',
        emotion: '당황함과 미안함',
        dialogue: 'AI로 색과 배경을 바꿨으니 괜찮을 줄 알았는데, 민우가 상처받은 모습을 보니 당황스럽고 미안해.',
      },
      friendReaction: {
        expression: '😟',
        emotion: '헷갈림과 염려',
        dialogue: '누가 처음 만든 그림이고 어떻게 바뀌었는지 알 수 없어 헷갈려. 민우에게 확인은 한 걸까?',
      },
      observerAdvice: '그림을 사용할 수 있는지 사전에 확인하는 것이 무엇보다 중요합니다.',
    },
    {
      id: 'name_only',
      title: '3. 그림을 만든 사람의 이름만 표시하고 게시한다.',
      description: '사용할 수 있는지 확인하지 않고, 게시물 아래에 ‘그림을 만든 사람: 민우’라고만 표시하여 올린다.',
      isRecommended: false,
      creatorReaction: {
        expression: '😟',
        emotion: '답답함과 당황',
        dialogue: '이름이 적혀 있긴 하지만, 나에게 쓸 수 있는지 확인하지 않고 올리니 마음이 답답해.',
      },
      userReaction: {
        expression: '😅',
        emotion: '찝찝함',
        dialogue: '이름만 적으면 될 줄 알았는데, 민우에게 쓸 수 있는지 직접 허락을 구하지 않아 마음이 찜찜해.',
      },
      friendReaction: {
        expression: '🤔',
        emotion: '궁금함',
        dialogue: '민우 이름이 적혀 있긴 한데, 민우에게 정말 사용 허락을 받았는지는 알 수 없어.',
      },
      observerAdvice: '이름 표기 외에도 먼저 쓸 수 있는지 사전에 확인을 받는 과정이 필요합니다.',
    },
    {
      id: 'changed_so_ok',
      title: '4. 허락받지 못했지만 많이 바뀌었으므로 게시한다.',
      description: '민우에게 물어보지 않고 “AI가 아주 다르게 바꿨으니 괜찮겠지!” 하며 게시한다.',
      isRecommended: false,
      creatorReaction: {
        expression: '😠',
        emotion: '실망과 속상함',
        dialogue: '배경이나 색이 많이 바뀌었어도 처음 내 그림 형태가 그대로 있잖아! 확인하지 않고 올리면 속상해.',
      },
      userReaction: {
        expression: '😰',
        emotion: '후회스럽고 미안함',
        dialogue: 'AI로 많이 바꿨다고 내 마음대로 생각했는데, 처음 그림을 만든 민우의 권리를 먼저 생각했어야 했어.',
      },
      friendReaction: {
        expression: '🧐',
        emotion: '실망스러움',
        dialogue: '많이 바뀐 것 같아도 민우 그림을 바탕으로 한 게 보여. 꼭 미리 확인했어야지.',
      },
      observerAdvice: 'AI로 아무리 많이 바뀌었더라도 바탕이 된 원래 그림을 만든 사람의 허락과 존중이 우선입니다.',
    },
  ],
};

// Step 9 New Scenario Choices & Results
export const STEP9_SCENARIO_TEXT =
  '지호는 친구가 그린 동물 캐릭터를 AI로 스티커처럼 바꾸어 학급 단체 대화방에 공유하려고 합니다. 아직 그림을 만든 친구에게 사용할 수 있는지 확인하지 않았습니다.';

export const STEP9_CHOICES: Step9ChoiceResult[] = [
  {
    id: 'share_immediately',
    title: '1. 바로 공유한다.',
    description: '그림을 만든 친구에게 물어보지 않고 학급 대화방에 스티커를 바로 보낸다.',
    isDesirable: false,
    creatorReaction: {
      expression: '😢',
      emotion: '당황과 속상함',
      dialogue: '단톡방에 올라온 스티커 내 캐릭터잖아! 내 동의도 없이 올리면 어떡해.',
    },
    userReaction: {
      expression: '😰',
      emotion: '당황과 미안함',
      dialogue: '친구들이 좋아할 줄 알았는데 친구가 화를 내니 지호도 미안하고 당황스러워졌어요.',
    },
    groupChatReaction: {
      expression: '😟',
      emotion: '걱정과 헷갈림',
      dialogue: '친구 캐릭터 같은데, 지호가 사용할 수 있는지 확인은 하고 보낸 건지 걱정돼요.',
    },
  },
  {
    id: 'name_only',
    title: '2. 친구 이름만 적고 공유한다.',
    description: '메시지에 친구 이름만 적어 두고 사용할 수 있는지 확인 없이 스티커를 올린다.',
    isDesirable: false,
    creatorReaction: {
      expression: '😟',
      emotion: '불쾌함과 답답함',
      dialogue: '내 이름을 써 줬더라도, 내가 스티커로 바꾸어 공유하는 걸 허락한 건 아닌데…',
    },
    userReaction: {
      expression: '😅',
      emotion: '찝찝함과 미안함',
      dialogue: '이름을 적으면 괜찮을 줄 알았는데, 쓸 수 있는지 미리 확인했어야 했구나.',
    },
    groupChatReaction: {
      expression: '🤔',
      emotion: '궁금함',
      dialogue: '친구 이름은 적혀 있는데, 정말 사용할 수 있는지 제대로 확인했는지 궁금해해요.',
    },
  },
  {
    id: 'ask_permission',
    title: '3. 사용할 수 있는지 먼저 확인한다.',
    description: '그림을 만든 친구에게 사용해도 되는지 먼저 물어보고 허락을 받은 뒤 공유한다.',
    isDesirable: true,
    creatorReaction: {
      expression: '😊',
      emotion: '기쁨과 안심',
      dialogue: '지호가 쓸 수 있는지 미리 물어봐 주고, 내 캐릭터를 존중해 줘서 정말 고마워!',
    },
    userReaction: {
      expression: '😄',
      emotion: '뿌듯함과 기쁨',
      dialogue: '친구에게 허락을 구하고 바른 방법으로 전송하니 당당하고 기분 좋아!',
    },
    groupChatReaction: {
      expression: '👍',
      emotion: '기쁨과 응원',
      dialogue: '확인하고 올바르게 공유하니 학급 대화방 친구들도 다 함께 즐겁게 스티커를 사용해요!',
    },
  },
  {
    id: 'no_share_if_denied',
    title: '4. 허락받지 못하면 공유하지 않는다.',
    description: '그림을 만든 친구가 거절하거나 허락을 받지 못했다면 공유를 중단한다.',
    isDesirable: true,
    creatorReaction: {
      expression: '😌',
      emotion: '안심과 고마움',
      dialogue: '내가 부담스러울 때 마음을 존중해 주고 공유하지 않아 주어서 정말 고마워!',
    },
    userReaction: {
      expression: '🤝',
      emotion: '스스로 대견함',
      dialogue: '원하던 스티커는 못 보냈지만, 친구의 권리를 지켜주었으니 바른 선택을 한 거야.',
    },
    groupChatReaction: {
      expression: '👏',
      emotion: '칭찬과 존경',
      dialogue: '친구의 뜻을 존중하고 절제하는 지호의 모습을 칭찬해요!',
    },
  },
];

export const REFLECTION_HINTS = {
  learned: [
    '사용할 수 있는지 확인',
    '그림을 만든 사람',
    '출처',
    'AI로 바꾼 사실',
    '게시하지 않기',
  ],
  felt: [
    '속상함',
    '미안함',
    '당황함',
    '입장 이해',
    '존중받는 마음',
  ],
  action: [
    '먼저 확인하기',
    '그림을 만든 사람 밝히기',
    'AI로 바꾼 사실 알리기',
    '사용할 수 없으면 멈추기',
  ],
};
