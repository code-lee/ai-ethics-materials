import React, { useState } from 'react';
import { ScenarioData } from '../types';
import { AiSpaceLionArtwork } from './Artworks';
import { Wrench, ShieldCheck, ArrowRight, Printer, RotateCcw, Lightbulb } from 'lucide-react';

interface Step8Props {
  scenario: ScenarioData;
  permissionStatus: 'allowed' | 'denied' | 'unchecked' | null;
  discussedNoPostReason: boolean;
  attachedCards: string[];
  discussedCardReason: boolean;
  showPostResult: boolean;
  blank1: string;
  blank2: string;
  blank3: string;
  blank4: string;
  discussedCriteria: boolean;
  showCriteriaResult: boolean;
  onSelectPermissionStatus: (status: 'allowed' | 'denied' | 'unchecked' | null) => void;
  onToggleDiscussedNoPostReason: (val: boolean) => void;
  onToggleCard: (cardId: string) => void;
  onResetCards: () => void;
  onToggleDiscussedCardReason: (val: boolean) => void;
  onToggleShowPostResult: (val: boolean) => void;
  onUpdateBlank: (key: 'blank1' | 'blank2' | 'blank3' | 'blank4', val: string) => void;
  onToggleDiscussedCriteria: (val: boolean) => void;
  onToggleShowCriteriaResult: (val: boolean) => void;
  onNext: () => void;
  speakText: (text: string) => void;
  readOnly?: boolean;
}

interface CardDefinition {
  id: string;
  text: string;
  type: 'correct_creator' | 'correct_ai' | 'distractor';
}

export const Step8PostFixer: React.FC<Step8Props> = ({
  scenario,
  permissionStatus,
  discussedNoPostReason,
  attachedCards,
  discussedCardReason,
  showPostResult,
  blank1,
  blank2,
  blank3,
  blank4,
  discussedCriteria,
  showCriteriaResult,
  onSelectPermissionStatus,
  onToggleDiscussedNoPostReason,
  onToggleCard,
  onResetCards,
  onToggleDiscussedCardReason,
  onToggleShowPostResult,
  onUpdateBlank,
  onToggleDiscussedCriteria,
  onToggleShowCriteriaResult,
  onNext,
  speakText,
  readOnly = false,
}) => {
  const [showCriteriaHint, setShowCriteriaHint] = useState<boolean>(false);

  // Cards when permission is 'allowed' (NO 'dont_post' card included!)
  const allowedCards: CardDefinition[] = [
    {
      id: 'creator',
      text: '원래 그림: 민우의 「무지개 사자」',
      type: 'correct_creator',
    },
    {
      id: 'distractor_changed',
      text: '그림이 많이 달라졌으니 수진이가 만든 그림이에요.',
      type: 'distractor',
    },
    {
      id: 'distractor_name_only',
      text: '민우의 이름만 적으면 허락 없이 사용해도 돼요.',
      type: 'distractor',
    },
    {
      id: 'ai',
      text: '수진이가 AI를 활용하여 색과 배경을 바꾸었어요.',
      type: 'correct_ai',
    },
    {
      id: 'distractor_no_ai',
      text: 'AI로 바꾼 사실은 알리지 않아도 돼요.',
      type: 'distractor',
    },
    {
      id: 'distractor_free',
      text: '인터넷에 올라온 그림은 자유롭게 사용할 수 있어요.',
      type: 'distractor',
    },
  ];

  const handleSelectPermissionStatus = (status: 'allowed' | 'denied' | 'unchecked') => {
    if (readOnly) return;
    onSelectPermissionStatus(status);
  };

  const hasOriginalInfoCard = attachedCards.includes('creator');
  const hasAiDisclosureCard = attachedCards.includes('ai');
  const hasInappropriateCard =
    attachedCards.includes('distractor_changed') ||
    attachedCards.includes('distractor_name_only') ||
    attachedCards.includes('distractor_no_ai') ||
    attachedCards.includes('distractor_free');

  const isAllowedPostCorrect = hasOriginalInfoCard && hasAiDisclosureCard && !hasInappropriateCard;

  const isAllowedCompleted =
    permissionStatus === 'allowed' &&
    isAllowedPostCorrect &&
    discussedCardReason &&
    showPostResult;

  const isDeniedCompleted =
    permissionStatus === 'denied' &&
    discussedNoPostReason;

  const isCriteriaInputsFilled =
    blank1.trim() !== '' &&
    blank2.trim() !== '' &&
    blank3.trim() !== '' &&
    blank4.trim() !== '';

  const isFullyCompleted =
    (isAllowedCompleted || isDeniedCompleted) &&
    isCriteriaInputsFilled &&
    discussedCriteria &&
    showCriteriaResult;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-400 to-yellow-400 rounded-3xl p-5 sm:p-7 border-4 border-amber-300 shadow-lg text-slate-900">
        <div className="flex items-center gap-2 mb-2 text-amber-950 font-black text-xs sm:text-sm uppercase tracking-wide">
          <span className="bg-white/80 px-3 py-1 rounded-full border border-amber-400">2차시 · 8단계</span>
          <span>문제가 있는 그림 게시물 수정하기 (최종 산출물)</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-black text-slate-900 mb-2 leading-tight">
          "게시물을 바르게 고치기 위해 필요한 내용을 골라 보세요."
        </h2>
        <p className="text-sm sm:text-lg text-slate-800 font-medium leading-relaxed">
          먼저 그림 사용 허락 여부를 확인하고, 상황에 맞게 게시물을 고쳐 봅시다.
        </p>
      </div>

      {/* Initial Question: Permission Check Result */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-indigo-200 shadow-md space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-indigo-100">
          <span className="text-2xl">❓</span>
          <h3 className="text-base sm:text-lg font-black text-slate-900">
            민우에게 그림을 사용할 수 있는지 확인한 결과는 무엇인가요?
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            onClick={() => handleSelectPermissionStatus('allowed')}
            disabled={readOnly}
            className={`p-4 rounded-2xl border-2 font-black text-xs sm:text-sm transition flex items-center justify-center gap-2 ${
              readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
            } ${
              permissionStatus === 'allowed'
                ? 'bg-emerald-100 border-emerald-500 text-emerald-950 ring-2 ring-emerald-300'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span>1. 사용할 수 있도록 허락받았어요.</span>
          </button>

          <button
            onClick={() => handleSelectPermissionStatus('denied')}
            disabled={readOnly}
            className={`p-4 rounded-2xl border-2 font-black text-xs sm:text-sm transition flex items-center justify-center gap-2 ${
              readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
            } ${
              permissionStatus === 'denied'
                ? 'bg-rose-100 border-rose-500 text-rose-950 ring-2 ring-rose-300'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span>2. 사용할 수 없다는 답을 들었어요.</span>
          </button>

          <button
            onClick={() => handleSelectPermissionStatus('unchecked')}
            disabled={readOnly}
            className={`p-4 rounded-2xl border-2 font-black text-xs sm:text-sm transition flex items-center justify-center gap-2 ${
              readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
            } ${
              permissionStatus === 'unchecked'
                ? 'bg-amber-100 border-amber-500 text-amber-950 ring-2 ring-amber-300'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span>3. 아직 확인하지 않았어요.</span>
          </button>
        </div>

        {/* Guidance for unchecked status */}
        {permissionStatus === 'unchecked' && (
          <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 text-amber-950 text-xs sm:text-sm font-bold flex flex-col sm:flex-row items-center justify-between gap-3 animate-fadeIn">
            <span>⚠️ "그림을 게시하기 전에 사용할 수 있는지 먼저 확인해야 해요."</span>
            <button
              onClick={() => handleSelectPermissionStatus(null)}
              disabled={readOnly}
              className={`px-4 py-2 bg-amber-500 hover:bg-amber-600 text-amber-950 font-black rounded-xl text-xs transition shrink-0 ${
                readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
              }`}
            >
              확인 결과 다시 고르기
            </button>
          </div>
        )}
      </div>

      {/* Printable Consolidated Area */}
      <div className="printable-area space-y-6">
        <div className="hidden print:block mb-4 pb-4 border-b-2 border-slate-300 text-slate-900">
          <h1 className="text-xl font-black">[내 그림, 사용해도 될까?] 8단계 학습 활동지</h1>
          <p className="text-sm font-bold text-slate-700">게시물 고치기 및 그림 사용 기준 기록입니다.</p>
        </div>
        {/* BRANCH 1: allowed (사용할 수 있도록 허락받았어요) */}
        {permissionStatus === 'allowed' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fadeIn">
            {/* Card Palette (5 cols on lg) */}
            <div className="lg:col-span-5 bg-white rounded-3xl p-5 border-4 border-slate-200 shadow-md space-y-4 no-print">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <h3 className="text-base sm:text-lg font-black text-slate-800 flex items-center gap-2">
                  <Wrench className="w-5 h-5 text-amber-500" />
                  <span>게시물 수정 카드 목록</span>
                </h3>
                <button
                  onClick={() => !readOnly && onResetCards()}
                  disabled={readOnly}
                  className="text-xs text-slate-500 hover:text-slate-800 underline font-bold cursor-pointer"
                >
                  초기화
                </button>
              </div>

              <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                {allowedCards.map((card) => {
                  const isAttached = attachedCards.includes(card.id);

                  return (
                    <button
                      key={card.id}
                      onClick={() => !readOnly && onToggleCard(card.id)}
                      disabled={readOnly}
                      className={`w-full p-3.5 rounded-2xl border-2 text-left transition flex items-center justify-between gap-2.5 ${
                        readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                      } ${
                        isAttached
                          ? 'bg-amber-100 border-amber-500 ring-2 ring-amber-300 font-bold text-amber-950'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">🧩</span>
                        <span className="font-extrabold text-xs sm:text-sm">{card.text}</span>
                      </div>
                      <span
                        className={`text-xs font-black px-2.5 py-1 rounded-xl ${
                          isAttached
                            ? 'bg-amber-300 text-amber-950 border border-amber-400'
                            : 'bg-slate-200 text-slate-600 border border-slate-300'
                        }`}
                      >
                        {isAttached ? '선택됨' : '선택'}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Discussion Check & Confirm Button */}
              {attachedCards.length > 0 && !showPostResult && (
                <div className="space-y-3 pt-3 border-t border-slate-200 animate-fadeIn">
                  <label className="flex items-center gap-2.5 cursor-pointer select-none bg-amber-50 p-3 rounded-xl border border-amber-200">
                    <input
                      type="checkbox"
                      checked={discussedCardReason}
                      disabled={readOnly}
                      onChange={(e) => !readOnly && onToggleDiscussedCardReason(e.target.checked)}
                      className="w-5 h-5 rounded text-amber-600 focus:ring-amber-500 border-2 border-slate-300"
                    />
                    <span className="font-extrabold text-xs text-amber-950">
                      🗣️ 카드를 고른 이유를 이야기했습니다.
                    </span>
                  </label>

                  <button
                    onClick={() => {
                      if (readOnly) return;
                      onToggleShowPostResult(true);
                      speakText('수정된 게시물을 확인합니다.');
                    }}
                    disabled={!discussedCardReason || readOnly}
                    className={`w-full py-3 font-black text-sm rounded-xl shadow border-2 transition ${
                      discussedCardReason && !readOnly
                        ? 'bg-amber-400 hover:bg-amber-500 text-amber-950 border-amber-500 cursor-pointer'
                        : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                    }`}
                  >
                    🛠️ 게시물 고치기 결과 확인
                  </button>
                </div>
              )}
            </div>

            {/* Side-by-Side Posts (7 cols on lg) */}
            <div className="lg:col-span-7 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 1. 수정 전 게시물 (Before) */}
                <div className="bg-slate-900 text-white rounded-3xl p-4 border-4 border-amber-400 shadow-md space-y-3">
                  <div className="bg-amber-600 text-white px-3 py-1 rounded-xl text-xs font-black inline-block">
                    📌 수정 전 게시물 (문제 상황)
                  </div>

                  <div className="bg-slate-800 p-3 rounded-2xl border border-slate-700 text-xs font-bold text-amber-200">
                    “내가 만든 멋진 우주 사자입니다! 🚀”
                  </div>

                  <div className="max-w-[180px] mx-auto">
                    <AiSpaceLionArtwork showBadge={false} />
                  </div>

                  <div className="bg-slate-800/90 p-3 rounded-xl border border-amber-800/60 text-xs text-amber-200 font-bold text-center">
                    ❓ 이 게시물에서 더 확인하거나 고쳐야 할 부분을 찾아보세요.
                  </div>
                </div>

                {/* 2. 수정 후 게시물 (After) */}
                <div className="bg-slate-900 text-white rounded-3xl p-4 border-4 border-emerald-400 shadow-md space-y-3 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="bg-emerald-600 text-white px-3 py-1 rounded-xl text-xs font-black inline-block no-print">
                      ✨ 수정 후 게시물
                    </div>

                    {!showPostResult ? (
                      <div className="bg-slate-800/80 border-2 border-slate-700 rounded-2xl p-6 text-center space-y-2 my-auto">
                        <div className="text-3xl">🛠️</div>
                        <div className="text-xs font-black text-slate-300">
                          왼쪽에서 카드를 선택하고 이유를 말한 뒤 '게시물 고치기 결과 확인'을 누르세요.
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="max-w-[180px] mx-auto">
                          <AiSpaceLionArtwork showBadge={false} />
                        </div>

                        {/* Show lines strictly reflecting student's chosen cards */}
                        <div className="bg-slate-800 p-3 rounded-2xl border border-emerald-400/80 space-y-1.5 text-xs">
                          {attachedCards.map((cardId) => {
                            const card = allowedCards.find((c) => c.id === cardId);
                            if (!card) return null;
                            return (
                              <div key={cardId} className="text-emerald-300 font-bold">
                                • {card.text}
                              </div>
                            );
                          })}
                          <div className="text-emerald-300 font-bold border-t border-slate-700 pt-1.5 mt-1.5">
                            • 민우에게 그림 사용 허락을 받고 게시했어요.
                          </div>
                        </div>

                        {/* Feedback banner */}
                        {isAllowedPostCorrect ? (
                          <div className="p-3 bg-emerald-950/90 border border-emerald-500 text-emerald-200 rounded-xl font-extrabold text-xs">
                            ✅ 올바르게 게시물을 수정했습니다! (원래 그림 출처 표시 + AI 활용 안내 + 사용 허락 완료)
                          </div>
                        ) : (
                          <div className="bg-amber-950/90 border-2 border-amber-500 rounded-2xl p-3.5 text-amber-200 space-y-2 text-xs no-print">
                            <div className="font-black text-amber-300 flex items-center gap-1">
                              <span>💭</span>
                              <span>게시물을 다시 점검해 보기 위한 질문</span>
                            </div>
                            <ul className="list-disc pl-4 space-y-1 font-medium">
                              {!hasOriginalInfoCard && <li>그림을 만든 사람과 원래 그림 제목을 카드로 고르셨나요?</li>}
                              {!hasAiDisclosureCard && <li>AI로 바꾼 사실을 밝히는 카드를 고르셨나요?</li>}
                              {hasInappropriateCard && <li>부적절하거나 잘못된 카드가 포함되어 있지는 않나요?</li>}
                            </ul>
                            <div className="pt-1">
                              <button
                                onClick={() => {
                                  if (readOnly) return;
                                  onToggleShowPostResult(false);
                                  onToggleDiscussedCardReason(false);
                                }}
                                disabled={readOnly}
                                className={`w-full py-2 bg-amber-500 hover:bg-amber-600 text-amber-950 font-black text-xs rounded-xl shadow flex items-center justify-center gap-1 transition ${
                                  readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                                }`}
                              >
                                <RotateCcw className="w-4 h-4" />
                                <span>다시 수정하기</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* BRANCH 2: denied (사용할 수 없다는 답을 들었어요) */}
        {permissionStatus === 'denied' && (
          <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-rose-200 shadow-md space-y-5 animate-fadeIn">
            <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-5 text-rose-950 space-y-2">
              <div className="font-black text-rose-900 text-base sm:text-lg flex items-center gap-2">
                <span>🚫</span>
                <span>민우에게 그림 사용을 확인했지만 허락받지 못했어요. 따라서 이 그림은 게시하지 않아요.</span>
              </div>
              <p className="text-slate-700 text-xs sm:text-sm font-medium">
                친구의 의사를 존중하고 허락받지 못한 그림을 게시하지 않는 올바른 판단입니다!
              </p>
            </div>

            {/* Post non-published visual box */}
            <div className="bg-slate-900 text-white rounded-3xl p-6 border-4 border-rose-400 text-center space-y-3 max-w-lg mx-auto">
              <div className="text-4xl">🔒</div>
              <h4 className="text-lg font-black text-rose-300">게시하지 않기로 했어요.</h4>
              <p className="text-xs text-slate-300 font-medium">
                그림을 만든 사람의 허락을 얻지 못했으므로 그림을 수정하거나 인터넷에 올리지 않습니다.
              </p>
            </div>

            {/* Discussion prompt for denied status */}
            <div className="bg-rose-50/80 p-5 rounded-2xl border border-rose-200 space-y-3 no-print">
              <div className="font-black text-rose-950 text-xs sm:text-sm flex items-center gap-2">
                <span>💬</span>
                <span>허락받지 못한 그림을 게시하지 않아야 하는 까닭은 무엇인가요?</span>
              </div>

              <label className="flex items-center gap-3 cursor-pointer select-none bg-white p-3.5 rounded-xl border border-rose-200">
                <input
                  type="checkbox"
                  checked={discussedNoPostReason}
                  disabled={readOnly}
                  onChange={(e) => !readOnly && onToggleDiscussedNoPostReason(e.target.checked)}
                  className="w-5 h-5 rounded text-rose-600 focus:ring-rose-500 border-2 border-slate-300"
                />
                <span className="font-extrabold text-xs sm:text-sm text-rose-950">
                  🗣️ 우리 모둠은 게시하지 않아야 하는 까닭을 이야기했습니다.
                </span>
              </label>
            </div>
          </div>
        )}

        {/* Part 2: Criteria Completion (Fill in the blanks - printable) */}
        {(isAllowedCompleted || isDeniedCompleted) && (
          <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-indigo-200 shadow-md space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-2 border-b border-indigo-100">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-6 h-6 text-indigo-600" />
                <h3 className="text-lg font-black text-slate-900">
                  📜 그림 사용 기준 완성하기 (빈칸에 알맞은 말을 적어 보세요)
                </h3>
              </div>

              <button
                onClick={() => setShowCriteriaHint(!showCriteriaHint)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-xl text-xs font-black transition cursor-pointer no-print"
              >
                <Lightbulb className="w-4 h-4 text-amber-600" />
                <span>{showCriteriaHint ? '도움말 닫기' : '💡 작성 안내 보기'}</span>
              </button>
            </div>

            {showCriteriaHint && (
              <div className="bg-amber-50 border border-amber-300 p-3 rounded-2xl text-xs font-medium text-amber-950 space-y-1 animate-fadeIn no-print">
                <p className="text-slate-700">
                  💡 모둠 친구들과 함께 이야기하며 각 빈칸에 알맞은 단어를 스스로 적어 봅시다.
                </p>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm font-bold text-slate-800">
              {/* Item 1 */}
              <div className="p-3.5 rounded-2xl border-2 border-slate-200 bg-slate-50 space-y-1.5">
                <div>1. 다른 사람의 그림은 사용하기 전에</div>
                <input
                  type="text"
                  value={blank1}
                  disabled={readOnly}
                  onChange={(e) => onUpdateBlank('blank1', e.target.value)}
                  placeholder="알맞은 말을 적어 보세요."
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold text-indigo-950 focus:outline-none focus:border-indigo-500 disabled:bg-slate-100 disabled:text-slate-500"
                />
                <div>을 확인해요.</div>
              </div>

              {/* Item 2 */}
              <div className="p-3.5 rounded-2xl border-2 border-slate-200 bg-slate-50 space-y-1.5">
                <div>2. 그림을 만든 사람과</div>
                <input
                  type="text"
                  value={blank2}
                  disabled={readOnly}
                  onChange={(e) => onUpdateBlank('blank2', e.target.value)}
                  placeholder="알맞은 말을 적어 보세요."
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold text-indigo-950 focus:outline-none focus:border-indigo-500 disabled:bg-slate-100 disabled:text-slate-500"
                />
                <div>을 밝혀요.</div>
              </div>

              {/* Item 3 */}
              <div className="p-3.5 rounded-2xl border-2 border-slate-200 bg-slate-50 space-y-1.5">
                <div>3. AI로</div>
                <input
                  type="text"
                  value={blank3}
                  disabled={readOnly}
                  onChange={(e) => onUpdateBlank('blank3', e.target.value)}
                  placeholder="알맞은 말을 적어 보세요."
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold text-indigo-950 focus:outline-none focus:border-indigo-500 disabled:bg-slate-100 disabled:text-slate-500"
                />
                <div>사실을 알려요.</div>
              </div>

              {/* Item 4 */}
              <div className="p-3.5 rounded-2xl border-2 border-slate-200 bg-slate-50 space-y-1.5">
                <div>4. 사용할 수 없다면</div>
                <input
                  type="text"
                  value={blank4}
                  disabled={readOnly}
                  onChange={(e) => onUpdateBlank('blank4', e.target.value)}
                  placeholder="알맞은 말을 적어 보세요."
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold text-indigo-950 focus:outline-none focus:border-indigo-500 disabled:bg-slate-100 disabled:text-slate-500"
                />
                <div>하지 않아요.</div>
              </div>
            </div>

            {/* Checkbox & Example Criteria Button */}
            {isCriteriaInputsFilled && !showCriteriaResult && (
              <div className="space-y-3 pt-3 border-t border-indigo-100 animate-fadeIn no-print">
                <label className="flex items-center gap-3 cursor-pointer select-none bg-indigo-50 p-3.5 rounded-2xl border border-indigo-200">
                  <input
                    type="checkbox"
                    checked={discussedCriteria}
                    disabled={readOnly}
                    onChange={(e) => !readOnly && onToggleDiscussedCriteria(e.target.checked)}
                    className="w-6 h-6 rounded-lg text-indigo-600 focus:ring-indigo-500 border-2 border-indigo-300"
                  />
                  <span className="font-extrabold text-xs sm:text-sm text-indigo-950">
                    🗣️ 우리 모둠이 그림 사용 기준을 이야기하며 완성했습니다.
                  </span>
                </label>

                <div className="flex justify-center">
                  <button
                    onClick={() => {
                      if (readOnly) return;
                      onToggleShowCriteriaResult(true);
                      speakText('핵심 내용을 확인합니다.');
                    }}
                    disabled={!discussedCriteria || readOnly}
                    className={`py-3 px-8 font-black text-xs sm:text-sm rounded-2xl shadow-lg border-2 transition ${
                      discussedCriteria && !readOnly
                        ? 'bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-700 cursor-pointer hover:scale-102'
                        : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                    }`}
                  >
                    📘 핵심 내용 확인하기
                  </button>
                </div>
              </div>
            )}

            {/* Deep Dive & Core Concept Section (깊이 알아보기) */}
            {showCriteriaResult && (
              <div className="bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-5 sm:p-7 border-4 border-indigo-400 shadow-xl space-y-5 animate-fadeIn">
                <div className="flex items-center gap-2.5 pb-3 border-b border-indigo-700">
                  <span className="text-2xl">📘</span>
                  <div>
                    <h3 className="text-lg sm:text-xl font-black text-indigo-200">
                      깊이 알아보기
                    </h3>
                    <p className="text-xs sm:text-sm font-extrabold text-amber-300">
                      저작권과 그림을 바르게 사용하는 방법 알아보기
                    </p>
                  </div>
                </div>

                <p className="text-xs sm:text-sm font-medium text-indigo-100 leading-relaxed bg-indigo-950/70 p-3.5 rounded-2xl border border-indigo-700/60">
                  앞에서 게시물을 직접 고치고 그림 사용 기준을 정리한 내용을 바탕으로, 저작권의 뜻과 바른 그림 사용 방법을 확인해 봅시다.
                </p>

                {/* 1. 저작권은 무엇일까요? */}
                <div className="space-y-2.5">
                  <h4 className="text-sm sm:text-base font-black text-amber-300 flex items-center gap-2">
                    <span>💡</span>
                    <span>저작권은 무엇일까요?</span>
                  </h4>
                  <div className="bg-slate-800/90 p-4 rounded-2xl border border-slate-700 space-y-2">
                    <p className="text-xs sm:text-sm font-bold text-white leading-relaxed">
                      “저작권은 자신이 만든 그림과 같은 창작물을 보호받고, 다른 사람이 정해진 방법을 지켜 사용하도록 하는 권리입니다.”
                    </p>
                    <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm font-medium text-indigo-200">
                      <li>내가 만든 그림뿐 아니라 다른 사람이 만든 그림도 소중히 여겨야 합니다.</li>
                      <li>다른 사람의 그림을 사용하거나 바꾸어 게시할 때에는 사용할 수 있는지 먼저 확인해야 합니다.</li>
                    </ul>
                  </div>
                </div>

                {/* 2. 그림을 바르게 사용하는 방법 */}
                <div className="space-y-2.5">
                  <h4 className="text-sm sm:text-base font-black text-emerald-300 flex items-center gap-2">
                    <span>📌</span>
                    <span>그림을 바르게 사용하는 방법</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm">
                    <div className="bg-slate-800/90 p-3.5 rounded-2xl border border-slate-700 space-y-1">
                      <div className="font-black text-emerald-300">① 확인하기</div>
                      <div className="font-bold text-slate-200">“사용할 수 있는지 먼저 확인해요.”</div>
                    </div>
                    <div className="bg-slate-800/90 p-3.5 rounded-2xl border border-slate-700 space-y-1">
                      <div className="font-black text-emerald-300">② 밝히기</div>
                      <div className="font-bold text-slate-200">“그림을 만든 사람과 출처를 밝혀요.”</div>
                    </div>
                    <div className="bg-slate-800/90 p-3.5 rounded-2xl border border-slate-700 space-y-1">
                      <div className="font-black text-emerald-300">③ 알리기</div>
                      <div className="font-bold text-slate-200">“AI로 바꾼 사실을 알려요.”</div>
                    </div>
                    <div className="bg-slate-800/90 p-3.5 rounded-2xl border border-slate-700 space-y-1">
                      <div className="font-black text-emerald-300">④ 게시하지 않기</div>
                      <div className="font-bold text-slate-200">“사용할 수 없다면 게시하지 않아요.”</div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Output Actions: Print & Next Step Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <button
          onClick={handlePrint}
          className="w-full sm:w-auto py-3.5 px-6 bg-slate-800 hover:bg-slate-900 text-white font-extrabold text-sm rounded-2xl shadow flex items-center justify-center gap-2 transition cursor-pointer"
        >
          <Printer className="w-5 h-5 text-slate-300" />
          <span>수정 게시물 및 그림 사용 기준 인쇄하기</span>
        </button>

        <button
          onClick={onNext}
          disabled={!isFullyCompleted || readOnly}
          className={`w-full sm:w-auto py-4 px-8 font-black text-lg sm:text-xl rounded-2xl shadow-lg border-2 flex items-center justify-center gap-3 transition ${
            isFullyCompleted && !readOnly
              ? 'bg-amber-400 hover:bg-amber-500 text-amber-950 border-amber-500 cursor-pointer hover:scale-102'
              : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
          }`}
        >
          <span>9단계: 새 상황 적용 & 배움 기록 카드로 이동</span>
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
