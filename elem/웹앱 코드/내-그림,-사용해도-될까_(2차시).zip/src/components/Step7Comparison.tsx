import React from 'react';
import { ScenarioData } from '../types';
import { ArrowRight, HelpCircle } from 'lucide-react';

interface Step7Props {
  scenario: ScenarioData;
  discussed: boolean;
  showResult: boolean;
  onToggleDiscussed: (val: boolean) => void;
  onShowResult: (val: boolean) => void;
  onNext: () => void;
  speakText: (text: string) => void;
  readOnly?: boolean;
}

export const Step7Comparison: React.FC<Step7Props> = ({
  scenario,
  discussed,
  showResult,
  onToggleDiscussed,
  onShowResult,
  onNext,
  speakText,
  readOnly = false,
}) => {
  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="bg-gradient-to-r from-purple-600 via-indigo-500 to-blue-500 rounded-3xl p-5 sm:p-7 border-4 border-purple-300 shadow-lg text-white">
        <div className="flex items-center gap-2 mb-2 text-purple-100 font-black text-xs sm:text-sm uppercase tracking-wide">
          <span className="bg-white/20 px-3 py-1 rounded-full border border-white/30 text-white">2차시 · 7단계</span>
          <span>처음 역할놀이와 다시 한 역할놀이 비교하기</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-black text-white mb-2 leading-tight">
          "처음 역할놀이와 다시 한 역할놀이의 행동 및 마음 변화를 비교해 보세요!"
        </h2>
        <p className="text-sm sm:text-lg text-purple-100 font-medium leading-relaxed">
          두 역할놀이를 비교하며 행동과 인물들의 마음이 어떻게 달라졌는지 이야기 나누어 봅시다.
        </p>
      </div>

      {/* Part 1: Discussion Questions First */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-purple-200 shadow-md space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-purple-100">
          <HelpCircle className="w-6 h-6 text-purple-600" />
          <h3 className="text-lg sm:text-xl font-black text-slate-800">
            💬 모둠 나눔 질문 (질문에 대해 함께 이야기해 보세요)
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-purple-50 p-4 rounded-2xl border border-purple-200 space-y-1">
            <span className="font-extrabold text-xs text-purple-900 block">질문 1</span>
            <p className="text-xs sm:text-sm font-black text-slate-900">
              두 역할놀이에서 무엇이 달라졌나요?
            </p>
          </div>

          <div className="bg-purple-50 p-4 rounded-2xl border border-purple-200 space-y-1">
            <span className="font-extrabold text-xs text-purple-900 block">질문 2</span>
            <p className="text-xs sm:text-sm font-black text-slate-900">
              어떤 행동 때문에 인물의 마음이 달라졌나요?
            </p>
          </div>

          <div className="bg-purple-50 p-4 rounded-2xl border border-purple-200 space-y-1">
            <span className="font-extrabold text-xs text-purple-900 block">질문 3</span>
            <p className="text-xs sm:text-sm font-black text-slate-900">
              그림을 바르게 사용하기 위해 무엇이 필요했나요?
            </p>
          </div>
        </div>

        {/* Group Discussion Confirmation & Show Comparison Button */}
        {!showResult && (
          <div className="space-y-4 pt-4 border-t border-purple-100 animate-fadeIn">
            <label className="flex items-center gap-3 cursor-pointer select-none bg-purple-50 p-4 rounded-2xl border border-purple-200">
              <input
                type="checkbox"
                checked={discussed}
                disabled={readOnly}
                onChange={(e) => !readOnly && onToggleDiscussed(e.target.checked)}
                className="w-6 h-6 rounded-lg text-purple-600 focus:ring-purple-500 border-2 border-purple-300"
              />
              <span className="font-extrabold text-xs sm:text-sm text-purple-950">
                🗣️ 우리 모둠은 세 가지 나눔 질문에 대해 이야기를 나눴습니다.
              </span>
            </label>

            <div className="flex justify-center">
              <button
                onClick={() => {
                  if (readOnly) return;
                  onShowResult(true);
                  speakText('비교 내용을 확인합니다.');
                }}
                disabled={!discussed || readOnly}
                className={`py-3.5 px-8 font-black text-base sm:text-lg rounded-2xl shadow-lg border-2 transition ${
                  discussed && !readOnly
                    ? 'bg-purple-600 hover:bg-purple-700 text-white border-purple-700 cursor-pointer hover:scale-102'
                    : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                }`}
              >
                📊 비교 내용 확인하기
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Part 2: Neutral Comparison Prompt & Side-by-Side Comparison Grid */}
      {showResult && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-indigo-50 border-2 border-indigo-300 rounded-2xl p-4 text-center text-xs sm:text-sm font-bold text-indigo-950">
            📌 그림을 만든 사람의 마음이 어떻게 달라졌는지 모둠에서 말한 내용과 비교해 보세요.
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* First Roleplay Card (Problem Situation) */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border-4 border-amber-300 shadow-md space-y-4">
              <div className="bg-amber-500 text-white p-3.5 rounded-2xl font-black text-base sm:text-lg flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <span>📌</span>
                  <span>처음 역할놀이 (문제 상황)</span>
                </span>
                <span className="text-xs bg-amber-700 px-2.5 py-1 rounded-full">1차시 3단계</span>
              </div>

              <div className="space-y-3 text-xs sm:text-sm">
                <div className="bg-amber-50 p-3.5 rounded-2xl border border-amber-200">
                  <div className="text-xs font-black text-amber-900 mb-0.5">📌 처음에 한 행동</div>
                  <p className="font-bold text-amber-950">
                    사용할 수 있는지 확인하지 않고 저장하여, AI로 바꾼 뒤 게시함
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="font-black text-amber-900 block">🎨 {scenario.creatorName} (그림을 만든 사람의 마음)</span>
                  <p className="text-slate-700 text-xs font-medium">
                    "내 허락도 없이 마음대로 사용해서 속상하고 당황스러웠어."
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="font-black text-blue-900 block">🤖 {scenario.userName} (그림을 사용한 사람의 생각)</span>
                  <p className="text-slate-700 text-xs font-medium">
                    "AI로 바꿨으니 괜찮을 줄 알았는데 친구가 상처받아 미안했어."
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="font-black text-emerald-900 block">🧒 {scenario.friendName} (반 친구가 알게 된 정보)</span>
                  <p className="text-slate-700 text-xs font-medium">
                    "누가 처음 만든 그림인지, 미리 허락을 받았는지 알 수 없었어."
                  </p>
                </div>
              </div>
            </div>

            {/* Second Roleplay Card (Re-enacted Situation) */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border-4 border-emerald-400 shadow-md space-y-4">
              <div className="bg-emerald-500 text-white p-3.5 rounded-2xl font-black text-base sm:text-lg flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <span>✨</span>
                  <span>다시 한 역할놀이 (해결 장면)</span>
                </span>
                <span className="text-xs bg-emerald-700 px-2.5 py-1 rounded-full">2차시 6단계</span>
              </div>

              <div className="space-y-3 text-xs sm:text-sm">
                <div className="bg-emerald-50 p-3.5 rounded-2xl border border-emerald-200">
                  <div className="text-xs font-black text-emerald-900 mb-0.5">📌 다시 한 행동</div>
                  <p className="font-bold text-emerald-950">
                    사전에 사용할 수 있는지 확인하고, 그림을 만든 사람과 출처, AI로 바꾼 사실을 밝힘
                  </p>
                </div>

                <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-200 space-y-1">
                  <span className="font-black text-amber-900 block">🎨 {scenario.creatorName} (그림을 만든 사람의 마음 변화 까닭)</span>
                  <p className="text-slate-700 text-xs font-medium">
                    "미리 사용할 수 있는지 물어봐 주고 내 이름과 출처를 적어 주어서 마음이 안심되었어."
                  </p>
                </div>

                <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-200 space-y-1">
                  <span className="font-black text-blue-900 block">🤖 {scenario.userName} (그림을 사용한 사람이 새롭게 생각한 점)</span>
                  <p className="text-slate-700 text-xs font-medium">
                    "친구에게 미리 허락을 구하고 예절을 지켜 올리는 것이 얼마나 중요한지 깨달았어."
                  </p>
                </div>

                <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-200 space-y-1">
                  <span className="font-black text-emerald-900 block">🧒 {scenario.friendName} (반 친구가 새롭게 알게 된 정보)</span>
                  <p className="text-slate-700 text-xs font-medium">
                    "누가 처음 만들었고 어떻게 AI로 바뀌었는지 명확하게 알 수 있게 되었어."
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Next Step Action Button */}
          <div className="flex justify-end pt-2">
            <button
              onClick={onNext}
              disabled={readOnly}
              className={`py-4 px-8 font-black text-lg sm:text-xl rounded-2xl shadow-lg border-2 flex items-center gap-3 transition ${
                !readOnly
                  ? 'bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-700 cursor-pointer hover:scale-102'
                  : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
              }`}
            >
              <span>8단계: 문제가 있는 게시물 고치기</span>
              <ArrowRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
