import React, { useState } from 'react';
import { ActionChoiceId, ScenarioData } from '../types';
import { REENACTMENT_SCRIPTS } from '../data/scenarioData';
import { TimerWidget } from './TimerWidget';
import { Sparkles, ArrowRight, Lightbulb, RotateCcw, MessageSquare } from 'lucide-react';

interface Step6Props {
  scenario: ScenarioData;
  selectedChoice: ActionChoiceId | null;
  discussedChoiceReason: boolean;
  showReactions: boolean;
  isPrepFinished: boolean;
  isRoleplayFinished: boolean;
  onSelectChoice: (id: ActionChoiceId) => void;
  onToggleDiscussedChoiceReason: (val: boolean) => void;
  onToggleShowReactions: (val: boolean) => void;
  onTogglePrepFinished: (val: boolean) => void;
  onToggleRoleplayFinished: (val: boolean) => void;
  onResetChoice: () => void;
  onNext: () => void;
  speakText: (text: string) => void;
  readOnly?: boolean;
}

export const Step6SolutionRoleplay: React.FC<Step6Props> = ({
  scenario,
  selectedChoice,
  discussedChoiceReason,
  showReactions,
  isPrepFinished,
  isRoleplayFinished,
  onSelectChoice,
  onToggleDiscussedChoiceReason,
  onToggleShowReactions,
  onTogglePrepFinished,
  onToggleRoleplayFinished,
  onResetChoice,
  onNext,
  speakText,
  readOnly = false,
}) => {
  const [showHint, setShowHint] = useState<boolean>(false);

  const selectedChoiceObj = scenario.choices.find((c) => c.id === selectedChoice);
  const isDesirableChoice = selectedChoice === 'permission_and_credit';

  const isCompleted =
    isDesirableChoice &&
    showReactions &&
    isPrepFinished &&
    isRoleplayFinished;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 rounded-3xl p-5 sm:p-7 border-4 border-emerald-300 shadow-lg text-white">
        <div className="flex items-center gap-2 mb-2 text-emerald-100 font-black text-xs sm:text-sm uppercase tracking-wide">
          <span className="bg-white/20 px-3 py-1 rounded-full border border-white/30 text-white">2차시 · 6단계</span>
          <span>바른 해결 방법 선택 및 역할놀이 재연하기</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-black text-white mb-2 leading-tight">
          "각 인물의 마음과 그림을 사용하는 방법을 생각하며 가장 적절한 행동을 선택해 보세요."
        </h2>
        <p className="text-sm sm:text-lg text-emerald-100 font-medium leading-relaxed">
          행동을 선택하고 이유를 말한 뒤 인물의 반응을 확인해 보세요.
        </p>
      </div>

      {/* Part 1: Action Choice Selection */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-slate-200 shadow-md space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-500" />
            <span>행동 선택지</span>
          </h3>

          <button
            onClick={() => setShowHint(!showHint)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-xl text-xs font-black transition cursor-pointer"
          >
            <Lightbulb className="w-4 h-4 text-amber-600" />
            <span>{showHint ? '도움말 닫기' : '💡 말하기 도움말'}</span>
          </button>
        </div>

        {showHint && (
          <div className="bg-amber-50 border border-amber-300 p-3 rounded-2xl text-xs font-medium text-amber-950 animate-fadeIn">
            💡 어떤 행동이 그림을 만든 친구의 마음을 존중하고 올바른 정보를 전달할지 모둠에서 생각해 보세요.
          </div>
        )}

        {/* 4 Choices */}
        <div className="space-y-2.5">
          {scenario.choices.map((choice) => {
            const isSelected = selectedChoice === choice.id;

            return (
              <button
                key={choice.id}
                onClick={() => !readOnly && onSelectChoice(choice.id)}
                disabled={readOnly}
                className={`w-full p-4 rounded-2xl border-2 text-left transition flex items-center justify-between gap-3 ${
                  readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                } ${
                  isSelected
                    ? 'bg-indigo-50 border-indigo-500 ring-2 ring-indigo-300 text-indigo-950 font-black'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div>
                  <div className="font-extrabold text-sm sm:text-base">{choice.title}</div>
                  <div className="text-xs text-slate-500 font-medium mt-0.5">{choice.description}</div>
                </div>
                <span className="text-xl flex-shrink-0">
                  {isSelected ? '🔘' : '⚪'}
                </span>
              </button>
            );
          })}
        </div>

        {/* Discussion Checkbox & Show Reactions Button */}
        {selectedChoice && !showReactions && (
          <div className="space-y-4 pt-4 border-t border-slate-200 animate-fadeIn">
            <label className="flex items-center gap-3 cursor-pointer select-none bg-indigo-50 p-4 rounded-2xl border border-indigo-200">
              <input
                type="checkbox"
                checked={discussedChoiceReason}
                disabled={readOnly}
                onChange={(e) => !readOnly && onToggleDiscussedChoiceReason(e.target.checked)}
                className="w-6 h-6 rounded-lg text-indigo-600 focus:ring-indigo-500 border-2 border-indigo-300"
              />
              <span className="font-extrabold text-xs sm:text-sm text-indigo-950">
                🗣️ 내가 이 행동을 선택한 이유를 모둠에서 이야기했습니다.
              </span>
            </label>

            <div className="flex justify-center">
              <button
                onClick={() => {
                  if (readOnly) return;
                  onToggleShowReactions(true);
                  speakText('등장인물의 반응과 마음을 확인합니다.');
                }}
                disabled={!discussedChoiceReason || readOnly}
                className={`py-3.5 px-8 font-black text-base sm:text-lg rounded-2xl shadow-lg border-2 transition ${
                  discussedChoiceReason && !readOnly
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700 cursor-pointer hover:scale-102'
                    : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                }`}
              >
                👀 등장인물의 반응 보기
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Part 2: Choice Outcome / Reactions Display */}
      {selectedChoiceObj && showReactions && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-indigo-200 shadow-md space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-indigo-100">
              <h4 className="text-lg font-black text-indigo-950 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-600" />
                <span>선택에 따른 인물들의 마음과 상황</span>
              </h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Creator Minwoo */}
              <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 space-y-1">
                <span className="font-extrabold text-xs text-amber-900 block">🎨 {scenario.creatorName} (그림을 만든 사람)</span>
                <span className="font-black text-amber-950 text-xs sm:text-sm block">
                  {selectedChoiceObj.creatorReaction.expression} {selectedChoiceObj.creatorReaction.emotion}
                </span>
                <p className="text-slate-700 text-xs font-medium leading-relaxed bg-white/80 p-2.5 rounded-xl border border-amber-100">
                  "{selectedChoiceObj.creatorReaction.dialogue}"
                </p>
              </div>

              {/* User Sujin */}
              <div className="bg-blue-50 p-4 rounded-2xl border border-blue-200 space-y-1">
                <span className="font-extrabold text-xs text-blue-900 block">🤖 {scenario.userName} (그림을 사용한 사람)</span>
                <span className="font-black text-blue-950 text-xs sm:text-sm block">
                  {selectedChoiceObj.userReaction.expression} {selectedChoiceObj.userReaction.emotion}
                </span>
                <p className="text-slate-700 text-xs font-medium leading-relaxed bg-white/80 p-2.5 rounded-xl border border-blue-100">
                  "{selectedChoiceObj.userReaction.dialogue}"
                </p>
              </div>

              {/* Friend Donghyun */}
              <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 space-y-1">
                <span className="font-extrabold text-xs text-emerald-900 block">🧒 {scenario.friendName} (반 친구)</span>
                <span className="font-black text-emerald-950 text-xs sm:text-sm block">
                  {selectedChoiceObj.friendReaction.expression} {selectedChoiceObj.friendReaction.emotion}
                </span>
                <p className="text-slate-700 text-xs font-medium leading-relaxed bg-white/80 p-2.5 rounded-xl border border-emerald-100">
                  "{selectedChoiceObj.friendReaction.dialogue}"
                </p>
              </div>
            </div>

            {/* If Undesirable Choice Selected: Questioning Prompt + Rethink Button */}
            {!isDesirableChoice && (
              <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 text-amber-950 space-y-3">
                <div className="font-black text-sm text-amber-900 flex items-center gap-1.5">
                  <span>💭</span>
                  <span>이 선택을 되돌아보기 위한 질문</span>
                </div>
                <ul className="space-y-1 text-xs sm:text-sm font-bold text-slate-800 list-disc pl-5">
                  <li>그림을 사용할 수 있는지 확인했나요?</li>
                  <li>그림을 만든 사람과 출처를 알 수 있나요?</li>
                  <li>AI로 바꾼 사실이 드러나나요?</li>
                  <li>그림을 만든 사람의 마음은 어떨까요?</li>
                </ul>

                <div className="flex justify-end pt-1">
                  <button
                    onClick={() => !readOnly && onResetChoice()}
                    disabled={readOnly}
                    className={`py-2.5 px-5 bg-amber-500 hover:bg-amber-600 text-amber-950 font-black text-xs sm:text-sm rounded-xl shadow flex items-center gap-1.5 transition ${
                      readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                    }`}
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>다시 생각하기</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Part 3: Re-enactment Preparation & Timers (Only when Desirable Choice is active) */}
          {isDesirableChoice && (
            <div className="space-y-6 animate-fadeIn">
              {/* Semi-structured Re-enactment Script Templates */}
              <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-emerald-300 shadow-md space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-emerald-200">
                  <h4 className="text-lg font-black text-emerald-950 flex items-center gap-2">
                    <span>🎭</span>
                    <span>바른 해결 장면 재연을 위한 대사 틀</span>
                  </h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* User */}
                  <div className="bg-blue-50 p-4 rounded-2xl border border-blue-200 space-y-1.5">
                    <span className="font-black text-xs text-blue-900 block">{REENACTMENT_SCRIPTS.user.title}</span>
                    <div className="text-xs sm:text-sm font-bold text-slate-800 bg-white p-3 rounded-xl space-y-1">
                      <p>{REENACTMENT_SCRIPTS.user.line1}</p>
                      <p>{REENACTMENT_SCRIPTS.user.line2}</p>
                      <p>{REENACTMENT_SCRIPTS.user.line3}</p>
                    </div>
                  </div>

                  {/* Creator */}
                  <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 space-y-1.5">
                    <span className="font-black text-xs text-amber-900 block">{REENACTMENT_SCRIPTS.creator.title}</span>
                    <div className="text-xs sm:text-sm font-bold text-slate-800 bg-white p-3 rounded-xl space-y-1">
                      <p>{REENACTMENT_SCRIPTS.creator.line1}</p>
                      <p>{REENACTMENT_SCRIPTS.creator.line2}</p>
                    </div>
                  </div>

                  {/* Friend */}
                  <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 space-y-1.5">
                    <span className="font-black text-xs text-emerald-900 block">{REENACTMENT_SCRIPTS.friend.title}</span>
                    <div className="text-xs sm:text-sm font-bold text-slate-800 bg-white p-3 rounded-xl space-y-1">
                      <p>{REENACTMENT_SCRIPTS.friend.line1}</p>
                      <p>{REENACTMENT_SCRIPTS.friend.line2}</p>
                    </div>
                  </div>

                  {/* Observer */}
                  <div className="bg-purple-50 p-4 rounded-2xl border border-purple-200 space-y-1.5">
                    <span className="font-black text-xs text-purple-900 block">{REENACTMENT_SCRIPTS.observer.title}</span>
                    <div className="text-xs sm:text-sm font-bold text-slate-800 bg-white p-3 rounded-xl space-y-1">
                      <p>{REENACTMENT_SCRIPTS.observer.line1}</p>
                      <p>{REENACTMENT_SCRIPTS.observer.line2}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Timer 1: 해결 장면 대사 준비 (2분) */}
              <div className="bg-white rounded-3xl p-5 border-4 border-amber-300 shadow-md space-y-3">
                <div className="flex items-center gap-2 text-amber-950 font-black text-base sm:text-lg">
                  <span>⏱️</span>
                  <span>1. 해결 장면 대사 준비 (2분)</span>
                </div>
                <TimerWidget
                  initialSeconds={120}
                  title="해결 장면 대사 준비 타이머"
                  subtitle="2분 동안 서로 허락을 구하고 감사하는 바른 해결 대사를 연습하세요!"
                  readOnly={readOnly}
                />
                <label className="flex items-center gap-3 cursor-pointer select-none bg-amber-50 p-3.5 rounded-2xl border border-amber-200">
                  <input
                    type="checkbox"
                    checked={isPrepFinished}
                    disabled={readOnly}
                    onChange={(e) => !readOnly && onTogglePrepFinished(e.target.checked)}
                    className="w-6 h-6 rounded-lg text-amber-600 focus:ring-amber-500 border-2 border-amber-300"
                  />
                  <span className="font-extrabold text-xs sm:text-sm text-amber-950">
                    ✅ 해결 장면 대사 준비 완료
                  </span>
                </label>
              </div>

              {/* Timer 2: 해결 장면 역할놀이 (3분) */}
              <div className="bg-white rounded-3xl p-5 border-4 border-emerald-300 shadow-md space-y-3">
                <div className="flex items-center gap-2 text-emerald-950 font-black text-base sm:text-lg">
                  <span>🎭</span>
                  <span>2. 해결 장면 역할놀이 재연 (3분)</span>
                </div>
                <TimerWidget
                  initialSeconds={180}
                  title="해결 장면 역할놀이 타이머"
                  subtitle="3분 동안 올바른 저작권 존중 행동을 모둠 친구들과 직접 연기해 보세요!"
                  readOnly={readOnly}
                />
                <label className="flex items-center gap-3 cursor-pointer select-none bg-emerald-50 p-3.5 rounded-2xl border border-emerald-200">
                  <input
                    type="checkbox"
                    checked={isRoleplayFinished}
                    disabled={readOnly}
                    onChange={(e) => !readOnly && onToggleRoleplayFinished(e.target.checked)}
                    className="w-6 h-6 rounded-lg text-emerald-600 focus:ring-emerald-500 border-2 border-emerald-300"
                  />
                  <span className="font-extrabold text-xs sm:text-sm text-emerald-950">
                    ✅ 해결 장면 역할놀이 완료
                  </span>
                </label>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Next Step Action Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onNext}
          disabled={!isCompleted || readOnly}
          className={`py-4 px-8 font-black text-lg sm:text-xl rounded-2xl shadow-lg border-2 flex items-center gap-3 transition ${
            isCompleted && !readOnly
              ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700 cursor-pointer hover:scale-102'
              : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
          }`}
        >
          <span>7단계: 역할놀이 변화 비교하기</span>
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
