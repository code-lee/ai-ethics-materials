import React from 'react';
import { ScenarioData } from '../types';
import { CREATOR_EMOTIONS, USER_EMOTIONS } from '../data/scenarioData';
import { ArrowRight, RotateCcw, Volume2, MessageSquare } from 'lucide-react';

interface Step5Props {
  scenario: ScenarioData;
  creatorEmotions: string[];
  userEmotions: string[];
  said: boolean;
  discussed: boolean;
  onToggleCreatorEmotion: (emotion: string) => void;
  onToggleUserEmotion: (emotion: string) => void;
  onToggleSaid: (val: boolean) => void;
  onToggleDiscussed: (val: boolean) => void;
  onNext: () => void;
  speakText: (text: string) => void;
  readOnly?: boolean;
}

export const Step5RoleSwitch: React.FC<Step5Props> = ({
  scenario,
  creatorEmotions,
  userEmotions,
  said,
  discussed,
  onToggleCreatorEmotion,
  onToggleUserEmotion,
  onToggleSaid,
  onToggleDiscussed,
  onNext,
  speakText,
  readOnly = false,
}) => {
  const isCompleted = creatorEmotions.length > 0 && userEmotions.length > 0 && said && discussed;

  const handleSpeakPractice = () => {
    const text = `그림을 만든 사람 민우의 마음: ${creatorEmotions.join(', ')}. 그림을 사용한 사람 수진이의 마음: ${userEmotions.join(', ')}.`;
    speakText(text);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 rounded-3xl p-5 sm:p-7 border-4 border-amber-300 shadow-lg text-white">
        <div className="flex items-center gap-2 mb-2 text-amber-100 font-black text-xs sm:text-sm uppercase tracking-wide">
          <span className="bg-white/20 px-3 py-1 rounded-full border border-white/30 text-white">2차시 · 5단계</span>
          <span>판단 이유 말하기 & 역할 교환하기</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-black text-white mb-2 leading-tight">
          "역할을 서로 바꾸어 상대방의 마음을 헤아리고 판단 이유를 소리 내어 말해 보세요!"
        </h2>
        <p className="text-sm sm:text-lg text-amber-100 font-medium leading-relaxed">
          서로 역할을 교환하여 상대방의 입장과 마음이 어땠을지 직접 대사로 주고받아 봅시다.
        </p>
      </div>

      {/* Part 1: Emotion Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Creator Minwoo's Emotions */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border-4 border-amber-200 shadow-md space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-amber-100">
            <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <span>🎨</span>
              <span>그림을 만든 사람 ({scenario.creatorName})의 마음</span>
            </h3>
            <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full">
              낱말 선택
            </span>
          </div>

          <p className="text-xs text-slate-600 font-medium">
            자신에게 확인하지 않고 그림이 사용된 민우의 마음은 어땠을까요? (해당되는 마음을 고르세요)
          </p>

          <div className="flex flex-wrap gap-2">
            {CREATOR_EMOTIONS.map((emotion) => {
              const isSelected = creatorEmotions.includes(emotion);

              return (
                <button
                  key={emotion}
                  onClick={() => !readOnly && onToggleCreatorEmotion(emotion)}
                  disabled={readOnly}
                  className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-extrabold border-2 transition ${
                    readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                  } ${
                    isSelected
                      ? 'bg-amber-500 text-amber-950 border-amber-600 shadow ring-2 ring-amber-300'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {isSelected ? `✅ ${emotion}` : emotion}
                </button>
              );
            })}
          </div>
        </div>

        {/* User Sujin's Emotions */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border-4 border-blue-200 shadow-md space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-blue-100">
            <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <span>🤖</span>
              <span>그림을 사용한 사람 ({scenario.userName})의 마음</span>
            </h3>
            <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full">
              낱말 선택
            </span>
          </div>

          <p className="text-xs text-slate-600 font-medium">
            친구가 상처받은 모습을 본 수진이의 마음은 어땠을까요? (해당되는 마음을 고르세요)
          </p>

          <div className="flex flex-wrap gap-2">
            {USER_EMOTIONS.map((emotion) => {
              const isSelected = userEmotions.includes(emotion);

              return (
                <button
                  key={emotion}
                  onClick={() => !readOnly && onToggleUserEmotion(emotion)}
                  disabled={readOnly}
                  className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-extrabold border-2 transition ${
                    readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                  } ${
                    isSelected
                      ? 'bg-blue-600 text-white border-blue-700 shadow ring-2 ring-blue-300'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {isSelected ? `✅ ${emotion}` : emotion}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Dialogue Practice Preview */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-indigo-200 shadow-md space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-indigo-100">
          <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-indigo-600" />
            <span>🗣️ 마음과 바라는 행동 말하기 틀</span>
          </h3>
          <button
            onClick={handleSpeakPractice}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-950 rounded-xl text-xs font-black border border-indigo-200 transition cursor-pointer"
          >
            <Volume2 className="w-4 h-4 text-indigo-600" />
            <span>음성으로 듣기</span>
          </button>
        </div>

        <div className="space-y-3 text-xs sm:text-sm font-bold text-slate-800">
          <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 space-y-2">
            <span className="font-extrabold text-amber-900 block">🎨 그림을 만든 사람 ({scenario.creatorName}) / 🤖 그림을 사용한 사람 ({scenario.userName}):</span>
            <p className="text-slate-900 leading-relaxed">
              “나는 <span className="text-amber-700 font-black">__________</span> 역할이라서{' '}
              <span className="text-amber-700 font-black underline">
                {creatorEmotions.length > 0 ? creatorEmotions.join(', ') : '__________'}
              </span>
              한 마음이 들어.”
            </p>
            <p className="text-slate-900 leading-relaxed">
              “네가 <span className="text-indigo-700 font-black underline">__________________________________</span>해 주면 좋겠어.”
            </p>
            <p className="text-slate-900 leading-relaxed">
              “다음부터는 <span className="text-blue-700 font-black underline">__________________________________</span>할게.”
            </p>
          </div>
        </div>
      </div>

      {/* Role Exchange & Speaking Confirmation Checkboxes */}
      <div className="bg-white rounded-3xl p-5 border-4 border-amber-300 shadow-md space-y-3">
        <label className="flex items-center gap-3 cursor-pointer select-none bg-amber-50 p-3.5 rounded-2xl border border-amber-200">
          <input
            type="checkbox"
            checked={said}
            disabled={readOnly}
            onChange={(e) => !readOnly && onToggleSaid(e.target.checked)}
            className="w-6 h-6 rounded-lg text-amber-600 focus:ring-amber-500 border-2 border-amber-300"
          />
          <span className="font-extrabold text-xs sm:text-sm text-amber-950">
            🗣️ 우리 모둠은 두 역할의 마음과 바라는 행동을 대사로 직접 소리 내어 말했습니다.
          </span>
        </label>

        <label className="flex items-center gap-3 cursor-pointer select-none bg-orange-50 p-3.5 rounded-2xl border border-orange-200">
          <input
            type="checkbox"
            checked={discussed}
            disabled={readOnly}
            onChange={(e) => !readOnly && onToggleDiscussed(e.target.checked)}
            className="w-6 h-6 rounded-lg text-orange-600 focus:ring-orange-500 border-2 border-orange-300"
          />
          <span className="font-extrabold text-xs sm:text-sm text-orange-950">
            🔄 우리 모둠은 역할을 서로 바꾸어 마음과 바라는 행동을 충분히 주고받았습니다.
          </span>
        </label>
      </div>

      {/* Next Step Action Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onNext}
          disabled={!isCompleted || readOnly}
          className={`py-4 px-8 font-black text-lg sm:text-xl rounded-2xl shadow-lg border-2 flex items-center gap-3 transition ${
            isCompleted && !readOnly
              ? 'bg-amber-500 hover:bg-amber-600 text-amber-950 border-amber-600 cursor-pointer hover:scale-102'
              : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
          }`}
        >
          <span>6단계: 바른 해결 방법 선택 및 역할놀이 재연하기</span>
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
