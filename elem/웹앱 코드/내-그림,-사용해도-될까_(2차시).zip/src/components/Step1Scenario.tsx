import React from 'react';
import { ScenarioData } from '../types';
import { OriginalLionArtwork, AiSpaceLionArtwork } from './Artworks';
import { TimerWidget } from './TimerWidget';
import { ArrowRight, Lightbulb, CheckCircle2 } from 'lucide-react';

interface Step1Props {
  scenario: ScenarioData;
  finished: boolean;
  onToggleFinished: (val: boolean) => void;
  onNext: () => void;
  speakText: (text: string) => void;
  readOnly?: boolean;
}

export const Step1Scenario: React.FC<Step1Props> = ({
  scenario,
  finished,
  onToggleFinished,
  onNext,
  speakText,
  readOnly = false,
}) => {
  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-orange-500 rounded-3xl p-5 sm:p-7 border-4 border-amber-300 shadow-lg text-white">
        <div className="flex items-center gap-2 mb-2 text-amber-100 font-black text-xs sm:text-sm uppercase tracking-wide">
          <span className="bg-white/20 px-3 py-1 rounded-full border border-white/30 text-white">1차시 · 1단계</span>
          <span>그림을 보며 혼자 생각해 보세요</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-black text-white mb-2 leading-tight">
          "두 그림을 조용히 관찰하며 나만의 생각을 정리해 보세요."
        </h2>
        <p className="text-sm sm:text-lg text-amber-100 font-medium leading-relaxed">
          친구와 이야기하기 전에 1분 동안 조용히 그림을 보며 각자 생각해 보세요. 지금은 정답을 말하거나 적지 않아도 됩니다.
        </p>
      </div>

      {/* Side-by-Side Artworks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Minwoo's Original Artwork */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border-4 border-amber-200 shadow-md flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-amber-100">
              <span className="bg-amber-100 text-amber-900 border border-amber-300 px-3 py-1 rounded-full text-xs font-black">
                🎨 그림을 만든 사람 (민우)
              </span>
              <span className="text-xs font-bold text-slate-500">손그림 작품</span>
            </div>
            <h3 className="text-lg font-black text-slate-900 text-center">
              「{scenario.originalArtworkTitle}」
            </h3>
            <OriginalLionArtwork />
          </div>
          <div className="bg-amber-50 p-3.5 rounded-2xl border border-amber-200 text-xs text-amber-950 font-bold text-center">
            민우가 시간과 정성을 들여 직접 그린 작품입니다.
          </div>
        </div>

        {/* Sujin's AI Modified Artwork */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border-4 border-blue-200 shadow-md flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-blue-100">
              <span className="bg-blue-100 text-blue-900 border border-blue-300 px-3 py-1 rounded-full text-xs font-black">
                🤖 그림을 사용한 사람 (수진)
              </span>
              <span className="text-xs font-bold text-slate-500">AI 활용 게시물</span>
            </div>
            <h3 className="text-lg font-black text-slate-900 text-center">
              「{scenario.aiArtworkTitle}」
            </h3>
            <AiSpaceLionArtwork showBadge={false} />
          </div>
          <div className="bg-blue-50 p-3.5 rounded-2xl border border-blue-200 text-xs text-blue-950 font-bold text-center">
            수진이가 AI 프로그램으로 색과 배경을 바꾸어 올린 게시물입니다.
          </div>
        </div>
      </div>

      {/* Observation Caption */}
      <div className="bg-amber-50/80 border-2 border-amber-300 rounded-2xl p-4 text-center text-xs sm:text-sm font-bold text-amber-950">
        📌 두 그림에서 이어지는 부분과 달라진 부분을 찾아보세요. 두 그림은 서로 어떤 관계가 있다고 생각하나요?
      </div>

      {/* 4 Thinking Questions Grid */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-slate-200 shadow-md space-y-4">
        <h3 className="text-lg font-black text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-200">
          <Lightbulb className="w-5 h-5 text-amber-500" />
          <span>혼자 생각하기 질문 (1분 동안 생각해 보세요)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm">
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 font-extrabold text-slate-800 space-y-1">
            <span className="text-amber-600 block text-xs">질문 1</span>
            <p>두 그림에서 같은 부분과 달라진 부분은 무엇인가요?</p>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 font-extrabold text-slate-800 space-y-1">
            <span className="text-amber-600 block text-xs">질문 2</span>
            <p>두 그림은 서로 어떤 관계가 있다고 생각하나요?</p>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 font-extrabold text-slate-800 space-y-1">
            <span className="text-amber-600 block text-xs">질문 3</span>
            <p>민우와 수진은 각각 어떤 마음일까요?</p>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 font-extrabold text-slate-800 space-y-1">
            <span className="text-amber-600 block text-xs">질문 4</span>
            <p>수진의 행동에서 더 살펴보아야 할 점이나 궁금한 점은 무엇인가요?</p>
          </div>
        </div>
      </div>

      {/* 1-Minute Individual Timer Widget */}
      <div className="bg-white rounded-3xl p-5 border-4 border-amber-300 shadow-md space-y-4">
        <div className="flex items-center gap-2 text-amber-950 font-black text-base sm:text-lg">
          <span>⏱️</span>
          <span>1분 개인 생각 타이머</span>
        </div>

        <TimerWidget
          initialSeconds={60}
          title="개인 사고 활동 타이머"
          subtitle="친구와 이야기 나누기 전, 1분 동안 조용히 그림을 보며 혼자 생각해 봅시다."
          readOnly={readOnly}
        />

        {/* Checkbox confirmation */}
        <label className="flex items-center gap-3 cursor-pointer select-none bg-amber-50 p-4 rounded-2xl border-2 border-amber-300 transition hover:bg-amber-100">
          <input
            type="checkbox"
            checked={finished}
            disabled={readOnly}
            onChange={(e) => {
              if (readOnly) return;
              onToggleFinished(e.target.checked);
              if (e.target.checked) {
                speakText('개인 생각을 완료했습니다.');
              }
            }}
            className="w-6 h-6 rounded-lg text-amber-600 focus:ring-amber-500 border-2 border-amber-400"
          />
          <span className="font-extrabold text-sm sm:text-base text-amber-950">
            ✅ 개인 생각을 마쳤어요
          </span>
        </label>
      </div>

      {/* Footer Guidance & Next Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <p className="text-xs sm:text-sm font-bold text-slate-600">
          개인 생각을 마쳤나요? 다음 단계에서 역할을 정하고 서로의 생각을 나누어 봅시다.
        </p>

        <button
          onClick={onNext}
          disabled={!finished || readOnly}
          className={`w-full sm:w-auto py-4 px-8 font-black text-lg sm:text-xl rounded-2xl shadow-lg border-2 flex items-center justify-center gap-3 transition ${
            finished && !readOnly
              ? 'bg-amber-500 hover:bg-amber-600 text-amber-950 border-amber-600 cursor-pointer hover:scale-102'
              : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
          }`}
        >
          <span>2단계: 역할별 생각 준비하기</span>
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
