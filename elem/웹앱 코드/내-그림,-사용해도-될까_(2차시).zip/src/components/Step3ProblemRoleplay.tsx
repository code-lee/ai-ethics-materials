import React, { useState } from 'react';
import { ScenarioData } from '../types';
import { ROLES } from '../data/scenarioData';
import { TimerWidget } from './TimerWidget';
import { ArrowRight, MessageSquare, ChevronDown, ChevronUp } from 'lucide-react';

interface Step3Props {
  scenario: ScenarioData;
  roleplayFinished: boolean;
  onToggleRoleplayFinished: (val: boolean) => void;
  onNext: () => void;
  speakText: (text: string) => void;
  readOnly?: boolean;
}

export const Step3ProblemRoleplay: React.FC<Step3Props> = ({
  scenario,
  roleplayFinished,
  onToggleRoleplayFinished,
  onNext,
  speakText,
  readOnly = false,
}) => {
  const [showScriptTemplates, setShowScriptTemplates] = useState<boolean>(false);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 rounded-3xl p-5 sm:p-7 border-4 border-purple-300 shadow-lg text-white">
        <div className="flex items-center gap-2 mb-2 text-purple-100 font-black text-xs sm:text-sm uppercase tracking-wide">
          <span className="bg-white/20 px-3 py-1 rounded-full border border-white/30 text-white">1차시 · 3단계</span>
          <span>문제 상황 역할놀이 하기</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-black text-white mb-2 leading-tight">
          "각 인물의 생각과 마음이 잘 드러나도록 모둠 친구들과 직접 역할놀이를 시작해 보세요."
        </h2>
        <p className="text-sm sm:text-lg text-purple-100 font-medium leading-relaxed">
          2단계에서 정한 역할을 바탕으로 문제 상황 속 인물의 입장이 되어 대화를 나누어 봅시다.
        </p>
      </div>

      {/* Scenario Context Reminder */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border-4 border-purple-200 shadow-md space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-purple-100">
          <span className="text-xl">📌</span>
          <h3 className="text-base sm:text-lg font-black text-slate-900">
            오늘의 역할놀이 문제 상황
          </h3>
        </div>
        <p className="text-xs sm:text-sm font-bold text-slate-800 bg-purple-50 p-4 rounded-2xl border border-purple-100 leading-relaxed">
          "{scenario.contextText}"
        </p>
      </div>

      {/* Toggle Button for 2단계 대사 틀 다시 보기 */}
      <div className="bg-white rounded-3xl p-4 border-4 border-slate-200 shadow-sm space-y-3">
        <button
          onClick={() => setShowScriptTemplates(!showScriptTemplates)}
          className="w-full p-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-950 font-black text-xs sm:text-sm rounded-2xl border-2 border-indigo-200 flex items-center justify-between transition cursor-pointer"
        >
          <span className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-indigo-600" />
            <span>💬 2단계 대사 예시 틀 참고하기</span>
          </span>
          {showScriptTemplates ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {showScriptTemplates && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 animate-fadeIn">
            {Object.values(ROLES).map((role) => (
              <div key={role.id} className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
                <span className="font-black text-xs text-indigo-900 block">
                  {role.avatar} {role.scriptTemplate.title}
                </span>
                <div className="text-xs font-bold text-slate-700 bg-white p-2.5 rounded-xl border border-slate-200 space-y-1">
                  <p>{role.scriptTemplate.line1}</p>
                  {role.scriptTemplate.line2 && <p>{role.scriptTemplate.line2}</p>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 3-Minute Roleplay Timer */}
      <div className="bg-white rounded-3xl p-5 border-4 border-purple-300 shadow-md space-y-4">
        <div className="flex items-center gap-2 text-purple-950 font-black text-base sm:text-lg">
          <span>⏱️</span>
          <span>3분 역할놀이 타이머</span>
        </div>

        <TimerWidget
          initialSeconds={180}
          title="문제 상황 역할놀이 타이머"
          subtitle="3분 동안 각 인물의 솔직한 생각과 느낌이 드러나도록 자유롭게 이야기해 보세요."
          readOnly={readOnly}
        />

        {/* Checkbox confirmation */}
        <label className="flex items-center gap-3 cursor-pointer select-none bg-purple-50 p-4 rounded-2xl border-2 border-purple-300 transition hover:bg-purple-100">
          <input
            type="checkbox"
            checked={roleplayFinished}
            disabled={readOnly}
            onChange={(e) => {
              if (readOnly) return;
              onToggleRoleplayFinished(e.target.checked);
              if (e.target.checked) {
                speakText('역할놀이를 완료했습니다.');
              }
            }}
            className="w-6 h-6 rounded-lg text-purple-600 focus:ring-purple-500 border-2 border-purple-400"
          />
          <span className="font-extrabold text-xs sm:text-sm text-purple-950">
            ✅ 우리 모둠원이 각자 역할을 맡아 문제 상황 역할놀이를 완료했습니다.
          </span>
        </label>
      </div>

      {/* Next Step Action Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onNext}
          disabled={!roleplayFinished || readOnly}
          className={`py-4 px-8 font-black text-lg sm:text-xl rounded-2xl shadow-lg border-2 flex items-center gap-3 transition ${
            roleplayFinished && !readOnly
              ? 'bg-purple-600 hover:bg-purple-700 text-white border-purple-700 cursor-pointer hover:scale-102'
              : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
          }`}
        >
          <span>4단계: 문제 상황 스스로 판단하기</span>
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
