import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, FastForward, Timer, Bell } from 'lucide-react';

interface TimerWidgetProps {
  initialSeconds?: number;
  title?: string;
  subtitle?: string;
  onComplete?: () => void;
  onSkip?: () => void;
  autoStart?: boolean;
  readOnly?: boolean;
}

export const TimerWidget: React.FC<TimerWidgetProps> = ({
  initialSeconds = 120, // default 2 minutes
  title = '모둠 토의 & 역할놀이 시간',
  subtitle = '친구들과 이야기를 나누며 역할을 나누고 대사를 준비해 보세요!',
  onComplete,
  onSkip,
  autoStart = false,
  readOnly = false,
}) => {
  const [timeLeft, setTimeLeft] = useState<number>(initialSeconds);
  const [isRunning, setIsRunning] = useState<boolean>(autoStart);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      setIsFinished(true);
      if (onComplete) onComplete();
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, timeLeft, onComplete]);

  const toggleTimer = () => {
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(initialSeconds);
    setIsFinished(false);
  };

  const handleSkip = () => {
    setIsRunning(false);
    setTimeLeft(0);
    setIsFinished(true);
    if (onSkip) onSkip();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercent = Math.max(0, Math.min(100, ((initialSeconds - timeLeft) / initialSeconds) * 100));

  return (
    <div className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 p-1 rounded-3xl shadow-xl my-4 text-white">
      <div className="bg-slate-900 rounded-[22px] p-4 sm:p-6 flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Title & info */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="w-12 h-12 sm:w-14 sm:h-14 bg-amber-500/20 rounded-2xl border-2 border-amber-400/50 flex items-center justify-center text-amber-300 flex-shrink-0">
            <Timer className={`w-7 h-7 sm:w-8 sm:h-8 ${isRunning ? 'animate-pulse text-amber-300' : ''}`} />
          </div>
          <div>
            <h4 className="text-base sm:text-lg font-bold text-amber-200 flex items-center gap-2">
              <span>⏱️</span> {title}
            </h4>
            <p className="text-xs sm:text-sm text-slate-300">{subtitle}</p>
          </div>
        </div>

        {/* Timer display & progress */}
        <div className="flex flex-col items-center justify-center px-4 py-2 bg-slate-800/80 rounded-2xl border border-slate-700 min-w-[160px]">
          <div className="text-3xl sm:text-4xl font-extrabold tracking-wider font-mono text-amber-400">
            {formatTime(timeLeft)}
          </div>
          {/* Progress bar */}
          <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden mt-1.5">
            <div
              className="bg-amber-400 h-full transition-all duration-1000 ease-linear rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Control buttons */}
        <div className="flex items-center gap-2 flex-wrap justify-center w-full md:w-auto">
          <button
            onClick={() => !readOnly && toggleTimer()}
            disabled={readOnly}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition shadow ${
              readOnly ? 'opacity-50 cursor-not-allowed' : ''
            } ${
              isRunning
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                : 'bg-emerald-500 text-white hover:bg-emerald-400'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-4 h-4 fill-slate-950" />
                <span>일시정지</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                <span>{timeLeft === initialSeconds ? '타이머 시작' : '계속하기'}</span>
              </>
            )}
          </button>

          <button
            onClick={() => !readOnly && resetTimer()}
            disabled={readOnly}
            className={`px-3 py-2.5 bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white rounded-xl text-xs sm:text-sm font-medium flex items-center gap-1 transition border border-slate-700 ${
              readOnly ? 'opacity-50 cursor-not-allowed' : ''
            }`}
            title="타이머 초기화"
          >
            <RotateCcw className="w-4 h-4" />
            <span>초기화</span>
          </button>

          <button
            onClick={() => !readOnly && handleSkip()}
            disabled={readOnly}
            className={`px-3.5 py-2.5 bg-slate-800/90 text-rose-300 hover:bg-rose-950 hover:text-rose-200 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1 transition border border-rose-800/60 ${
              readOnly ? 'opacity-50 cursor-not-allowed' : ''
            }`}
            title="선생님 지도 하에 타이머 종료"
          >
            <FastForward className="w-4 h-4 text-rose-400" />
            <span>선생님 건너뛰기</span>
          </button>
        </div>
      </div>

      {isFinished && (
        <div className="bg-amber-500 text-slate-950 text-xs sm:text-sm font-bold py-1.5 text-center rounded-b-[18px] flex items-center justify-center gap-2 animate-bounce">
          <Bell className="w-4 h-4" />
          <span>토의 시간이 종료되었습니다! 준비한 대화를 나눠 보세요.</span>
        </div>
      )}
    </div>
  );
};
