import React, { useState } from 'react';
import { Step9ChoiceId } from '../types';
import { STEP9_CHOICES, STEP9_SCENARIO_TEXT, REFLECTION_HINTS } from '../data/scenarioData';
import { HelpCircle, FileText, Volume2, Printer, RotateCcw, Lightbulb } from 'lucide-react';

interface Step9Props {
  selectedChoiceId: Step9ChoiceId | null;
  discussed: boolean;
  showOutcome: boolean;
  learned: string;
  felt: string;
  action: string;
  customSentence: string;
  followupText: string;
  discussedFollowup: boolean;
  showFollowupExample: boolean;
  onSelectChoice: (id: Step9ChoiceId) => void;
  onToggleDiscussed: (val: boolean) => void;
  onToggleShowOutcome: (val: boolean) => void;
  onUpdateField: (field: 'learned' | 'felt' | 'action' | 'customSentence', val: string) => void;
  onUpdateFollowupText: (val: string) => void;
  onToggleDiscussedFollowup: (val: boolean) => void;
  onToggleShowFollowupExample: (val: boolean) => void;
  onReset: () => void;
  speakText: (text: string) => void;
  readOnly?: boolean;
}

export const Step9Reflection: React.FC<Step9Props> = ({
  selectedChoiceId,
  discussed,
  showOutcome,
  learned,
  felt,
  action,
  customSentence,
  followupText,
  discussedFollowup,
  showFollowupExample,
  onSelectChoice,
  onToggleDiscussed,
  onToggleShowOutcome,
  onUpdateField,
  onUpdateFollowupText,
  onToggleDiscussedFollowup,
  onToggleShowFollowupExample,
  onReset,
  speakText,
  readOnly = false,
}) => {
  const [showReflectionHint, setShowReflectionHint] = useState<boolean>(false);

  // Reset follow-up state when choice changes
  const handleSelectChoiceInternal = (id: Step9ChoiceId) => {
    if (readOnly) return;
    onUpdateFollowupText('');
    onToggleDiscussedFollowup(false);
    onToggleShowFollowupExample(false);
    onSelectChoice(id);
  };

  const handleRethinkChoice = () => {
    if (readOnly) return;
    onUpdateFollowupText('');
    onToggleDiscussedFollowup(false);
    onToggleShowFollowupExample(false);
    onToggleShowOutcome(false);
    onToggleDiscussed(false);
  };

  // Determine if learning record section should be accessible
  const canShowLearningRecordCard =
    showOutcome &&
    (selectedChoiceId === 'ask_permission' || selectedChoiceId === 'no_share_if_denied') &&
    showFollowupExample;

  const selectedChoice = STEP9_CHOICES.find((c) => c.id === selectedChoiceId);

  const isLearningRecordComplete =
    learned.trim() !== '' &&
    felt.trim() !== '' &&
    action.trim() !== '' &&
    customSentence.trim() !== '';

  const handleSpeakLearningRecord = () => {
    const textToSpeak = `배움 기록 카드. 새롭게 알게 된 점: ${learned}. 역할을 바꾸며 느낀 점: ${felt}. 실천할 행동: ${action}. 내가 직접 정리한 한 문장: ${customSentence}.`;
    speakText(textToSpeak);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-400 via-orange-400 to-rose-400 rounded-3xl p-5 sm:p-7 border-4 border-amber-300 shadow-lg text-slate-900">
        <div className="flex items-center gap-2 mb-2 text-amber-950 font-black text-xs sm:text-sm uppercase tracking-wide">
          <span className="bg-white/80 px-3 py-1 rounded-full border border-amber-400">2차시 · 9단계</span>
          <span>새로운 상황 적용 및 배움 기록 카드 작성</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-black text-slate-900 mb-2 leading-tight">
          "새로운 상황에 배운 내용을 적용해 보고, '배움 기록 카드'를 정성껏 완성해 보세요!"
        </h2>
        <p className="text-sm sm:text-lg text-slate-800 font-medium leading-relaxed">
          지호의 AI 스티커 공유 사례에 올바른 판단을 적용해 본 뒤, 나만의 배움을 정리해 봅시다.
        </p>
      </div>

      {/* Part 1: New Situation Exercise (지호의 AI 스티커 사례) */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-indigo-200 shadow-md space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-indigo-100">
          <HelpCircle className="w-6 h-6 text-indigo-600" />
          <h3 className="text-lg sm:text-xl font-black text-slate-900">
            🧩 새로운 상황 문제: 지호의 AI 스티커 공유
          </h3>
        </div>

        <div className="bg-indigo-50/80 p-4 sm:p-5 rounded-2xl border border-indigo-200 text-xs sm:text-sm text-indigo-950 font-bold leading-relaxed">
          📌 "{STEP9_SCENARIO_TEXT}"
        </div>

        {/* 4 Choices */}
        <div className="space-y-2.5">
          {STEP9_CHOICES.map((choice) => {
            const isSelected = selectedChoiceId === choice.id;

            return (
              <button
                key={choice.id}
                onClick={() => handleSelectChoiceInternal(choice.id)}
                disabled={readOnly}
                className={`w-full p-4 rounded-2xl border-2 text-left transition flex items-center justify-between gap-3 ${
                  readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                } ${
                  isSelected
                    ? 'bg-indigo-50 border-indigo-500 ring-2 ring-indigo-300 text-indigo-950 font-black'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div>
                  <div className="font-extrabold text-sm sm:text-base">{choice.title}</div>
                  <div className="text-xs text-slate-500 font-medium mt-0.5">{choice.description}</div>
                </div>
                <span className="text-xl flex-shrink-0">
                  {isSelected ? '🔘' : '⚪'}
                </span>
              </button>
            );
          })}
        </div>

        {/* Discussion Checkbox & Show Reaction Button */}
        {selectedChoiceId && !showOutcome && (
          <div className="space-y-4 pt-3 border-t border-indigo-100 animate-fadeIn">
            <label className="flex items-center gap-3 cursor-pointer select-none bg-indigo-50 p-3.5 rounded-2xl border border-indigo-200">
              <input
                type="checkbox"
                checked={discussed}
                disabled={readOnly}
                onChange={(e) => !readOnly && onToggleDiscussed(e.target.checked)}
                className="w-6 h-6 rounded-lg text-indigo-600 focus:ring-indigo-500 border-2 border-indigo-300"
              />
              <span className="font-extrabold text-xs sm:text-sm text-indigo-950">
                🗣️ 내가 이 행동을 선택한 이유를 이야기했습니다.
              </span>
            </label>

            <div className="flex justify-center">
              <button
                onClick={() => {
                  if (readOnly) return;
                  onToggleShowOutcome(true);
                  speakText('등장인물의 반응을 확인합니다.');
                }}
                disabled={!discussed || readOnly}
                className={`py-3.5 px-8 font-black text-sm sm:text-base rounded-2xl shadow-lg border-2 transition ${
                  discussed && !readOnly
                    ? 'bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-700 cursor-pointer hover:scale-102'
                    : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                }`}
              >
                👀 등장인물의 반응 보기
              </button>
            </div>
          </div>
        )}

        {/* Choice Reactions Result Display (Only after clicking button) */}
        {selectedChoice && showOutcome && (
          <div className="space-y-4 pt-2 animate-fadeIn">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Creator (수아) Reaction */}
              <div className="bg-amber-50 p-3.5 rounded-2xl border border-amber-200 space-y-1">
                <span className="font-extrabold text-xs text-amber-900 block">🎨 그림을 만든 친구 (수아)</span>
                <span className="font-black text-amber-950 text-xs sm:text-sm block">
                  {selectedChoice.creatorReaction.expression} {selectedChoice.creatorReaction.emotion}
                </span>
                <p className="text-slate-700 text-xs font-medium bg-white/80 p-2.5 rounded-xl border border-amber-100">
                  "{selectedChoice.creatorReaction.dialogue}"
                </p>
              </div>

              {/* User (지호) Reaction */}
              <div className="bg-blue-50 p-3.5 rounded-2xl border border-blue-200 space-y-1">
                <span className="font-extrabold text-xs text-blue-900 block">🤖 지호 (그림을 사용한 친구)</span>
                <span className="font-black text-blue-950 text-xs sm:text-sm block">
                  {selectedChoice.userReaction.expression} {selectedChoice.userReaction.emotion}
                </span>
                <p className="text-slate-700 text-xs font-medium bg-white/80 p-2.5 rounded-xl border border-blue-100">
                  "{selectedChoice.userReaction.dialogue}"
                </p>
              </div>

              {/* Group Chat Friends Reaction */}
              <div className="bg-emerald-50 p-3.5 rounded-2xl border border-emerald-200 space-y-1">
                <span className="font-extrabold text-xs text-emerald-900 block">💬 단체 대화방 친구들</span>
                <span className="font-black text-emerald-950 text-xs sm:text-sm block">
                  {selectedChoice.groupChatReaction.expression} {selectedChoice.groupChatReaction.emotion}
                </span>
                <p className="text-slate-700 text-xs font-medium bg-white/80 p-2.5 rounded-xl border border-emerald-100">
                  "{selectedChoice.groupChatReaction.dialogue}"
                </p>
              </div>
            </div>

            {/* If Choice 1 or Choice 2 selected (Undesirable choices): Display questions & "다시 생각하고 선택하기" button */}
            {!selectedChoice.isDesirable && (
              <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-5 text-rose-950 space-y-3 text-xs sm:text-sm font-bold">
                <div className="font-black text-rose-900 flex items-center gap-2 text-sm sm:text-base">
                  <span>💭</span>
                  <span>아래 질문을 스스로에게 던지며 다시 생각해 봅시다:</span>
                </div>
                <ul className="list-disc pl-5 space-y-1.5 font-extrabold text-slate-800">
                  <li>그림을 사용할 수 있는지 확인했나요?</li>
                  <li>친구 이름만 적으면 사용할 수 있을까요?</li>
                  <li>AI로 바꾼 사실을 알 수 있나요?</li>
                  <li>그림을 만든 친구의 마음은 어떨까요?</li>
                </ul>
                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleRethinkChoice}
                    className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs sm:text-sm font-black transition cursor-pointer shadow flex items-center gap-1.5"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>다시 생각하고 선택하기</span>
                  </button>
                </div>
              </div>
            )}

            {/* If Choice 3 selected (ask_permission): Follow-up sentence completion input */}
            {selectedChoiceId === 'ask_permission' && (
              <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 text-amber-950 space-y-4 text-xs sm:text-sm font-bold animate-fadeIn">
                <div className="font-black text-amber-950 text-sm sm:text-base flex items-center gap-2">
                  <span>❓</span>
                  <span>친구가 그림 사용을 허락하지 않는다면 어떻게 해야 할까요?</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-amber-200 space-y-2">
                  <label className="text-xs sm:text-sm font-extrabold text-slate-800 block">
                    “친구가 그림 사용을 허락하지 않는다면 지호는
                  </label>
                  <input
                    type="text"
                    value={followupText}
                    disabled={readOnly}
                    onChange={(e) => !readOnly && onUpdateFollowupText(e.target.value)}
                    placeholder="지호가 해야 할 행동을 직접 적어 보세요."
                    className="w-full px-4 py-3 bg-amber-50/50 border-2 border-amber-300 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-amber-500 disabled:bg-slate-100 disabled:text-slate-500"
                  />
                  <span className="text-xs sm:text-sm font-extrabold text-slate-800 block">.”</span>
                </div>

                {!showFollowupExample ? (
                  <div className="space-y-3 pt-1">
                    <label className="flex items-center gap-2.5 cursor-pointer select-none bg-white p-3 rounded-xl border border-amber-200">
                      <input
                        type="checkbox"
                        checked={discussedFollowup}
                        disabled={readOnly}
                        onChange={(e) => !readOnly && onToggleDiscussedFollowup(e.target.checked)}
                        className="w-5 h-5 rounded text-amber-600 focus:ring-amber-500 border-2 border-slate-300"
                      />
                      <span className="font-extrabold text-xs sm:text-sm text-amber-950">
                        🗣️ 우리 모둠의 생각을 적고 서로 이야기했습니다.
                      </span>
                    </label>

                    <div className="flex justify-end">
                      <button
                        onClick={() => {
                          if (readOnly) return;
                          onToggleShowFollowupExample(true);
                          speakText('생각 예시를 확인합니다.');
                        }}
                        disabled={followupText.trim() === '' || !discussedFollowup || readOnly}
                        className={`px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm shadow transition border-2 ${
                          followupText.trim() !== '' && discussedFollowup && !readOnly
                            ? 'bg-amber-500 hover:bg-amber-600 text-amber-950 border-amber-600 cursor-pointer'
                            : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                        }`}
                      >
                        💡 생각 확인하기
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-emerald-100 border border-emerald-300 text-emerald-950 rounded-xl font-extrabold text-xs sm:text-sm space-y-1.5 animate-fadeIn">
                    <div className="flex items-center gap-2 font-black text-emerald-900">
                      <span>💡</span>
                      <span>생각 예시: AI로 바꾼 스티커를 단체 대화방에 공유하지 않아요.</span>
                    </div>
                    <p className="text-emerald-800 text-xs font-medium">
                      친구가 허락하지 않으면 공유하지 않는 것이 친구의 마음과 권리를 존중하는 올바른 길입니다!
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* If Choice 4 selected (no_share_if_denied): Explanation input */}
            {selectedChoiceId === 'no_share_if_denied' && (
              <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 text-amber-950 space-y-4 text-xs sm:text-sm font-bold animate-fadeIn">
                <div className="font-black text-amber-950 text-sm sm:text-base flex items-center gap-2">
                  <span>❓</span>
                  <span>왜 허락받지 못한 스티커를 공유하지 않아야 하는지 자신의 말로 적어 보세요.</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-amber-200 space-y-2">
                  <label className="text-xs sm:text-sm font-extrabold text-slate-800 block">
                    “허락받지 못한 스티커를 공유하지 않아야 하는 까닭:
                  </label>
                  <input
                    type="text"
                    value={followupText}
                    disabled={readOnly}
                    onChange={(e) => !readOnly && onUpdateFollowupText(e.target.value)}
                    placeholder="공유하지 않아야 하는 이유를 직접 적어 보세요."
                    className="w-full px-4 py-3 bg-amber-50/50 border-2 border-amber-300 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-amber-500 disabled:bg-slate-100 disabled:text-slate-500"
                  />
                  <span className="text-xs sm:text-sm font-extrabold text-slate-800 block">.”</span>
                </div>

                {!showFollowupExample ? (
                  <div className="space-y-3 pt-1">
                    <label className="flex items-center gap-2.5 cursor-pointer select-none bg-white p-3 rounded-xl border border-amber-200">
                      <input
                        type="checkbox"
                        checked={discussedFollowup}
                        disabled={readOnly}
                        onChange={(e) => !readOnly && onToggleDiscussedFollowup(e.target.checked)}
                        className="w-5 h-5 rounded text-amber-600 focus:ring-amber-500 border-2 border-slate-300"
                      />
                      <span className="font-extrabold text-xs sm:text-sm text-amber-950">
                        🗣️ 우리 모둠의 생각을 적고 서로 이야기했습니다.
                      </span>
                    </label>

                    <div className="flex justify-end">
                      <button
                        onClick={() => {
                          if (readOnly) return;
                          onToggleShowFollowupExample(true);
                          speakText('생각 예시를 확인합니다.');
                        }}
                        disabled={followupText.trim() === '' || !discussedFollowup || readOnly}
                        className={`px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm shadow transition border-2 ${
                          followupText.trim() !== '' && discussedFollowup && !readOnly
                            ? 'bg-amber-500 hover:bg-amber-600 text-amber-950 border-amber-600 cursor-pointer'
                            : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                        }`}
                      >
                        💡 생각 확인하기
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-emerald-100 border border-emerald-300 text-emerald-950 rounded-xl font-extrabold text-xs sm:text-sm space-y-1.5 animate-fadeIn">
                    <div className="flex items-center gap-2 font-black text-emerald-900">
                      <span>💡</span>
                      <span>생각 예시: 친구의 허락 없는 창작물 사용은 마음을 아프게 하고 권리를 침해할 수 있기 때문입니다.</span>
                    </div>
                    <p className="text-emerald-800 text-xs font-medium">
                      그림을 바르게 사용하는 방법을 잘 이해했어요!
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Part 2: Learning Record Card (배움 돌아보기 - 올바른 선택/확인 완료 시에만 제시) */}
      {canShowLearningRecordCard && (
        <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-amber-300 shadow-md space-y-6 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-amber-200">
            <div className="flex items-center gap-2">
              <FileText className="w-6 h-6 text-amber-500" />
              <h3 className="text-lg font-black text-slate-900">
                📝 배움 기록 카드 작성
              </h3>
            </div>

            <button
              onClick={() => setShowReflectionHint(!showReflectionHint)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300 rounded-xl text-xs font-black transition cursor-pointer"
            >
              <Lightbulb className="w-4 h-4 text-amber-600" />
              <span>{showReflectionHint ? '도움말 닫기' : '💡 작성 도움말 보기'}</span>
            </button>
          </div>

          {/* Hint Options Drawer (Only short words/phrases for reference, NO auto-fill on click) */}
          {showReflectionHint && (
            <div className="bg-amber-50 border-2 border-amber-300 p-4 rounded-2xl space-y-3 text-xs font-medium text-amber-950 animate-fadeIn">
              <div className="font-black text-amber-900 flex items-center gap-1">
                <Lightbulb className="w-4 h-4 text-amber-600" />
                <span>💡 작성 참고 단어 (참고 단어를 보고 스스로 문장을 완성해 보세요)</span>
              </div>

              <div className="space-y-1.5">
                <div className="font-bold text-slate-800">1. 새롭게 알게 된 점 참고 단어:</div>
                <div className="flex flex-wrap gap-1.5">
                  {REFLECTION_HINTS.learned.map((h, i) => (
                    <span
                      key={i}
                      className="bg-white px-2.5 py-1 rounded-lg border border-amber-200 text-xs font-bold text-slate-800"
                    >
                      #{h}
                    </span>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="font-bold text-slate-800">2. 느낀 점 참고 단어:</div>
                <div className="flex flex-wrap gap-1.5">
                  {REFLECTION_HINTS.felt.map((h, i) => (
                    <span
                      key={i}
                      className="bg-white px-2.5 py-1 rounded-lg border border-amber-200 text-xs font-bold text-slate-800"
                    >
                      #{h}
                    </span>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="font-bold text-slate-800">3. 실천할 행동 참고 단어:</div>
                <div className="flex flex-wrap gap-1.5">
                  {REFLECTION_HINTS.action.map((h, i) => (
                    <span
                      key={i}
                      className="bg-white px-2.5 py-1 rounded-lg border border-amber-200 text-xs font-bold text-slate-800"
                    >
                      #{h}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 1. 새롭게 알게 된 점 */}
          <div className="space-y-1.5">
            <label className="text-xs sm:text-sm font-black text-amber-950 block">
              1. 새롭게 알게 된 점:
            </label>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-bold text-slate-700 whitespace-nowrap">
                새롭게 알게 된 점은
              </span>
              <input
                type="text"
                value={learned}
                disabled={readOnly}
                onChange={(e) => !readOnly && onUpdateField('learned', e.target.value)}
                placeholder="스스로 적어 보세요."
                className="w-full px-3.5 py-2.5 bg-white border-2 border-amber-300 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-amber-500 disabled:bg-slate-100 disabled:text-slate-500"
              />
              <span className="text-xs sm:text-sm font-bold text-slate-700 whitespace-nowrap">
                입니다.
              </span>
            </div>
          </div>

          {/* 2. 역할을 바꾸어 보니 */}
          <div className="space-y-1.5">
            <label className="text-xs sm:text-sm font-black text-amber-950 block">
              2. 역할을 바꾸며 느낀 점:
            </label>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-bold text-slate-700 whitespace-nowrap">
                역할을 바꾸어 보니
              </span>
              <input
                type="text"
                value={felt}
                disabled={readOnly}
                onChange={(e) => !readOnly && onUpdateField('felt', e.target.value)}
                placeholder="스스로 적어 보세요."
                className="w-full px-3.5 py-2.5 bg-white border-2 border-amber-300 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-amber-500 disabled:bg-slate-100 disabled:text-slate-500"
              />
              <span className="text-xs sm:text-sm font-bold text-slate-700 whitespace-nowrap">
                했습니다.
              </span>
            </div>
          </div>

          {/* 3. 앞으로 그림을 사용할 때 */}
          <div className="space-y-1.5">
            <label className="text-xs sm:text-sm font-black text-amber-950 block">
              3. 앞으로 실천할 행동:
            </label>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-bold text-slate-700 whitespace-nowrap">
                앞으로 그림을 사용할 때
              </span>
              <input
                type="text"
                value={action}
                disabled={readOnly}
                onChange={(e) => !readOnly && onUpdateField('action', e.target.value)}
                placeholder="스스로 적어 보세요."
                className="w-full px-3.5 py-2.5 bg-white border-2 border-amber-300 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-amber-500 disabled:bg-slate-100 disabled:text-slate-500"
              />
              <span className="text-xs sm:text-sm font-bold text-slate-700 whitespace-nowrap">
                하겠습니다.
              </span>
            </div>
          </div>

          {/* 4. 배운 내용을 한 문장으로 정리해 보세요 */}
          <div className="space-y-1.5 bg-amber-50 p-4 rounded-2xl border border-amber-200">
            <label className="text-xs sm:text-sm font-black text-amber-950 block">
              4. 배운 내용을 한 문장으로 정리해 보세요:
            </label>
            <input
              type="text"
              value={customSentence}
              disabled={readOnly}
              onChange={(e) => !readOnly && onUpdateField('customSentence', e.target.value)}
              placeholder="배운 내용을 한 문장으로 정리해 보세요."
              className="w-full px-4 py-3 bg-white border-2 border-amber-300 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-amber-500 disabled:bg-slate-100 disabled:text-slate-500"
            />
          </div>

          {/* Printable Completed Learning Record Card */}
          {isLearningRecordComplete && (
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 border-4 border-amber-400 rounded-3xl p-6 shadow-xl space-y-4 printable-area animate-fadeIn">
              <div className="text-center pb-3 border-b-2 border-amber-300">
                <h3 className="text-2xl font-black text-amber-950">
                  📜 배움 기록 카드
                </h3>
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-slate-800 font-bold">
                <div className="bg-white p-3.5 rounded-2xl border border-amber-200 space-y-1">
                  <span className="text-amber-900 font-black text-xs block">💡 1. 새롭게 알게 된 점:</span>
                  <p className="text-slate-900">새롭게 알게 된 점은 {learned} 입니다.</p>
                </div>

                <div className="bg-white p-3.5 rounded-2xl border border-amber-200 space-y-1">
                  <span className="text-amber-900 font-black text-xs block">💖 2. 역할을 바꾸며 느낀 점:</span>
                  <p className="text-slate-900">역할을 바꾸어 보니 {felt} 했습니다.</p>
                </div>

                <div className="bg-white p-3.5 rounded-2xl border border-amber-200 space-y-1">
                  <span className="text-amber-900 font-black text-xs block">🤙 3. 실천할 행동:</span>
                  <p className="text-slate-900">앞으로 그림을 사용할 때 {action} 하겠습니다.</p>
                </div>

                <div className="bg-white p-3.5 rounded-2xl border border-amber-200 space-y-1">
                  <span className="text-amber-900 font-black text-xs block">✏️ 4. 내가 직접 정리한 한 문장:</span>
                  <p className="text-slate-900">{customSentence}</p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3">
                <button
                  onClick={handleSpeakLearningRecord}
                  className="w-full sm:w-auto px-4 py-2 bg-indigo-100 hover:bg-indigo-200 text-indigo-950 font-bold text-xs rounded-xl border border-indigo-300 flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Volume2 className="w-4 h-4 text-indigo-700" />
                  <span>나의 배움 소리로 듣기</span>
                </button>

                <button
                  onClick={handlePrint}
                  className="w-full sm:w-auto px-5 py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-black text-xs sm:text-sm rounded-xl shadow flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Printer className="w-4 h-4 text-slate-300" />
                  <span>배움 기록 카드 인쇄하기</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Restart Button */}
      <div className="flex justify-end pt-4">
        <button
          onClick={onReset}
          className="py-3.5 px-6 bg-amber-400 hover:bg-amber-500 text-amber-950 font-black text-sm rounded-2xl shadow flex items-center gap-2 transition cursor-pointer border-2 border-amber-500"
        >
          <RotateCcw className="w-5 h-5" />
          <span>처음부터 다시 하기</span>
        </button>
      </div>
    </div>
  );
};
