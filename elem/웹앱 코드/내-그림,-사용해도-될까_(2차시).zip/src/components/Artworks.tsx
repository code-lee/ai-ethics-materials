import React, { useState } from 'react';
import { Sparkles, Wand2, Heart, ShieldCheck, HelpCircle, Sticker } from 'lucide-react';
import { ScenarioId } from '../types';

// Minwoo's Rainbow Lion
export const OriginalLionArtwork: React.FC<{ className?: string; showBadge?: boolean }> = ({
  className = '',
  showBadge = true,
}) => {
  return (
    <div className={`relative bg-amber-50/90 border-4 border-amber-300 rounded-2xl p-4 shadow-md overflow-hidden text-center flex flex-col items-center justify-between ${className}`}>
      {showBadge && (
        <div className="absolute top-3 left-3 bg-amber-400 text-amber-950 px-3 py-1 rounded-full text-xs sm:text-sm font-bold shadow flex items-center gap-1 z-10">
          <Heart className="w-4 h-4 fill-amber-900 text-amber-900" />
          <span>그림을 만든 사람: 민우 (손그림)</span>
        </div>
      )}

      <div className="w-full flex-1 flex items-center justify-center my-2 py-2">
        <svg viewBox="0 0 300 300" className="w-full max-w-[220px] sm:max-w-[250px] h-auto drop-shadow-md select-none">
          <rect x="10" y="10" width="280" height="280" rx="20" fill="#FFFBEB" stroke="#FCD34D" strokeWidth="4" strokeDasharray="8 6" />
          <g className="rainbow-mane">
            <circle cx="150" cy="120" r="85" fill="#EF4444" opacity="0.8" />
            <circle cx="150" cy="120" r="77" fill="#F97316" opacity="0.85" />
            <circle cx="150" cy="120" r="69" fill="#FACC15" opacity="0.9" />
            <circle cx="150" cy="120" r="61" fill="#10B981" opacity="0.85" />
            <circle cx="150" cy="120" r="53" fill="#3B82F6" opacity="0.85" />
            <circle cx="150" cy="120" r="45" fill="#8B5CF6" opacity="0.85" />
          </g>
          <circle cx="150" cy="130" r="42" fill="#FDE047" stroke="#D97706" strokeWidth="4" />
          <circle cx="118" cy="98" r="14" fill="#FDE047" stroke="#D97706" strokeWidth="3" />
          <circle cx="118" cy="98" r="8" fill="#F87171" />
          <circle cx="182" cy="98" r="14" fill="#FDE047" stroke="#D97706" strokeWidth="3" />
          <circle cx="182" cy="98" r="8" fill="#F87171" />
          <circle cx="135" cy="122" r="6" fill="#1E293B" />
          <circle cx="137" cy="120" r="2" fill="#FFFFFF" />
          <circle cx="165" cy="122" r="6" fill="#1E293B" />
          <circle cx="167" cy="120" r="2" fill="#FFFFFF" />
          <ellipse cx="126" cy="134" rx="6" ry="4" fill="#F43F5E" opacity="0.6" />
          <ellipse cx="174" cy="134" rx="6" ry="4" fill="#F43F5E" opacity="0.6" />
          <polygon points="150,132 144,140 156,140" fill="#D97706" />
          <path d="M 150 140 L 150 148 M 150 148 Q 142 154 136 148 M 150 148 Q 158 154 164 148" fill="none" stroke="#B45309" strokeWidth="3" strokeLinecap="round" />
          <path d="M 125 170 Q 150 160 175 170 L 180 230 Q 150 240 120 230 Z" fill="#FBBF24" stroke="#D97706" strokeWidth="4" />
          <ellipse cx="132" cy="230" rx="12" ry="8" fill="#FDE047" stroke="#D97706" strokeWidth="3" />
          <ellipse cx="168" cy="230" rx="12" ry="8" fill="#FDE047" stroke="#D97706" strokeWidth="3" />
          <text x="150" y="272" textAnchor="middle" fill="#92400E" fontSize="15" fontWeight="bold" fontFamily="sans-serif">
            "무지개 사자 (민우 그림)"
          </text>
        </svg>
      </div>

      <div className="w-full bg-amber-100/90 rounded-xl p-2 text-xs sm:text-sm text-amber-900 font-medium">
        ✏️ 크레파스와 색연필로 정성껏 그린 민우의 원래 그림
      </div>
    </div>
  );
};

// Sujin's AI Space Lion
export const AiSpaceLionArtwork: React.FC<{ className?: string; showBadge?: boolean }> = ({
  className = '',
  showBadge = true,
}) => {
  return (
    <div className={`relative bg-slate-900 border-4 border-indigo-500 rounded-2xl p-4 shadow-xl overflow-hidden text-center flex flex-col items-center justify-between text-white ${className}`}>
      {showBadge && (
        <div className="absolute top-3 left-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-3 py-1 rounded-full text-xs sm:text-sm font-bold shadow-lg flex items-center gap-1 z-10">
          <Wand2 className="w-4 h-4 text-cyan-300" />
          <span>AI로 바꾼 그림: 수진 (우주 사자)</span>
        </div>
      )}

      <div className="w-full flex-1 flex items-center justify-center my-2 py-2">
        <svg viewBox="0 0 300 300" className="w-full max-w-[220px] sm:max-w-[250px] h-auto drop-shadow-[0_0_15px_rgba(99,102,241,0.5)] select-none">
          <defs>
            <radialGradient id="spaceBg" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#312E81" />
              <stop offset="60%" stopColor="#1E1B4B" />
              <stop offset="100%" stopColor="#0F172A" />
            </radialGradient>
            <linearGradient id="neonMane" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#06B6D4" />
              <stop offset="50%" stopColor="#8B5CF6" />
              <stop offset="100%" stopColor="#EC4899" />
            </linearGradient>
            <linearGradient id="goldGlow" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FDE047" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>
          </defs>
          <rect x="10" y="10" width="280" height="280" rx="20" fill="url(#spaceBg)" stroke="#6366F1" strokeWidth="3" />
          <circle cx="50" cy="50" r="2" fill="#67E8F9" />
          <circle cx="240" cy="70" r="3" fill="#F472B6" />
          <circle cx="70" cy="220" r="2.5" fill="#FDE047" />
          <g className="neon-mane">
            <circle cx="150" cy="120" r="82" fill="url(#neonMane)" opacity="0.9" />
          </g>
          <circle cx="150" cy="130" r="50" fill="#1E293B" stroke="#38BDF8" strokeWidth="4" />
          <circle cx="150" cy="130" r="38" fill="url(#goldGlow)" />
          <circle cx="135" cy="122" r="7" fill="#0284C7" />
          <circle cx="165" cy="122" r="7" fill="#0284C7" />
          <polygon points="150,132 145,140 155,140" fill="#7C2D12" />
          <path d="M 120 174 Q 150 165 180 174 L 188 230 Q 150 240 112 230 Z" fill="#E2E8F0" stroke="#64748B" strokeWidth="3" />
          <text x="150" y="272" textAnchor="middle" fill="#E0E7FF" fontSize="15" fontWeight="bold" fontFamily="sans-serif">
            "우주 사자 (AI로 바꾼 그림)"
          </text>
        </svg>
      </div>

      <div className="w-full bg-slate-800/90 rounded-xl p-2 text-xs sm:text-sm text-cyan-200 font-medium border border-slate-700">
        🚀 AI 기술로 민우의 그림을 우주 테마로 바꾼 그림
      </div>
    </div>
  );
};

// Suah's Baby Dinosaur (Handdrawn)
export const OriginalDinosaurArtwork: React.FC<{ className?: string; showBadge?: boolean }> = ({
  className = '',
  showBadge = true,
}) => {
  return (
    <div className={`relative bg-emerald-50/90 border-4 border-emerald-300 rounded-2xl p-4 shadow-md overflow-hidden text-center flex flex-col items-center justify-between ${className}`}>
      {showBadge && (
        <div className="absolute top-3 left-3 bg-emerald-400 text-emerald-950 px-3 py-1 rounded-full text-xs sm:text-sm font-bold shadow flex items-center gap-1 z-10">
          <Heart className="w-4 h-4 fill-emerald-900 text-emerald-900" />
          <span>그림을 만든 사람: 수아 (손그림)</span>
        </div>
      )}

      <div className="w-full flex-1 flex items-center justify-center my-2 py-2">
        <svg viewBox="0 0 300 300" className="w-full max-w-[220px] sm:max-w-[250px] h-auto drop-shadow-md select-none">
          <rect x="10" y="10" width="280" height="280" rx="20" fill="#ECFDF5" stroke="#34D399" strokeWidth="4" strokeDasharray="8 6" />

          {/* Dinosaur Body */}
          <path d="M 110 160 Q 90 120 120 80 Q 160 70 180 110 Q 200 150 180 190 Q 150 220 120 200 Z" fill="#34D399" stroke="#059669" strokeWidth="4" />

          {/* Spikes on back */}
          <polygon points="125,75 135,55 145,75" fill="#FBBF24" stroke="#D97706" strokeWidth="2" />
          <polygon points="145,80 158,60 168,82" fill="#FBBF24" stroke="#D97706" strokeWidth="2" />
          <polygon points="165,95 180,78 188,100" fill="#FBBF24" stroke="#D97706" strokeWidth="2" />

          {/* Cute Dinosaur Eyes */}
          <circle cx="135" cy="105" r="7" fill="#064E3B" />
          <circle cx="137" cy="103" r="2.5" fill="#FFFFFF" />
          <ellipse cx="128" cy="115" rx="5" ry="3" fill="#F43F5E" opacity="0.6" />

          {/* Smile */}
          <path d="M 130 122 Q 138 128 145 120" fill="none" stroke="#064E3B" strokeWidth="3" strokeLinecap="round" />

          {/* Belly */}
          <path d="M 125 150 Q 150 145 160 185 Q 135 195 125 150 Z" fill="#A7F3D0" />

          {/* Tiny Arms & Legs */}
          <ellipse cx="120" cy="160" rx="8" ry="5" fill="#059669" />
          <ellipse cx="130" cy="202" rx="10" ry="7" fill="#059669" />
          <ellipse cx="160" cy="198" rx="10" ry="7" fill="#059669" />

          {/* Tail */}
          <path d="M 180 170 Q 220 175 230 155 Q 210 185 175 188 Z" fill="#34D399" stroke="#059669" strokeWidth="3" />

          <text x="150" y="272" textAnchor="middle" fill="#065F46" fontSize="15" fontWeight="bold" fontFamily="sans-serif">
            "아기 공룡 (수아 그림)"
          </text>
        </svg>
      </div>

      <div className="w-full bg-emerald-100/90 rounded-xl p-2 text-xs sm:text-sm text-emerald-900 font-medium">
        🦖 쉬는 시간마다 정성껏 공들여 그린 수아의 아기 공룡 캐릭터
      </div>
    </div>
  );
};

// Jiho's 3D Dinosaur AI Sticker
export const AiDinosaurStickerArtwork: React.FC<{ className?: string; showBadge?: boolean }> = ({
  className = '',
  showBadge = true,
}) => {
  return (
    <div className={`relative bg-purple-950 border-4 border-purple-500 rounded-2xl p-4 shadow-xl overflow-hidden text-center flex flex-col items-center justify-between text-white ${className}`}>
      {showBadge && (
        <div className="absolute top-3 left-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white px-3 py-1 rounded-full text-xs sm:text-sm font-bold shadow-lg flex items-center gap-1 z-10">
          <Sticker className="w-4 h-4 text-pink-300" />
          <span>AI 스티커: 지호 (3D 공룡)</span>
        </div>
      )}

      <div className="w-full flex-1 flex items-center justify-center my-2 py-2">
        <svg viewBox="0 0 300 300" className="w-full max-w-[220px] sm:max-w-[250px] h-auto drop-shadow-[0_0_18px_rgba(168,85,247,0.6)] select-none">
          <defs>
            <radialGradient id="stickerBg" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#581C87" />
              <stop offset="100%" stopColor="#2E1065" />
            </radialGradient>
            <linearGradient id="3dGreen" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#34D399" />
              <stop offset="50%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#047857" />
            </linearGradient>
          </defs>

          {/* Dark Sticker Backing Canvas */}
          <rect x="10" y="10" width="280" height="280" rx="20" fill="url(#stickerBg)" stroke="#A855F7" strokeWidth="3" />

          {/* White Sticker Outline Effect */}
          <path d="M 100 160 Q 80 110 120 70 Q 170 60 190 100 Q 210 140 190 190 Q 150 230 110 210 Z" fill="#FFFFFF" opacity="0.9" />

          {/* 3D Rendered Dinosaur Body */}
          <path d="M 105 160 Q 85 115 120 75 Q 165 65 185 105 Q 205 145 185 190 Q 150 225 115 205 Z" fill="url(#3dGreen)" stroke="#064E3B" strokeWidth="2" />

          {/* 3D Spikes */}
          <polygon points="125,70 138,45 148,70" fill="#F59E0B" stroke="#78350F" strokeWidth="1.5" />
          <polygon points="148,75 162,50 172,78" fill="#F59E0B" stroke="#78350F" strokeWidth="1.5" />

          {/* 3D Shiny Glass Eyes */}
          <circle cx="135" cy="102" r="8" fill="#0284C7" />
          <circle cx="137" cy="100" r="3" fill="#FFFFFF" />

          {/* Sticker Tag */}
          <g transform="translate(180, 200)">
            <rect x="0" y="0" width="80" height="28" rx="14" fill="#EC4899" stroke="#FFFFFF" strokeWidth="2" />
            <text x="40" y="18" textAnchor="middle" fill="#FFFFFF" fontSize="12" fontWeight="bold">3D 스티커⚡</text>
          </g>

          <text x="150" y="272" textAnchor="middle" fill="#F3E8FF" fontSize="15" fontWeight="bold" fontFamily="sans-serif">
            "3D 공룡 스티커 (AI로 바꾼 그림)"
          </text>
        </svg>
      </div>

      <div className="w-full bg-purple-900/90 rounded-xl p-2 text-xs sm:text-sm text-purple-200 font-medium border border-purple-700">
        ✨ 수아 그림을 기반으로 AI가 생성한 3D 입체 캐릭터 스티커
      </div>
    </div>
  );
};

// Side-by-side comparison component supporting both scenarios
export const ArtworkComparison: React.FC<{ scenarioId: ScenarioId }> = ({ scenarioId }) => {
  const [viewMode, setViewMode] = useState<'side' | 'toggle'>('side');
  const [activeTab, setActiveTab] = useState<'original' | 'ai'>('original');

  return (
    <div className="w-full bg-white rounded-3xl p-4 sm:p-6 border-2 border-slate-200 shadow-lg">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-amber-500" />
          <h3 className="text-lg sm:text-xl font-bold text-slate-800">그림 비교하기</h3>
        </div>

        <div className="flex bg-slate-100 p-1 rounded-xl text-xs sm:text-sm font-semibold">
          <button
            onClick={() => setViewMode('side')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              viewMode === 'side'
                ? 'bg-white text-indigo-600 shadow-sm font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            📱 나란히 비교
          </button>
          <button
            onClick={() => setViewMode('toggle')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              viewMode === 'toggle'
                ? 'bg-white text-indigo-600 shadow-sm font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            🔄 탭으로 전환
          </button>
        </div>
      </div>

      {scenarioId === 'lion' ? (
        viewMode === 'side' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            <OriginalLionArtwork />
            <AiSpaceLionArtwork />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex gap-2">
              <button
                onClick={() => setActiveTab('original')}
                className={`flex-1 py-3 px-4 rounded-xl text-sm sm:text-base font-bold flex items-center justify-center gap-2 transition ${
                  activeTab === 'original'
                    ? 'bg-amber-400 text-amber-950 shadow'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                🎨 민우의 원래 그림 (손그림)
              </button>
              <button
                onClick={() => setActiveTab('ai')}
                className={`flex-1 py-3 px-4 rounded-xl text-sm sm:text-base font-bold flex items-center justify-center gap-2 transition ${
                  activeTab === 'ai'
                    ? 'bg-indigo-600 text-white shadow'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                🤖 수진이의 AI로 바꾼 그림
              </button>
            </div>
            <div>
              {activeTab === 'original' ? <OriginalLionArtwork /> : <AiSpaceLionArtwork />}
            </div>
          </div>
        )
      ) : viewMode === 'side' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
          <OriginalDinosaurArtwork />
          <AiDinosaurStickerArtwork />
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('original')}
              className={`flex-1 py-3 px-4 rounded-xl text-sm sm:text-base font-bold flex items-center justify-center gap-2 transition ${
                activeTab === 'original'
                  ? 'bg-emerald-400 text-emerald-950 shadow'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              🦖 수아의 원래 캐릭터 (손그림)
            </button>
            <button
              onClick={() => setActiveTab('ai')}
              className={`flex-1 py-3 px-4 rounded-xl text-sm sm:text-base font-bold flex items-center justify-center gap-2 transition ${
                activeTab === 'ai'
                  ? 'bg-purple-600 text-white shadow'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              ✨ 지호의 3D AI 스티커
            </button>
          </div>
          <div>
            {activeTab === 'original' ? <OriginalDinosaurArtwork /> : <AiDinosaurStickerArtwork />}
          </div>
        </div>
      )}

      {/* Observation callout */}
      <div className="mt-4 bg-amber-50/70 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
        <HelpCircle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5" />
        <div className="text-xs sm:text-sm text-slate-700 leading-relaxed">
          <span className="font-bold text-amber-900 block mb-1">🔍 함께 관찰해 봅시다!</span>
          {scenarioId === 'lion' ? (
            <>
              오른쪽 AI 그림은 우주 배경으로 바뀌었지만, <strong className="text-indigo-700">사자의 표정과 무지개 갈기 디자인</strong>은 민우가 직접 그린 그림에서 따온 것입니다. 그림을 만든 사람의 허락 없이 공개해도 될까요?
            </>
          ) : (
            <>
              오른쪽 AI 스티커는 3D 입체 효과가 추가되었지만, <strong className="text-purple-700">공룡의 귀여운 표정과 뿔 디자인</strong>은 수아 캐릭터 원본입니다. 학급 대화방에 허락 없이 전송해도 될까요?
            </>
          )}
        </div>
      </div>
    </div>
  );
};
