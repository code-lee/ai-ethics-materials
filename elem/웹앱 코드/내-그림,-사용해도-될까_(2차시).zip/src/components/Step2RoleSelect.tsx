import React from 'react';
import { RoleType, ScenarioData } from '../types';
import { ROLES, ROLE_HINTS } from '../data/scenarioData';
import { ArrowRight, Users, MessageSquare } from 'lucide-react';

interface Step2Props {
  scenario: ScenarioData;
  selectedRole: RoleType | null;
  isPrepared: boolean;
  onSelectRole: (role: RoleType) => void;
  onTogglePrepared: (val: boolean) => void;
  onNext: () => void;
  speakText: (text: string) => void;
  readOnly?: boolean;
}

export const Step2RoleSelect: React.FC<Step2Props> = ({
  scenario,
  selectedRole,
  isPrepared,
  onSelectRole,
  onTogglePrepared,
  onNext,
  speakText,
  readOnly = false,
}) => {
  const currentRoleInfo = selectedRole ? ROLES[selectedRole] : null;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600 rounded-3xl p-5 sm:p-7 border-4 border-blue-300 shadow-lg text-white">
        <div className="flex items-center gap-2 mb-2 text-blue-100 font-black text-xs sm:text-sm uppercase tracking-wide">
          <span className="bg-white/20 px-3 py-1 rounded-full border border-white/30 text-white">1차시 · 2단계</span>
          <span>역할별 입장 생각 준비하기</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-black text-white mb-2 leading-tight">
          "모둠에서 담당할 역할을 정하고, 그 역할의 입장에서 생각할 준비를 하세요!"
        </h2>
        <p className="text-sm sm:text-lg text-blue-100 font-medium leading-relaxed">
          모둠원 4명이 4가지 역할을 나누어 맡고, 인물의 마음과 생각을 표현할 단어를 살펴봅시다.
        </p>
      </div>

      {/* Role Selection Grid (4 Neutral Cards) */}
      <div className="space-y-4">
        <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
          <Users className="w-5 h-5 text-indigo-500" />
          <span>역할 선택하기 (아래 4가지 역할을 모둠에서 골고루 나누어 맡으세요)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.values(ROLES).map((role) => {
            const isSelected = selectedRole === role.id;

            return (
              <button
                key={role.id}
                onClick={() => {
                  if (readOnly) return;
                  onSelectRole(role.id);
                  speakText(`${role.name} 역할을 선택했습니다.`);
                }}
                disabled={readOnly}
                className={`p-5 rounded-3xl border-4 text-left transition flex flex-col justify-between space-y-3 ${
                  readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                } ${
                  isSelected
                    ? 'bg-indigo-50 border-indigo-500 shadow-lg ring-4 ring-indigo-200'
                    : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-3xl">{role.avatar}</span>
                    <span className={`px-2.5 py-1 rounded-full text-xs font-black border ${role.badgeColor}`}>
                      {role.name}
                    </span>
                  </div>
                  <h4 className="text-base font-black text-slate-900">
                    {role.characterName}
                  </h4>
                  <p className="text-xs text-slate-600 font-medium leading-relaxed">
                    {role.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 text-xs font-bold text-indigo-900">
                  {isSelected ? '✅ 선택한 역할' : '👉 역할 선택하기'}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Role Thinking & Helper Keywords (Only shown when a role is selected) */}
      {currentRoleInfo && (
        <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-indigo-200 shadow-md space-y-5 animate-fadeIn">
          <div className="flex items-center justify-between pb-3 border-b border-indigo-100">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{currentRoleInfo.avatar}</span>
              <div>
                <h3 className="text-lg font-black text-slate-900">
                  {currentRoleInfo.name} ({currentRoleInfo.characterName})의 생각 준비
                </h3>
                <p className="text-xs font-bold text-indigo-900">{currentRoleInfo.thought}</p>
              </div>
            </div>
          </div>

          {/* Helper Words (Short emotion/motive words only, NO completed answers) */}
          <div className="space-y-2">
            <h4 className="text-xs sm:text-sm font-black text-slate-800 flex items-center gap-1.5">
              <span>💡</span>
              <span>말할 내용 준비를 돕는 단어 낱말카드</span>
            </h4>
            <div className="flex flex-wrap gap-2">
              {ROLE_HINTS[currentRoleInfo.id]?.map((word, idx) => (
                <span
                  key={idx}
                  className="px-3.5 py-1.5 bg-indigo-50 border border-indigo-200 text-indigo-950 font-extrabold rounded-xl text-xs sm:text-sm"
                >
                  #{word}
                </span>
              ))}
            </div>
          </div>

          {/* Semi-structured Dialogue Script Template */}
          <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-200 space-y-2">
            <h4 className="text-xs sm:text-sm font-black text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-indigo-600" />
              <span>{currentRoleInfo.scriptTemplate.title}의 대사 예시 틀</span>
            </h4>
            <div className="text-xs sm:text-sm font-bold text-slate-800 space-y-1 bg-white p-3 rounded-xl border border-slate-200">
              <p>{currentRoleInfo.scriptTemplate.line1}</p>
              {currentRoleInfo.scriptTemplate.line2 && <p>{currentRoleInfo.scriptTemplate.line2}</p>}
            </div>
          </div>
        </div>
      )}

      {/* Group Role Division Confirmation Checkbox */}
      <div className="bg-white rounded-3xl p-5 border-4 border-blue-200 shadow-md space-y-3">
        <label className="flex items-center gap-3 cursor-pointer select-none bg-blue-50 p-4 rounded-2xl border-2 border-blue-300">
          <input
            type="checkbox"
            checked={isPrepared}
            disabled={readOnly}
            onChange={(e) => !readOnly && onTogglePrepared(e.target.checked)}
            className="w-6 h-6 rounded-lg text-blue-600 focus:ring-blue-500 border-2 border-blue-400"
          />
          <span className="font-extrabold text-xs sm:text-sm text-blue-950">
            ✅ 우리 모둠원이 4가지 역할을 모두 하나씩 골고루 맡아 나누었습니다.
          </span>
        </label>
      </div>

      {/* Next Step Action Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onNext}
          disabled={!selectedRole || !isPrepared || readOnly}
          className={`py-4 px-8 font-black text-lg sm:text-xl rounded-2xl shadow-lg border-2 flex items-center gap-3 transition ${
            selectedRole && isPrepared && !readOnly
              ? 'bg-blue-600 hover:bg-blue-700 text-white border-blue-700 cursor-pointer hover:scale-102'
              : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
          }`}
        >
          <span>3단계: 문제 상황 역할놀이 실행하기</span>
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
