import React from 'react';
import { ScenarioData } from '../types';
import { ArrowRight, HelpCircle, Lightbulb } from 'lucide-react';

export type OptionChoice = 'kept' | 'not_kept' | 'unsure';

export interface Step4AnswerState {
  q1: OptionChoice | null;
  q2: OptionChoice | null;
  q3: OptionChoice | null;
}

interface Step4Props {
  scenario: ScenarioData;
  answers: Step4AnswerState;
  discussed: boolean;
  showResults: boolean;
  onUpdateAnswer: (qKey: 'q1' | 'q2' | 'q3', val: OptionChoice) => void;
  onToggleDiscussed: (val: boolean) => void;
  onShowResults: (val: boolean) => void;
  onNext: () => void;
  speakText: (text: string) => void;
  readOnly?: boolean;
}

export const Step4CopyrightCheck: React.FC<Step4Props> = ({
  scenario,
  answers,
  discussed,
  showResults,
  onUpdateAnswer,
  onToggleDiscussed,
  onShowResults,
  onNext,
  speakText,
  readOnly = false,
}) => {
  const isAllAnswered = answers.q1 !== null && answers.q2 !== null && answers.q3 !== null;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 rounded-3xl p-5 sm:p-7 border-4 border-emerald-300 shadow-lg text-white">
        <div className="flex items-center gap-2 mb-2 text-emerald-100 font-black text-xs sm:text-sm uppercase tracking-wide">
          <span className="bg-white/20 px-3 py-1 rounded-full border border-white/30 text-white">1차시 · 4단계</span>
          <span>문제 상황 스스로 판단하기</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-black text-white mb-2 leading-tight">
          "수진이가 게시판에 올린 그림 게시물을 살펴보고 스스로 판단해 보세요."
        </h2>
        <p className="text-sm sm:text-lg text-emerald-100 font-medium leading-relaxed">
          수진이의 행동에 대해 세 가지 질문에 답변을 선택하고 이유를 말해 봅시다.
        </p>
      </div>

      {/* 3 Questions Grid */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-slate-200 shadow-md space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
          <HelpCircle className="w-6 h-6 text-emerald-600" />
          <h3 className="text-lg font-black text-slate-900">
            그림 게시물 점검 질문 (각 질문에 스스로 판단해 보세요)
          </h3>
        </div>

        {/* Question 1 */}
        <div className="p-4 sm:p-5 rounded-2xl border-2 border-slate-200 bg-slate-50 space-y-3">
          <div className="font-extrabold text-sm sm:text-base text-slate-900">
            1. 그림을 사용하기 전에 사용할 수 있는지 미리 확인했나요?
          </div>
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            {[
              { id: 'kept', label: '지켰다' },
              { id: 'not_kept', label: '지키지 않았다' },
              { id: 'unsure', label: '잘 모르겠다' },
            ].map((opt) => (
              <button
                key={opt.id}
                onClick={() => {
                  if (readOnly) return;
                  onUpdateAnswer('q1', opt.id as OptionChoice);
                  onShowResults(false);
                }}
                disabled={readOnly}
                className={`py-3 px-2 rounded-xl text-xs sm:text-sm font-black border-2 transition ${
                  readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                } ${
                  answers.q1 === opt.id
                    ? 'bg-emerald-600 text-white border-emerald-700 shadow ring-2 ring-emerald-300'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Question 2 */}
        <div className="p-4 sm:p-5 rounded-2xl border-2 border-slate-200 bg-slate-50 space-y-3">
          <div className="font-extrabold text-sm sm:text-base text-slate-900">
            2. 누가 처음 만든 그림인지 알 수 있게 했나요?
          </div>
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            {[
              { id: 'kept', label: '지켰다' },
              { id: 'not_kept', label: '지키지 않았다' },
              { id: 'unsure', label: '잘 모르겠다' },
            ].map((opt) => (
              <button
                key={opt.id}
                onClick={() => {
                  if (readOnly) return;
                  onUpdateAnswer('q2', opt.id as OptionChoice);
                  onShowResults(false);
                }}
                disabled={readOnly}
                className={`py-3 px-2 rounded-xl text-xs sm:text-sm font-black border-2 transition ${
                  readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                } ${
                  answers.q2 === opt.id
                    ? 'bg-emerald-600 text-white border-emerald-700 shadow ring-2 ring-emerald-300'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Question 3 */}
        <div className="p-4 sm:p-5 rounded-2xl border-2 border-slate-200 bg-slate-50 space-y-3">
          <div className="font-extrabold text-sm sm:text-base text-slate-900">
            3. AI로 그림을 바꾼 사실을 알렸나요?
          </div>
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            {[
              { id: 'kept', label: '지켰다' },
              { id: 'not_kept', label: '지키지 않았다' },
              { id: 'unsure', label: '잘 모르겠다' },
            ].map((opt) => (
              <button
                key={opt.id}
                onClick={() => {
                  if (readOnly) return;
                  onUpdateAnswer('q3', opt.id as OptionChoice);
                  onShowResults(false);
                }}
                disabled={readOnly}
                className={`py-3 px-2 rounded-xl text-xs sm:text-sm font-black border-2 transition ${
                  readOnly ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
                } ${
                  answers.q3 === opt.id
                    ? 'bg-emerald-600 text-white border-emerald-700 shadow ring-2 ring-emerald-300'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Discussion Checkbox & Confirm Button */}
        {isAllAnswered && !showResults && (
          <div className="space-y-4 pt-4 border-t border-slate-200 animate-fadeIn">
            <label className="flex items-center gap-3 cursor-pointer select-none bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-200">
              <input
                type="checkbox"
                checked={discussed}
                disabled={readOnly}
                onChange={(e) => !readOnly && onToggleDiscussed(e.target.checked)}
                className="w-6 h-6 rounded-lg text-emerald-600 focus:ring-emerald-500 border-2 border-emerald-300"
              />
              <span className="font-extrabold text-xs sm:text-sm text-emerald-950">
                🗣️ 우리 모둠의 판단 이유를 함께 이야기했습니다.
              </span>
            </label>

            <div className="flex justify-center">
              <button
                onClick={() => {
                  if (readOnly) return;
                  onShowResults(true);
                  speakText('판단 결과를 확인합니다.');
                }}
                disabled={!discussed || readOnly}
                className={`py-3.5 px-8 font-black text-base sm:text-lg rounded-2xl shadow-lg border-2 transition ${
                  discussed && !readOnly
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700 cursor-pointer hover:scale-102'
                    : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                }`}
              >
                📊 판단 결과 확인하기
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Judgment Outcome, Reflection Questions & Concept Summary (Only after clicking '판단 결과 확인하기') */}
      {showResults && (
        <div className="space-y-6 animate-fadeIn">
          {/* 사건에서 확인한 결과 */}
          <div className="bg-white rounded-3xl p-5 sm:p-7 border-4 border-indigo-200 shadow-md space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-indigo-100">
              <Lightbulb className="w-6 h-6 text-indigo-600" />
              <h3 className="text-lg font-black text-slate-900">
                🔍 사건에서 확인한 결과
              </h3>
            </div>

            <p className="text-xs sm:text-sm font-bold text-slate-700">
              “우리 모둠의 판단과 사건에서 확인한 결과를 비교해 보세요.”
            </p>

            <div className="space-y-2 text-xs sm:text-sm font-bold">
              <div className="p-3.5 rounded-2xl bg-slate-50 border-2 border-slate-200 flex items-center justify-between">
                <span>1. 그림을 사용할 수 있는지 확인하기</span>
                <span className="px-3 py-1 bg-rose-100 text-rose-900 rounded-xl font-extrabold border border-rose-300">
                  지키지 않음
                </span>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-50 border-2 border-slate-200 flex items-center justify-between">
                <span>2. 처음 그림을 만든 사람과 출처 밝히기</span>
                <span className="px-3 py-1 bg-rose-100 text-rose-900 rounded-xl font-extrabold border border-rose-300">
                  지키지 않음
                </span>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-50 border-2 border-slate-200 flex items-center justify-between">
                <span>3. AI로 바꾼 사실 알리기</span>
                <span className="px-3 py-1 bg-rose-100 text-rose-900 rounded-xl font-extrabold border border-rose-300">
                  지키지 않음
                </span>
              </div>
            </div>

            {/* Questions to reflect if judgment differs */}
            {(answers.q1 !== 'not_kept' || answers.q2 !== 'not_kept' || answers.q3 !== 'not_kept') && (
              <div className="bg-amber-50 p-4 rounded-2xl border-2 border-amber-300 text-xs sm:text-sm font-bold text-amber-950 space-y-2">
                <div className="font-black text-amber-900 flex items-center gap-1.5">
                  <span>💭</span>
                  <span>결과가 다르게 나온 부분에 대해 함께 생각해 봅시다</span>
                </div>
                <ul className="list-disc pl-5 space-y-1 font-extrabold text-slate-800">
                  <li>어떤 장면을 다시 살펴보면 좋을까요?</li>
                  <li>그 정보는 게시물에서 확인할 수 있었나요?</li>
                  <li>그림을 만든 사람의 마음은 어떠했을까요?</li>
                </ul>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Next Step Action Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onNext}
          disabled={!showResults || readOnly}
          className={`py-4 px-8 font-black text-lg sm:text-xl rounded-2xl shadow-lg border-2 flex items-center gap-3 transition ${
            showResults && !readOnly
              ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700 cursor-pointer hover:scale-102'
              : 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
          }`}
        >
          <span>5단계: 판단 이유 말하기 & 역할 교환하기</span>
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
