import React, { useState } from 'react';
import { StepNumber } from '../types';
import { RotateCcw, Volume2, VolumeX, Lock, ShieldCheck, GraduationCap, XCircle } from 'lucide-react';

interface HeaderProps {
  currentViewStep: StepNumber;
  highestCompletedStep: StepNumber;
  completedSteps: Set<StepNumber>;
  isTeacherPreview: boolean;
  onSelectStudentStep: (step: StepNumber) => void;
  onTeacherJumpStep: (step: StepNumber) => void;
  onExitTeacherPreview: () => void;
  onReset: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

const STEP_ITEMS: { step: StepNumber; period: 1 | 2; name: string; icon: string }[] = [
  // 1차시
  { step: 1, period: 1, name: '1. 혼자 생각', icon: '🔍' },
  { step: 2, period: 1, name: '2. 역할 준비', icon: '🎭' },
  { step: 3, period: 1, name: '3. 문제 역할놀이', icon: '🛑' },
  { step: 4, period: 1, name: '4. 스스로 판단', icon: '🕵️' },
  { step: 5, period: 1, name: '5. 판단 이유 & 역할 교환', icon: '🔄' },
  // 2차시
  { step: 6, period: 2, name: '6. 바른 해결 재연', icon: '✨' },
  { step: 7, period: 2, name: '7. 변화 비교', icon: '⚖️' },
  { step: 8, period: 2, name: '8. 게시물 고치기', icon: '🛠️' },
  { step: 9, period: 2, name: '9. 새 상황 & 배움 기록', icon: '📝' },
];

export const Header: React.FC<HeaderProps> = ({
  currentViewStep,
  highestCompletedStep,
  completedSteps,
  isTeacherPreview,
  onSelectStudentStep,
  onTeacherJumpStep,
  onExitTeacherPreview,
  onReset,
  soundEnabled,
  onToggleSound,
}) => {
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showTeacherMenu, setShowTeacherMenu] = useState<boolean>(false);

  const triggerLockedToast = () => {
    setToastMessage('앞의 활동을 먼저 마쳐 주세요.');
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  const handleStudentStepClick = (step: StepNumber) => {
    const isUnlocked = step <= highestCompletedStep || completedSteps.has(step);
    if (isUnlocked) {
      onSelectStudentStep(step);
    } else {
      triggerLockedToast();
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b-4 border-amber-300 shadow-sm px-3 sm:px-6 py-3 no-print">
      <div className="max-w-6xl mx-auto flex flex-col gap-2.5">
        {/* Top Header Row */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Logo & Title */}
          <div
            className="flex items-center gap-2.5 cursor-pointer"
            onClick={() => onSelectStudentStep(1)}
          >
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-amber-400 to-orange-400 rounded-2xl flex items-center justify-center text-white text-xl sm:text-2xl shadow-md border-2 border-white flex-shrink-0">
              🎨
            </div>
            <div>
              <h1 className="text-base sm:text-2xl font-black tracking-tight text-slate-800 flex items-center gap-1.5 flex-wrap">
                <span>내 그림, 사용해도 될까?</span>
                <span className="px-2 py-0.5 bg-amber-100 text-amber-900 text-xs font-extrabold rounded-full border border-amber-300">
                  초등 3~4학년 2차시 수업용
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 font-medium hidden sm:block">
                모둠 토의 & 역할놀이 중심 AI 저작권 윤리 수업 앱
              </p>
            </div>
          </div>

          {/* Controls: Sound, Teacher Dropdown, Reset */}
          <div className="flex items-center gap-2 flex-wrap justify-end w-full md:w-auto">
            {/* Audio Toggle */}
            <button
              onClick={onToggleSound}
              className={`p-2 rounded-xl border-2 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition ${
                soundEnabled
                  ? 'bg-amber-100 border-amber-300 text-amber-900 hover:bg-amber-200'
                  : 'bg-slate-100 border-slate-300 text-slate-600 hover:bg-slate-200'
              }`}
              title={soundEnabled ? '음성 안내 켜짐' : '음성 안내 꺼짐'}
              aria-label="음성 토글"
            >
              {soundEnabled ? (
                <Volume2 className="w-5 h-5 text-amber-700" />
              ) : (
                <VolumeX className="w-5 h-5 text-slate-500" />
              )}
            </button>

            {/* Teacher Free Step Jump Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowTeacherMenu((prev) => !prev)}
                className="px-3 py-2 bg-indigo-50 border-2 border-indigo-200 hover:bg-indigo-100 text-indigo-950 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-1.5 transition"
                title="교사 전용 단계 바로 이동"
              >
                <GraduationCap className="w-4 h-4 text-indigo-700" />
                <span>교사용 단계 이동</span>
              </button>

              {showTeacherMenu && (
                <div className="absolute right-0 mt-2 w-52 bg-white border-2 border-indigo-300 rounded-2xl shadow-xl z-50 p-2 space-y-1">
                  <div className="text-[11px] font-black text-indigo-900 px-2 py-1 border-b border-indigo-100 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                    <span>교사용 미리보기 단계 선택</span>
                  </div>
                  <div className="max-h-60 overflow-y-auto space-y-0.5">
                    {STEP_ITEMS.map((item) => (
                      <button
                        key={item.step}
                        onClick={() => {
                          onTeacherJumpStep(item.step);
                          setShowTeacherMenu(false);
                        }}
                        className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ${
                          currentViewStep === item.step
                            ? 'bg-indigo-600 text-white'
                            : 'hover:bg-slate-100 text-slate-800'
                        }`}
                      >
                        <span>{item.icon}</span>
                        <span>{item.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Reset Button */}
            <button
              onClick={onReset}
              className="p-2 bg-slate-100 border-2 border-slate-200 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-1.5 transition"
              title="처음부터 다시 하기"
            >
              <RotateCcw className="w-5 h-5 text-slate-600" />
              <span className="hidden sm:inline">처음부터 다시 하기</span>
            </button>
          </div>
        </div>

        {/* Teacher Preview Notice Bar (If active) */}
        {isTeacherPreview && (
          <div className="bg-indigo-600 text-white px-4 py-2 rounded-2xl flex items-center justify-between text-xs sm:text-sm font-black shadow animate-fadeIn">
            <div className="flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-indigo-200" />
              <span>🎓 교사용 단계 미리보기 중입니다 (학생 진도와 활동 기록에 영향을 주지 않습니다)</span>
            </div>
            <button
              onClick={onExitTeacherPreview}
              className="bg-white text-indigo-950 hover:bg-indigo-50 px-3 py-1 rounded-xl text-xs font-black flex items-center gap-1 transition cursor-pointer"
            >
              <XCircle className="w-4 h-4 text-indigo-700" />
              <span>미리보기 종료 (학생 화면)</span>
            </button>
          </div>
        )}

        {/* Step Navigation Bar */}
        <div className="overflow-x-auto pb-1 scrollbar-none">
          <div className="flex items-center min-w-max gap-3">
            {/* 1차시 Group */}
            <div className="flex items-center gap-1 bg-amber-50 p-1 rounded-2xl border-2 border-amber-200">
              <span className="px-2 py-1 bg-amber-300 text-amber-950 font-black text-[11px] sm:text-xs rounded-xl flex-shrink-0">
                1차시: 문제 찾기
              </span>
              {STEP_ITEMS.filter((i) => i.period === 1).map((item) => {
                const isActive = currentViewStep === item.step;
                const isCompleted = completedSteps.has(item.step);
                const isUnlocked = item.step <= highestCompletedStep || isCompleted;

                return (
                  <button
                    key={item.step}
                    onClick={() => handleStudentStepClick(item.step)}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-extrabold transition-all border ${
                      isActive
                        ? 'bg-amber-400 border-amber-500 text-amber-950 shadow scale-105'
                        : isCompleted
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-900 hover:bg-emerald-200'
                        : isUnlocked
                        ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        : 'bg-slate-100 border-slate-200 text-slate-400 opacity-80 cursor-not-allowed'
                    }`}
                  >
                    <span>{item.icon}</span>
                    <span>{item.name}</span>
                    {isCompleted && <span className="text-emerald-700 font-black">✓</span>}
                    {!isUnlocked && <Lock className="w-3 h-3 text-slate-400" />}
                  </button>
                );
              })}
            </div>

            {/* Divider arrow */}
            <span className="text-amber-400 font-black text-lg">➔</span>

            {/* 2차시 Group */}
            <div className="flex items-center gap-1 bg-indigo-50 p-1 rounded-2xl border-2 border-indigo-200">
              <span className="px-2 py-1 bg-indigo-500 text-white font-black text-[11px] sm:text-xs rounded-xl flex-shrink-0">
                2차시: 바른 해결
              </span>
              {STEP_ITEMS.filter((i) => i.period === 2).map((item) => {
                const isActive = currentViewStep === item.step;
                const isCompleted = completedSteps.has(item.step);
                const isUnlocked = item.step <= highestCompletedStep || isCompleted;

                return (
                  <button
                    key={item.step}
                    onClick={() => handleStudentStepClick(item.step)}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-extrabold transition-all border ${
                      isActive
                        ? 'bg-indigo-600 border-indigo-700 text-white shadow scale-105'
                        : isCompleted
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-900 hover:bg-emerald-200'
                        : isUnlocked
                        ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        : 'bg-slate-100 border-slate-200 text-slate-400 opacity-80 cursor-not-allowed'
                    }`}
                  >
                    <span>{item.icon}</span>
                    <span>{item.name}</span>
                    {isCompleted && <span className="text-emerald-700 font-black">✓</span>}
                    {!isUnlocked && <Lock className="w-3 h-3 text-slate-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Locked Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-slate-900/90 text-amber-300 border-2 border-amber-400 px-6 py-3 rounded-2xl font-black text-sm sm:text-base shadow-2xl z-50 flex items-center gap-2 animate-bounce">
          <Lock className="w-5 h-5 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </header>
  );
};
