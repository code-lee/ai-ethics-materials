import React, { useState } from 'react';
import { ActionChoiceId, RoleType, StepNumber, Step9ChoiceId } from './types';
import { SCENARIO_1 } from './data/scenarioData';
import { Header } from './components/Header';
import { Step1Scenario } from './components/Step1Scenario';
import { Step2RoleSelect } from './components/Step2RoleSelect';
import { Step3ProblemRoleplay } from './components/Step3ProblemRoleplay';
import { OptionChoice, Step4AnswerState, Step4CopyrightCheck } from './components/Step4CopyrightCheck';
import { Step5RoleSwitch } from './components/Step5RoleSwitch';
import { Step6SolutionRoleplay } from './components/Step6SolutionRoleplay';
import { Step7Comparison } from './components/Step7Comparison';
import { Step8PostFixer } from './components/Step8PostFixer';
import { Step9Reflection } from './components/Step9Reflection';

export const App: React.FC = () => {
  // Navigation & Progress State
  const [currentViewStep, setCurrentViewStep] = useState<StepNumber>(1);
  const [currentStudentStep, setCurrentStudentStep] = useState<StepNumber>(1);
  const [highestCompletedStep, setHighestCompletedStep] = useState<StepNumber>(1);
  const [completedSteps, setCompletedSteps] = useState<Set<StepNumber>>(new Set());
  const [isTeacherPreview, setIsTeacherPreview] = useState<boolean>(false);

  // Sound State
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Step 1 State
  const [step1Finished, setStep1Finished] = useState<boolean>(false);

  // Step 2 State
  const [step2SelectedRole, setStep2SelectedRole] = useState<RoleType | null>(null);
  const [step2Prepared, setStep2Prepared] = useState<boolean>(false);

  // Step 3 State
  const [step3RoleplayFinished, setStep3RoleplayFinished] = useState<boolean>(false);

  // Step 4 State
  const [step4Answers, setStep4Answers] = useState<Step4AnswerState>({
    q1: null,
    q2: null,
    q3: null,
  });
  const [step4Discussed, setStep4Discussed] = useState<boolean>(false);
  const [step4ShowResults, setStep4ShowResults] = useState<boolean>(false);

  // Step 5 State
  const [step5CreatorEmotions, setStep5CreatorEmotions] = useState<string[]>([]);
  const [step5UserEmotions, setStep5UserEmotions] = useState<string[]>([]);
  const [step5Said, setStep5Said] = useState<boolean>(false);
  const [step5Discussed, setStep5Discussed] = useState<boolean>(false);

  // Step 6 State
  const [step6SelectedChoice, setStep6SelectedChoice] = useState<ActionChoiceId | null>(null);
  const [step6DiscussedChoiceReason, setStep6DiscussedChoiceReason] = useState<boolean>(false);
  const [step6ShowReactions, setStep6ShowReactions] = useState<boolean>(false);
  const [step6IsPrepFinished, setStep6IsPrepFinished] = useState<boolean>(false);
  const [step6IsRoleplayFinished, setStep6IsRoleplayFinished] = useState<boolean>(false);

  // Step 7 State
  const [step7Discussed, setStep7Discussed] = useState<boolean>(false);
  const [step7ShowResult, setStep7ShowResult] = useState<boolean>(false);

  // Step 8 State
  const [step8PermissionStatus, setStep8PermissionStatus] = useState<'allowed' | 'denied' | 'unchecked' | null>(null);
  const [step8DiscussedNoPostReason, setStep8DiscussedNoPostReason] = useState<boolean>(false);
  const [step8AttachedCards, setStep8AttachedCards] = useState<string[]>([]);
  const [step8DiscussedCardReason, setStep8DiscussedCardReason] = useState<boolean>(false);
  const [step8ShowPostResult, setStep8ShowPostResult] = useState<boolean>(false);
  const [step8Blank1, setStep8Blank1] = useState<string>('');
  const [step8Blank2, setStep8Blank2] = useState<string>('');
  const [step8Blank3, setStep8Blank3] = useState<string>('');
  const [step8Blank4, setStep8Blank4] = useState<string>('');
  const [step8DiscussedCriteria, setStep8DiscussedCriteria] = useState<boolean>(false);
  const [step8ShowCriteriaResult, setStep8ShowCriteriaResult] = useState<boolean>(false);

  // Step 9 State
  const [step9SelectedChoiceId, setStep9SelectedChoiceId] = useState<Step9ChoiceId | null>(null);
  const [step9Discussed, setStep9Discussed] = useState<boolean>(false);
  const [step9ShowOutcome, setStep9ShowOutcome] = useState<boolean>(false);
  const [step9FollowupText, setStep9FollowupText] = useState<string>('');
  const [step9DiscussedFollowup, setStep9DiscussedFollowup] = useState<boolean>(false);
  const [step9ShowFollowupExample, setStep9ShowFollowupExample] = useState<boolean>(false);
  const [step9Learned, setStep9Learned] = useState<string>('');
  const [step9Felt, setStep9Felt] = useState<string>('');
  const [step9Action, setStep9Action] = useState<string>('');
  const [step9CustomSentence, setStep9CustomSentence] = useState<string>('');

  // Voice synthesis helper
  const speakText = (text: string) => {
    if (!soundEnabled) return;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ko-KR';
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Navigation logic
  const handleSelectStudentStep = (step: StepNumber) => {
    setCurrentViewStep(step);
    setCurrentStudentStep(step);
    setIsTeacherPreview(false);
  };

  const handleTeacherJumpStep = (step: StepNumber) => {
    setCurrentViewStep(step);
    setIsTeacherPreview(true);
  };

  const handleExitTeacherPreview = () => {
    setCurrentViewStep(currentStudentStep);
    setIsTeacherPreview(false);
  };

  const handleNextStep = () => {
    if (isTeacherPreview) {
      const next = Math.min(9, currentViewStep + 1) as StepNumber;
      setCurrentViewStep(next);
    } else {
      setCompletedSteps((prev) => new Set([...prev, currentViewStep]));
      const next = Math.min(9, currentViewStep + 1) as StepNumber;
      setHighestCompletedStep((prev) => Math.max(prev, next) as StepNumber);
      setCurrentStudentStep(next);
      setCurrentViewStep(next);
      setIsTeacherPreview(false);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectStep8PermissionStatus = (status: 'allowed' | 'denied' | 'unchecked' | null) => {
    if (isTeacherPreview) return;
    setStep8PermissionStatus(status);
    setStep8DiscussedNoPostReason(false);
    setStep8AttachedCards([]);
    setStep8ShowPostResult(false);
    setStep8DiscussedCardReason(false);
    setStep8Blank1('');
    setStep8Blank2('');
    setStep8Blank3('');
    setStep8Blank4('');
    setStep8DiscussedCriteria(false);
    setStep8ShowCriteriaResult(false);
  };

  const handleReset = () => {
    setCurrentViewStep(1);
    setCurrentStudentStep(1);
    setHighestCompletedStep(1);
    setCompletedSteps(new Set());
    setIsTeacherPreview(false);

    setStep1Finished(false);

    setStep2SelectedRole(null);
    setStep2Prepared(false);

    setStep3RoleplayFinished(false);

    setStep4Answers({ q1: null, q2: null, q3: null });
    setStep4Discussed(false);
    setStep4ShowResults(false);

    setStep5CreatorEmotions([]);
    setStep5UserEmotions([]);
    setStep5Said(false);
    setStep5Discussed(false);

    setStep6SelectedChoice(null);
    setStep6DiscussedChoiceReason(false);
    setStep6ShowReactions(false);
    setStep6IsPrepFinished(false);
    setStep6IsRoleplayFinished(false);

    setStep7Discussed(false);
    setStep7ShowResult(false);

    setStep8PermissionStatus(null);
    setStep8DiscussedNoPostReason(false);
    setStep8AttachedCards([]);
    setStep8DiscussedCardReason(false);
    setStep8ShowPostResult(false);
    setStep8Blank1('');
    setStep8Blank2('');
    setStep8Blank3('');
    setStep8Blank4('');
    setStep8DiscussedCriteria(false);
    setStep8ShowCriteriaResult(false);

    setStep9SelectedChoiceId(null);
    setStep9Discussed(false);
    setStep9ShowOutcome(false);
    setStep9FollowupText('');
    setStep9DiscussedFollowup(false);
    setStep9ShowFollowupExample(false);
    setStep9Learned('');
    setStep9Felt('');
    setStep9Action('');
    setStep9CustomSentence('');

    speakText('처음부터 다시 시작합니다.');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Step 8 Card Toggle Helper
  const handleToggleStep8Card = (cardId: string) => {
    setStep8ShowPostResult(false);
    setStep8DiscussedCardReason(false);

    if (cardId === 'dont_post') {
      setStep8AttachedCards(['dont_post']);
      speakText('허락받지 못해 게시하지 않는 카드를 선택했습니다.');
      return;
    }

    setStep8AttachedCards((prev) => {
      const filtered = prev.filter((item) => item !== 'dont_post');
      if (filtered.includes(cardId)) {
        return filtered.filter((item) => item !== cardId);
      } else {
        return [...filtered, cardId];
      }
    });
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-800 pb-16">
      <Header
        currentViewStep={currentViewStep}
        highestCompletedStep={highestCompletedStep}
        completedSteps={completedSteps}
        isTeacherPreview={isTeacherPreview}
        onSelectStudentStep={handleSelectStudentStep}
        onTeacherJumpStep={handleTeacherJumpStep}
        onExitTeacherPreview={handleExitTeacherPreview}
        onReset={handleReset}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
      />

      <main className="max-w-5xl mx-auto px-4 sm:px-6 pt-6">
        {isTeacherPreview && (
          <div className="bg-amber-500 text-amber-950 font-black px-4 py-3 rounded-2xl mb-6 text-center border-2 border-amber-600 shadow-md text-xs sm:text-sm animate-fadeIn no-print flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 mx-auto">
              <span>👩‍🏫</span>
              <span>교사용 미리 보기: 학생의 활동 기록은 변경되지 않습니다.</span>
            </div>
            <button
              onClick={handleExitTeacherPreview}
              className="px-3 py-1 bg-amber-950 text-white rounded-xl text-xs font-bold hover:bg-black transition cursor-pointer"
            >
              미리 보기 종료
            </button>
          </div>
        )}
        {currentViewStep === 1 && (
          <Step1Scenario
            scenario={SCENARIO_1}
            finished={step1Finished}
            onToggleFinished={setStep1Finished}
            onNext={handleNextStep}
            speakText={speakText}
            readOnly={isTeacherPreview}
          />
        )}

        {currentViewStep === 2 && (
          <Step2RoleSelect
            scenario={SCENARIO_1}
            selectedRole={step2SelectedRole}
            isPrepared={step2Prepared}
            onSelectRole={setStep2SelectedRole}
            onTogglePrepared={setStep2Prepared}
            onNext={handleNextStep}
            speakText={speakText}
            readOnly={isTeacherPreview}
          />
        )}

        {currentViewStep === 3 && (
          <Step3ProblemRoleplay
            scenario={SCENARIO_1}
            roleplayFinished={step3RoleplayFinished}
            onToggleRoleplayFinished={setStep3RoleplayFinished}
            onNext={handleNextStep}
            speakText={speakText}
            readOnly={isTeacherPreview}
          />
        )}

        {currentViewStep === 4 && (
          <Step4CopyrightCheck
            scenario={SCENARIO_1}
            answers={step4Answers}
            discussed={step4Discussed}
            showResults={step4ShowResults}
            onUpdateAnswer={(qKey: 'q1' | 'q2' | 'q3', val: OptionChoice) =>
              setStep4Answers((prev) => ({ ...prev, [qKey]: val }))
            }
            onToggleDiscussed={setStep4Discussed}
            onShowResults={setStep4ShowResults}
            onNext={handleNextStep}
            speakText={speakText}
            readOnly={isTeacherPreview}
          />
        )}

        {currentViewStep === 5 && (
          <Step5RoleSwitch
            scenario={SCENARIO_1}
            creatorEmotions={step5CreatorEmotions}
            userEmotions={step5UserEmotions}
            said={step5Said}
            discussed={step5Discussed}
            onToggleCreatorEmotion={(emotion) =>
              setStep5CreatorEmotions((prev) =>
                prev.includes(emotion) ? prev.filter((e) => e !== emotion) : [...prev, emotion]
              )
            }
            onToggleUserEmotion={(emotion) =>
              setStep5UserEmotions((prev) =>
                prev.includes(emotion) ? prev.filter((e) => e !== emotion) : [...prev, emotion]
              )
            }
            onToggleSaid={setStep5Said}
            onToggleDiscussed={setStep5Discussed}
            onNext={handleNextStep}
            speakText={speakText}
            readOnly={isTeacherPreview}
          />
        )}

        {currentViewStep === 6 && (
          <Step6SolutionRoleplay
            scenario={SCENARIO_1}
            selectedChoice={step6SelectedChoice}
            discussedChoiceReason={step6DiscussedChoiceReason}
            showReactions={step6ShowReactions}
            isPrepFinished={step6IsPrepFinished}
            isRoleplayFinished={step6IsRoleplayFinished}
            onSelectChoice={(id) => {
              setStep6SelectedChoice(id);
              setStep6ShowReactions(false);
              setStep6DiscussedChoiceReason(false);
            }}
            onToggleDiscussedChoiceReason={setStep6DiscussedChoiceReason}
            onToggleShowReactions={setStep6ShowReactions}
            onTogglePrepFinished={setStep6IsPrepFinished}
            onToggleRoleplayFinished={setStep6IsRoleplayFinished}
            onResetChoice={() => {
              setStep6SelectedChoice(null);
              setStep6ShowReactions(false);
              setStep6DiscussedChoiceReason(false);
            }}
            onNext={handleNextStep}
            speakText={speakText}
            readOnly={isTeacherPreview}
          />
        )}

        {currentViewStep === 7 && (
          <Step7Comparison
            scenario={SCENARIO_1}
            discussed={step7Discussed}
            showResult={step7ShowResult}
            onToggleDiscussed={setStep7Discussed}
            onShowResult={setStep7ShowResult}
            onNext={handleNextStep}
            speakText={speakText}
            readOnly={isTeacherPreview}
          />
        )}

        {currentViewStep === 8 && (
          <Step8PostFixer
            scenario={SCENARIO_1}
            permissionStatus={step8PermissionStatus}
            discussedNoPostReason={step8DiscussedNoPostReason}
            attachedCards={step8AttachedCards}
            discussedCardReason={step8DiscussedCardReason}
            showPostResult={step8ShowPostResult}
            blank1={step8Blank1}
            blank2={step8Blank2}
            blank3={step8Blank3}
            blank4={step8Blank4}
            discussedCriteria={step8DiscussedCriteria}
            showCriteriaResult={step8ShowCriteriaResult}
            onSelectPermissionStatus={handleSelectStep8PermissionStatus}
            onToggleDiscussedNoPostReason={setStep8DiscussedNoPostReason}
            onToggleCard={handleToggleStep8Card}
            onResetCards={() => {
              setStep8AttachedCards([]);
              setStep8ShowPostResult(false);
              setStep8DiscussedCardReason(false);
            }}
            onToggleDiscussedCardReason={setStep8DiscussedCardReason}
            onToggleShowPostResult={setStep8ShowPostResult}
            onUpdateBlank={(key, val) => {
              if (key === 'blank1') setStep8Blank1(val);
              if (key === 'blank2') setStep8Blank2(val);
              if (key === 'blank3') setStep8Blank3(val);
              if (key === 'blank4') setStep8Blank4(val);
            }}
            onToggleDiscussedCriteria={setStep8DiscussedCriteria}
            onToggleShowCriteriaResult={setStep8ShowCriteriaResult}
            onNext={handleNextStep}
            speakText={speakText}
            readOnly={isTeacherPreview}
          />
        )}

        {currentViewStep === 9 && (
          <Step9Reflection
            selectedChoiceId={step9SelectedChoiceId}
            discussed={step9Discussed}
            showOutcome={step9ShowOutcome}
            learned={step9Learned}
            felt={step9Felt}
            action={step9Action}
            customSentence={step9CustomSentence}
            followupText={step9FollowupText}
            discussedFollowup={step9DiscussedFollowup}
            showFollowupExample={step9ShowFollowupExample}
            onSelectChoice={(id) => {
              setStep9SelectedChoiceId(id);
              setStep9ShowOutcome(false);
              setStep9Discussed(false);
            }}
            onToggleDiscussed={setStep9Discussed}
            onToggleShowOutcome={setStep9ShowOutcome}
            onUpdateField={(field, val) => {
              if (field === 'learned') setStep9Learned(val);
              if (field === 'felt') setStep9Felt(val);
              if (field === 'action') setStep9Action(val);
              if (field === 'customSentence') setStep9CustomSentence(val);
            }}
            onUpdateFollowupText={setStep9FollowupText}
            onToggleDiscussedFollowup={setStep9DiscussedFollowup}
            onToggleShowFollowupExample={setStep9ShowFollowupExample}
            onReset={handleReset}
            speakText={speakText}
            readOnly={isTeacherPreview}
          />
        )}
      </main>
    </div>
  );
};

export default App;
