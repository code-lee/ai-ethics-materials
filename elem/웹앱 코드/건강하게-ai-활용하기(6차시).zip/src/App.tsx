/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  StepId,
  AppState,
  INITIAL_STATE,
  INITIAL_GROUP_CHECKS,
  Activity1State,
  Activity2State,
  Activity3State,
  PromiseState,
  ReflectionState,
} from './types';
import { Header } from './components/Header';
import { ProgressStepper } from './components/ProgressStepper';
import { StartScreen } from './components/StartScreen';
import { Activity1Screen } from './components/Activity1Screen';
import { Activity2Screen } from './components/Activity2Screen';
import { Activity3Screen } from './components/Activity3Screen';
import { PromiseScreen } from './components/PromiseScreen';
import { ReflectionScreen } from './components/ReflectionScreen';
import { CompletionModal } from './components/CompletionModal';

const STORAGE_KEY = 'healthy_ai_ethics_lesson_data_v4';

export default function App() {
  const [appState, setAppState] = useState<AppState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('healthy_ai_ethics_lesson_data_v3');
      if (saved) {
        const parsed = JSON.parse(saved);
        const migratedGroupChecks = parsed.activity3?.groupChecks || {
          thinking: parsed.activity3?.check1?.thinking || '',
          control: parsed.activity3?.check1?.control || '',
          balance: parsed.activity3?.check1?.balance || '',
        };

        return {
          ...INITIAL_STATE,
          ...parsed,
          startThought: parsed.startThought ?? '',
          activity1: { ...INITIAL_STATE.activity1, ...(parsed.activity1 || {}) },
          activity2: { ...INITIAL_STATE.activity2, ...(parsed.activity2 || {}) },
          activity3: {
            ...INITIAL_STATE.activity3,
            ...(parsed.activity3 || {}),
            groupChecks: { ...INITIAL_GROUP_CHECKS, ...migratedGroupChecks },
            groupNeedsRevision: parsed.activity3?.groupNeedsRevision ?? false,
          },
          promise: {
            ...INITIAL_STATE.promise,
            ...(parsed.promise || {}),
            timeRule: parsed.promise?.timeRule ?? parsed.activity3?.timeRule ?? '',
            stopRule: parsed.promise?.stopRule ?? parsed.activity3?.stopRule ?? '',
            firstActionRule: parsed.promise?.firstActionRule ?? parsed.activity3?.firstActionRule ?? '',
            selfCheckFeasible: parsed.promise?.selfCheckFeasible ?? '',
            selfCheckBalance: parsed.promise?.selfCheckBalance ?? '',
          },
          reflection: { ...INITIAL_STATE.reflection, ...(parsed.reflection || {}) },
        };
      }
    } catch (e) {
      console.error('Failed to load saved state from localStorage:', e);
    }
    return INITIAL_STATE;
  });

  const [showCompletionModal, setShowCompletionModal] = useState(false);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
    } catch (e) {
      console.error('Failed to save state to localStorage:', e);
    }
  }, [appState]);

  // Step Navigation Helper
  const goToStep = (targetStep: StepId) => {
    setAppState((prev) => ({
      ...prev,
      currentStep: targetStep,
    }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const markStepCompleteAndProceed = (currentStep: StepId, nextStep: StepId) => {
    setAppState((prev) => {
      const updatedCompleted = prev.completedSteps.includes(currentStep)
        ? prev.completedSteps
        : [...prev.completedSteps, currentStep];

      return {
        ...prev,
        completedSteps: updatedCompleted,
        currentStep: nextStep,
      };
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // State Update Handlers
  const updateStartThought = (thought: string) => {
    setAppState((prev) => ({
      ...prev,
      startThought: thought,
    }));
  };

  const updateActivity1 = (updated: Partial<Activity1State>) => {
    setAppState((prev) => ({
      ...prev,
      activity1: { ...prev.activity1, ...updated },
    }));
  };

  const updateActivity2 = (updated: Partial<Activity2State>) => {
    setAppState((prev) => {
      const nextActivity2 = { ...prev.activity2, ...updated };
      let nextCompletedSteps = prev.completedSteps;
      let nextIsCompleted = prev.isCompleted;

      // If summaryCompleted is explicitly set to false
      if (updated.summaryCompleted === false || nextActivity2.summaryCompleted === false) {
        nextCompletedSteps = prev.completedSteps.filter(
          (s) => s !== 'activity2' && s !== 'activity3' && s !== 'promise' && s !== 'reflection'
        );
        nextIsCompleted = false;
      }

      return {
        ...prev,
        activity2: nextActivity2,
        completedSteps: nextCompletedSteps,
        isCompleted: nextIsCompleted,
      };
    });
  };

  const updateActivity3 = (updated: Partial<Activity3State>) => {
    setAppState((prev) => {
      const nextActivity3 = { ...prev.activity3, ...updated };
      let nextCompletedSteps = prev.completedSteps;
      let nextIsCompleted = prev.isCompleted;

      // If method, checks, or groupNeedsRevision changed, invalidate activity3 and subsequent completions if invalid
      if (
        updated.method1 !== undefined ||
        updated.method2 !== undefined ||
        updated.method3 !== undefined ||
        updated.groupChecks !== undefined ||
        updated.groupNeedsRevision !== undefined
      ) {
        const isMethodsFilled =
          nextActivity3.method1.trim().length > 0 &&
          nextActivity3.method2.trim().length > 0 &&
          nextActivity3.method3.trim().length > 0;
        const checks = nextActivity3.groupChecks;
        const areAllYes =
          checks.thinking === 'yes' &&
          checks.control === 'yes' &&
          checks.balance === 'yes';
        const canComplete = isMethodsFilled && areAllYes && !nextActivity3.groupNeedsRevision;

        if (!canComplete) {
          nextCompletedSteps = prev.completedSteps.filter(
            (s) => s !== 'activity3' && s !== 'promise' && s !== 'reflection'
          );
          nextIsCompleted = false;
        }
      }

      return {
        ...prev,
        activity3: nextActivity3,
        completedSteps: nextCompletedSteps,
        isCompleted: nextIsCompleted,
      };
    });
  };

  const updatePromise = (updated: Partial<PromiseState>) => {
    setAppState((prev) => {
      const newPromise = { ...prev.promise, ...updated };
      let newPreferredText = newPromise.preferredRuleText;
      let newPriorityRule = newPromise.priorityRule;

      if (newPromise.preferredRuleType === 'time') {
        newPreferredText = newPromise.timeRule;
        newPriorityRule = newPromise.timeRule;
      } else if (newPromise.preferredRuleType === 'stop') {
        newPreferredText = newPromise.stopRule;
        newPriorityRule = newPromise.stopRule;
      } else if (newPromise.preferredRuleType === 'first') {
        newPreferredText = newPromise.firstActionRule;
        newPriorityRule = newPromise.firstActionRule;
      }

      const isRulesComplete =
        newPromise.timeRule.trim().length > 0 &&
        newPromise.stopRule.trim().length > 0 &&
        newPromise.firstActionRule.trim().length > 0 &&
        newPromise.selfCheckFeasible === 'yes' &&
        newPromise.selfCheckBalance === 'yes';

      const isPlanComplete =
        Boolean(newPromise.preferredRuleType) &&
        newPromise.startDate.trim().length > 0 &&
        newPromise.difficultyStrategy.trim().length > 0;

      let nextCompletedSteps = prev.completedSteps;
      let nextIsCompleted = prev.isCompleted;

      if (!isRulesComplete || !isPlanComplete) {
        nextCompletedSteps = prev.completedSteps.filter(
          (s) => s !== 'promise' && s !== 'reflection'
        );
        nextIsCompleted = false;
      }

      return {
        ...prev,
        promise: {
          ...newPromise,
          preferredRuleText: newPreferredText,
          priorityRule: newPriorityRule,
        },
        completedSteps: nextCompletedSteps,
        isCompleted: nextIsCompleted,
      };
    });
  };

  const updateReflection = (updated: Partial<ReflectionState>) => {
    setAppState((prev) => ({
      ...prev,
      reflection: { ...prev.reflection, ...updated },
    }));
  };

  const handleReset = () => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem('healthy_ai_ethics_lesson_data_v3');
    setAppState(INITIAL_STATE);
    setShowCompletionModal(false);
    setConfirmResetOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCompleteAll = () => {
    setAppState((prev) => {
      const updatedCompleted: StepId[] = prev.completedSteps.includes('reflection')
        ? prev.completedSteps
        : [...prev.completedSteps, 'reflection'];
      return {
        ...prev,
        completedSteps: updatedCompleted,
        isCompleted: true,
      };
    });
    setShowCompletionModal(true);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col font-sans">
      {/* Header */}
      <Header
        onReset={() => setConfirmResetOpen(true)}
        showResetButton={appState.completedSteps.length > 0 || appState.currentStep !== 'start'}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-10">
        {/* Progress Stepper */}
        <ProgressStepper
          currentStep={appState.currentStep}
          completedSteps={appState.completedSteps}
          onStepClick={goToStep}
        />

        {/* Dynamic Screen View */}
        <div className="mt-4 sm:mt-6">
          {appState.currentStep === 'start' && (
            <StartScreen
              startThought={appState.startThought}
              onChangeStartThought={updateStartThought}
              onStart={() => markStepCompleteAndProceed('start', 'activity1')}
            />
          )}

          {appState.currentStep === 'activity1' && (
            <Activity1Screen
              data={appState.activity1}
              onChange={updateActivity1}
              onNext={() => markStepCompleteAndProceed('activity1', 'activity2')}
            />
          )}

          {appState.currentStep === 'activity2' && (
            <Activity2Screen
              data={appState.activity2}
              onChange={updateActivity2}
              onNext={() => markStepCompleteAndProceed('activity2', 'activity3')}
            />
          )}

          {appState.currentStep === 'activity3' && (
            <Activity3Screen
              data={appState.activity3}
              onChange={updateActivity3}
              onNext={() => markStepCompleteAndProceed('activity3', 'promise')}
            />
          )}

          {appState.currentStep === 'promise' && (
            <PromiseScreen
              groupMethods={appState.activity3}
              promise={appState.promise}
              onChange={updatePromise}
              onNext={() => markStepCompleteAndProceed('promise', 'reflection')}
            />
          )}

          {appState.currentStep === 'reflection' && (
            <ReflectionScreen
              startThought={appState.startThought}
              data={appState.reflection}
              onChange={updateReflection}
              onComplete={handleCompleteAll}
            />
          )}
        </div>
      </main>

      {/* Reset Confirmation Dialog */}
      {confirmResetOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border-2 border-slate-200 space-y-5">
            <h3 className="text-xl font-bold text-slate-900">
              처음부터 다시 시작할까요?
            </h3>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              지금까지 작성한 모든 내용이 초기화되고 첫 화면으로 돌아갑니다. 다시 시작하시겠습니까?
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setConfirmResetOpen(false)}
                className="px-5 py-2.5 rounded-full font-bold text-slate-600 hover:bg-slate-100 text-sm transition-colors cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleReset}
                className="px-5 py-2.5 rounded-full font-bold bg-rose-600 hover:bg-rose-700 text-white text-sm transition-colors shadow-xs cursor-pointer"
              >
                다시 시작하기
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Completion Modal */}
      {showCompletionModal && (
        <CompletionModal
          appState={appState}
          onClose={() => setShowCompletionModal(false)}
          onReset={handleReset}
        />
      )}
    </div>
  );
}
