export type StepId = 'start' | 'activity1' | 'activity2' | 'activity3' | 'promise' | 'reflection';

export interface Activity1State {
  whenList: string[];
  customWhen: string;
  purposeList: string[];
  customPurpose: string;
  canStopSelf: 'easy' | 'depends' | 'hard' | '';
  maintainOrRegulate: string;
}

export interface Activity2State {
  currentStage: number; // 0: Comparison 1, 1: Comparison 2, 2: Comparison 3, 3: Summary
  comp1SelectedA: number[];
  comp1SelectedB: number[];
  comp1Thought: string;
  comp1ViewingDiff: boolean;
  comp1Completed: boolean;
  comp2SelectedA: number[];
  comp2SelectedB: number[];
  comp2Thought: string;
  comp2ViewingDiff: boolean;
  comp2Completed: boolean;
  comp3SelectedA: number[];
  comp3SelectedB: number[];
  comp3Thought: string;
  comp3ViewingDiff: boolean;
  comp3Completed: boolean;
  summaryThought: string; // Student's own synthesis sentence at the end of Activity 2
  summaryCompleted: boolean;
}

export interface GroupCheckState {
  thinking: 'yes' | 'rethink' | '';
  control: 'yes' | 'rethink' | '';
  balance: 'yes' | 'rethink' | '';
}

export interface Activity3State {
  method1: string;
  method2: string;
  method3: string;
  groupChecks: GroupCheckState;
  groupNeedsRevision: boolean;
}

export interface PromiseState {
  // 개인 규칙 3가지 (생활 속 적용 1단계)
  timeRule: string;
  stopRule: string;
  firstActionRule: string;
  selfCheckFeasible: 'yes' | 'rethink' | '';
  selfCheckBalance: 'yes' | 'rethink' | '';
  // 실천 계획 (생활 속 적용 2단계)
  priorityRule?: string;
  preferredRuleType?: 'time' | 'stop' | 'first' | '';
  preferredRuleText?: string;
  startDate: string;
  difficultyStrategy: string;
}

export interface ReflectionState {
  thoughtChange: string; // 수업 시작 때의 생각과 지금 생각의 변화
  selfDiscovery: string; // 나의 AI 사용 습관에서 새롭게 발견한 점
}

export interface AppState {
  currentStep: StepId;
  completedSteps: StepId[];
  startThought: string;
  activity1: Activity1State;
  activity2: Activity2State;
  activity3: Activity3State;
  promise: PromiseState;
  reflection: ReflectionState;
  isCompleted: boolean;
}

export const INITIAL_GROUP_CHECKS: GroupCheckState = {
  thinking: '',
  control: '',
  balance: '',
};

export const INITIAL_STATE: AppState = {
  currentStep: 'start',
  completedSteps: [],
  startThought: '',
  activity1: {
    whenList: [],
    customWhen: '',
    purposeList: [],
    customPurpose: '',
    canStopSelf: '',
    maintainOrRegulate: '',
  },
  activity2: {
    currentStage: 0,
    comp1SelectedA: [],
    comp1SelectedB: [],
    comp1Thought: '',
    comp1ViewingDiff: false,
    comp1Completed: false,
    comp2SelectedA: [],
    comp2SelectedB: [],
    comp2Thought: '',
    comp2ViewingDiff: false,
    comp2Completed: false,
    comp3SelectedA: [],
    comp3SelectedB: [],
    comp3Thought: '',
    comp3ViewingDiff: false,
    comp3Completed: false,
    summaryThought: '',
    summaryCompleted: false,
  },
  activity3: {
    method1: '',
    method2: '',
    method3: '',
    groupChecks: { ...INITIAL_GROUP_CHECKS },
    groupNeedsRevision: false,
  },
  promise: {
    timeRule: '',
    stopRule: '',
    firstActionRule: '',
    selfCheckFeasible: '',
    selfCheckBalance: '',
    priorityRule: '',
    preferredRuleType: '',
    preferredRuleText: '',
    startDate: '',
    difficultyStrategy: '',
  },
  reflection: {
    thoughtChange: '',
    selfDiscovery: '',
  },
  isCompleted: false,
};

export const STEPS_META: { id: StepId; label: string; stepNumber: number }[] = [
  { id: 'start', label: '시작', stepNumber: 1 },
  { id: 'activity1', label: '활동1', stepNumber: 2 },
  { id: 'activity2', label: '활동2', stepNumber: 3 },
  { id: 'activity3', label: '활동3', stepNumber: 4 },
  { id: 'promise', label: '생활 속 적용', stepNumber: 5 },
  { id: 'reflection', label: '돌아보기', stepNumber: 6 },
];
