import React from 'react';
import { Sparkles, RotateCcw } from 'lucide-react';

interface HeaderProps {
  onReset: () => void;
  showResetButton?: boolean;
}

export const Header: React.FC<HeaderProps> = ({ onReset, showResetButton = true }) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between">
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700 border border-amber-300">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#705d00] sm:text-[#554600]">
              건강하게 AI 활용하기
            </h1>
            <p className="text-xs text-slate-500 hidden sm:block">초등학교 5~6학년 AI 윤리 수업</p>
          </div>
        </div>

        {showResetButton && (
          <button
            onClick={onReset}
            title="처음부터 다시 시작하기"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>처음부터 다시 하기</span>
          </button>
        )}
      </div>
    </header>
  );
};
