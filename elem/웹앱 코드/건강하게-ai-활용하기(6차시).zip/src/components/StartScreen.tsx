import React from 'react';
import { HelpCircle, ArrowRight, MessageSquareQuote, PenLine } from 'lucide-react';

interface StartScreenProps {
  startThought: string;
  onChangeStartThought: (thought: string) => void;
  onStart: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  startThought,
  onChangeStartThought,
  onStart,
}) => {
  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Main Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 border-2 border-slate-200/80 shadow-xs space-y-6 sm:space-y-8">
        {/* Stage Badge & Title */}
        <div className="text-center space-y-3">
          <span className="inline-block px-3.5 py-1 bg-amber-400 text-slate-900 font-bold text-xs sm:text-sm rounded-full shadow-xs whitespace-nowrap">
            시작
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight break-keep">
            AI를 많이 사용하면 무조건 문제가 될까요?
          </h2>
        </div>

        {/* Thought Bubbles */}
        <div className="space-y-4">
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-5 sm:p-6 text-slate-800 font-medium text-base sm:text-lg flex items-start gap-3">
            <MessageSquareQuote className="w-6 h-6 text-slate-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed break-keep">
              &ldquo;AI는 편리하니까 많이 사용해도 괜찮지 않을까?&rdquo;
            </p>
          </div>

          <div className="bg-amber-50/70 border-2 border-amber-300 rounded-2xl p-5 sm:p-6 text-slate-900 font-medium text-base sm:text-lg flex items-start gap-3">
            <MessageSquareQuote className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed break-keep">
              &ldquo;AI를 얼마나, 어떻게 사용하는지는 왜 중요할까?&rdquo;
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-5 sm:p-6 flex items-center justify-center gap-2.5 text-center">
            <HelpCircle className="w-6 h-6 text-[#705d00] shrink-0" />
            <span className="text-[#705d00] font-bold text-lg sm:text-xl break-keep">
              여러분은 어떻게 생각하나요?
            </span>
          </div>
        </div>

        {/* Student's Initial Thought Input */}
        <div className="bg-slate-50/80 border-2 border-slate-200 rounded-2xl p-5 sm:p-6 space-y-3">
          <div className="flex items-center gap-2">
            <PenLine className="w-4 h-4 text-amber-600 shrink-0" />
            <h3 className="font-bold text-slate-900 text-base sm:text-lg break-keep">
              지금 나의 생각
            </h3>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 font-medium break-keep">
            AI를 많이 사용하는 것에 대한 지금의 생각을 한 문장으로 적어 보세요.
          </p>
          <textarea
            rows={2}
            value={startThought}
            onChange={(e) => onChangeStartThought(e.target.value)}
            placeholder="지금 떠오르는 생각을 적어 보세요."
            className="w-full p-3.5 rounded-xl border-2 border-slate-200 bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-none placeholder:text-slate-400 break-keep leading-relaxed"
          />
        </div>
      </div>

      {/* Learning Question Box */}
      <div className="bg-blue-50/80 border border-blue-200 rounded-3xl p-6 sm:p-8 text-center space-y-2">
        <span className="text-blue-700 font-bold text-xs sm:text-sm tracking-wider block whitespace-nowrap">
          학습 문제
        </span>
        <p className="text-slate-900 font-extrabold text-lg sm:text-xl leading-relaxed break-keep">
          &ldquo;AI를 스스로 조절하며 건강하게 활용하는 방법을 알아봅시다.&rdquo;
        </p>
      </div>

      {/* Start Button */}
      <div className="flex justify-center pt-2">
        <button
          type="button"
          disabled={!startThought || startThought.trim().length === 0}
          onClick={onStart}
          className={`w-full sm:w-auto min-w-[240px] px-8 py-4 text-lg sm:text-xl font-extrabold rounded-full shadow-md transition-all duration-200 flex items-center justify-center gap-2 whitespace-nowrap ${
            startThought && startThought.trim().length > 0
              ? 'bg-[#ffd700] hover:bg-[#fed100] active:translate-y-0.5 text-slate-900 cursor-pointer hover:shadow-lg border-b-4 border-[#cca700]'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed border-b-4 border-slate-300'
          }`}
        >
          <span className="whitespace-nowrap">활동 시작하기</span>
          <ArrowRight className="w-5 h-5 shrink-0" />
        </button>
      </div>
    </div>
  );
};
