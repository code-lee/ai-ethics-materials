import React, { useState, useRef } from 'react';
import {
  Edit,
  HelpCircle,
  Clock,
  Square,
  UserCheck,
  CheckCircle,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  ClipboardCheck,
  Sparkles,
  FileText,
  Users,
} from 'lucide-react';
import { Activity3State, PromiseState } from '../types';

interface PromiseScreenProps {
  groupMethods?: Activity3State;
  promise: PromiseState;
  onChange: (updated: Partial<PromiseState>) => void;
  onNext: () => void;
}

export const PromiseScreen: React.FC<PromiseScreenProps> = ({
  groupMethods,
  promise,
  onChange,
  onNext,
}) => {
  const [showHelpTime, setShowHelpTime] = useState(false);
  const [showHelpStop, setShowHelpStop] = useState(false);
  const [showHelpFirst, setShowHelpFirst] = useState(false);
  const [showGroupRef, setShowGroupRef] = useState(false);

  const personalRulesRef = useRef<HTMLDivElement>(null);

  const handleRethink = () => {
    personalRulesRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Rule text change resets self checks and updates preferred text if currently selected
  const handleRuleChange = (
    field: 'timeRule' | 'stopRule' | 'firstActionRule',
    value: string
  ) => {
    const updatePayload: Partial<PromiseState> = {
      [field]: value,
      selfCheckFeasible: '',
      selfCheckBalance: '',
    };

    if (
      (field === 'timeRule' && promise.preferredRuleType === 'time') ||
      (field === 'stopRule' && promise.preferredRuleType === 'stop') ||
      (field === 'firstActionRule' && promise.preferredRuleType === 'first')
    ) {
      updatePayload.preferredRuleText = value;
      updatePayload.priorityRule = value;
    }

    onChange(updatePayload);
  };

  const isRulesComplete =
    promise.timeRule.trim().length > 0 &&
    promise.stopRule.trim().length > 0 &&
    promise.firstActionRule.trim().length > 0 &&
    promise.selfCheckFeasible === 'yes' &&
    promise.selfCheckBalance === 'yes';

  const isPlanComplete =
    Boolean(promise.preferredRuleType) &&
    promise.startDate.trim().length > 0 &&
    promise.difficultyStrategy.trim().length > 0;

  const isFormComplete = isRulesComplete && isPlanComplete;

  return (
    <div className="w-full max-w-3xl mx-auto space-y-8 animate-fadeIn pb-12">
      {/* Header Info */}
      <div className="text-center space-y-3">
        <span className="inline-block px-3.5 py-1 bg-amber-400 text-slate-900 font-bold text-xs sm:text-sm rounded-full shadow-xs whitespace-nowrap">
          생활 속 적용
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 break-keep">
          나에게 맞는 AI 사용 규칙 정하기
        </h2>
        <p className="text-slate-600 text-base sm:text-lg break-keep leading-relaxed max-w-2xl mx-auto">
          지금까지 한 활동을 떠올리며, 나에게 맞는 AI 사용 규칙을 정해 봅시다.
        </p>
      </div>

      {/* Reference: 우리 모둠이 나눈 방법 참고 아코디언 */}
      {groupMethods && (groupMethods.method1 || groupMethods.method2 || groupMethods.method3) && (
        <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-4 sm:p-5 text-blue-900 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-sm sm:text-base">
              <Users className="w-4 h-4 text-blue-600 shrink-0" />
              <span>활동3에서 우리 모둠이 나눈 생각 참고하기</span>
            </div>
            <button
              type="button"
              onClick={() => setShowGroupRef(!showGroupRef)}
              className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 bg-white/80 hover:bg-white px-2.5 py-1 rounded-full border border-blue-200 transition-colors cursor-pointer"
            >
              <span>{showGroupRef ? '접기' : '모둠 생각 보기'}</span>
              {showGroupRef ? (
                <ChevronUp className="w-3.5 h-3.5 shrink-0" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 shrink-0" />
              )}
            </button>
          </div>

          {showGroupRef && (
            <div className="space-y-2 pt-2 border-t border-blue-200/80 animate-fadeIn">
              <p className="text-xs text-blue-700 mb-2">
                * 모둠의 생각을 참고하여, 내 생활에 맞는 AI 사용 규칙을 정해 보세요.
              </p>
              <div className="grid grid-cols-1 gap-2 text-xs sm:text-sm">
                {groupMethods.method1 && (
                  <div className="bg-white p-3 rounded-xl border border-blue-100 font-medium">
                    <span className="font-bold text-blue-900 mr-2">모둠 방법 1:</span>
                    {groupMethods.method1}
                  </div>
                )}
                {groupMethods.method2 && (
                  <div className="bg-white p-3 rounded-xl border border-blue-100 font-medium">
                    <span className="font-bold text-blue-900 mr-2">모둠 방법 2:</span>
                    {groupMethods.method2}
                  </div>
                )}
                {groupMethods.method3 && (
                  <div className="bg-white p-3 rounded-xl border border-blue-100 font-medium">
                    <span className="font-bold text-blue-900 mr-2">모둠 방법 3:</span>
                    {groupMethods.method3}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Section 1: 나의 AI 사용 규칙 정하기 */}
      <div
        ref={personalRulesRef}
        className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-6"
      >
        <div className="flex items-center gap-2.5 text-amber-800 font-extrabold text-xl pb-2 border-b border-slate-100">
          <Edit className="w-6 h-6 text-amber-600 shrink-0" />
          <h3 className="break-keep">1. 나의 AI 사용 규칙 정하기</h3>
        </div>

        {/* 1. AI를 언제, 얼마나 사용할지 */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 font-bold text-base sm:text-lg text-slate-900 break-keep">
              <Clock className="w-5 h-5 text-amber-600 shrink-0" />
              <span>AI를 언제, 얼마나 사용할지</span>
            </label>
            <button
              type="button"
              onClick={() => setShowHelpTime(!showHelpTime)}
              className="inline-flex items-center gap-1 text-xs sm:text-sm font-semibold text-amber-700 hover:text-amber-900 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-full transition-colors border border-amber-200 whitespace-nowrap cursor-pointer"
            >
              <HelpCircle className="w-4 h-4 shrink-0" />
              <span>{showHelpTime ? '도움말 닫기' : '도움말 보기'}</span>
              {showHelpTime ? (
                <ChevronUp className="w-3.5 h-3.5 shrink-0" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 shrink-0" />
              )}
            </button>
          </div>

          {showHelpTime && (
            <div className="bg-amber-50/80 border border-amber-300 rounded-xl p-3.5 text-xs sm:text-sm text-slate-800 animate-fadeIn break-keep leading-relaxed">
              <span className="font-bold text-amber-800">예시: </span>
              &ldquo;사용하기 전에 필요한 시간을 정하고 시작하기&rdquo;
            </div>
          )}

          <textarea
            rows={3}
            value={promise.timeRule}
            onChange={(e) => handleRuleChange('timeRule', e.target.value)}
            placeholder="AI를 언제, 얼마나 사용할지 나의 규칙을 적어 보세요."
            className="w-full p-4 rounded-2xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-y placeholder:text-slate-400 break-keep leading-relaxed"
          />
        </div>

        {/* 2. AI 사용을 조절해야 할 때 */}
        <div className="space-y-2 pt-2">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 font-bold text-base sm:text-lg text-slate-900 break-keep">
              <Square className="w-5 h-5 text-amber-600 shrink-0" />
              <span>AI 사용을 조절해야 할 때</span>
            </label>
            <button
              type="button"
              onClick={() => setShowHelpStop(!showHelpStop)}
              className="inline-flex items-center gap-1 text-xs sm:text-sm font-semibold text-amber-700 hover:text-amber-900 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-full transition-colors border border-amber-200 whitespace-nowrap cursor-pointer"
            >
              <HelpCircle className="w-4 h-4 shrink-0" />
              <span>{showHelpStop ? '도움말 닫기' : '도움말 보기'}</span>
              {showHelpStop ? (
                <ChevronUp className="w-3.5 h-3.5 shrink-0" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 shrink-0" />
              )}
            </button>
          </div>

          {showHelpStop && (
            <div className="bg-amber-50/80 border border-amber-300 rounded-xl p-3.5 text-xs sm:text-sm text-slate-800 animate-fadeIn break-keep leading-relaxed">
              <span className="font-bold text-amber-800">예시: </span>
              &ldquo;정해진 시간이 지나면 바로 멈추기&rdquo;, &ldquo;해야 할 일이 밀리지 않게 하기&rdquo;
            </div>
          )}

          <textarea
            rows={3}
            value={promise.stopRule}
            onChange={(e) => handleRuleChange('stopRule', e.target.value)}
            placeholder="AI 사용을 어떻게 조절하고 멈출지 나의 규칙을 적어 보세요."
            className="w-full p-4 rounded-2xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-y placeholder:text-slate-400 break-keep leading-relaxed"
          />
        </div>

        {/* 3. AI를 사용하기 전에 내가 먼저 해 볼 것 */}
        <div className="space-y-2 pt-2">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 font-bold text-base sm:text-lg text-slate-900 break-keep">
              <UserCheck className="w-5 h-5 text-amber-600 shrink-0" />
              <span>AI를 사용하기 전에 내가 먼저 해 볼 것</span>
            </label>
            <button
              type="button"
              onClick={() => setShowHelpFirst(!showHelpFirst)}
              className="inline-flex items-center gap-1 text-xs sm:text-sm font-semibold text-amber-700 hover:text-amber-900 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-full transition-colors border border-amber-200 whitespace-nowrap cursor-pointer"
            >
              <HelpCircle className="w-4 h-4 shrink-0" />
              <span>{showHelpFirst ? '도움말 닫기' : '도움말 보기'}</span>
              {showHelpFirst ? (
                <ChevronUp className="w-3.5 h-3.5 shrink-0" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 shrink-0" />
              )}
            </button>
          </div>

          {showHelpFirst && (
            <div className="bg-amber-50/80 border border-amber-300 rounded-xl p-3.5 text-xs sm:text-sm text-slate-800 animate-fadeIn break-keep leading-relaxed">
              <span className="font-bold text-amber-800">예시: </span>
              &ldquo;AI에게 묻기 전에 내 생각을 먼저 정리해 보기&rdquo;, &ldquo;AI에게 묻기 전에 내가 먼저 해결해 보기&rdquo;
            </div>
          )}

          <textarea
            rows={3}
            value={promise.firstActionRule}
            onChange={(e) => handleRuleChange('firstActionRule', e.target.value)}
            placeholder="AI를 켜기 전에 내가 먼저 해 볼 행동을 적어 보세요."
            className="w-full p-4 rounded-2xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-y placeholder:text-slate-400 break-keep leading-relaxed"
          />
        </div>
      </div>

      {/* Section 2: 나의 규칙 점검하기 (Self-Check) */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center gap-2.5 text-blue-900 font-extrabold text-xl pb-2 border-b border-slate-100">
          <ClipboardCheck className="w-6 h-6 text-blue-600 shrink-0" />
          <h3 className="break-keep">2. 나의 규칙 점검하기</h3>
        </div>

        <p className="text-slate-600 text-sm sm:text-base break-keep leading-relaxed">
          내가 정한 규칙이 나에게 잘 맞는지 스스로 점검해 보세요.
        </p>

        <div className="space-y-6">
          {/* Question 1: 실제로 실천할 수 있는 규칙인가요? */}
          <div className="space-y-3 p-5 rounded-2xl bg-slate-50 border border-slate-200/80">
            <div className="flex items-start gap-2.5">
              <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                1
              </div>
              <h4 className="font-bold text-slate-900 text-base sm:text-lg leading-snug break-keep">
                실제로 실천할 수 있는 규칙인가요?
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <button
                type="button"
                onClick={() => onChange({ selfCheckFeasible: 'yes' })}
                className={`flex items-center justify-center gap-2 p-3.5 rounded-xl border-2 font-bold text-sm sm:text-base transition-all cursor-pointer whitespace-nowrap ${
                  promise.selfCheckFeasible === 'yes'
                    ? 'border-blue-500 bg-blue-50 text-blue-900 shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>네, 실천할 수 있어요</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onChange({ selfCheckFeasible: 'rethink' });
                  handleRethink();
                }}
                className={`flex items-center justify-center gap-2 p-3.5 rounded-xl border-2 font-bold text-sm sm:text-base transition-all cursor-pointer whitespace-nowrap ${
                  promise.selfCheckFeasible === 'rethink'
                    ? 'border-amber-500 bg-amber-50 text-amber-900 shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <span>다시 생각해 볼래요</span>
              </button>
            </div>

            {promise.selfCheckFeasible === 'rethink' && (
              <p className="text-xs sm:text-sm text-amber-800 bg-amber-50 p-3 rounded-xl border border-amber-200 mt-2 font-medium break-keep leading-relaxed animate-fadeIn">
                위로 올라가서 내가 지킬 수 있는 내용으로 규칙을 다듬어 보세요.
              </p>
            )}
          </div>

          {/* Question 2: AI 사용과 다른 생활이 균형을 이루도록 도와주는 규칙인가요? */}
          <div className="space-y-3 p-5 rounded-2xl bg-slate-50 border border-slate-200/80">
            <div className="flex items-start gap-2.5">
              <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                2
              </div>
              <h4 className="font-bold text-slate-900 text-base sm:text-lg leading-snug break-keep">
                AI 사용과 다른 생활이 균형을 이루도록 도와주는 규칙인가요?
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <button
                type="button"
                onClick={() => onChange({ selfCheckBalance: 'yes' })}
                className={`flex items-center justify-center gap-2 p-3.5 rounded-xl border-2 font-bold text-sm sm:text-base transition-all cursor-pointer whitespace-nowrap ${
                  promise.selfCheckBalance === 'yes'
                    ? 'border-blue-500 bg-blue-50 text-blue-900 shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>네, 도움이 돼요</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onChange({ selfCheckBalance: 'rethink' });
                  handleRethink();
                }}
                className={`flex items-center justify-center gap-2 p-3.5 rounded-xl border-2 font-bold text-sm sm:text-base transition-all cursor-pointer whitespace-nowrap ${
                  promise.selfCheckBalance === 'rethink'
                    ? 'border-amber-500 bg-amber-50 text-amber-900 shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <span>다시 생각해 볼래요</span>
              </button>
            </div>

            {promise.selfCheckBalance === 'rethink' && (
              <p className="text-xs sm:text-sm text-amber-800 bg-amber-50 p-3 rounded-xl border border-amber-200 mt-2 font-medium break-keep leading-relaxed animate-fadeIn">
                위로 올라가서 AI 사용과 다른 생활이 균형을 이루도록 규칙을 다듬어 보세요.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Section 3: 나의 실천 계획 */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center gap-2.5 text-slate-900 font-extrabold text-xl pb-2 border-b border-slate-100">
          <FileText className="w-6 h-6 text-amber-600 shrink-0" />
          <h3 className="break-keep">3. 나의 실천 계획</h3>
        </div>

        {/* Priority Rule Selection (Required) */}
        {promise.timeRule.trim().length > 0 &&
          promise.stopRule.trim().length > 0 &&
          promise.firstActionRule.trim().length > 0 && (
            <div className="space-y-3 p-5 rounded-2xl bg-amber-50/50 border border-amber-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-700 shrink-0" />
                  <label className="block font-bold text-slate-900 text-sm sm:text-base break-keep">
                    가장 먼저 실천하고 싶은 규칙을 1개 선택해 보세요. (필수)
                  </label>
                </div>
                {!promise.preferredRuleType && (
                  <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2.5 py-0.5 rounded-full">
                    선택 필요
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                {[
                  { type: 'time' as const, category: 'AI를 언제, 얼마나 사용할지', text: promise.timeRule },
                  { type: 'stop' as const, category: 'AI 사용을 조절해야 할 때', text: promise.stopRule },
                  { type: 'first' as const, category: 'AI를 사용하기 전에 내가 먼저 해 볼 것', text: promise.firstActionRule },
                ].map((item) => {
                  const isSelected = promise.preferredRuleType === item.type;

                  return (
                    <button
                      key={item.type}
                      type="button"
                      onClick={() =>
                        onChange({
                          preferredRuleType: item.type,
                          preferredRuleText: item.text,
                          priorityRule: item.text,
                        })
                      }
                      className={`p-3.5 rounded-xl border-2 text-left text-xs sm:text-sm font-semibold transition-all cursor-pointer flex flex-col justify-between gap-1.5 ${
                        isSelected
                          ? 'border-amber-500 bg-amber-100 text-amber-950 shadow-2xs ring-2 ring-amber-300'
                          : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <div>
                        <span className="block font-bold text-xs text-slate-500 mb-1 break-keep">
                          {item.category}
                        </span>
                        <span className="block text-xs sm:text-sm text-slate-900 font-bold leading-relaxed break-keep">
                          &ldquo;{item.text}&rdquo;
                        </span>
                      </div>
                      {isSelected && (
                        <div className="flex items-center gap-1 text-xs font-extrabold text-amber-800 pt-1">
                          <CheckCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>선택됨</span>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

        {/* Action Plan Questions */}
        <div className="space-y-5 pt-1">
          <div className="space-y-2">
            <label className="block font-bold text-slate-900 text-sm sm:text-base break-keep">
              이 규칙을 언제부터 실천할까요?
            </label>
            <input
              type="text"
              value={promise.startDate}
              onChange={(e) => onChange({ startDate: e.target.value })}
              placeholder="언제부터 실천할지 적어 보세요."
              className="w-full p-3.5 rounded-xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base break-keep leading-relaxed"
            />
          </div>

          <div className="space-y-2">
            <label className="block font-bold text-slate-900 text-sm sm:text-base break-keep">
              규칙을 지키기 어려울 때는 어떻게 해 볼까요?
            </label>
            <input
              type="text"
              value={promise.difficultyStrategy}
              onChange={(e) => onChange({ difficultyStrategy: e.target.value })}
              placeholder="규칙을 지키기 어려울 때 어떻게 할지 적어 보세요."
              className="w-full p-3.5 rounded-xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base break-keep leading-relaxed"
            />
          </div>
        </div>
      </div>

      {/* Next Button */}
      <div className="flex justify-center pt-2">
        <button
          type="button"
          disabled={!isFormComplete}
          onClick={onNext}
          className={`w-full sm:w-auto min-w-[240px] px-8 py-4 font-extrabold text-lg rounded-full shadow-md transition-all duration-200 flex items-center justify-center gap-2 whitespace-nowrap ${
            isFormComplete
              ? 'bg-[#ffd700] hover:bg-[#fed100] active:translate-y-0.5 text-slate-900 cursor-pointer hover:shadow-lg border-b-4 border-[#cca700]'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed border-b-4 border-slate-300'
          }`}
        >
          <span className="whitespace-nowrap">돌아보기로 이동</span>
          <ArrowRight className="w-5 h-5 shrink-0" />
        </button>
      </div>
    </div>
  );
};
