import React, { useRef } from 'react';
import {
  Users,
  MessageSquare,
  CheckCircle2,
  HelpCircle,
  ArrowRight,
  ClipboardList,
  Edit3,
} from 'lucide-react';
import { Activity3State, GroupCheckState } from '../types';

interface Activity3ScreenProps {
  data: Activity3State;
  onChange: (updated: Partial<Activity3State>) => void;
  onNext: () => void;
}

export const Activity3Screen: React.FC<Activity3ScreenProps> = ({
  data,
  onChange,
  onNext,
}) => {
  const methodsInputRef = useRef<HTMLDivElement>(null);

  const isMethodsFilled =
    data.method1.trim().length > 0 &&
    data.method2.trim().length > 0 &&
    data.method3.trim().length > 0;

  const checks = data.groupChecks || { thinking: '', control: '', balance: '' };

  const areAllYes =
    checks.thinking === 'yes' &&
    checks.control === 'yes' &&
    checks.balance === 'yes';

  const groupNeedsRevision = Boolean(data.groupNeedsRevision);

  const canCompleteActivity3 = isMethodsFilled && areAllYes && !groupNeedsRevision;

  // Real method change handler:
  // Only substantive content changes (trim comparison) reset groupNeedsRevision and reset checks.
  const handleMethodChange = (field: 'method1' | 'method2' | 'method3', value: string) => {
    const prevValue = data[field] || '';
    if (prevValue === value) return; // Ignore identical value

    // If only whitespace changed, update the text without resetting groupNeedsRevision or checks
    if (prevValue.trim() === value.trim()) {
      onChange({ [field]: value });
      return;
    }

    onChange({
      [field]: value,
      groupNeedsRevision: false,
      groupChecks: {
        thinking: '',
        control: '',
        balance: '',
      },
    });
  };

  // Group check change handler:
  // If 'rethink' is chosen on ANY question, groupNeedsRevision becomes true.
  // If 'yes' is chosen, groupNeedsRevision remains unchanged (still true if previously true).
  const handleCheckChange = (field: keyof GroupCheckState, value: 'yes' | 'rethink') => {
    const newChecks: GroupCheckState = {
      ...checks,
      [field]: value,
    };

    const newNeedsRevision = value === 'rethink' ? true : groupNeedsRevision;

    onChange({
      groupChecks: newChecks,
      groupNeedsRevision: newNeedsRevision,
    });
  };

  const scrollToMethods = () => {
    methodsInputRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-8 animate-fadeIn pb-12">
      {/* Header Info */}
      <div className="text-center space-y-3">
        <span className="inline-block px-3.5 py-1 bg-amber-400 text-slate-900 font-bold text-xs sm:text-sm rounded-full shadow-xs whitespace-nowrap">
          활동3
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 break-keep">
          우리 모둠의 건강한 AI 활용 방법 정하기
        </h2>
        <p className="text-slate-600 text-base sm:text-lg break-keep leading-relaxed max-w-2xl mx-auto">
          활동2에서 찾은 차이를 떠올리며, 건강한 AI 활용 방법을 모둠에서 세 가지 정해 봅시다.
        </p>
      </div>

      {/* Group Collaboration Notice Banner */}
      <div className="bg-blue-50/80 border-2 border-blue-200 rounded-2xl p-4 sm:p-5 flex items-center gap-3.5 text-blue-900 shadow-2xs">
        <div className="w-10 h-10 rounded-xl bg-blue-500 text-white flex items-center justify-center shrink-0">
          <Users className="w-5 h-5" />
        </div>
        <p className="text-sm sm:text-base font-semibold break-keep leading-relaxed">
          모둠원과 의견을 나눈 뒤, 모둠의 생각을 한 기기에 기록해 보세요.
        </p>
      </div>

      {/* Section 1: 우리 모둠의 AI 활용 방법 3가지 작성 */}
      <div
        ref={methodsInputRef}
        className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-6"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5 text-slate-900 font-extrabold text-lg sm:text-xl">
            <MessageSquare className="w-6 h-6 text-amber-600 shrink-0" />
            <h3 className="break-keep">우리 모둠의 AI 활용 방법</h3>
          </div>
          <span className="text-xs font-bold text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200 whitespace-nowrap">
            모둠 토의
          </span>
        </div>

        <p className="text-slate-600 text-sm sm:text-base break-keep leading-relaxed">
          모둠원과 의견을 나누고, 모둠에서 중요하다고 생각하는 방법 3가지를 적어 보세요.
        </p>

        <div className="space-y-5">
          {/* Method 1 */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 font-bold text-base sm:text-lg text-slate-900 break-keep">
              <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-900 flex items-center justify-center text-xs font-extrabold shrink-0">
                1
              </span>
              <span>우리 모둠의 AI 활용 방법</span>
            </label>
            <textarea
              rows={2}
              value={data.method1}
              onChange={(e) => handleMethodChange('method1', e.target.value)}
              placeholder="모둠에서 정한 방법을 적어 보세요."
              className="w-full p-3.5 sm:p-4 rounded-2xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-y placeholder:text-slate-400 break-keep leading-relaxed"
            />
          </div>

          {/* Method 2 */}
          <div className="space-y-2 pt-1">
            <label className="flex items-center gap-2 font-bold text-base sm:text-lg text-slate-900 break-keep">
              <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-900 flex items-center justify-center text-xs font-extrabold shrink-0">
                2
              </span>
              <span>우리 모둠의 AI 활용 방법</span>
            </label>
            <textarea
              rows={2}
              value={data.method2}
              onChange={(e) => handleMethodChange('method2', e.target.value)}
              placeholder="모둠에서 정한 방법을 적어 보세요."
              className="w-full p-3.5 sm:p-4 rounded-2xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-y placeholder:text-slate-400 break-keep leading-relaxed"
            />
          </div>

          {/* Method 3 */}
          <div className="space-y-2 pt-1">
            <label className="flex items-center gap-2 font-bold text-base sm:text-lg text-slate-900 break-keep">
              <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-900 flex items-center justify-center text-xs font-extrabold shrink-0">
                3
              </span>
              <span>우리 모둠의 AI 활용 방법</span>
            </label>
            <textarea
              rows={2}
              value={data.method3}
              onChange={(e) => handleMethodChange('method3', e.target.value)}
              placeholder="모둠에서 정한 방법을 적어 보세요."
              className="w-full p-3.5 sm:p-4 rounded-2xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-y placeholder:text-slate-400 break-keep leading-relaxed"
            />
          </div>
        </div>
      </div>

      {/* Section 2: 우리 모둠의 방법을 함께 점검해 봅시다 */}
      {isMethodsFilled && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-6 animate-fadeIn">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5 text-slate-900 font-extrabold text-lg sm:text-xl">
              <ClipboardList className="w-6 h-6 text-blue-600 shrink-0" />
              <h3 className="break-keep">우리 모둠의 방법을 함께 점검해 봅시다</h3>
            </div>
            <span className="text-xs font-bold text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200 whitespace-nowrap">
              모둠 전체 점검
            </span>
          </div>

          <p className="text-slate-600 text-sm sm:text-base break-keep leading-relaxed">
            우리 모둠이 정한 세 가지 방법을 함께 살펴보며 확인해 봅시다.
          </p>

          {/* 3 Unified Review Questions */}
          <div className="space-y-4 pt-1">
            {/* Question 1: 스스로 생각하고 해결하는 데 도움이 되나요? */}
            <div className="space-y-2.5 p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="text-sm sm:text-base font-bold text-slate-900 break-keep">
                ① 스스로 생각하고 해결하는 데 도움이 되나요?
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => handleCheckChange('thinking', 'yes')}
                  className={`p-3 rounded-xl border-2 font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap ${
                    checks.thinking === 'yes'
                      ? 'border-blue-400 bg-blue-50 text-blue-900 shadow-2xs'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>그래요</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleCheckChange('thinking', 'rethink')}
                  className={`p-3 rounded-xl border-2 font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap ${
                    checks.thinking === 'rethink'
                      ? 'border-amber-400 bg-amber-50 text-amber-900 shadow-2xs'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <span>다시 생각해 보기</span>
                </button>
              </div>
            </div>

            {/* Question 2: 필요할 때 AI 사용을 조절하는 데 도움이 되나요? */}
            <div className="space-y-2.5 p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="text-sm sm:text-base font-bold text-slate-900 break-keep">
                ② 필요할 때 AI 사용을 조절하는 데 도움이 되나요?
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => handleCheckChange('control', 'yes')}
                  className={`p-3 rounded-xl border-2 font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap ${
                    checks.control === 'yes'
                      ? 'border-blue-400 bg-blue-50 text-blue-900 shadow-2xs'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>그래요</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleCheckChange('control', 'rethink')}
                  className={`p-3 rounded-xl border-2 font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap ${
                    checks.control === 'rethink'
                      ? 'border-amber-400 bg-amber-50 text-amber-900 shadow-2xs'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <span>다시 생각해 보기</span>
                </button>
              </div>
            </div>

            {/* Question 3: 학습과 생활의 균형에 도움이 되나요? */}
            <div className="space-y-2.5 p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="text-sm sm:text-base font-bold text-slate-900 break-keep">
                ③ 학습과 생활의 균형에 도움이 되나요?
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => handleCheckChange('balance', 'yes')}
                  className={`p-3 rounded-xl border-2 font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap ${
                    checks.balance === 'yes'
                      ? 'border-blue-400 bg-blue-50 text-blue-900 shadow-2xs'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>그래요</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleCheckChange('balance', 'rethink')}
                  className={`p-3 rounded-xl border-2 font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap ${
                    checks.balance === 'rethink'
                      ? 'border-amber-400 bg-amber-50 text-amber-900 shadow-2xs'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <span>다시 생각해 보기</span>
                </button>
              </div>
            </div>
          </div>

          {/* RETHINK / REVISION NOTICE (when groupNeedsRevision is true) */}
          {groupNeedsRevision && (
            <div className="p-4 sm:p-5 rounded-2xl bg-amber-50 border-2 border-amber-200 text-amber-900 space-y-2 animate-fadeIn mt-4">
              <div className="flex items-center gap-2 font-bold text-sm sm:text-base">
                <HelpCircle className="w-5 h-5 text-amber-600 shrink-0" />
                <span className="break-keep">
                  점검한 내용을 보고 우리 모둠의 방법에서 필요한 부분을 고쳐 봅시다.
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-700 break-keep leading-relaxed">
                위쪽 입력 상자에서 내용을 수정하면 새로운 점검을 진행할 수 있습니다.
              </p>
              <button
                type="button"
                onClick={scrollToMethods}
                className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-amber-800 hover:text-amber-950 bg-amber-100/80 hover:bg-amber-200 px-3.5 py-1.5 rounded-full transition-colors mt-1 cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5 shrink-0" />
                <span>위로 올라가서 방법 수정하기</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Section 3: 최종 모둠 정리 카드 (isMethodsFilled && areAllYes && !groupNeedsRevision) */}
      {canCompleteActivity3 && (
        <div className="bg-amber-50/60 rounded-3xl p-6 sm:p-8 border-2 border-amber-300 shadow-xs space-y-5 animate-fadeIn">
          <div className="flex items-center gap-2.5 text-amber-950 font-extrabold text-lg sm:text-xl pb-3 border-b border-amber-200/80">
            <MessageSquare className="w-6 h-6 text-amber-600 shrink-0" />
            <h3 className="break-keep">우리 모둠이 정한 AI 활용 방법</h3>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-3 bg-white p-4 rounded-2xl border border-amber-200/70 shadow-2xs">
              <span className="w-6 h-6 rounded-full bg-amber-400 text-slate-900 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                1
              </span>
              <p className="text-sm sm:text-base text-slate-900 font-bold break-keep leading-relaxed whitespace-pre-wrap">
                {data.method1}
              </p>
            </div>

            <div className="flex items-start gap-3 bg-white p-4 rounded-2xl border border-amber-200/70 shadow-2xs">
              <span className="w-6 h-6 rounded-full bg-amber-400 text-slate-900 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                2
              </span>
              <p className="text-sm sm:text-base text-slate-900 font-bold break-keep leading-relaxed whitespace-pre-wrap">
                {data.method2}
              </p>
            </div>

            <div className="flex items-start gap-3 bg-white p-4 rounded-2xl border border-amber-200/70 shadow-2xs">
              <span className="w-6 h-6 rounded-full bg-amber-400 text-slate-900 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                3
              </span>
              <p className="text-sm sm:text-base text-slate-900 font-bold break-keep leading-relaxed whitespace-pre-wrap">
                {data.method3}
              </p>
            </div>
          </div>

          <p className="text-slate-700 text-sm sm:text-base font-semibold text-center break-keep pt-2 leading-relaxed">
            모둠에서 나눈 생각을 바탕으로 이제 나에게 맞는 규칙을 정해 봅시다.
          </p>
        </div>
      )}

      {/* Next Button */}
      <div className="flex justify-center pt-2">
        <button
          type="button"
          disabled={!canCompleteActivity3}
          onClick={onNext}
          className={`w-full sm:w-auto min-w-[240px] px-8 py-4 font-extrabold text-lg rounded-full shadow-md transition-all duration-200 flex items-center justify-center gap-2 whitespace-nowrap ${
            canCompleteActivity3
              ? 'bg-[#ffd700] hover:bg-[#fed100] active:translate-y-0.5 text-slate-900 cursor-pointer hover:shadow-lg border-b-4 border-[#cca700]'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed border-b-4 border-slate-300'
          }`}
        >
          <span className="whitespace-nowrap">나에게 적용하기</span>
          <ArrowRight className="w-5 h-5 shrink-0" />
        </button>
      </div>
    </div>
  );
};
