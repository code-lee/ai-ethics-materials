import React from 'react';
import {
  RotateCcw,
  Printer,
  Sparkles,
  Bookmark,
  FileText,
  Clock,
  Square,
  UserCheck,
  X,
  Brain,
  MessageSquare,
  Users,
} from 'lucide-react';
import { AppState } from '../types';

interface CompletionModalProps {
  appState: AppState;
  onClose: () => void;
  onReset: () => void;
}

export const CompletionModal: React.FC<CompletionModalProps> = ({
  appState,
  onClose,
  onReset,
}) => {
  // Derive priority rule text and category
  let priorityRuleText = '';
  let priorityRuleCategory = '';

  if (appState.promise.preferredRuleType === 'time') {
    priorityRuleText = appState.promise.timeRule;
    priorityRuleCategory = 'AI를 언제, 얼마나 사용할지';
  } else if (appState.promise.preferredRuleType === 'stop') {
    priorityRuleText = appState.promise.stopRule;
    priorityRuleCategory = 'AI 사용을 조절해야 할 때';
  } else if (appState.promise.preferredRuleType === 'first') {
    priorityRuleText = appState.promise.firstActionRule;
    priorityRuleCategory = 'AI를 사용하기 전에 내가 먼저 해 볼 것';
  } else if (appState.promise.preferredRuleText) {
    priorityRuleText = appState.promise.preferredRuleText;
  } else if (appState.promise.priorityRule) {
    priorityRuleText = appState.promise.priorityRule;
  }

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border-2 border-amber-300 flex flex-col">
        {/* Header banner */}
        <div className="bg-amber-400 p-6 sm:p-8 text-slate-900 rounded-t-3xl relative flex items-center justify-between">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/90 text-slate-900 rounded-full text-xs font-extrabold mb-1 whitespace-nowrap">
              <Sparkles className="w-3.5 h-3.5 text-amber-700 shrink-0" />
              <span>학습 완료</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold break-keep">
              건강하게 AI 활용하기 학습을 마쳤습니다!
            </h2>
            <p className="text-slate-800 text-sm sm:text-base font-medium break-keep leading-relaxed">
              모둠과 함께 정한 방법과 나에게 맞춘 규칙 및 실천 계획을 일상에서 실천해 보세요.
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white/80 hover:bg-white text-slate-700 flex items-center justify-center transition-colors shrink-0 ml-2 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 flex-1 text-slate-900">
          {/* Section: 수업 시작할 때 나의 생각 */}
          {appState.startThought && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-2">
              <span className="text-xs font-extrabold text-slate-500 tracking-wider block whitespace-nowrap">
                수업을 시작할 때 나의 생각
              </span>
              <p className="text-sm sm:text-base font-semibold text-slate-800 leading-relaxed break-keep">
                &ldquo;{appState.startThought}&rdquo;
              </p>
            </div>
          )}

          {/* Section: 활동2에서 내가 정리한 생각 */}
          {appState.activity2.summaryThought && (
            <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 sm:p-6 space-y-2">
              <div className="flex items-center gap-1.5 text-amber-800">
                <MessageSquare className="w-4 h-4 shrink-0" />
                <span className="text-xs font-extrabold tracking-wider whitespace-nowrap">
                  비교를 통해 내가 정리한 생각 (활동2)
                </span>
              </div>
              <p className="text-base sm:text-lg font-extrabold text-slate-900 leading-relaxed break-keep">
                &ldquo;{appState.activity2.summaryThought}&rdquo;
              </p>
            </div>
          )}

          {/* Section: 우리 모둠이 정한 AI 활용 방법 3가지 (활동3) */}
          {(appState.activity3.method1 || appState.activity3.method2 || appState.activity3.method3) && (
            <div className="bg-blue-50/60 border-2 border-blue-200 rounded-2xl p-5 sm:p-6 space-y-4">
              <div className="flex items-center gap-2 text-blue-900 font-extrabold text-lg">
                <Users className="w-5 h-5 text-blue-600 shrink-0" />
                <h3 className="break-keep">우리 모둠이 정한 AI 활용 방법 3가지 (활동3)</h3>
              </div>

              <div className="grid grid-cols-1 gap-2.5 text-sm sm:text-base">
                {appState.activity3.method1 && (
                  <div className="bg-white p-3.5 rounded-xl border border-blue-200/80 flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-900 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                      1
                    </span>
                    <p className="text-slate-900 font-semibold break-keep leading-relaxed">
                      {appState.activity3.method1}
                    </p>
                  </div>
                )}
                {appState.activity3.method2 && (
                  <div className="bg-white p-3.5 rounded-xl border border-blue-200/80 flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-900 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                      2
                    </span>
                    <p className="text-slate-900 font-semibold break-keep leading-relaxed">
                      {appState.activity3.method2}
                    </p>
                  </div>
                )}
                {appState.activity3.method3 && (
                  <div className="bg-white p-3.5 rounded-xl border border-blue-200/80 flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-900 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                      3
                    </span>
                    <p className="text-slate-900 font-semibold break-keep leading-relaxed">
                      {appState.activity3.method3}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Section: 내가 정한 3가지 AI 사용 규칙 (생활 속 적용) */}
          <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-lg">
              <Bookmark className="w-5 h-5 text-amber-600 shrink-0" />
              <h3 className="break-keep">내가 정한 3가지 AI 사용 규칙 (생활 속 적용)</h3>
            </div>

            <div className="grid grid-cols-1 gap-3 text-sm sm:text-base">
              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1">
                <div className="flex items-center gap-2 font-bold text-slate-700 text-xs sm:text-sm">
                  <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="break-keep">1. AI를 언제, 얼마나 사용할지</span>
                </div>
                <p className="text-slate-900 font-medium pl-6 break-keep leading-relaxed">
                  {appState.promise.timeRule || '(미작성)'}
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1">
                <div className="flex items-center gap-2 font-bold text-slate-700 text-xs sm:text-sm">
                  <Square className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="break-keep">2. AI 사용을 조절해야 할 때</span>
                </div>
                <p className="text-slate-900 font-medium pl-6 break-keep leading-relaxed">
                  {appState.promise.stopRule || '(미작성)'}
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1">
                <div className="flex items-center gap-2 font-bold text-slate-700 text-xs sm:text-sm">
                  <UserCheck className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="break-keep">3. AI를 사용하기 전에 내가 먼저 해 볼 것</span>
                </div>
                <p className="text-slate-900 font-medium pl-6 break-keep leading-relaxed">
                  {appState.promise.firstActionRule || '(미작성)'}
                </p>
              </div>
            </div>
          </div>

          {/* Section: 실천 세부 계획 */}
          {(appState.promise.startDate || appState.promise.difficultyStrategy) && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-3">
              <div className="flex items-center gap-2 text-slate-900 font-extrabold text-base sm:text-lg">
                <FileText className="w-5 h-5 text-amber-600 shrink-0" />
                <h3 className="break-keep">실천 계획</h3>
              </div>
              <div className="space-y-2 text-sm sm:text-base">
                {priorityRuleText && (
                  <div className="text-slate-800 break-keep leading-relaxed space-y-0.5">
                    <strong className="text-slate-900 font-bold block sm:inline mr-1">
                      가장 먼저 실천할 규칙:
                    </strong>
                    {priorityRuleCategory && (
                      <span className="text-xs font-bold text-slate-500 bg-slate-200/80 px-2 py-0.5 rounded mr-1.5 align-middle">
                        {priorityRuleCategory}
                      </span>
                    )}
                    <span className="font-bold text-slate-900">&ldquo;{priorityRuleText}&rdquo;</span>
                  </div>
                )}
                {appState.promise.startDate && (
                  <p className="text-slate-800 break-keep leading-relaxed">
                    <strong className="text-slate-900 font-bold">실천 시작 시기:</strong>{' '}
                    {appState.promise.startDate}
                  </p>
                )}
                {appState.promise.difficultyStrategy && (
                  <p className="text-slate-800 break-keep leading-relaxed">
                    <strong className="text-slate-900 font-bold">규칙을 지키기 어려울 때:</strong>{' '}
                    {appState.promise.difficultyStrategy}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Section: 돌아보기 성찰 */}
          {(appState.reflection.thoughtChange || appState.reflection.selfDiscovery) && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-3">
              <div className="flex items-center gap-2 text-slate-900 font-extrabold text-base sm:text-lg">
                <Brain className="w-5 h-5 text-amber-600 shrink-0" />
                <h3 className="break-keep">나의 돌아보기</h3>
              </div>
              <div className="space-y-2 text-xs sm:text-sm text-slate-800">
                {appState.reflection.thoughtChange && (
                  <p className="break-keep leading-relaxed">
                    <strong className="font-bold text-slate-900">
                      수업 시작 전과 비교해 달라진 생각:
                    </strong>{' '}
                    {appState.reflection.thoughtChange}
                  </p>
                )}
                {appState.reflection.selfDiscovery && (
                  <p className="break-keep leading-relaxed">
                    <strong className="font-bold text-slate-900">
                      나의 AI 사용 습관에서 새롭게 발견한 점:
                    </strong>{' '}
                    {appState.reflection.selfDiscovery}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-200 rounded-b-3xl flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onReset}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-bold text-rose-700 hover:text-rose-900 hover:bg-rose-50 rounded-full transition-colors whitespace-nowrap cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 shrink-0" />
            <span>처음부터 다시 하기</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-full font-bold text-xs sm:text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              <Printer className="w-4 h-4 shrink-0" />
              <span>인쇄 / 저장</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 bg-amber-400 hover:bg-amber-500 text-slate-950 font-extrabold text-xs sm:text-sm rounded-full transition-colors shadow-xs whitespace-nowrap cursor-pointer"
            >
              확인
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
