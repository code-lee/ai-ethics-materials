import React from 'react';
import {
  Check,
  ArrowRight,
  ArrowLeft,
  Clock,
  PenLine,
  Eye,
  MessageSquare,
} from 'lucide-react';
import { Activity2State } from '../types';
import { Activity2Illustration } from './Activity2Illustration';

interface Activity2ScreenProps {
  data: Activity2State;
  onChange: (updated: Partial<Activity2State>) => void;
  onNext: () => void;
}

export const Activity2Screen: React.FC<Activity2ScreenProps> = ({
  data,
  onChange,
  onNext,
}) => {
  // Stage 0: Comparison 1
  // Stage 1: Comparison 2
  // Stage 2: Comparison 3
  // Stage 3: Summary of the 3 comparisons & student synthesis

  // Comparison 1 data
  const comp1 = {
    title: '비교 1. 수학 문제를 해결하는 두 기록',
    recordA: {
      name: '기록 A',
      timeline: [
        { id: 0, time: '15:30', text: '수학 문제를 읽음' },
        { id: 1, time: '15:35', text: '먼저 스스로 풀어봄' },
        { id: 2, time: '15:45', text: '어려운 부분을 AI에게 설명해 달라고 함' },
        { id: 3, time: '16:00', text: 'AI의 설명을 참고하여 자신의 풀이를 다시 정리함' },
      ],
    },
    recordB: {
      name: '기록 B',
      timeline: [
        { id: 0, time: '15:30', text: '수학 문제를 읽음' },
        { id: 1, time: '15:35', text: '바로 AI에게 풀이 방법을 물어봄' },
        { id: 2, time: '15:45', text: '다음 문제를 읽음' },
        { id: 3, time: '15:50', text: '스스로 풀어보기 전에 AI에게 풀이 방법을 물어봄' },
      ],
    },
    focusTitle: 'AI 사용 전·후의 해결 과정',
    focusDesc: 'AI를 사용하기 전과 사용한 뒤에 스스로 무엇을 했는지 살펴보았습니다.',
  };

  // Comparison 2 data
  const comp2 = {
    title: '비교 2. 그림 아이디어를 찾는 두 기록',
    recordA: {
      name: '기록 A',
      timeline: [
        { id: 0, time: '15:00', text: 'AI로 관심 있는 그림 아이디어를 찾아보기 시작함' },
        { id: 1, time: '15:20', text: '미리 정한 시간이 됨' },
        { id: 2, time: '15:20', text: 'AI 사용을 멈춤' },
        { id: 3, time: '15:25', text: '더 찾아보고 싶은 내용을 메모해 둠' },
      ],
    },
    recordB: {
      name: '기록 B',
      timeline: [
        { id: 0, time: '15:00', text: 'AI로 관심 있는 그림 아이디어를 찾아보기 시작함' },
        { id: 1, time: '15:20', text: '미리 정한 시간이 됨' },
        { id: 2, time: '15:20', text: '관련 내용을 하나 더 살펴봄' },
        { id: 3, time: '15:35', text: '또 다른 내용이 궁금해 계속 살펴봄' },
      ],
    },
    focusTitle: '사용을 멈추거나 이어간 모습',
    focusDesc: 'AI를 사용하다가 언제 멈추고 언제 계속 사용했는지 살펴보았습니다.',
  };

  // Comparison 3 data
  const comp3 = {
    title: '비교 3. 숙제에 AI를 활용한 두 기록',
    recordA: {
      name: '기록 A',
      timeline: [
        { id: 0, time: '16:00', text: '숙제에 필요한 내용을 AI로 찾아봄' },
        { id: 1, time: '16:30', text: '해야 할 일을 예정대로 시작함' },
        { id: 2, time: '21:30', text: '평소와 비슷한 시간에 잠잘 준비를 함' },
      ],
    },
    recordB: {
      name: '기록 B',
      timeline: [
        { id: 0, time: '16:00', text: '숙제에 필요한 내용을 AI로 찾아봄' },
        { id: 1, time: '16:30', text: '관심 있는 내용을 계속 찾아봄' },
        { id: 2, time: '18:00', text: '해야 할 일을 평소보다 늦게 시작함' },
        { id: 3, time: '22:30', text: '잠잘 준비가 평소보다 늦어짐' },
      ],
    },
    focusTitle: 'AI 사용 뒤 생활의 변화',
    focusDesc: 'AI를 사용한 뒤 해야 할 일이나 잠 등 생활이 어떻게 달라졌는지 살펴보았습니다.',
  };

  const comparisons = [comp1, comp2, comp3];
  const currentCompIdx = data.currentStage; // 0, 1, 2
  const isSummaryStage = data.currentStage === 3;

  // State helpers
  const getSelectedA = (idx: number) => {
    if (idx === 0) return data.comp1SelectedA;
    if (idx === 1) return data.comp2SelectedA;
    return data.comp3SelectedA;
  };

  const getSelectedB = (idx: number) => {
    if (idx === 0) return data.comp1SelectedB;
    if (idx === 1) return data.comp2SelectedB;
    return data.comp3SelectedB;
  };

  const getViewingDiff = (idx: number) => {
    if (idx === 0) return data.comp1ViewingDiff;
    if (idx === 1) return data.comp2ViewingDiff;
    return data.comp3ViewingDiff;
  };

  const getThought = (idx: number) => {
    if (idx === 0) return data.comp1Thought;
    if (idx === 1) return data.comp2Thought;
    return data.comp3Thought;
  };

  const getCompleted = (idx: number) => {
    if (idx === 0) return data.comp1Completed;
    if (idx === 1) return data.comp2Completed;
    return data.comp3Completed;
  };

  const toggleSelectA = (itemId: number) => {
    const idx = currentCompIdx;
    const currentList = getSelectedA(idx);
    const exists = currentList.includes(itemId);
    const updated = exists
      ? currentList.filter((id) => id !== itemId)
      : [...currentList, itemId];

    if (idx === 0) onChange({ comp1SelectedA: updated, comp1Completed: false, summaryCompleted: false });
    else if (idx === 1) onChange({ comp2SelectedA: updated, comp2Completed: false, summaryCompleted: false });
    else onChange({ comp3SelectedA: updated, comp3Completed: false, summaryCompleted: false });
  };

  const toggleSelectB = (itemId: number) => {
    const idx = currentCompIdx;
    const currentList = getSelectedB(idx);
    const exists = currentList.includes(itemId);
    const updated = exists
      ? currentList.filter((id) => id !== itemId)
      : [...currentList, itemId];

    if (idx === 0) onChange({ comp1SelectedB: updated, comp1Completed: false, summaryCompleted: false });
    else if (idx === 1) onChange({ comp2SelectedB: updated, comp2Completed: false, summaryCompleted: false });
    else onChange({ comp3SelectedB: updated, comp3Completed: false, summaryCompleted: false });
  };

  const setViewingDiff = (val: boolean) => {
    const idx = currentCompIdx;
    if (idx === 0) onChange({ comp1ViewingDiff: val });
    else if (idx === 1) onChange({ comp2ViewingDiff: val });
    else onChange({ comp3ViewingDiff: val });
  };

  const setThought = (val: string) => {
    const idx = currentCompIdx;
    if (idx === 0) onChange({ comp1Thought: val, comp1Completed: false, summaryCompleted: false });
    else if (idx === 1) onChange({ comp2Thought: val, comp2Completed: false, summaryCompleted: false });
    else onChange({ comp3Thought: val, comp3Completed: false, summaryCompleted: false });
  };

  const handleConfirmThought = () => {
    const idx = currentCompIdx;
    if (idx === 0) onChange({ comp1Completed: true });
    else if (idx === 1) onChange({ comp2Completed: true });
    else onChange({ comp3Completed: true });
  };

  const handleNextStage = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    onChange({ currentStage: data.currentStage + 1 });
  };

  const handlePrevStage = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    onChange({ currentStage: Math.max(0, data.currentStage - 1) });
  };

  const canAccessStage = (targetStage: number) => {
    if (targetStage === 0) return true;
    if (targetStage === 1) return data.comp1Completed;
    if (targetStage === 2) return data.comp1Completed && data.comp2Completed;
    if (targetStage === 3) return data.comp1Completed && data.comp2Completed && data.comp3Completed;
    return false;
  };

  // If in comparison 1, 2, or 3
  const compData = comparisons[currentCompIdx];
  const selectedA = !isSummaryStage ? getSelectedA(currentCompIdx) : [];
  const selectedB = !isSummaryStage ? getSelectedB(currentCompIdx) : [];
  const viewingDiff = !isSummaryStage ? getViewingDiff(currentCompIdx) : false;
  const currentThought = !isSummaryStage ? getThought(currentCompIdx) : '';
  const isCompleted = !isSummaryStage ? getCompleted(currentCompIdx) : false;

  const hasSelectionsOnBoth = selectedA.length > 0 && selectedB.length > 0;
  const canConfirmThought = currentThought.trim().length > 0;

  return (
    <div className="w-full max-w-3xl mx-auto space-y-8 animate-fadeIn pb-12">
      {/* Header Info */}
      <div className="text-center space-y-3">
        <span className="inline-block px-3.5 py-1 bg-amber-400 text-slate-900 font-bold text-xs sm:text-sm rounded-full shadow-xs whitespace-nowrap">
          활동2
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 break-keep">
          활동2. 같은 AI 사용, 무엇이 다를까?
        </h2>
        <p className="text-slate-700 text-base sm:text-lg max-w-xl mx-auto font-medium break-keep leading-relaxed">
          두 AI 사용 기록을 비교하며, 눈에 띄는 부분을 눌러 표시해 봅시다.
        </p>
      </div>

      {/* Progress Dots */}
      <div className="flex items-center justify-center gap-2 pt-1 pb-2">
        {['비교 1', '비교 2', '비교 3', '생각 정리'].map((stepName, i) => {
          const isActive = data.currentStage === i;
          const isDone =
            (i === 0 && data.comp1Completed) ||
            (i === 1 && data.comp2Completed) ||
            (i === 2 && data.comp3Completed) ||
            (i === 3 && data.summaryCompleted);
          const isAccessible = canAccessStage(i);

          return (
            <button
              key={i}
              type="button"
              disabled={!isAccessible}
              onClick={() => {
                if (isAccessible) {
                  onChange({ currentStage: i });
                }
              }}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-slate-900 text-white shadow-xs'
                  : isDone
                  ? 'bg-amber-100 text-amber-900 hover:bg-amber-200 cursor-pointer'
                  : isAccessible
                  ? 'bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer'
                  : 'bg-slate-100 text-slate-400 opacity-60 cursor-not-allowed'
              }`}
            >
              {isDone && <Check className="w-3 h-3 text-amber-700 shrink-0" />}
              <span>{stepName}</span>
            </button>
          );
        })}
      </div>

      {/* STAGE 0, 1, 2: Comparison Views */}
      {!isSummaryStage && compData && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-6">
          {/* Comparison Header */}
          <div className="border-b border-slate-100 pb-4 space-y-1.5">
            <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 break-keep">
              {compData.title}
            </h3>
            <p className="text-sm sm:text-base text-slate-700 font-medium break-keep leading-relaxed">
              두 기록에서 비교해 보고 싶은 부분을 눌러 표시해 보세요.
            </p>
          </div>

          {/* VIEW 1: SELECTING ITEMS IN RECORD A & RECORD B */}
          {!viewingDiff && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Record A */}
                <div className="bg-white rounded-2xl border-2 border-slate-200 p-5 space-y-3 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-xs font-extrabold whitespace-nowrap">
                      {compData.recordA.name}
                    </span>
                    <span className="text-xs text-slate-500 font-medium whitespace-nowrap">
                      {selectedA.length}개 표시됨
                    </span>
                  </div>

                  {/* Situation Illustration */}
                  <Activity2Illustration compIndex={currentCompIdx} type="A" />

                  <div className="space-y-2 pt-1">
                    {compData.recordA.timeline.map((item) => {
                      const isSelected = selectedA.includes(item.id);
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => toggleSelectA(item.id)}
                          className={`w-full text-left p-3.5 rounded-xl border-2 transition-all flex items-start gap-2.5 cursor-pointer select-none ${
                            isSelected
                              ? 'bg-amber-100 border-amber-400 text-amber-950 font-bold shadow-xs'
                              : 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-800 font-medium'
                          }`}
                        >
                          <span
                            className={`font-mono text-xs font-bold px-2 py-0.5 rounded shrink-0 flex items-center gap-1 mt-0.5 whitespace-nowrap ${
                              isSelected
                                ? 'bg-amber-200 text-amber-900'
                                : 'bg-slate-200 text-slate-700'
                            }`}
                          >
                            <Clock className="w-3 h-3 shrink-0" />
                            {item.time}
                          </span>
                          <span className="text-sm leading-relaxed break-keep min-w-0 flex-1">
                            {item.text}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Record B */}
                <div className="bg-white rounded-2xl border-2 border-slate-200 p-5 space-y-3 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-xs font-extrabold whitespace-nowrap">
                      {compData.recordB.name}
                    </span>
                    <span className="text-xs text-slate-500 font-medium whitespace-nowrap">
                      {selectedB.length}개 표시됨
                    </span>
                  </div>

                  {/* Situation Illustration */}
                  <Activity2Illustration compIndex={currentCompIdx} type="B" />

                  <div className="space-y-2 pt-1">
                    {compData.recordB.timeline.map((item) => {
                      const isSelected = selectedB.includes(item.id);
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => toggleSelectB(item.id)}
                          className={`w-full text-left p-3.5 rounded-xl border-2 transition-all flex items-start gap-2.5 cursor-pointer select-none ${
                            isSelected
                              ? 'bg-amber-100 border-amber-400 text-amber-950 font-bold shadow-xs'
                              : 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-800 font-medium'
                          }`}
                        >
                          <span
                            className={`font-mono text-xs font-bold px-2 py-0.5 rounded shrink-0 flex items-center gap-1 mt-0.5 whitespace-nowrap ${
                              isSelected
                                ? 'bg-amber-200 text-amber-900'
                                : 'bg-slate-200 text-slate-700'
                            }`}
                          >
                            <Clock className="w-3 h-3 shrink-0" />
                            {item.time}
                          </span>
                          <span className="text-sm leading-relaxed break-keep min-w-0 flex-1">
                            {item.text}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Selection Summary Action Bar */}
              <div className="pt-2 flex flex-col md:flex-row items-center justify-between gap-3 border-t border-slate-100">
                <p className="text-xs sm:text-sm text-slate-600 font-medium break-keep text-center md:text-left leading-relaxed">
                  {hasSelectionsOnBoth
                    ? '기록 A와 B에서 비교해 보고 싶은 모습을 표시했습니다. 아래 버튼을 눌러 확인해 보세요.'
                    : '기록 A와 B에서 비교해 보고 싶은 부분을 각각 하나 이상 표시해 보세요.'}
                </p>

                <button
                  type="button"
                  onClick={() => setViewingDiff(true)}
                  disabled={!hasSelectionsOnBoth}
                  className={`w-full md:w-auto min-w-[200px] px-6 py-3.5 rounded-full font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 transition-all shadow-xs shrink-0 whitespace-nowrap ${
                    hasSelectionsOnBoth
                      ? 'bg-slate-900 text-white hover:bg-slate-800 active:translate-y-0.5 cursor-pointer'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <span className="whitespace-nowrap">내가 표시한 모습 보기</span>
                  <ArrowRight className="w-4 h-4 shrink-0" />
                </button>
              </div>
            </div>
          )}

          {/* VIEW 2: VIEWING SELECTED ITEMS & STUDENT THOUGHT INPUT */}
          {viewingDiff && (
            <div className="space-y-6">
              {/* Back button */}
              <div>
                <button
                  type="button"
                  onClick={() => setViewingDiff(false)}
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3.5 py-1.5 rounded-full transition-colors cursor-pointer whitespace-nowrap"
                >
                  <ArrowLeft className="w-4 h-4 shrink-0" />
                  <span>다시 선택하기</span>
                </button>
              </div>

              {/* Highlighted Results Card */}
              <div className="bg-slate-50/80 rounded-2xl p-5 sm:p-6 border-2 border-slate-200 space-y-4">
                <div className="space-y-1">
                  <h4 className="text-base sm:text-lg font-extrabold text-slate-900 break-keep">
                    내가 표시한 모습
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-600 font-medium break-keep">
                    기록 A와 기록 B에서 내가 표시한 모습입니다.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  {/* Selected A */}
                  <div className="bg-white rounded-xl p-4 border border-slate-200 space-y-2">
                    <span className="text-xs font-bold text-slate-700 block whitespace-nowrap">
                      기록 A에서 내가 표시한 모습 ({selectedA.length}개)
                    </span>
                    <ul className="space-y-1.5">
                      {compData.recordA.timeline
                        .filter((item) => selectedA.includes(item.id))
                        .map((item) => (
                          <li
                            key={item.id}
                            className="text-xs sm:text-sm text-slate-800 flex items-start gap-2 bg-amber-50 p-2.5 rounded-lg border border-amber-200 font-medium break-keep"
                          >
                            <span className="font-mono text-xs font-bold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded shrink-0 whitespace-nowrap">
                              {item.time}
                            </span>
                            <span className="leading-relaxed min-w-0 flex-1">
                              {item.text}
                            </span>
                          </li>
                        ))}
                    </ul>
                  </div>

                  {/* Selected B */}
                  <div className="bg-white rounded-xl p-4 border border-slate-200 space-y-2">
                    <span className="text-xs font-bold text-slate-700 block whitespace-nowrap">
                      기록 B에서 내가 표시한 모습 ({selectedB.length}개)
                    </span>
                    <ul className="space-y-1.5">
                      {compData.recordB.timeline
                        .filter((item) => selectedB.includes(item.id))
                        .map((item) => (
                          <li
                            key={item.id}
                            className="text-xs sm:text-sm text-slate-800 flex items-start gap-2 bg-amber-50 p-2.5 rounded-lg border border-amber-200 font-medium break-keep"
                          >
                            <span className="font-mono text-xs font-bold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded shrink-0 whitespace-nowrap">
                              {item.time}
                            </span>
                            <span className="leading-relaxed min-w-0 flex-1">
                              {item.text}
                            </span>
                          </li>
                        ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Student Thought Input Section */}
              <div className="bg-white rounded-2xl p-5 sm:p-6 border-2 border-slate-200 space-y-3">
                <div className="flex items-center gap-2">
                  <PenLine className="w-4 h-4 text-amber-600 shrink-0" />
                  <h4 className="font-bold text-slate-900 text-sm sm:text-base break-keep">
                    나의 생각
                  </h4>
                </div>
                <p className="text-xs sm:text-sm text-slate-700 font-semibold leading-relaxed break-keep">
                  두 기록을 비교해 보니 어떤 차이가 보이나요? 그 차이가 AI 사용에서 왜 중요하다고 생각하나요?
                </p>
                <textarea
                  rows={2}
                  value={currentThought}
                  onChange={(e) => setThought(e.target.value)}
                  placeholder="내 생각을 한 문장으로 적어 보세요."
                  className="w-full p-3.5 rounded-xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-none placeholder:text-slate-400 break-keep leading-relaxed"
                />

                {!isCompleted && (
                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={handleConfirmThought}
                      disabled={!canConfirmThought}
                      className={`w-full md:w-auto min-w-[180px] px-6 py-3 rounded-full font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 transition-all shadow-xs shrink-0 whitespace-nowrap ${
                        canConfirmThought
                          ? 'bg-[#ffd700] hover:bg-[#fed100] text-slate-900 border-b-2 border-[#cca700] active:translate-y-0.5 cursor-pointer'
                          : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      <span className="whitespace-nowrap">생각 정리하기</span>
                      <ArrowRight className="w-4 h-4 shrink-0" />
                    </button>
                  </div>
                )}
              </div>

              {/* Once student thought is confirmed: show recap & student's thought */}
              {isCompleted && (
                <div className="space-y-4 pt-1 animate-fadeIn">
                  {/* Summary of What Was Looked At in this comparison */}
                  <div className="bg-slate-50 rounded-2xl p-5 sm:p-6 border-2 border-slate-200 space-y-2.5">
                    <div className="flex items-center gap-2">
                      <Eye className="w-4 h-4 text-slate-600 shrink-0" />
                      <span className="text-xs font-extrabold text-slate-600 tracking-wide uppercase whitespace-nowrap">
                        이번 비교에서 살펴본 점
                      </span>
                    </div>

                    <h5 className="text-base sm:text-lg font-extrabold text-slate-900 leading-snug break-keep">
                      {compData.focusTitle}
                    </h5>

                    <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed break-keep">
                      {compData.focusDesc}
                    </p>
                  </div>

                  {/* Student's Written Thought Read-Only Card */}
                  <div className="bg-amber-50/60 rounded-2xl p-4 sm:p-5 border-2 border-amber-200 space-y-1.5">
                    <span className="text-xs font-bold text-amber-800 block whitespace-nowrap">
                      내가 적은 생각
                    </span>
                    <p className="text-sm sm:text-base font-bold text-slate-900 leading-relaxed break-keep">
                      &ldquo;{currentThought}&rdquo;
                    </p>
                  </div>

                  {/* Navigation to Next Comparison or Stage 3 */}
                  <div className="pt-3 flex flex-col md:flex-row items-center justify-between gap-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={handlePrevStage}
                      disabled={currentCompIdx === 0}
                      className={`text-xs sm:text-sm font-bold text-slate-500 hover:text-slate-800 transition-colors whitespace-nowrap ${
                        currentCompIdx === 0 ? 'invisible' : 'cursor-pointer'
                      }`}
                    >
                      ← 이전 비교로
                    </button>

                    <button
                      type="button"
                      onClick={handleNextStage}
                      className="w-full md:w-auto min-w-[200px] px-8 py-3.5 bg-[#ffd700] hover:bg-[#fed100] active:translate-y-0.5 text-slate-900 text-sm sm:text-base font-extrabold rounded-full shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 border-b-2 border-[#cca700] shrink-0 whitespace-nowrap cursor-pointer"
                    >
                      <span className="whitespace-nowrap">
                        {currentCompIdx === 0 && '비교 2로 이동'}
                        {currentCompIdx === 1 && '비교 3으로 이동'}
                        {currentCompIdx === 2 && '비교 내용 돌아보기'}
                      </span>
                      <ArrowRight className="w-4 h-4 shrink-0" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* STAGE 3: Final Comparisons Overview & Student's Own Synthesis */}
      {isSummaryStage && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-6">
            <div className="text-center space-y-2 border-b border-slate-100 pb-5">
              <span className="inline-block px-3 py-1 bg-amber-100 text-amber-900 font-extrabold text-xs rounded-full whitespace-nowrap">
                세 번의 비교 돌아보기
              </span>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 break-keep">
                세 번의 비교에서 무엇을 살펴봤나요?
              </h3>
            </div>

            {/* 3 Neutral Comparison Cards with Student Thoughts */}
            <div className="space-y-4">
              {/* 1. AI 사용 전·후의 해결 과정 */}
              <div className="bg-slate-50 rounded-2xl p-5 border-2 border-slate-200 space-y-3">
                <div className="flex items-start gap-4">
                  <div className="w-9 h-9 rounded-xl bg-amber-300 text-slate-900 font-extrabold flex items-center justify-center text-sm shrink-0 shadow-2xs mt-0.5">
                    1
                  </div>
                  <div className="space-y-1 min-w-0 flex-1">
                    <h4 className="font-extrabold text-slate-900 text-base sm:text-lg break-keep">
                      AI 사용 전·후의 해결 과정
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed break-keep">
                      AI를 사용하기 전과 사용한 뒤에 스스로 무엇을 했는지 살펴보았습니다.
                    </p>
                  </div>
                </div>

                {/* Student's Written Thought in Comp 1 */}
                <div className="bg-amber-50/70 border border-amber-200/90 rounded-xl p-3.5 ml-0 sm:ml-13 space-y-1">
                  <span className="text-xs font-bold text-amber-800 block whitespace-nowrap">
                    비교 1에서 내가 적은 생각
                  </span>
                  <p className="text-xs sm:text-sm font-semibold text-slate-900 leading-relaxed break-keep">
                    {data.comp1Thought ? (
                      <>&ldquo;{data.comp1Thought}&rdquo;</>
                    ) : (
                      <span className="text-slate-400 font-normal">(작성된 생각 없음)</span>
                    )}
                  </p>
                </div>
              </div>

              {/* 2. 사용을 멈추거나 이어간 모습 */}
              <div className="bg-slate-50 rounded-2xl p-5 border-2 border-slate-200 space-y-3">
                <div className="flex items-start gap-4">
                  <div className="w-9 h-9 rounded-xl bg-amber-300 text-slate-900 font-extrabold flex items-center justify-center text-sm shrink-0 shadow-2xs mt-0.5">
                    2
                  </div>
                  <div className="space-y-1 min-w-0 flex-1">
                    <h4 className="font-extrabold text-slate-900 text-base sm:text-lg break-keep">
                      사용을 멈추거나 이어간 모습
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed break-keep">
                      AI를 언제 멈추고 언제 계속 사용했는지 살펴보았습니다.
                    </p>
                  </div>
                </div>

                {/* Student's Written Thought in Comp 2 */}
                <div className="bg-amber-50/70 border border-amber-200/90 rounded-xl p-3.5 ml-0 sm:ml-13 space-y-1">
                  <span className="text-xs font-bold text-amber-800 block whitespace-nowrap">
                    비교 2에서 내가 적은 생각
                  </span>
                  <p className="text-xs sm:text-sm font-semibold text-slate-900 leading-relaxed break-keep">
                    {data.comp2Thought ? (
                      <>&ldquo;{data.comp2Thought}&rdquo;</>
                    ) : (
                      <span className="text-slate-400 font-normal">(작성된 생각 없음)</span>
                    )}
                  </p>
                </div>
              </div>

              {/* 3. AI 사용 뒤 생활의 변화 */}
              <div className="bg-slate-50 rounded-2xl p-5 border-2 border-slate-200 space-y-3">
                <div className="flex items-start gap-4">
                  <div className="w-9 h-9 rounded-xl bg-amber-300 text-slate-900 font-extrabold flex items-center justify-center text-sm shrink-0 shadow-2xs mt-0.5">
                    3
                  </div>
                  <div className="space-y-1 min-w-0 flex-1">
                    <h4 className="font-extrabold text-slate-900 text-base sm:text-lg break-keep">
                      AI 사용 뒤 생활의 변화
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed break-keep">
                      AI를 사용한 뒤 해야 할 일이나 잠 등 생활이 어떻게 달라졌는지 살펴보았습니다.
                    </p>
                  </div>
                </div>

                {/* Student's Written Thought in Comp 3 */}
                <div className="bg-amber-50/70 border border-amber-200/90 rounded-xl p-3.5 ml-0 sm:ml-13 space-y-1">
                  <span className="text-xs font-bold text-amber-800 block whitespace-nowrap">
                    비교 3에서 내가 적은 생각
                  </span>
                  <p className="text-xs sm:text-sm font-semibold text-slate-900 leading-relaxed break-keep">
                    {data.comp3Thought ? (
                      <>&ldquo;{data.comp3Thought}&rdquo;</>
                    ) : (
                      <span className="text-slate-400 font-normal">(작성된 생각 없음)</span>
                    )}
                  </p>
                </div>
              </div>
            </div>

            {/* Student's Own Synthesis Section */}
            <div className="bg-amber-50/60 rounded-2xl p-5 sm:p-6 border-2 border-amber-300/90 space-y-3.5">
              <div className="flex items-center gap-2 text-slate-900">
                <MessageSquare className="w-5 h-5 text-amber-700 shrink-0" />
                <h4 className="font-extrabold text-base sm:text-lg break-keep">
                  나의 생각 정리하기
                </h4>
              </div>

              <p className="text-xs sm:text-sm text-slate-800 font-semibold leading-relaxed break-keep">
                세 번의 비교를 돌아보면, 건강하게 AI를 사용하려면 무엇을 살펴봐야 한다고 생각하나요?
              </p>

              <input
                type="text"
                value={data.summaryThought}
                onChange={(e) => onChange({ summaryThought: e.target.value, summaryCompleted: false })}
                placeholder="내 생각을 한 문장으로 적어 보세요."
                className="w-full px-4 py-3.5 bg-white rounded-xl border-2 border-amber-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-hidden font-medium text-slate-900 text-sm sm:text-base placeholder:text-slate-400 break-keep leading-relaxed shadow-2xs"
              />
            </div>
          </div>

          {/* Action Button: [활동3으로 이동] */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-3 pt-2">
            <button
              type="button"
              onClick={handlePrevStage}
              className="text-xs sm:text-sm font-bold text-slate-500 hover:text-slate-800 transition-colors whitespace-nowrap cursor-pointer"
            >
              ← 비교 3으로 돌아가기
            </button>

            <button
              type="button"
              disabled={
                !data.comp1Completed ||
                !data.comp2Completed ||
                !data.comp3Completed ||
                !data.summaryThought ||
                data.summaryThought.trim().length === 0
              }
              onClick={() => {
                onChange({ summaryCompleted: true });
                onNext();
              }}
              className={`w-full md:w-auto min-w-[240px] px-8 py-4 font-extrabold text-lg rounded-full shadow-md transition-all flex items-center justify-center gap-2 whitespace-nowrap ${
                data.comp1Completed &&
                data.comp2Completed &&
                data.comp3Completed &&
                data.summaryThought &&
                data.summaryThought.trim().length > 0
                  ? 'bg-[#ffd700] hover:bg-[#fed100] active:translate-y-0.5 text-slate-900 cursor-pointer hover:shadow-lg border-b-4 border-[#cca700]'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed border-b-4 border-slate-300'
              }`}
            >
              <span className="whitespace-nowrap">활동3으로 이동</span>
              <ArrowRight className="w-5 h-5 shrink-0" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
