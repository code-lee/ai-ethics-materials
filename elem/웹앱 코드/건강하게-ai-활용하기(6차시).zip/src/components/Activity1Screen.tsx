import React from 'react';
import {
  Clock,
  BookOpen,
  Gamepad2,
  HelpCircle,
  Palette,
  PlusCircle,
  Target,
  Edit3,
  ArrowRight,
  Search,
  KeyRound,
  FileText,
  Sparkles,
  MessageCircle,
} from 'lucide-react';
import { Activity1State } from '../types';

interface Activity1ScreenProps {
  data: Activity1State;
  onChange: (updated: Partial<Activity1State>) => void;
  onNext: () => void;
}

export const Activity1Screen: React.FC<Activity1ScreenProps> = ({
  data,
  onChange,
  onNext,
}) => {
  const whenOptions = [
    { id: 'study', label: '공부할 때', icon: BookOpen },
    { id: 'curious', label: '모르는 것이 생겼을 때', icon: HelpCircle },
    { id: 'create', label: '그림이나 글을 만들 때', icon: Palette },
    { id: 'play', label: '심심하거나 쉬고 있을 때', icon: Gamepad2 },
    { id: 'other', label: '기타 (직접 입력)', icon: PlusCircle },
  ];

  const purposeOptions = [
    { id: 'info', label: '개념이나 정보 검색 및 이해하기', icon: Search },
    { id: 'hint', label: '문제 풀이 힌트 얻기', icon: KeyRound },
    { id: 'translate', label: '번역이나 글 다듬기', icon: FileText },
    { id: 'creative', label: '창작 아이디어(그림, 이야기 등) 얻기', icon: Sparkles },
    { id: 'chat', label: '대화 및 재미/놀이', icon: MessageCircle },
    { id: 'other_purpose', label: '기타 (직접 입력)', icon: PlusCircle },
  ];

  const stopSelfOptions: { value: Activity1State['canStopSelf']; label: string }[] = [
    { value: 'easy', label: '쉽게 멈출 수 있어요' },
    { value: 'depends', label: '때에 따라 달라요' },
    { value: 'hard', label: '멈추기 어려울 때가 있어요' },
  ];

  const toggleWhen = (label: string) => {
    const exists = data.whenList.includes(label);
    const newList = exists
      ? data.whenList.filter((item) => item !== label)
      : [...data.whenList, label];
    onChange({ whenList: newList });
  };

  const togglePurpose = (label: string) => {
    const exists = data.purposeList.includes(label);
    const newList = exists
      ? data.purposeList.filter((item) => item !== label)
      : [...data.purposeList, label];
    onChange({ purposeList: newList });
  };

  const isFormComplete =
    data.whenList.length > 0 &&
    data.purposeList.length > 0 &&
    Boolean(data.canStopSelf);

  return (
    <div className="w-full max-w-3xl mx-auto space-y-8 animate-fadeIn pb-12">
      {/* Header Info */}
      <div className="text-center space-y-3">
        <span className="inline-block px-3.5 py-1 bg-amber-400 text-slate-900 font-bold text-xs sm:text-sm rounded-full shadow-xs whitespace-nowrap">
          활동1
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 break-keep">
          나의 AI 사용 습관 점검하기
        </h2>
        <p className="text-slate-600 text-base sm:text-lg break-keep leading-relaxed">
          나의 AI 사용 모습을 솔직하게 돌아봅시다.
        </p>
      </div>

      {/* Question 1: 언제 AI를 사용하나요? */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 break-keep">
            1. 나는 언제 AI를 사용하나요? <span className="text-xs font-normal text-slate-500 whitespace-nowrap">(복수 선택 가능)</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {whenOptions.map((opt) => {
            const isSelected = data.whenList.includes(opt.label);
            const Icon = opt.icon;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => toggleWhen(opt.label)}
                className={`flex items-center gap-3.5 p-4 rounded-2xl border-2 text-left transition-all duration-200 cursor-pointer ${
                  isSelected
                    ? 'border-amber-400 bg-amber-50/80 text-slate-900 font-bold shadow-xs'
                    : 'border-slate-200 bg-slate-50/70 text-slate-700 hover:border-slate-300 hover:bg-slate-100/80'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-amber-200 text-amber-900' : 'bg-white text-slate-500 border border-slate-200'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-sm sm:text-base leading-snug break-keep">{opt.label}</span>
              </button>
            );
          })}
        </div>

        {data.whenList.includes('기타 (직접 입력)') && (
          <div className="pt-2">
            <input
              type="text"
              value={data.customWhen}
              onChange={(e) => onChange({ customWhen: e.target.value })}
              placeholder="직접 입력: 언제 AI를 사용하는지 적어 보세요."
              className="w-full px-4 py-3 rounded-xl border-2 border-amber-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base break-keep"
            />
          </div>
        )}
      </div>

      {/* Question 2: 주로 어떤 목적으로 AI를 사용하나요? */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 shrink-0">
            <Target className="w-5 h-5" />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 break-keep">
            2. 주로 어떤 목적으로 AI를 사용하나요? <span className="text-xs font-normal text-slate-500 whitespace-nowrap">(복수 선택 가능)</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {purposeOptions.map((opt) => {
            const isSelected = data.purposeList.includes(opt.label);
            const Icon = opt.icon;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => togglePurpose(opt.label)}
                className={`flex items-center gap-3.5 p-4 rounded-2xl border-2 text-left transition-all duration-200 cursor-pointer ${
                  isSelected
                    ? 'border-amber-400 bg-amber-50/80 text-slate-900 font-bold shadow-xs'
                    : 'border-slate-200 bg-slate-50/70 text-slate-700 hover:border-slate-300 hover:bg-slate-100/80'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-amber-200 text-amber-900' : 'bg-white text-slate-500 border border-slate-200'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-sm sm:text-base leading-snug break-keep">{opt.label}</span>
              </button>
            );
          })}
        </div>

        {data.purposeList.includes('기타 (직접 입력)') && (
          <div className="pt-2">
            <input
              type="text"
              value={data.customPurpose}
              onChange={(e) => onChange({ customPurpose: e.target.value })}
              placeholder="직접 입력: 어떤 목적으로 AI를 사용하는지 적어 보세요."
              className="w-full px-4 py-3 rounded-xl border-2 border-amber-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base break-keep"
            />
          </div>
        )}
      </div>

      {/* Question 3: 필요할 때 AI 사용을 스스로 멈출 수 있나요? */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 break-keep">
            3. 필요할 때 AI 사용을 스스로 멈출 수 있나요?
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {stopSelfOptions.map((opt) => {
            const isSelected = data.canStopSelf === opt.value;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => onChange({ canStopSelf: opt.value })}
                className={`py-4 px-4 rounded-2xl border-2 text-center text-sm sm:text-base transition-all duration-200 cursor-pointer break-keep ${
                  isSelected
                    ? 'border-amber-400 bg-amber-50 text-slate-900 font-bold shadow-xs'
                    : 'border-slate-200 bg-slate-50/70 text-slate-700 hover:border-slate-300 hover:bg-slate-100'
                }`}
              >
                {opt.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Question 4: 나의 AI 사용 모습에서 계속 유지하고 싶은 점이나 조절해 보고 싶은 점 */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 shrink-0">
            <Edit3 className="w-5 h-5" />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 break-keep">
            4. 나의 AI 사용 모습에서 계속 유지하고 싶은 점이나 조절해 보고 싶은 점은 무엇인가요?
          </h3>
        </div>

        <textarea
          rows={4}
          value={data.maintainOrRegulate}
          onChange={(e) => onChange({ maintainOrRegulate: e.target.value })}
          placeholder="내 생각을 적어 보세요."
          className="w-full p-4 rounded-2xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base placeholder:text-slate-400 resize-y break-keep leading-relaxed"
        />
      </div>

      {/* Next Button */}
      <div className="flex justify-center pt-4">
        <button
          type="button"
          disabled={!isFormComplete}
          onClick={onNext}
          className={`w-full sm:w-auto min-w-[240px] px-8 py-4 font-extrabold text-lg rounded-full shadow-md transition-all duration-200 flex items-center justify-center gap-2 whitespace-nowrap ${
            isFormComplete
              ? 'bg-[#ffd700] hover:bg-[#fed100] active:translate-y-0.5 text-slate-900 cursor-pointer hover:shadow-lg border-b-4 border-[#cca700]'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed border-b-4 border-slate-300'
          }`}
        >
          <span className="whitespace-nowrap">다음 활동으로</span>
          <ArrowRight className="w-5 h-5 shrink-0" />
        </button>
      </div>
    </div>
  );
};
