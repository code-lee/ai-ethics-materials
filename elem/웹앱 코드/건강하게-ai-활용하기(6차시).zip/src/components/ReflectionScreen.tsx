import React from 'react';
import { ArrowRight, BookOpen } from 'lucide-react';
import { ReflectionState } from '../types';

interface ReflectionScreenProps {
  startThought?: string;
  data: ReflectionState;
  onChange: (updated: Partial<ReflectionState>) => void;
  onComplete: () => void;
}

export const ReflectionScreen: React.FC<ReflectionScreenProps> = ({
  startThought,
  data,
  onChange,
  onComplete,
}) => {
  const isFormComplete =
    data.thoughtChange.trim().length > 0 &&
    data.selfDiscovery.trim().length > 0;

  return (
    <div className="w-full max-w-3xl mx-auto space-y-8 animate-fadeIn pb-12">
      {/* Header Info */}
      <div className="text-center space-y-3">
        <span className="inline-block px-3.5 py-1 bg-amber-400 text-slate-900 font-bold text-xs sm:text-sm rounded-full shadow-xs whitespace-nowrap">
          돌아보기
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 break-keep">
          건강한 AI 활용 돌아보기
        </h2>
        <p className="text-slate-600 text-base sm:text-lg max-w-xl mx-auto break-keep leading-relaxed">
          수업을 시작할 때의 생각과 지금까지 배운 내용을 비교하며 나의 생각을 정리해 봅시다.
        </p>
      </div>

      {/* Read-Only Card: 수업을 시작할 때 나의 생각 */}
      <div className="bg-amber-50/70 rounded-3xl p-6 sm:p-7 border-2 border-amber-300 shadow-xs space-y-2.5">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-amber-700 shrink-0" />
          <h3 className="font-extrabold text-slate-900 text-base sm:text-lg break-keep">
            수업을 시작할 때 나의 생각
          </h3>
        </div>
        <div className="bg-white/95 rounded-2xl p-4 sm:p-5 border border-amber-200">
          <p className="text-slate-800 text-sm sm:text-base font-semibold leading-relaxed break-keep">
            {startThought && startThought.trim().length > 0
              ? startThought
              : '시작 화면에서 작성한 생각이 여기에 표시됩니다.'}
          </p>
        </div>
      </div>

      {/* Question 1: 수업을 시작할 때의 생각과 지금의 생각은 어떻게 달라졌나요? */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-full bg-amber-400 text-slate-900 font-extrabold flex items-center justify-center text-sm shrink-0 mt-0.5">
            1
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug break-keep">
            수업을 시작할 때의 생각과 지금의 생각은 어떻게 달라졌나요?
          </h3>
        </div>

        <textarea
          rows={4}
          value={data.thoughtChange}
          onChange={(e) => onChange({ thoughtChange: e.target.value })}
          placeholder="달라진 생각이나 새롭게 알게 된 점을 적어 보세요."
          className="w-full p-4 rounded-2xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-y placeholder:text-slate-400 break-keep leading-relaxed"
        />
      </div>

      {/* Question 2: 나의 AI 사용 습관에서 새롭게 발견한 점은 무엇인가요? */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xs space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-full bg-amber-400 text-slate-900 font-extrabold flex items-center justify-center text-sm shrink-0 mt-0.5">
            2
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug break-keep">
            나의 AI 사용 습관에서 새롭게 발견한 점은 무엇인가요?
          </h3>
        </div>

        <textarea
          rows={4}
          value={data.selfDiscovery}
          onChange={(e) => onChange({ selfDiscovery: e.target.value })}
          placeholder="내 생각을 적어 보세요."
          className="w-full p-4 rounded-2xl border-2 border-slate-200 bg-slate-50/50 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-200 outline-hidden text-sm sm:text-base resize-y placeholder:text-slate-400 break-keep leading-relaxed"
        />
      </div>

      {/* Action Button: [활동 마치기] */}
      <div className="flex justify-center pt-2">
        <button
          type="button"
          disabled={!isFormComplete}
          onClick={onComplete}
          className={`w-full sm:w-auto min-w-[240px] px-8 py-4 text-lg font-extrabold rounded-full shadow-md transition-all duration-200 flex items-center justify-center gap-2 whitespace-nowrap ${
            isFormComplete
              ? 'bg-[#ffd700] hover:bg-[#fed100] active:translate-y-0.5 text-slate-900 cursor-pointer hover:shadow-lg border-b-4 border-[#cca700]'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed border-b-4 border-slate-300'
          }`}
        >
          <span className="whitespace-nowrap">활동 마치기</span>
          <ArrowRight className="w-5 h-5 shrink-0" />
        </button>
      </div>
    </div>
  );
};
