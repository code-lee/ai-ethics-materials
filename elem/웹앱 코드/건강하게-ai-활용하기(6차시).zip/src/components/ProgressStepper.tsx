import React from 'react';
import { StepId, STEPS_META } from '../types';

interface ProgressStepperProps {
  currentStep: StepId;
  completedSteps: StepId[];
  onStepClick: (step: StepId) => void;
}

export const ProgressStepper: React.FC<ProgressStepperProps> = ({
  currentStep,
  completedSteps,
  onStepClick,
}) => {
  const currentIndex = STEPS_META.findIndex((s) => s.id === currentStep);

  return (
    <nav aria-label="학습 진행 단계" className="w-full max-w-2xl mx-auto my-6 px-2 sm:px-4">
      {/* Visual Stepper with Connected Line */}
      <div className="relative flex items-center justify-between">
        {/* Background Track Line */}
        <div className="absolute left-4 right-4 top-1/2 -translate-y-1/2 h-1 bg-slate-200 rounded-full -z-10" />

        {/* Active Progress Track Line */}
        <div
          className="absolute left-4 top-1/2 -translate-y-1/2 h-1 bg-amber-400 rounded-full -z-10 transition-all duration-300"
          style={{
            width: `calc(${currentIndex / (STEPS_META.length - 1)} * (100% - 32px))`,
          }}
        />

        {STEPS_META.map((step) => {
          const isCurrent = step.id === currentStep;
          const isCompleted = completedSteps.includes(step.id);
          const isAccessible = isCompleted || isCurrent;

          return (
            <div key={step.id} className="flex flex-col items-center group">
              <button
                type="button"
                disabled={!isAccessible}
                onClick={() => isAccessible && onStepClick(step.id)}
                className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-bold text-xs sm:text-sm transition-all duration-200 ${
                  isCurrent
                    ? 'bg-[#ffd700] text-slate-900 shadow-md ring-4 ring-amber-300/50 scale-110 cursor-default font-extrabold'
                    : isCompleted
                    ? 'bg-slate-700 text-white shadow-xs hover:bg-slate-800 cursor-pointer hover:scale-105'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed opacity-80'
                }`}
                title={
                  isCurrent
                    ? `${step.label} (진행 중)`
                    : isCompleted
                    ? `${step.label} (완료 - 클릭하여 이동)`
                    : `${step.label} (잠김)`
                }
              >
                <span>{step.stepNumber}</span>
              </button>

              <span
                className={`mt-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                  isCurrent
                    ? 'text-amber-900 font-extrabold'
                    : isCompleted
                    ? 'text-slate-700'
                    : 'text-slate-400'
                }`}
              >
                {step.label}
              </span>
            </div>
          );
        })}
      </div>
    </nav>
  );
};

