import React from 'react';

interface Activity2IllustrationProps {
  compIndex: number; // 0: 비교1, 1: 비교2, 2: 비교3
  type: 'A' | 'B';
}

interface BigScene {
  renderScene: () => React.ReactNode;
}

export const Activity2Illustration: React.FC<Activity2IllustrationProps> = ({
  compIndex,
  type,
}) => {
  // ─────────────────────────────────────────────────────────────
  // 캐릭터 포즈별 세부 렌더러 (자세, 몸의 기울기, 양손 동작 차별화)
  // ─────────────────────────────────────────────────────────────

  // 1. 공책에 몰입하여 직접 쓰는 자세 (상체 앞으로 기울어짐, 왼손 공책 지지, 오른손 연필 필기)
  const renderStudentWritingNotebook = (x = 55, y = 20) => (
    <g transform={`translate(${x}, ${y})`}>
      {/* Head leaning forward */}
      <circle cx="26" cy="22" r="17" fill="#fed7aa" />
      {/* Hair */}
      <path
        d="M9 22 C10 8 26 8 26 8 C26 8 43 8 43 22 C34 11 26 11 17 12 C12 13 9 22 9 22 Z"
        fill="#334155"
      />
      <path d="M9 22 Q 7 30 11 34 Q 13 25 17 22 Z" fill="#334155" />
      {/* Eyes looking down at notebook */}
      <ellipse cx="20" cy="24" rx="1.8" ry="2" fill="#1e293b" />
      <ellipse cx="30" cy="24" rx="1.8" ry="2" fill="#1e293b" />

      {/* Torso leaning forward */}
      <path
        d="M10 38 C10 38 18 36 26 36 C34 36 42 38 42 38 L48 78 L4 78 Z"
        fill="#3b82f6"
      />
      <polygon points="26,36 21,43 31,43" fill="#ffffff" />

      {/* Left arm holding notebook corner */}
      <path
        d="M10 46 C4 58 8 68 18 72"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="18" cy="72" r="4.5" fill="#fed7aa" />

      {/* Right arm writing with pencil */}
      <path
        d="M38 46 C44 58 40 70 28 75"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="28" cy="75" r="4.5" fill="#fed7aa" />
      {/* Pencil in right hand */}
      <g transform="translate(26, 68) rotate(40)">
        <rect x="0" y="0" width="4" height="22" rx="1" fill="#f59e0b" />
        <polygon points="0,0 4,0 2,-4" fill="#fde68a" />
        <polygon points="1,-2 3,-2 2,-4" fill="#1e293b" />
      </g>
    </g>
  );

  // 2. AI 참고하면서 공책에 정리하는 자세 (시선은 우측 화면 확인, 손은 공책에 연필 작성 유지)
  const renderStudentReferencingAndWriting = (x = 65, y = 20) => (
    <g transform={`translate(${x}, ${y})`}>
      {/* Head tilted slightly right towards tablet */}
      <circle cx="28" cy="22" r="17" fill="#fed7aa" />
      <path
        d="M11 22 C12 8 28 8 28 8 C28 8 45 8 45 22 C36 11 28 11 19 12 C14 13 11 22 11 22 Z"
        fill="#334155"
      />
      <path d="M11 22 Q 9 30 13 34 Q 15 25 19 22 Z" fill="#334155" />
      {/* Eyes glancing right to screen */}
      <ellipse cx="26" cy="23" rx="1.8" ry="2" fill="#1e293b" />
      <ellipse cx="36" cy="23" rx="1.8" ry="2" fill="#1e293b" />

      {/* Torso */}
      <path
        d="M12 38 C12 38 20 36 28 36 C36 36 44 38 44 38 L50 78 L6 78 Z"
        fill="#3b82f6"
      />
      <polygon points="28,36 23,43 33,43" fill="#ffffff" />

      {/* Left arm holding notebook */}
      <path
        d="M12 46 C6 58 4 68 12 73"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="12" cy="73" r="4.5" fill="#fed7aa" />

      {/* Right arm writing on notebook */}
      <path
        d="M40 46 C36 58 30 68 22 74"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="22" cy="74" r="4.5" fill="#fed7aa" />
      {/* Pencil */}
      <g transform="translate(20, 67) rotate(35)">
        <rect x="0" y="0" width="4" height="22" rx="1" fill="#f59e0b" />
        <polygon points="0,0 4,0 2,-4" fill="#fde68a" />
        <polygon points="1,-2 3,-2 2,-4" fill="#1e293b" />
      </g>
    </g>
  );

  // 3. AI 기기에 집중하여 손을 뻗어 조작/질문하는 자세 (상체 기기 쪽으로 쏠림, 손이 화면 터치)
  const renderStudentOperatingTablet = (x = 35, y = 20) => (
    <g transform={`translate(${x}, ${y})`}>
      {/* Head turned towards right tablet */}
      <circle cx="30" cy="22" r="17" fill="#fed7aa" />
      <path
        d="M13 22 C14 8 30 8 30 8 C30 8 47 8 47 22 C38 11 30 11 21 12 C16 13 13 22 13 22 Z"
        fill="#334155"
      />
      {/* Eyes looking straight at tablet */}
      <ellipse cx="27" cy="23" rx="1.8" ry="2" fill="#1e293b" />
      <ellipse cx="37" cy="23" rx="1.8" ry="2" fill="#1e293b" />

      {/* Torso leaning right */}
      <path
        d="M14 38 C14 38 22 36 30 36 C38 36 46 38 46 38 L54 78 L10 78 Z"
        fill="#3b82f6"
      />
      <polygon points="30,36 25,43 35,43" fill="#ffffff" />

      {/* Left arm resting on desk */}
      <path
        d="M14 46 C12 58 18 68 26 72"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="26" cy="72" r="4.5" fill="#fed7aa" />

      {/* Right arm reaching out directly to touch tablet screen */}
      <path
        d="M44 46 C56 54 68 60 78 63"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5.5"
        strokeLinecap="round"
      />
      <circle cx="78" cy="63" r="5" fill="#fed7aa" />
    </g>
  );

  // 4. 기기를 닫고 사용을 완전히 멈춘 동작 (상체는 편안히 뒤로 물러나고, 손은 닫힌 기기 덮개를 마무리하고 손을 뗌)
  const renderStudentClosingDevice = (x = 42, y = 20) => (
    <g transform={`translate(${x}, ${y})`}>
      {/* Head upright, looking at closed tablet */}
      <circle cx="26" cy="22" r="17" fill="#fed7aa" />
      <path
        d="M9 22 C10 8 26 8 26 8 C26 8 43 8 43 22 C34 11 26 11 17 12 C12 13 9 22 9 22 Z"
        fill="#334155"
      />
      <ellipse cx="23" cy="23" rx="1.8" ry="2" fill="#1e293b" />
      <ellipse cx="33" cy="23" rx="1.8" ry="2" fill="#1e293b" />

      {/* Torso upright */}
      <path
        d="M10 38 C10 38 18 36 26 36 C34 36 42 38 42 38 L48 78 L4 78 Z"
        fill="#3b82f6"
      />
      <polygon points="26,36 21,43 31,43" fill="#ffffff" />

      {/* Left arm resting naturally */}
      <path
        d="M10 46 C6 58 12 68 20 72"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="20" cy="72" r="4.5" fill="#fed7aa" />

      {/* Right arm having closed the cover, resting at the edge */}
      <path
        d="M40 46 C48 54 54 62 58 68"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="58" cy="68" r="4.5" fill="#fed7aa" />
    </g>
  );

  // 5. 메모지에 집중하여 필기하는 자세 (메모지 쪽으로 몸이 향함, 연필 필기)
  const renderStudentWritingMemo = (x = 55, y = 20) => (
    <g transform={`translate(${x}, ${y})`}>
      <circle cx="26" cy="22" r="17" fill="#fed7aa" />
      <path
        d="M9 22 C10 8 26 8 26 8 C26 8 43 8 43 22 C34 11 26 11 17 12 C12 13 9 22 9 22 Z"
        fill="#334155"
      />
      <ellipse cx="22" cy="24" rx="1.8" ry="2" fill="#1e293b" />
      <ellipse cx="32" cy="24" rx="1.8" ry="2" fill="#1e293b" />

      <path
        d="M10 38 C10 38 18 36 26 36 C34 36 42 38 42 38 L48 78 L4 78 Z"
        fill="#3b82f6"
      />
      <polygon points="26,36 21,43 31,43" fill="#ffffff" />

      <path
        d="M10 46 C6 58 12 68 20 72"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="20" cy="72" r="4.5" fill="#fed7aa" />

      <path
        d="M38 46 C42 58 36 68 28 74"
        fill="none"
        stroke="#2563eb"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="28" cy="74" r="4.5" fill="#fed7aa" />
      {/* Pencil */}
      <g transform="translate(26, 67) rotate(40)">
        <rect x="0" y="0" width="4" height="22" rx="1" fill="#f59e0b" />
        <polygon points="0,0 4,0 2,-4" fill="#fde68a" />
        <polygon points="1,-2 3,-2 2,-4" fill="#1e293b" />
      </g>
    </g>
  );

  // 6. 책상을 정리하고 일어서서 침대로 향하는 전신 자세
  const renderStudentWalkingToBed = (x = 78, y = 20) => (
    <g transform={`translate(${x}, ${y})`}>
      {/* Head */}
      <circle cx="18" cy="18" r="14" fill="#fed7aa" />
      <path
        d="M4 18 C5 6 18 6 18 6 C18 6 32 6 32 18 C25 9 18 9 11 10 C7 11 4 18 4 18 Z"
        fill="#334155"
      />
      <ellipse cx="20" cy="19" rx="1.6" ry="1.8" fill="#1e293b" />
      <ellipse cx="28" cy="19" rx="1.6" ry="1.8" fill="#1e293b" />

      {/* Torso */}
      <path
        d="M6 31 C6 31 12 29 18 29 C24 29 30 31 30 31 L34 62 L2 62 Z"
        fill="#3b82f6"
      />

      {/* Arms relaxing at side while walking */}
      <path
        d="M6 38 Q 2 48 8 58"
        fill="none"
        stroke="#2563eb"
        strokeWidth="4"
        strokeLinecap="round"
      />
      <circle cx="8" cy="58" r="3.5" fill="#fed7aa" />
      <path
        d="M30 38 Q 36 48 30 58"
        fill="none"
        stroke="#2563eb"
        strokeWidth="4"
        strokeLinecap="round"
      />
      <circle cx="30" cy="58" r="3.5" fill="#fed7aa" />

      {/* Legs walking right toward bed */}
      <rect x="7" y="62" width="8" height="26" rx="3" fill="#1e293b" />
      <rect x="21" y="62" width="8" height="26" rx="3" fill="#1e293b" />
      {/* Shoes */}
      <rect x="7" y="84" width="12" height="6" rx="2" fill="#64748b" />
      <rect x="21" y="84" width="12" height="6" rx="2" fill="#64748b" />
    </g>
  );

  const scenes: BigScene[] = [];

  // =============================================================
  // 비교 1: 수학 문제를 해결하는 두 기록
  // =============================================================
  if (compIndex === 0) {
    if (type === 'A') {
      // 기록 A - [장면 1] 학생 + 대형 공책 중심 (직접 연필로 풀이 과정 작성 중, 태블릿은 작게 우측 옆으로 밀려남)
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Left: Open textbook (reference) */}
            <g transform="translate(12, 68)">
              <rect x="0" y="0" width="38" height="42" rx="3" fill="#ffffff" stroke="#94a3b8" strokeWidth="1.4" />
              <line x1="19" y1="0" x2="19" y2="42" stroke="#e2e8f0" strokeWidth="1.2" />
              <rect x="4" y="6" width="11" height="3" rx="1" fill="#64748b" />
              <rect x="4" y="12" width="12" height="2" rx="0.8" fill="#cbd5e1" />
              <rect x="4" y="17" width="10" height="2" rx="0.8" fill="#cbd5e1" />
            </g>

            {/* Center: BIG Active Notebook (Primary Focus 70%) */}
            <g transform="translate(56, 48)">
              <rect x="0" y="0" width="96" height="74" rx="5" fill="#ffffff" stroke="#2563eb" strokeWidth="2.5" />
              <line x1="12" y1="0" x2="12" y2="74" stroke="#e2e8f0" strokeWidth="1.5" />
              {/* Clear written math formula lines */}
              <rect x="18" y="10" width="42" height="5" rx="1.5" fill="#2563eb" />
              <rect x="18" y="20" width="68" height="3.5" rx="1" fill="#1e293b" />
              <rect x="18" y="28" width="60" height="3.5" rx="1" fill="#1e293b" />
              <rect x="18" y="36" width="64" height="3.5" rx="1" fill="#1e293b" />
              <rect x="18" y="44" width="54" height="3.5" rx="1" fill="#475569" />
              <rect x="18" y="52" width="62" height="3.5" rx="1" fill="#475569" />
              <rect x="18" y="60" width="48" height="3.5" rx="1" fill="#475569" />
            </g>

            {/* Right: Inactive tablet pushed far to side (small, low contrast) */}
            <g transform="translate(172, 78)">
              <rect x="0" y="0" width="34" height="44" rx="3" fill="#cbd5e1" />
              <rect x="2.5" y="2.5" width="29" height="39" rx="2" fill="#f1f5f9" />
            </g>

            {/* Student actively leaning over notebook and writing */}
            {renderStudentWritingNotebook(40, 18)}
          </g>
        ),
      });

      // 기록 A - [장면 2] 공책 중심 유지 + 우측 AI 설명 참고하며 자기 풀이 정리
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Center-Left: Big Notebook still the primary workspace */}
            <g transform="translate(16, 46)">
              <rect x="0" y="0" width="98" height="76" rx="5" fill="#ffffff" stroke="#2563eb" strokeWidth="2.5" />
              <line x1="12" y1="0" x2="12" y2="76" stroke="#e2e8f0" strokeWidth="1.5" />
              {/* Previous math steps */}
              <rect x="18" y="10" width="40" height="4" rx="1" fill="#2563eb" />
              <rect x="18" y="18" width="66" height="3" rx="1" fill="#1e293b" />
              <rect x="18" y="25" width="60" height="3" rx="1" fill="#1e293b" />
              {/* Organized Final Solution Box being written */}
              <rect x="18" y="38" width="70" height="30" rx="3" fill="#eff6ff" stroke="#93c5fd" strokeWidth="1.4" />
              <rect x="24" y="44" width="56" height="4" rx="1" fill="#1d4ed8" />
              <rect x="24" y="52" width="48" height="3.5" rx="1" fill="#3b82f6" />
              <rect x="24" y="59" width="40" height="3.5" rx="1" fill="#3b82f6" />
            </g>

            {/* Right: AI Reference Tablet showing a clean hint bubble */}
            <g transform="translate(128, 48)">
              <rect x="0" y="0" width="80" height="72" rx="5" fill="#1e293b" stroke="#0f172a" strokeWidth="1.5" />
              <rect x="3.5" y="3.5" width="73" height="65" rx="3" fill="#ffffff" />
              {/* Clean hint bubble */}
              <rect x="8" y="12" width="64" height="48" rx="4" fill="#fffbeb" stroke="#fde047" strokeWidth="1.4" />
              <rect x="14" y="20" width="32" height="4" rx="1" fill="#b45309" />
              <rect x="14" y="29" width="52" height="3.5" rx="1" fill="#d97706" />
              <rect x="14" y="37" width="44" height="3.5" rx="1" fill="#d97706" />
              <rect x="14" y="45" width="40" height="3.5" rx="1" fill="#d97706" />
            </g>

            {/* Student glancing at AI screen while writing on notebook */}
            {renderStudentReferencingAndWriting(38, 16)}
          </g>
        ),
      });
    } else {
      // 기록 B - [장면 1] 학생 + 대형 AI 기기 중심 (공책은 비어있고, 손이 AI 화면 터치)
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Left: Open textbook and blank small notebook (inactive) */}
            <g transform="translate(12, 68)">
              <rect x="0" y="0" width="34" height="42" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.2" />
              <line x1="17" y1="0" x2="17" y2="42" stroke="#e2e8f0" strokeWidth="1" />
              <rect x="4" y="6" width="10" height="3" rx="1" fill="#94a3b8" />
            </g>
            <g transform="translate(50, 74)">
              <rect x="0" y="0" width="36" height="38" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.2" />
              <line x1="6" y1="0" x2="6" y2="38" stroke="#f1f5f9" strokeWidth="1" />
            </g>

            {/* Center-Right: BIG Prominent Tablet with AI Question & Solution (Clean & uncluttered) */}
            <g transform="translate(94, 38)">
              <rect x="0" y="0" width="112" height="84" rx="6" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
              <rect x="4" y="4" width="104" height="76" rx="4" fill="#ffffff" />
              {/* Question bubble */}
              <rect x="10" y="12" width="78" height="14" rx="3" fill="#e2e8f0" />
              <rect x="16" y="17" width="58" height="4" rx="1" fill="#334155" />
              {/* AI Answer block */}
              <rect x="10" y="32" width="94" height="42" rx="4" fill="#eff6ff" stroke="#bfdbfe" strokeWidth="1.4" />
              <rect x="16" y="40" width="38" height="4.5" rx="1" fill="#1d4ed8" />
              <rect x="16" y="49" width="80" height="3.5" rx="1" fill="#475569" />
              <rect x="16" y="57" width="70" height="3.5" rx="1" fill="#475569" />
              <rect x="16" y="65" width="60" height="3.5" rx="1" fill="#475569" />
            </g>

            {/* Student leaning right, body oriented to tablet, hand touching screen */}
            {renderStudentOperatingTablet(36, 16)}
          </g>
        ),
      });

      // 기록 B - [장면 2] 다음 문제도 대형 AI 기기 중심 (공책은 여전히 비어있고, 다시 AI 화면 확인)
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Left: Problem #2 open and blank small notebook */}
            <g transform="translate(12, 68)">
              <rect x="0" y="0" width="34" height="42" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.2" />
              <line x1="17" y1="0" x2="17" y2="42" stroke="#e2e8f0" strokeWidth="1" />
              <rect x="4" y="6" width="14" height="3" rx="1" fill="#94a3b8" />
              <rect x="4" y="12" width="8" height="3" rx="1" fill="#3b82f6" />
            </g>
            <g transform="translate(50, 74)">
              <rect x="0" y="0" width="36" height="38" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.2" />
              <line x1="6" y1="0" x2="6" y2="38" stroke="#f1f5f9" strokeWidth="1" />
            </g>

            {/* Center-Right: BIG Tablet with Next Question & Solution */}
            <g transform="translate(94, 38)">
              <rect x="0" y="0" width="112" height="84" rx="6" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
              <rect x="4" y="4" width="104" height="76" rx="4" fill="#ffffff" />
              {/* Next Question bubble */}
              <rect x="10" y="12" width="80" height="14" rx="3" fill="#e2e8f0" />
              <rect x="16" y="17" width="62" height="4" rx="1" fill="#334155" />
              {/* Next AI Answer block */}
              <rect x="10" y="32" width="94" height="42" rx="4" fill="#eff6ff" stroke="#bfdbfe" strokeWidth="1.4" />
              <rect x="16" y="40" width="42" height="4.5" rx="1" fill="#1d4ed8" />
              <rect x="16" y="49" width="82" height="3.5" rx="1" fill="#475569" />
              <rect x="16" y="57" width="72" height="3.5" rx="1" fill="#475569" />
              <rect x="16" y="65" width="64" height="3.5" rx="1" fill="#475569" />
            </g>

            {/* Student body and hand still directly focused on AI screen */}
            {renderStudentOperatingTablet(36, 16)}
          </g>
        ),
      });
    }
  }

  // =============================================================
  // 비교 2: 그림 아이디어를 찾는 두 기록
  // =============================================================
  if (compIndex === 1) {
    if (type === 'A') {
      // 기록 A - [장면 1] 시계 확인 후 태블릿 커버를 닫아 확실히 사용을 멈춘 동작! (화면 닫힘, 손을 뗌)
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Left: Desk Clock */}
            <g transform="translate(14, 60)">
              <rect x="0" y="0" width="36" height="48" rx="5" fill="#ffffff" stroke="#94a3b8" strokeWidth="1.5" />
              <circle cx="18" cy="22" r="14" fill="#f8fafc" stroke="#64748b" strokeWidth="1.2" />
              <circle cx="18" cy="22" r="1.5" fill="#1e293b" />
              <line x1="18" y1="22" x2="25" y2="26" stroke="#1e293b" strokeWidth="1.5" strokeLinecap="round" />
              <line x1="18" y1="22" x2="18" y2="13" stroke="#1e293b" strokeWidth="1.5" strokeLinecap="round" />
              <rect x="6" y="39" width="24" height="4" rx="1" fill="#e2e8f0" />
            </g>

            {/* Center-Right: CLEARLY CLOSED TABLET (Folded folio cover / screen closed) */}
            <g transform="translate(112, 54)">
              {/* Tablet back casing */}
              <rect x="0" y="0" width="94" height="66" rx="6" fill="#334155" stroke="#1e293b" strokeWidth="2" />
              {/* Closed magnetic folio cover with stylish neat fold */}
              <rect x="3" y="3" width="88" height="60" rx="4" fill="#475569" />
              <line x1="30" y1="3" x2="30" y2="63" stroke="#334155" strokeWidth="2" />
              {/* Small sleek metallic clasp / logo showing it's completely closed */}
              <rect x="42" y="27" width="16" height="9" rx="2.5" fill="#64748b" stroke="#334155" strokeWidth="1" />
              <circle cx="50" cy="31.5" r="1.8" fill="#94a3b8" />
            </g>

            {/* Student sitting comfortably back having closed the device */}
            {renderStudentClosingDevice(42, 18)}
          </g>
        ),
      });

      // 기록 A - [장면 2] 대형 노란 메모지 중심 (기기는 좌측에 닫힌 채 머물고, 메모지에 연필로 다음 아이디어 작성)
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Left: Closed tablet pushed aside & inactive */}
            <g transform="translate(12, 74)">
              <rect x="0" y="0" width="38" height="44" rx="3" fill="#475569" stroke="#334155" strokeWidth="1.2" />
              <line x1="14" y1="0" x2="14" y2="44" stroke="#334155" strokeWidth="1.2" />
            </g>

            {/* Center: BIG Yellow Idea Memo Pad (Primary Focus 70%) */}
            <g transform="translate(68, 44)">
              <rect x="0" y="0" width="108" height="78" rx="5" fill="#fef9c3" stroke="#fde047" strokeWidth="2.5" />
              {/* Memo Header */}
              <rect x="14" y="10" width="46" height="5.5" rx="1.5" fill="#854d0e" />
              {/* Bullet notes lines */}
              <circle cx="18" cy="26" r="2.8" fill="#ca8a04" />
              <rect x="26" y="23.5" width="68" height="4.5" rx="1" fill="#a16207" />
              <circle cx="18" cy="40" r="2.8" fill="#ca8a04" />
              <rect x="26" y="37.5" width="70" height="4.5" rx="1" fill="#a16207" />
              <circle cx="18" cy="54" r="2.8" fill="#ca8a04" />
              <rect x="26" y="51.5" width="58" height="4.5" rx="1" fill="#a16207" />
              <circle cx="18" cy="67" r="2.8" fill="#ca8a04" />
              <rect x="26" y="64.5" width="46" height="4.5" rx="1" fill="#a16207" />
            </g>

            {/* Student leaning in and actively writing on memo pad */}
            {renderStudentWritingMemo(40, 16)}
          </g>
        ),
      });
    } else {
      // 기록 B - [장면 1] 시계가 있어도 손이 기기 화면을 계속 조작하여 새 아이디어 하나 더 열기 (구도 동일)
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Left: Desk Clock (same position as A for direct comparison) */}
            <g transform="translate(14, 60)">
              <rect x="0" y="0" width="36" height="48" rx="5" fill="#ffffff" stroke="#94a3b8" strokeWidth="1.5" />
              <circle cx="18" cy="22" r="14" fill="#f8fafc" stroke="#64748b" strokeWidth="1.2" />
              <circle cx="18" cy="22" r="1.5" fill="#1e293b" />
              <line x1="18" y1="22" x2="25" y2="26" stroke="#1e293b" strokeWidth="1.5" strokeLinecap="round" />
              <line x1="18" y1="22" x2="18" y2="13" stroke="#1e293b" strokeWidth="1.5" strokeLinecap="round" />
              <rect x="6" y="39" width="24" height="4" rx="1" fill="#e2e8f0" />
            </g>

            {/* Right: BIG Active Tablet with 2 Clean Art Cards (Primary Focus 70%) */}
            <g transform="translate(94, 40)">
              <rect x="0" y="0" width="112" height="82" rx="6" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
              <rect x="4" y="4" width="104" height="74" rx="4" fill="#ffffff" />
              {/* Art card 1 */}
              <rect x="8" y="10" width="46" height="60" rx="3.5" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.4" />
              <circle cx="22" cy="28" r="7" fill="#fde047" />
              <rect x="14" y="48" width="34" height="4" rx="1" fill="#64748b" />
              <rect x="14" y="56" width="26" height="3" rx="1" fill="#94a3b8" />
              {/* Extra opened card 2 */}
              <rect x="58" y="10" width="46" height="60" rx="3.5" fill="#fffbeb" stroke="#fde68a" strokeWidth="1.6" />
              <polygon points="66,42 76,26 84,36 92,22 100,42" fill="#f59e0b" />
              <rect x="64" y="48" width="34" height="4" rx="1" fill="#d97706" />
              <rect x="64" y="56" width="26" height="3" rx="1" fill="#f59e0b" />
            </g>

            {/* Student leaning right with hand actively touching/tapping screen */}
            {renderStudentOperatingTablet(36, 16)}
          </g>
        ),
      });

      // 기록 B - [장면 2] 대형 기기 중심 유지 + 새로운 관련 아이디어 카드 3개 계속 탐색
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Left: Clock (time advanced) */}
            <g transform="translate(14, 60)">
              <rect x="0" y="0" width="36" height="48" rx="5" fill="#ffffff" stroke="#94a3b8" strokeWidth="1.5" />
              <circle cx="18" cy="22" r="14" fill="#f8fafc" stroke="#64748b" strokeWidth="1.2" />
              <circle cx="18" cy="22" r="1.5" fill="#1e293b" />
              <line x1="18" y1="22" x2="26" y2="27" stroke="#1e293b" strokeWidth="1.5" strokeLinecap="round" />
              <line x1="18" y1="22" x2="10" y2="30" stroke="#3b82f6" strokeWidth="1.5" strokeLinecap="round" />
              <rect x="6" y="39" width="24" height="4" rx="1" fill="#e2e8f0" />
            </g>

            {/* Center-Right: BIG Tablet with 3 Clean Continuous Cards */}
            <g transform="translate(94, 40)">
              <rect x="0" y="0" width="112" height="82" rx="6" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
              <rect x="4" y="4" width="104" height="74" rx="4" fill="#ffffff" />
              {/* 3 Large Clean Cascade Cards */}
              <rect x="8" y="10" width="30" height="60" rx="3" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.2" />
              <circle cx="23" cy="26" r="5" fill="#fde047" />
              <rect x="12" y="46" width="22" height="3.5" rx="1" fill="#64748b" />
              <rect x="12" y="53" width="16" height="3" rx="1" fill="#94a3b8" />

              <rect x="41" y="10" width="30" height="60" rx="3" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.2" />
              <polygon points="45,36 51,26 56,31 61,24 67,36" fill="#94a3b8" />
              <rect x="45" y="46" width="22" height="3.5" rx="1" fill="#64748b" />
              <rect x="45" y="53" width="16" height="3" rx="1" fill="#94a3b8" />

              <rect x="74" y="10" width="30" height="60" rx="3" fill="#fffbeb" stroke="#fde68a" strokeWidth="1.4" />
              <circle cx="89" cy="26" r="5" fill="#f59e0b" />
              <rect x="78" y="46" width="22" height="3.5" rx="1" fill="#d97706" />
              <rect x="78" y="53" width="16" height="3" rx="1" fill="#f59e0b" />
            </g>

            {/* Student still actively touching and scrolling screen */}
            {renderStudentOperatingTablet(36, 16)}
          </g>
        ),
      });
    }
  }

  // =============================================================
  // 비교 3: 숙제에 AI를 활용한 두 기록
  // =============================================================
  if (compIndex === 2) {
    if (type === 'A') {
      // 기록 A - [장면 1] 학생 + 대형 숙제 공책 중심 (AI 기기는 닫고, 숙제 작성에 몰입)
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Left: Closed / set aside tablet (small, inactive) */}
            <g transform="translate(12, 74)">
              <rect x="0" y="0" width="36" height="44" rx="3" fill="#475569" stroke="#334155" strokeWidth="1.2" />
              <line x1="14" y1="0" x2="14" y2="44" stroke="#334155" strokeWidth="1" />
            </g>

            {/* Center: BIG Homework Notebook (Primary Focus 70%) */}
            <g transform="translate(58, 44)">
              <rect x="0" y="0" width="112" height="78" rx="5" fill="#ffffff" stroke="#2563eb" strokeWidth="2.5" />
              <rect x="14" y="10" width="48" height="5.5" rx="1.5" fill="#2563eb" />
              <rect x="14" y="21" width="84" height="4" rx="1" fill="#1e293b" />
              <rect x="14" y="29" width="88" height="4" rx="1" fill="#1e293b" />
              <rect x="14" y="37" width="80" height="4" rx="1" fill="#1e293b" />
              <rect x="14" y="46" width="86" height="4" rx="1" fill="#475569" />
              <rect x="14" y="55" width="76" height="4" rx="1" fill="#475569" />
              <rect x="14" y="64" width="64" height="4" rx="1" fill="#475569" />
            </g>

            {/* Student diligently writing homework with pencil */}
            {renderStudentWritingNotebook(42, 16)}
          </g>
        ),
      });

      // 기록 A - [장면 2] 동일 방 구도: 책상 정리 완료 + 학생이 침대로 이동하여 잠잘 준비
      scenes.push({
        renderScene: () => (
          <g>
            {/* Night Tone Room Background */}
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#0f172a" opacity="0.06" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />

            {/* Window with moon (Same Position) */}
            <g transform="translate(14, 16)">
              <rect x="0" y="0" width="36" height="36" rx="4" fill="#1e293b" />
              <circle cx="18" cy="18" r="8" fill="#fde047" />
              <circle cx="22" cy="15" r="7" fill="#1e293b" />
            </g>

            {/* Left: Organized Desk (Books neatly stacked, tablet closed, lamp off) */}
            <g transform="translate(14, 66)">
              {/* Desk surface */}
              <rect x="0" y="30" width="60" height="5" rx="1.5" fill="#94a3b8" />
              {/* Stacked books */}
              <rect x="6" y="21" width="42" height="9" rx="2" fill="#3b82f6" />
              <rect x="8" y="12" width="38" height="9" rx="2" fill="#10b981" />
              <rect x="10" y="3" width="34" height="9" rx="2" fill="#f59e0b" />
              {/* Closed tablet on side */}
              <rect x="49" y="18" width="10" height="12" rx="1" fill="#475569" />
            </g>

            {/* Right: Same Cozy Bed with yellow blanket */}
            <g transform="translate(132, 60)">
              <rect x="0" y="0" width="78" height="54" rx="6" fill="#fef08a" stroke="#eab308" strokeWidth="2.2" />
              <rect x="8" y="6" width="26" height="18" rx="4" fill="#ffffff" stroke="#e2e8f0" strokeWidth="1.4" />
              <path d="M0 26 Q 39 20 78 26 L78 54 L0 54 Z" fill="#fde047" />
            </g>

            {/* Center: Student standing up from desk and walking right to bed */}
            {renderStudentWalkingToBed(72, 16)}
          </g>
        ),
      });
    } else {
      // 기록 B - [장면 1] 학생 + 대형 켜진 기기 중심 (숙제는 펼치지 않고 웹/AI 관련 내용 계속 탐색)
      scenes.push({
        renderScene: () => (
          <g>
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#f8fafc" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

            {/* Left: Unopened homework books sitting in corner (inactive) */}
            <g transform="translate(12, 74)">
              <rect x="0" y="0" width="42" height="42" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.4" />
              <rect x="6" y="6" width="20" height="4" rx="1" fill="#94a3b8" />
              <rect x="6" y="14" width="26" height="2.5" rx="1" fill="#cbd5e1" />
            </g>

            {/* Center-Right: BIG Active Tablet with Clean Browsing Content (Primary Focus 70%) */}
            <g transform="translate(94, 38)">
              <rect x="0" y="0" width="112" height="84" rx="6" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
              <rect x="4" y="4" width="104" height="76" rx="4" fill="#ffffff" />
              {/* Clean web article card */}
              <rect x="8" y="12" width="96" height="60" rx="4" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.4" />
              <rect x="16" y="20" width="54" height="5" rx="1" fill="#1e293b" />
              <rect x="16" y="32" width="80" height="4" rx="1" fill="#94a3b8" />
              <rect x="16" y="42" width="72" height="4" rx="1" fill="#94a3b8" />
              <rect x="16" y="52" width="64" height="4" rx="1" fill="#94a3b8" />
            </g>

            {/* Student absorbed in screen, hand pointing/touching */}
            {renderStudentOperatingTablet(36, 16)}
          </g>
        ),
      });

      // 기록 B - [장면 2] 동일 방 구도: 같은 침대가 기다리고 있지만, 학생은 아직 책상에서 스탠드 켜고 늦게까지 숙제 중
      scenes.push({
        renderScene: () => (
          <g>
            {/* Midnight Tone Room Background */}
            <rect x="0" y="0" width="220" height="140" rx="12" fill="#020617" opacity="0.10" />
            <line x1="10" y1="126" x2="210" y2="126" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />

            {/* Window with moon (Same Position) */}
            <g transform="translate(14, 16)">
              <rect x="0" y="0" width="36" height="36" rx="4" fill="#020617" stroke="#334155" strokeWidth="1.2" />
              <circle cx="18" cy="18" r="8" fill="#fef08a" />
              <circle cx="22" cy="15" r="7" fill="#020617" />
            </g>

            {/* Right: Same Cozy Bed sitting ready & empty (Same Position & Size as A) */}
            <g transform="translate(132, 60)">
              <rect x="0" y="0" width="78" height="54" rx="6" fill="#fef08a" stroke="#eab308" strokeWidth="2.2" opacity="0.85" />
              <rect x="8" y="6" width="26" height="18" rx="4" fill="#ffffff" stroke="#e2e8f0" strokeWidth="1.4" />
              <path d="M0 26 Q 39 20 78 26 L78 54 L0 54 Z" fill="#fde047" />
            </g>

            {/* Left: Desk with Lamp ON casting light on open homework notebook */}
            <g transform="translate(14, 52)">
              {/* Desk surface */}
              <rect x="0" y="44" width="76" height="5" rx="1.5" fill="#94a3b8" />

              {/* Lamp casting yellow light cone */}
              <polygon points="12,-6 24,-6 48,46 0,46" fill="#fef08a" opacity="0.35" />
              <polygon points="14,-14 22,-14 20,-6 16,-6" fill="#f59e0b" />
              <path d="M18,-14 Q 10 -22 6 -10 L 6 44" fill="none" stroke="#64748b" strokeWidth="2.5" />
              <rect x="2" y="42" width="8" height="3" rx="1" fill="#475569" />

              {/* Open homework notebook under lamp light */}
              <rect x="18" y="16" width="54" height="28" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
              <rect x="24" y="21" width="26" height="3" rx="1" fill="#64748b" />
              <rect x="24" y="27" width="42" height="2.5" rx="0.8" fill="#94a3b8" />
              <rect x="24" y="33" width="36" height="2.5" rx="0.8" fill="#94a3b8" />

              {/* Unorganized tablet near desk corner */}
              <rect x="68" y="26" width="10" height="18" rx="1.5" fill="#475569" />
            </g>

            {/* Student still sitting at the desk on the left, writing late into the night */}
            {renderStudentWritingNotebook(28, 16)}
          </g>
        ),
      });
    }
  }

  // ─────────────────────────────────────────────────────────────
  // 최종 렌더링: 가로로 연결된 2개의 큰 장면 + 심플 화살표 (높이 약 170~210px 확보)
  // ─────────────────────────────────────────────────────────────
  return (
    <div className="w-full bg-slate-50/90 rounded-2xl p-2.5 sm:p-3.5 border border-slate-200 shadow-2xs">
      <div className="flex items-center justify-between gap-1.5 sm:gap-3">
        {/* Large Scene 1 */}
        <div className="flex-1 bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden h-40 sm:h-48 md:h-52 flex items-center justify-center p-1 sm:p-2">
          <svg
            viewBox="0 0 220 140"
            className="w-full h-full max-h-full object-contain select-none"
            aria-hidden="true"
          >
            {scenes[0]?.renderScene()}
          </svg>
        </div>

        {/* Minimalist connecting transition arrow */}
        <div className="shrink-0 flex items-center justify-center text-slate-400 px-0.5">
          <svg
            className="w-4 h-4 sm:w-5 sm:h-5 text-slate-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <path d="M5 12h14" />
            <path d="M12 5l7 7-7 7" />
          </svg>
        </div>

        {/* Large Scene 2 */}
        <div className="flex-1 bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden h-40 sm:h-48 md:h-52 flex items-center justify-center p-1 sm:p-2">
          <svg
            viewBox="0 0 220 140"
            className="w-full h-full max-h-full object-contain select-none"
            aria-hidden="true"
          >
            {scenes[1]?.renderScene()}
          </svg>
        </div>
      </div>
    </div>
  );
};
