# 건강하게 AI 활용하기

초등학교 5~6학년을 위한 건강하고 주도적인 AI 활용 교육 웹앱

## Run locally:

1. npm install
2. npm run dev

별도의 API 키나 서버 설정은 필요하지 않습니다.
