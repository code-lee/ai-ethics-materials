# AI 판단 실험실 (AI Decision Lab)

초등학교 5~6학년 AI 교육용 웹 애플리케이션입니다. 학습 데이터의 구성에 따라 AI의 분류 판단 결과가 어떻게 달라지는지 직접 관찰하고 실험할 수 있는 순수 클라이언트 정적 시뮬레이터입니다.

## 실행 방법

```bash
npm install
npm run dev
npm run build
```
