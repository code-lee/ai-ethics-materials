import React, { useState } from 'react';
import { AlienSvg } from './AlienSvg';
import { TEST_ALIEN, EXTRA_ALIENS, INITIAL_DATASET } from '../data/aliens';
import { AlienData, ClassificationResult, ExperimentSnapshot } from '../types';

interface Step3LabProps {
  dataset: AlienData[];
  labelOverrides: Record<string, 'A' | 'B'>;
  experiments: ExperimentSnapshot[];
  activeTab: 'relabel' | 'add' | 'free';
  hasCalculatedCurrent: boolean;
  calculation: ClassificationResult | null;
  initialCalculation?: ClassificationResult | null;
  pendingPrediction: 'A행성' | 'B행성' | '판단하기 어려움' | '잘 모르겠다' | null;
  currentObservation: string;
  duplicateWarning: boolean;
  onSelectTab: (tab: 'relabel' | 'add' | 'free') => void;
  onChangeLabelOverride: (id: string, newPlanet: 'A' | 'B') => void;
  onToggleExtraItem: (extraItem: AlienData) => void;
  onResetTab: () => void;
  onChangePrediction: (prediction: 'A행성' | 'B행성' | '판단하기 어려움' | '잘 모르겠다') => void;
  onChangeObservation: (obs: string, snapshotId?: string) => void;
  onRecalculate: () => void;
  onNextStep: () => void;
  onOpenInfo: () => void;
}

export const Step3Lab: React.FC<Step3LabProps> = ({
  dataset,
  labelOverrides,
  experiments,
  activeTab,
  hasCalculatedCurrent,
  calculation,
  initialCalculation,
  pendingPrediction,
  currentObservation,
  duplicateWarning,
  onSelectTab,
  onChangeLabelOverride,
  onToggleExtraItem,
  onResetTab,
  onChangePrediction,
  onChangeObservation,
  onRecalculate,
  onNextStep,
  onOpenInfo,
}) => {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [limitWarning, setLimitWarning] = useState<string | null>(null);

  // Filter base dataset (A-1 ~ B-4) and extra candidates (A-5, A-6, B-5, B-6)
  const baseDataset = INITIAL_DATASET;
  const extraDataset = EXTRA_ALIENS;

  // Active count
  const activeCount = dataset.filter((d) => d.included).length;

  // Checks for unlocks (both experiment snapshot and observation must be filled)
  const hasCompletedRelabel = experiments.some(
    (e) => e.experimentType === 'relabel' && Boolean(e.observation?.trim())
  );
  const hasCompletedAdd = experiments.some(
    (e) => e.experimentType === 'add' && Boolean(e.observation?.trim())
  );
  const canGoToStep4 = hasCompletedRelabel && hasCompletedAdd;

  // Check if both required experiments completed and produced no change from initial AI baseline
  const relabelCompletedSnapshots = experiments.filter(
    (e) => e.experimentType === 'relabel' && Boolean(e.observation?.trim())
  );
  const addCompletedSnapshots = experiments.filter(
    (e) => e.experimentType === 'add' && Boolean(e.observation?.trim())
  );
  const allRequiredNoChange =
    hasCompletedRelabel &&
    hasCompletedAdd &&
    relabelCompletedSnapshots.every((e) => e.changedFromInitial === false) &&
    addCompletedSnapshots.every((e) => e.changedFromInitial === false);

  // Find latest snapshot for current tab
  const tabSnapshots = experiments.filter((e) => e.experimentType === activeTab);
  const latestTabSnapshot =
    tabSnapshots.length > 0 ? tabSnapshots[tabSnapshots.length - 1] : null;

  // Changed items in baseDataset
  const changedBaseItems = baseDataset.filter(
    (d) => labelOverrides[d.id] && labelOverrides[d.id] !== d.planet
  );
  const changedCount = changedBaseItems.length;

  // Added extra IDs
  const addedExtraIds = dataset
    .filter((d) => d.isExtra && d.included)
    .map((d) => d.id);

  // Data manipulation validation (1~4 allowed for relabel)
  const isDataManipulated =
    activeTab === 'relabel'
      ? changedCount >= 1 && changedCount <= 4
      : activeTab === 'add'
      ? addedExtraIds.length >= 1
      : changedCount >= 1 || addedExtraIds.length >= 1;

  const canRecalculate = Boolean(pendingPrediction) && isDataManipulated;

  const predictionOptions: Array<'A행성' | 'B행성' | '판단하기 어려움' | '잘 모르겠다'> = [
    'A행성',
    'B행성',
    '판단하기 어려움',
    '잘 모르겠다',
  ];

  // Handler for planet change with 1~4 items limit in relabel experiment
  const handlePlanetChange = (id: string, newPlanet: 'A' | 'B') => {
    setLimitWarning(null);
    const originalItem = baseDataset.find((d) => d.id === id);
    const originalPlanet = originalItem ? originalItem.planet : 'A';
    const currentPlanet = labelOverrides[id] || originalPlanet;

    if (currentPlanet === newPlanet) return;

    if (activeTab === 'relabel') {
      // If student is reverting back to original
      if (newPlanet === originalPlanet) {
        onChangeLabelOverride(id, newPlanet);
        return;
      }
      // If student is changing to a new label and already changed 4
      if (changedCount >= 4 && currentPlanet === originalPlanet) {
        setLimitWarning(
          '한 번의 실험에서는 최대 4개까지 바꿀 수 있어요. 다른 조합은 새 실험에서 다시 시험해 보세요.'
        );
        return;
      }
    }

    onChangeLabelOverride(id, newPlanet);
  };

  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col gap-6">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#f0e7d9] border border-[#e0e0e0] mb-3">
          <span className="w-2 h-2 rounded-full bg-[#1a237e] animate-pulse" />
          <span className="text-[11px] font-bold text-[#4d4634] uppercase tracking-wider">
            Step 3: 데이터 실험실
          </span>
        </div>
        <h2 className="text-3xl md:text-4xl font-bold text-[#1a237e]">
          학습 데이터를 바꾸면 AI의 판단도 달라질까?
        </h2>
        <p className="text-[#4d4634] mt-2 text-base">
          학습 데이터의 구성을 한 가지씩 바꾸어 보고, AI의 판단 결과를 비교해 보세요.
        </p>
      </div>

      {/* 3가지 실험 탭 선택 영역 */}
      <div className="bg-white rounded-2xl border border-[#e0e0e0] p-4 shadow-xs">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2">
            {/* Tab 1: relabel */}
            <button
              onClick={() => onSelectTab('relabel')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'relabel'
                  ? 'bg-[#1a237e] text-white shadow-xs'
                  : 'bg-[#f8f9fa] text-[#4d4634] border border-[#e0e0e0] hover:bg-[#f0e7d9]'
              }`}
            >
              <span className="material-symbols-outlined text-sm">swap_horiz</span>
              <span>실험 1 · 출신 행성 표시 바꿔 보기</span>
              {hasCompletedRelabel && (
                <span className="w-2 h-2 rounded-full bg-[#2e7d32]" title="완료됨" />
              )}
            </button>

            {/* Tab 2: add */}
            <button
              onClick={() => {
                if (hasCompletedRelabel) onSelectTab('add');
              }}
              disabled={!hasCompletedRelabel}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'add'
                  ? 'bg-[#1a237e] text-white shadow-xs'
                  : hasCompletedRelabel
                  ? 'bg-[#f8f9fa] text-[#4d4634] border border-[#e0e0e0] hover:bg-[#f0e7d9]'
                  : 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed'
              }`}
            >
              {!hasCompletedRelabel && (
                <span className="material-symbols-outlined text-sm">lock</span>
              )}
              {hasCompletedRelabel && (
                <span className="material-symbols-outlined text-sm">add_circle_outline</span>
              )}
              <span>실험 2 · 새로운 데이터 더해 보기</span>
              {hasCompletedAdd && (
                <span className="w-2 h-2 rounded-full bg-[#2e7d32]" title="완료됨" />
              )}
            </button>

            {/* Tab 3: free */}
            <button
              onClick={() => {
                if (canGoToStep4) onSelectTab('free');
              }}
              disabled={!canGoToStep4}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'free'
                  ? 'bg-[#1a237e] text-white shadow-xs'
                  : canGoToStep4
                  ? 'bg-[#f8f9fa] text-[#4d4634] border border-[#e0e0e0] hover:bg-[#f0e7d9]'
                  : 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed'
              }`}
            >
              {!canGoToStep4 && (
                <span className="material-symbols-outlined text-sm">lock</span>
              )}
              {canGoToStep4 && (
                <span className="material-symbols-outlined text-sm">tune</span>
              )}
              <span>실험 3 · 자유롭게 다시 구성하기</span>
            </button>
          </div>

          <div className="text-xs font-bold px-3 py-1.5 rounded-lg bg-[#fbf3e4] text-[#735c00] border border-[#e0e0e0]">
            전체 완료한 실험: {experiments.length}회
          </div>
        </div>

        {/* Experiment Tab Specific Mission Guidance */}
        <div className="mt-3 pt-3 border-t border-[#e0e0e0] flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
          {activeTab === 'relabel' && (
            <div>
              <div className="text-sm font-bold text-[#1a237e] flex items-center gap-1.5">
                <span className="material-symbols-outlined text-base text-[#735c00]">flag</span>
                AI가 배우는 데이터의 출신 행성 표시를 바꾸면 판단은 어떻게 될까요?
              </div>
              <div className="text-xs font-semibold text-[#1f1b12] mt-1">
                한 번에 1~4개의 출신 행성 표시를 바꾸어 비교해 보세요.
              </div>
              <div className="text-[11px] text-[#7f7662] mt-0.5">
                한 번에 조금씩 바꾸면 어떤 변화가 결과와 관련 있는지 비교하기 쉬워요.
              </div>
            </div>
          )}

          {activeTab === 'add' && (
            <div>
              <div className="text-sm font-bold text-[#1a237e] flex items-center gap-1.5">
                <span className="material-symbols-outlined text-base text-[#735c00]">flag</span>
                기존 학습 데이터에 새로운 데이터를 더하면 판단은 어떻게 될까요?
              </div>
              <div className="text-xs text-[#7f7662] mt-0.5">
                비교하기 쉽도록 처음 데이터 상태로 되돌렸어요. 이번에는 새로운 데이터를 더해 봅니다.
              </div>
            </div>
          )}

          {activeTab === 'free' && (
            <div>
              <div className="text-sm font-bold text-[#1a237e] flex items-center gap-1.5">
                <span className="material-symbols-outlined text-base text-[#735c00]">flag</span>
                이번에는 원하는 데이터 구성을 직접 만들어 보세요.
              </div>
              <div className="text-xs text-[#7f7662] mt-0.5">
                앞의 실험과 달리 이번에는 여러 데이터의 출신 행성 표시를 바꾸거나 새로운 데이터를 자유롭게 추가해 볼 수 있어요.
              </div>
            </div>
          )}

          {/* Quick status message */}
          <div className="text-xs font-semibold text-[#4d4634] bg-[#f0e7d9] px-3 py-1.5 rounded-lg shrink-0">
            {activeTab === 'relabel' &&
              (changedCount > 0
                ? `현재 바꾼 데이터: ${changedBaseItems
                    .map((d) => `${d.id} (${d.planet}행성 → ${labelOverrides[d.id]}행성)`)
                    .join(', ')}`
                : '현재 바꾼 데이터 없음 (1~4개 선택)')}
            {activeTab === 'add' &&
              (addedExtraIds.length > 0
                ? `현재 추가한 새 데이터: ${addedExtraIds.join(', ')}`
                : '현재 추가한 새 데이터 없음')}
            {activeTab === 'free' &&
              `바꾼 표시: ${changedCount}개 / 추가 데이터: ${addedExtraIds.length}개`}
          </div>
        </div>
      </div>

      {/* Limit Warning (if trying to change 5th in relabel) */}
      {limitWarning && (
        <div className="p-3 bg-[#ffd54f]/30 border border-[#ffd54f] rounded-xl text-xs text-[#735c00] font-bold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-base">info</span>
            <span>{limitWarning}</span>
          </div>
          <button
            onClick={() => setLimitWarning(null)}
            className="text-xs underline hover:text-[#1f1b12]"
          >
            닫기
          </button>
        </div>
      )}

      {/* 3 Column Layout */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Left Column: 학습 데이터 조작 영역 */}
        <section className="bg-white rounded-2xl border border-[#e0e0e0] p-5 flex flex-col gap-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between pb-2 border-b border-[#e0e0e0]">
            <h3 className="text-lg font-bold text-[#1a237e] flex items-center gap-2">
              <span className="material-symbols-outlined text-[#735c00]">folder_open</span>
              {activeTab === 'add' ? 'AI 학습 데이터 구성' : 'AI가 배운 학습 데이터'}
            </h3>
            <span className="text-xs font-bold text-[#735c00] bg-[#ffd54f]/30 px-2.5 py-0.5 rounded-full border border-[#ffd54f]">
              학습 포함: {activeCount}개
            </span>
          </div>

          {/* Scrollable list based on active tab */}
          <div className="flex-1 bg-[#fff8f0]/40 rounded-xl border border-[#e0e0e0] overflow-y-auto max-h-[480px] divide-y divide-[#e0e0e0]">
            {/* Section 1: Base Dataset (A-1 ~ B-4) */}
            <div className="p-2 bg-[#f0e7d9]/40 text-[11px] font-bold text-[#4d4634] flex items-center justify-between">
              <span>
                {activeTab === 'add'
                  ? '기본 학습 데이터 (8개 · 출신 행성 고정)'
                  : '기본 학습 데이터 (8개 · 출신 행성 선택)'}
              </span>
              {activeTab === 'add' && (
                <span className="text-[10px] font-semibold text-[#735c00]">
                  (실험 2에서는 기본 데이터가 고정됩니다)
                </span>
              )}
            </div>

            {baseDataset.map((item) => {
              const isSelected = selectedId === item.id;
              const originalPlanet = item.planet;
              const effectivePlanet = labelOverrides[item.id] || originalPlanet;
              const isLabelChanged = effectivePlanet !== originalPlanet;
              const isFixed = activeTab === 'add';

              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedId(isSelected ? null : item.id)}
                  className={`p-3 flex flex-col gap-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#ffd54f]/20 border-l-4 border-l-[#735c00]'
                      : isLabelChanged
                      ? 'bg-[#fffde7]'
                      : 'hover:bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-lg bg-white border border-[#e0e0e0] p-1 flex items-center justify-center shrink-0">
                        <AlienSvg
                          color={item.color}
                          eyes={item.eyes}
                          antennae={item.antennae}
                          pattern={item.pattern}
                          className="w-9 h-9"
                        />
                      </div>
                      <div className="flex flex-col">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`text-xs font-black px-1.5 py-0.5 rounded ${
                              effectivePlanet === 'A'
                                ? 'bg-[#e0e0ff] text-[#1a237e]'
                                : 'bg-[#ffdad6] text-[#ba1a1a]'
                            }`}
                          >
                            {item.id}
                          </span>
                          <span className="text-xs font-bold text-[#1f1b12]">
                            ({effectivePlanet}행성)
                          </span>
                          {isLabelChanged && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-[#fbf3e4] text-[#735c00] border border-[#d0c6ae]">
                              {originalPlanet}행성 → {effectivePlanet}행성
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-[#7f7662]">
                          {item.colorLabel} · 눈 {item.eyes}개 · 더듬이{' '}
                          {item.antennae ? '있음' : '없음'} · {item.patternLabel}
                        </span>
                      </div>
                    </div>

                    {/* Origin planet switcher */}
                    {!isFixed ? (
                      <div
                        className="flex items-center gap-1 bg-[#f0e7d9] p-1 rounded-lg border border-[#e0e0e0] shrink-0"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          type="button"
                          onClick={() => handlePlanetChange(item.id, 'A')}
                          className={`px-2 py-1 rounded text-xs font-bold transition-all ${
                            effectivePlanet === 'A'
                              ? 'bg-[#1a237e] text-white shadow-xs'
                              : 'bg-white text-[#4d4634] hover:bg-[#fff8f0]'
                          }`}
                        >
                          A행성
                        </button>
                        <button
                          type="button"
                          onClick={() => handlePlanetChange(item.id, 'B')}
                          className={`px-2 py-1 rounded text-xs font-bold transition-all ${
                            effectivePlanet === 'B'
                              ? 'bg-[#ba1a1a] text-white shadow-xs'
                              : 'bg-white text-[#4d4634] hover:bg-[#fff8f0]'
                          }`}
                        >
                          B행성
                        </button>
                      </div>
                    ) : (
                      <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-[#e0e0e0] text-[#4d4634]">
                        {effectivePlanet}행성 고정
                      </span>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Section 2: Extra Dataset Candidates (Only shown in Tab 2 and Tab 3) */}
            {(activeTab === 'add' || activeTab === 'free') && (
              <>
                <div className="p-2.5 bg-[#e8eaf6] text-[11px] font-bold text-[#1a237e] flex items-center justify-between border-t-2 border-[#1a237e]/20">
                  <span className="flex items-center gap-1">
                    <span className="material-symbols-outlined text-sm">stars</span>
                    새롭게 확인된 탐사 데이터
                  </span>
                  <span className="text-[10px] font-normal text-[#4d4634]">
                    선택하여 학습에 추가/제거
                  </span>
                </div>

                {extraDataset.map((candidate) => {
                  const existingItem = dataset.find((d) => d.id === candidate.id);
                  const isIncluded = existingItem ? existingItem.included : false;
                  const isSelected = selectedId === candidate.id;

                  return (
                    <div
                      key={candidate.id}
                      onClick={() => setSelectedId(isSelected ? null : candidate.id)}
                      className={`p-3 flex items-center justify-between transition-all cursor-pointer ${
                        !isIncluded
                          ? 'bg-[#fcfcfc] hover:bg-[#f5f5f5]'
                          : isSelected
                          ? 'bg-[#ffd54f]/20 border-l-4 border-l-[#735c00]'
                          : 'bg-[#fffde7] hover:bg-[#fff9c4]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-lg bg-white border border-[#e0e0e0] p-1 flex items-center justify-center shrink-0">
                          <AlienSvg
                            color={candidate.color}
                            eyes={candidate.eyes}
                            antennae={candidate.antennae}
                            pattern={candidate.pattern}
                            className="w-9 h-9"
                          />
                        </div>
                        <div className="flex flex-col">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`text-xs font-black px-1.5 py-0.5 rounded ${
                                candidate.planet === 'A'
                                  ? 'bg-[#e0e0ff] text-[#1a237e]'
                                  : 'bg-[#ffdad6] text-[#ba1a1a]'
                              }`}
                            >
                              {candidate.id}
                            </span>
                            <span className="text-xs font-bold text-[#1f1b12]">
                              ({candidate.planet}행성)
                            </span>
                            <span className="text-[10px] px-1.5 py-0.2 bg-[#f0e7d9] text-[#735c00] rounded font-semibold">
                              새 데이터
                            </span>
                          </div>
                          <span className="text-[11px] text-[#7f7662]">
                            {candidate.colorLabel} · 눈 {candidate.eyes}개 · 더듬이{' '}
                            {candidate.antennae ? '있음' : '없음'} · {candidate.patternLabel}
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleExtraItem(candidate);
                        }}
                        className={`px-2.5 py-1 rounded-full text-xs font-bold transition-colors ${
                          isIncluded
                            ? 'bg-[#1a237e] text-white hover:bg-[#27308a]'
                            : 'bg-white border border-[#d0c6ae] text-[#4d4634] hover:bg-[#f0e7d9]'
                        }`}
                      >
                        {isIncluded ? '✓ 추가됨' : '+ 학습 추가'}
                      </button>
                    </div>
                  );
                })}
              </>
            )}
          </div>

          {/* Quick Actions */}
          <div className="flex items-center justify-between pt-1">
            <span className="text-xs text-[#7f7662]">
              {activeTab === 'relabel' && '1~4개의 출신 행성 표시를 바꾸어 보세요.'}
              {activeTab === 'add' && '새 데이터를 추가해 보세요.'}
              {activeTab === 'free' && '자유롭게 조합해 보세요.'}
            </span>
            <button
              onClick={onResetTab}
              className="text-[#735c00] bg-[#ffd54f]/20 hover:bg-[#ffd54f]/40 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 border border-[#ffd54f]"
            >
              <span className="material-symbols-outlined text-sm">undo</span>
              <span>처음 상태로</span>
            </button>
          </div>
        </section>

        {/* Center Column: 동일한 판단 대상 (테스트 생명체) */}
        <section className="bg-white rounded-2xl border border-[#e0e0e0] p-6 flex flex-col items-center justify-center text-center shadow-sm relative overflow-hidden">
          <div className="absolute top-3 right-3 text-[#7f7662]/50">
            <span className="material-symbols-outlined text-xl">visibility</span>
          </div>

          <h3 className="text-xl font-bold text-[#1a237e] mb-4">AI가 판단할 생명체</h3>

          <div className="w-48 h-48 rounded-2xl border-4 border-[#f0e7d9] bg-[#f8f9fa] p-4 flex items-center justify-center mb-4 relative shadow-inner">
            <AlienSvg
              color={TEST_ALIEN.color}
              eyes={TEST_ALIEN.eyes}
              antennae={TEST_ALIEN.antennae}
              pattern={TEST_ALIEN.pattern}
              showScanner={true}
              className="w-36 h-36"
            />
            <div className="absolute bottom-2 left-2 bg-[#1a237e] text-white px-2 py-0.5 rounded text-[9px] font-mono">
              SUBJECT: UNKNOWN
            </div>
          </div>

          <div className="bg-[#ffd54f] px-5 py-2.5 rounded-full border border-[#ebc23e] shadow-xs mb-3">
            <p className="text-xs font-bold text-[#735c00] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-sm">info</span>
              판단할 생명체는 모든 실험에서 같아요.
            </p>
          </div>

          <div className="text-xs text-[#7f7662] space-y-0.5">
            <div>보라색 · 눈 1개 · 더듬이 있음 · 줄무늬</div>
          </div>
        </section>

        {/* Right Column: 예상 → 실행 → 결과 → 비교 */}
        <section className="bg-white rounded-2xl border border-[#e0e0e0] p-6 flex flex-col justify-between shadow-sm relative overflow-hidden gap-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#e0e0e0]">
            <h3 className="text-xl font-bold text-[#1a237e]">AI의 판단 결과</h3>
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-[#f0e7d9] text-[#735c00] border border-[#d0c6ae]">
              현재 탭 실험 {tabSnapshots.length}회
            </span>
          </div>

          {/* ① 먼저 예상하기 */}
          <div className="bg-[#fbf3e4] border border-[#d0c6ae] rounded-xl p-4 flex flex-col gap-2.5">
            <div className="text-xs font-bold text-[#735c00] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-base">psychology</span>
              <span>이 데이터로 다시 판단하면 어떤 결과가 나올 것 같나요?</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {predictionOptions.map((opt) => {
                const isSelected = pendingPrediction === opt;
                let btnStyle = '';

                if (hasCalculatedCurrent) {
                  btnStyle = isSelected
                    ? 'bg-[#1a237e] text-white shadow-xs cursor-default'
                    : 'bg-[#f5f5f5] text-gray-400 border border-gray-200 cursor-not-allowed opacity-60';
                } else {
                  btnStyle = isSelected
                    ? 'bg-[#1a237e] text-white shadow-xs'
                    : 'bg-white text-[#4d4634] border border-[#e0e0e0] hover:border-[#ffd54f] hover:bg-[#fffdf7]';
                }

                return (
                  <button
                    key={opt}
                    type="button"
                    disabled={hasCalculatedCurrent}
                    onClick={() => onChangePrediction(opt)}
                    className={`py-2 px-2.5 rounded-lg text-xs font-bold transition-all text-center ${btnStyle}`}
                  >
                    {isSelected ? `✓ ${opt}` : opt}
                  </button>
                );
              })}
            </div>

            {hasCalculatedCurrent ? (
              <p className="text-[11px] text-[#735c00] font-medium mt-0.5">
                * 이 예상은 결과를 보기 전에 선택한 내용이에요.
              </p>
            ) : !pendingPrediction ? (
              <p className="text-[11px] text-[#ba1a1a] font-semibold mt-0.5">
                * 예상을 먼저 선택해야 「다시 판단하기」를 누를 수 있습니다.
              </p>
            ) : null}
          </div>

          {/* Data manipulation guidance when not manipulated */}
          {!isDataManipulated && (
            <div className="p-3 bg-[#f0e7d9] border border-[#d0c6ae] rounded-xl text-xs text-[#4d4634] font-medium flex items-center gap-2">
              <span className="material-symbols-outlined text-sm text-[#735c00] shrink-0">info</span>
              <span>
                {activeTab === 'relabel' &&
                  '한 번에 1~4개의 출신 행성 표시를 바꾸어 비교해 보세요.'}
                {activeTab === 'add' &&
                  '새롭게 확인된 탐사 데이터에서 추가할 항목을 1개 이상 선택해 주세요.'}
                {activeTab === 'free' &&
                  '처음 상태와 다르게 출신 행성 표시를 바꾸거나 새 데이터를 추가해 주세요.'}
              </span>
            </div>
          )}

          {/* Duplicate Warning */}
          {duplicateWarning && (
            <div className="p-3 bg-[#ffdad6] border border-[#ba1a1a]/30 rounded-xl text-xs text-[#ba1a1a] font-semibold flex items-center gap-2">
              <span className="material-symbols-outlined text-sm shrink-0">warning</span>
              <span>이미 실험한 데이터 구성이에요. 다른 데이터를 바꾸어 비교해 보세요.</span>
            </div>
          )}

          {/* ② & ③ 다시 판단하기 실행 & AI의 실제 판단 */}
          <div className="bg-[#fff8f0] rounded-xl border border-[#e0e0e0] p-5 flex flex-col items-center justify-center text-center shadow-xs min-h-[140px]">
            {hasCalculatedCurrent && calculation ? (
              <div className="w-full flex flex-col items-center gap-2">
                <span className="text-xs font-bold text-[#7f7662] tracking-widest uppercase mb-1">
                  AI의 실제 판단
                </span>
                <div
                  className={`text-3xl md:text-4xl font-black ${
                    calculation.decision === 'A행성'
                      ? 'text-[#1a237e]'
                      : calculation.decision === 'B행성'
                      ? 'text-[#ba1a1a]'
                      : 'text-[#735c00]'
                  }`}
                >
                  {calculation.decision}
                </div>

                <div className="w-full pt-3 border-t border-[#e0e0e0] text-xs text-[#4d4634] space-y-1">
                  <div className="font-semibold text-[#1f1b12]">
                    가장 비슷한 학습 데이터:{' '}
                    <span className="text-[#1a237e] font-bold">
                      {calculation.topItemIds.length > 0
                        ? calculation.topItemIds
                            .map((id) => {
                              const override = labelOverrides[id];
                              const original = baseDataset.find((d) => d.id === id)?.planet;
                              if (override && original && override !== original) {
                                return `${id} (현재 출신: ${override}행성)`;
                              }
                              return id;
                            })
                            .join(' / ')
                        : '없음'}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#7f7662]">
                    일치한 특징:{' '}
                    <span className="font-bold text-[#1f1b12]">{calculation.topScore} / 4</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-xs font-semibold text-[#7f7662] py-4 text-center">
                아직 다시 판단하지 않았어요. 먼저 결과를 예상해 보세요.
              </div>
            )}
          </div>

          {/* ④ 예상과 비교하기 & 관찰 기록 */}
          {hasCalculatedCurrent && latestTabSnapshot && (
            <div className="bg-white border border-[#e0e0e0] rounded-xl p-4 flex flex-col gap-3 shadow-xs">
              <div className="grid grid-cols-3 gap-2 pb-3 border-b border-[#e0e0e0] text-center">
                <div className="bg-[#f8f9fa] p-2 rounded-lg border border-[#e0e0e0] flex flex-col items-center">
                  <span className="text-[10px] text-[#7f7662] font-semibold">내 예상</span>
                  <span className="text-xs font-bold text-[#1a237e] mt-0.5">
                    {latestTabSnapshot.predictedResult || '선택 안 됨'}
                  </span>
                </div>
                <div className="bg-[#f8f9fa] p-2 rounded-lg border border-[#e0e0e0] flex flex-col items-center">
                  <span className="text-[10px] text-[#7f7662] font-semibold">처음 AI 판단</span>
                  <span className="text-xs font-bold text-[#4d4634] mt-0.5">
                    {initialCalculation?.decision || 'A행성'}
                  </span>
                </div>
                <div className="bg-[#fff8f0] p-2 rounded-lg border border-[#ffd54f] flex flex-col items-center">
                  <span className="text-[10px] text-[#735c00] font-bold">이번 실험 AI 판단</span>
                  <span className="text-xs font-black text-[#ba1a1a] mt-0.5">
                    {latestTabSnapshot.result}
                  </span>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label htmlFor="obsInput" className="text-xs font-bold text-[#1f1b12]">
                  데이터를 바꾼 뒤 AI의 판단은 처음과 비교해 어떻게 되었나요?
                </label>
                <input
                  id="obsInput"
                  type="text"
                  value={currentObservation}
                  onChange={(e) => onChangeObservation(e.target.value, latestTabSnapshot.id)}
                  placeholder="결과를 비교해 한 문장으로 적어 보세요."
                  className="w-full p-2.5 bg-[#fff8f0] border border-[#e0e0e0] rounded-lg text-xs focus:outline-none focus:border-[#ffd54f] focus:ring-2 focus:ring-[#ffd54f]/30"
                />
                {(!currentObservation || currentObservation.trim().length === 0) && (
                  <span className="text-[10px] text-[#ba1a1a] font-semibold">
                    * 관찰한 점을 적어야 이 실험이 완료됩니다.
                  </span>
                )}
              </div>

              {/* 다른 조합으로 한 번 더 실험하기 버튼 */}
              <div className="pt-2 border-t border-[#e0e0e0] flex items-center justify-between">
                <span className="text-[11px] text-[#7f7662]">
                  다른 조합으로 시험해 볼까요?
                </span>
                <button
                  type="button"
                  onClick={onResetTab}
                  className="px-3 py-1.5 bg-[#f0e7d9] text-[#735c00] hover:bg-[#ebdcc8] rounded-lg text-xs font-bold transition-all border border-[#d0c6ae] flex items-center gap-1"
                >
                  <span className="material-symbols-outlined text-sm">refresh</span>
                  <span>다른 조합으로 한 번 더 실험하기</span>
                </button>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-2.5 pt-1">
            <button
              onClick={onRecalculate}
              disabled={!canRecalculate}
              className="w-full bg-[#ffd54f] text-[#735c00] py-3.5 rounded-xl text-base font-bold hover:bg-[#ffe087] transition-all border-b-4 border-[#ebc23e] active:border-b-0 active:translate-y-1 shadow-sm disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-xl">restart_alt</span>
              <span>다시 판단하기</span>
            </button>

            {/* Navigation based on progress */}
            {canGoToStep4 ? (
              <div className="flex flex-col gap-2 pt-1">
                <button
                  onClick={onNextStep}
                  className="w-full bg-[#1a237e] text-white py-3 rounded-xl text-sm font-bold hover:bg-[#27308a] transition-all flex items-center justify-center gap-2 shadow-xs"
                >
                  <span>4단계: 탐사 결과 분석하기</span>
                  <span className="material-symbols-outlined text-sm">arrow_forward</span>
                </button>

                {activeTab !== 'free' && (
                  <button
                    onClick={() => onSelectTab(activeTab === 'relabel' ? 'add' : 'free')}
                    className="w-full bg-[#f0e7d9] text-[#4d4634] py-2 rounded-xl text-xs font-bold hover:bg-[#eae2d3] transition-all border border-[#d0c6ae] flex items-center justify-center gap-1.5"
                  >
                    <span>
                      {activeTab === 'relabel' ? '실험 2로 이동하기' : '실험 3으로 이동하기'}
                    </span>
                    <span className="material-symbols-outlined text-sm">arrow_forward</span>
                  </button>
                )}
              </div>
            ) : hasCompletedRelabel && activeTab === 'relabel' ? (
              <button
                onClick={() => onSelectTab('add')}
                className="w-full bg-[#1a237e] text-white py-3 rounded-xl text-sm font-bold hover:bg-[#27308a] transition-all flex items-center justify-center gap-2 shadow-xs"
              >
                <span>실험 2로 이동하기</span>
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            ) : (
              <div className="text-center p-2.5 bg-[#f8f9fa] rounded-xl border border-[#e0e0e0] text-xs text-[#7f7662]">
                실험 1(출신 행성 표시 바꾸기)과 실험 2(새 데이터 더하기)를 모두 관찰 기록까지
                작성해야 4단계로 갈 수 있어요.
                <div className="font-bold text-[#735c00] mt-0.5">
                  (실험 1: {hasCompletedRelabel ? '완료 ✓' : '진행 중'}, 실험 2:{' '}
                  {hasCompletedAdd ? '완료 ✓' : '잠김 🔒'})
                </div>
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Neutral Suggestion for Additional Exploration if all required experiments kept the same result */}
      {allRequiredNoChange && (
        <div className="bg-[#fbf3e4] border-2 border-[#d0c6ae] rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm animate-in fade-in duration-300">
          <div className="flex items-start gap-3">
            <span className="material-symbols-outlined text-[#735c00] text-2xl shrink-0 mt-0.5">
              explore
            </span>
            <div className="text-xs text-[#4d4634] space-y-1">
              <p className="text-sm font-bold text-[#1f1b12]">
                두 실험에서는 AI의 판단이 그대로였네요. 다른 데이터 구성을 한 번 더 시험해 보면 어떤 결과가 나올까요?
              </p>
              <p className="text-xs text-[#7f7662]">
                실험 3에서 여러 데이터의 출신 행성 표시를 바꾸거나 새로운 데이터를 자유롭게 조합해 볼 수 있어요.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onSelectTab('free')}
            className="shrink-0 px-4 py-2.5 bg-[#ffd54f] text-[#735c00] rounded-xl text-xs font-bold hover:bg-[#ffe087] transition-all border-b-2 border-[#ebc23e] active:border-b-0 active:translate-y-0.5 flex items-center gap-1.5 shadow-xs"
          >
            <span className="material-symbols-outlined text-sm">tune</span>
            <span>한 번 더 자유롭게 실험해 보기</span>
          </button>
        </div>
      )}

      {/* Floating Info Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onOpenInfo}
          className="bg-white border border-[#e0e0e0] shadow-sm rounded-full px-4 py-2.5 flex items-center gap-2 hover:bg-[#fff8f0] transition-colors text-xs font-bold text-[#1a237e]"
        >
          <span className="material-symbols-outlined text-base">help</span>
          <span>이 실험의 AI는?</span>
        </button>
      </div>
    </div>
  );
};
