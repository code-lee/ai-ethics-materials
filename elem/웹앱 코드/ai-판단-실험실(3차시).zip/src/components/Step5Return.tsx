import React, { useState } from 'react';
import { AppState } from '../types';
import yellowFlowerImage from '../assets/images/yellow_flower_1787276789825.jpg';

interface Step5ReturnProps {
  appState: AppState;
  choice: string | null;
  reason: string;
  principle: string;
  isSubmitted: boolean;
  onSelectChoice: (choice: string) => void;
  onChangeReason: (val: string) => void;
  onChangePrinciple: (val: string) => void;
  onSubmit: () => void;
  onRestartAll: () => void;
}

const CHOICES = [
  { id: 'ai1_trust', label: 'AI 1의 결과를 믿고 민들레라고 판단한다.', short: 'AI 1의 결과 믿기' },
  { id: 'ai2_trust', label: 'AI 2의 결과를 믿고 씀바귀라고 판단한다.', short: 'AI 2의 결과 믿기' },
  { id: 'preference_trust', label: '두 AI 중 더 마음에 드는 결과를 선택한다.', short: '마음에 드는 결과 선택' },
  { id: 'verify_more', label: '다른 자료와 정보를 더 확인해 본다.', short: '다른 자료 더 확인하기' },
];

export const Step5Return: React.FC<Step5ReturnProps> = ({
  appState,
  choice,
  reason,
  principle,
  isSubmitted,
  onSelectChoice,
  onChangeReason,
  onChangePrinciple,
  onSubmit,
  onRestartAll,
}) => {
  const [showRestartConfirm, setShowRestartConfirm] = useState(false);

  // Step 1 values
  const step1ChoiceLabel =
    appState.step1Prediction === 'A'
      ? 'A행성'
      : appState.step1Prediction === 'B'
      ? 'B행성'
      : appState.step1Prediction === 'unknown'
      ? '잘 모르겠다'
      : '작성하지 않음';

  const step1AiDecision = appState.step1AiResult?.decision || 'A행성';

  // Step 2 hypothesis (학생이 입력하지 않았을 경우 임의 정답 자동 생성 금지)
  const getHypothesisChangesText = () => {
    const changes = appState.step2HypothesisChanges || [];
    if (changes.length === 0) {
      if (appState.step2HypothesisChange && appState.step2HypothesisChange.trim().length > 0) {
        return appState.step2HypothesisChange;
      }
      return null;
    }
    const hasRelabel = changes.includes('relabel');
    const hasAdd = changes.includes('add');
    if (hasRelabel && hasAdd) return '출신 행성 표시 바꾸기 · 새로운 데이터 더하기';
    if (hasRelabel) return '출신 행성 표시 바꾸기';
    if (hasAdd) return '새로운 데이터 더하기';
    return null;
  };

  const hypChangesText = getHypothesisChangesText();
  const hypPredText = appState.step2HypothesisPrediction?.trim() || null;

  const hypothesisFull =
    hypChangesText && hypPredText
      ? `[변화를 줄 부분] ${hypChangesText} → [예상] ${hypPredText}`
      : hypChangesText
      ? `[변화를 줄 부분] ${hypChangesText}`
      : hypPredText
      ? `[예상] ${hypPredText}`
      : '작성하지 않음';

  // Step 3 values (experiments snapshot 기반)
  const experimentCount = appState.experiments?.length || 0;
  const experimentsList = appState.experiments || [];
  const lastExp =
    experimentsList.length > 0
      ? experimentsList[experimentsList.length - 1]
      : null;

  const formatExperimentChanges = () => {
    if (!lastExp) {
      return appState.modificationLogs.length > 0
        ? appState.modificationLogs.join(', ')
        : '기본 8개 데이터 유지';
    }
    const parts: string[] = [];
    if (lastExp.labelChanges && lastExp.labelChanges.length > 0) {
      parts.push(`표시변경(${lastExp.labelChanges.map((lc) => `${lc.id}: ${lc.from}→${lc.to}`).join(', ')})`);
    }
    if (lastExp.addedDataIds && lastExp.addedDataIds.length > 0) {
      parts.push(`추가(${lastExp.addedDataIds.join(', ')})`);
    }
    if (parts.length === 0) {
      return '기본 8개 데이터 전체 포함';
    }
    return parts.join(' / ');
  };

  const modifiedDataLog = formatExperimentChanges();

  const initialDecision = appState.step1AiResult?.decision || 'A행성';
  const finalDecision = lastExp ? lastExp.result : appState.step3Calculation?.decision || initialDecision;
  const beforeAfterDecision = `실험 전 [${initialDecision}] → 최종 실험 후 [${finalDecision}]`;

  // Step 4 values (학생이 작성하지 않았을 경우 임의 정답 자동 대입 금지)
  const step4Finding =
    (appState.step4Q3 && appState.step4Q3.trim().length > 0 ? appState.step4Q3 : null) ||
    (appState.step4Q2 && appState.step4Q2.trim().length > 0 ? appState.step4Q2 : null) ||
    (appState.step4Q1 && appState.step4Q1.trim().length > 0 ? appState.step4Q1 : null) ||
    '작성하지 않음';

  const [imageError, setImageError] = useState(false);

  const canCheckThoughts = choice !== null && reason.trim().length > 0;

  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col gap-8">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#f0e7d9] border border-[#e0e0e0] mb-3">
          <span className="w-2 h-2 rounded-full bg-[#1a237e] animate-pulse" />
          <span className="text-[11px] font-bold text-[#4d4634] uppercase tracking-wider">
            MISSION FINAL STAGE
          </span>
        </div>
        <h2 className="text-3xl md:text-5xl font-bold text-[#1f1b12]">
          지구에서도 AI를 만난다면?
        </h2>
        <p className="text-base md:text-lg text-[#4d4634] mt-3">
          우주 탐사선에서 배운 AI의 원리를 지구의 일상생활에 적용해 봅시다.
        </p>
      </div>

      {/* 12 Column Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Scenario & Choices (7 Cols) */}
        <div className="md:col-span-7 flex flex-col gap-6">
          {/* Scenario Card */}
          <div className="bg-white border border-[#e0e0e0] rounded-2xl overflow-hidden shadow-sm relative">
            <div className="p-5 border-b border-[#e0e0e0] bg-[#fbf3e4]/60">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="material-symbols-outlined text-[#735c00] text-xl">psychology</span>
                <h3 className="text-lg font-bold text-[#1f1b12]">상황 관찰</h3>
              </div>
              <p className="text-sm text-[#4d4634] leading-relaxed">
                지민이는 학교 화단에서 처음 보는 노란 식물을 발견했다. 한 AI 앱은 같은 사진을 보고 '<strong>민들레</strong>'라고 했지만, 다른 AI 앱은 '<strong>씀바귀</strong>'라고 판단했다.
              </p>
            </div>

            <div className="p-6 bg-[#f8f9fa] flex flex-col sm:flex-row gap-6 items-center">
              {/* Plant Photo (Local project asset) */}
              <div className="w-full sm:w-1/2">
                <div className="aspect-square rounded-xl overflow-hidden border border-[#e0e0e0] relative shadow-inner bg-white flex items-center justify-center">
                  {!imageError ? (
                    <img
                      src={yellowFlowerImage}
                      alt="학교 화단에서 발견한 노란 꽃"
                      referrerPolicy="no-referrer"
                      onError={() => setImageError(true)}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-[#fbf3e4] text-[#735c00] flex flex-col items-center justify-center text-xs font-bold p-3 text-center">
                      <span className="material-symbols-outlined text-2xl mb-1 text-[#735c00]">eco</span>
                      <span>노란 꽃 관찰 이미지</span>
                    </div>
                  )}
                  <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-xs text-white px-2 py-0.5 rounded text-[10px]">
                    화단 관찰 사진 #01
                  </div>
                </div>
              </div>

              {/* AI 1 vs AI 2 Verdicts (근거 없는 학습 설명 완전 삭제) */}
              <div className="w-full sm:w-1/2 flex flex-col gap-3">
                <div className="p-4 bg-white rounded-xl border border-[#e0e0e0] shadow-xs">
                  <div className="text-[11px] font-bold text-[#7f7662] mb-1">AI 1의 판단</div>
                  <div className="text-2xl font-bold text-[#735c00]">민들레</div>
                </div>

                <div className="p-4 bg-white rounded-xl border border-[#ba1a1a]/30 shadow-xs">
                  <div className="text-[11px] font-bold text-[#7f7662] mb-1">AI 2의 판단</div>
                  <div className="text-2xl font-bold text-[#ba1a1a]">씀바귀</div>
                </div>

                <div className="text-[11px] text-center text-[#7f7662] italic bg-[#f0e7d9]/60 p-2 rounded-lg">
                  사진만으로는 정확히 판단하기 어려울 수 있어요.
                </div>
              </div>
            </div>
          </div>

          {/* Question Card */}
          <div className="bg-white border border-[#e0e0e0] rounded-2xl p-6 shadow-sm">
            <h4 className="text-lg font-bold text-[#1f1b12] mb-4">
              지민이는 어떻게 하는 것이 좋을까요?
            </h4>

            <div className="flex flex-col gap-2.5">
              {CHOICES.map((c) => (
                <label
                  key={c.id}
                  className={`flex items-center gap-3 p-3.5 border rounded-xl cursor-pointer transition-all ${
                    choice === c.id
                      ? 'border-[#735c00] bg-[#ffd54f]/15 shadow-[0_0_0_1px_#735c00]'
                      : 'border-[#e0e0e0] hover:border-[#ffd54f] hover:bg-[#fff8f0]'
                  }`}
                >
                  <input
                    type="radio"
                    name="actionChoice"
                    value={c.id}
                    checked={choice === c.id}
                    onChange={() => onSelectChoice(c.id)}
                    className="w-4 h-4 text-[#735c00] focus:ring-[#735c00]"
                  />
                  <span className="text-sm font-semibold text-[#1f1b12]">{c.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Follow-up Reason Card & Check Thoughts */}
          <div className="bg-white border border-[#e0e0e0] rounded-2xl p-6 shadow-sm flex flex-col gap-4">
            <div>
              <label htmlFor="step5ReasonInput" className="block text-lg font-bold text-[#1f1b12] mb-2">
                왜 그렇게 생각했나요?
              </label>
              <textarea
                id="step5ReasonInput"
                value={reason}
                onChange={(e) => onChangeReason(e.target.value)}
                placeholder="선택한 까닭을 자신의 생각으로 적어 보세요."
                rows={3}
                className="w-full p-3.5 border border-[#e0e0e0] rounded-xl bg-[#fff8f0] focus:ring-2 focus:ring-[#ffd54f]/40 focus:border-[#ffd54f] outline-none transition-all resize-none text-sm"
              />
            </div>

            {/* 생각 확인하기 버튼 (선택지 + 이유 작성 후 클릭 가능) */}
            <div className="flex justify-start">
              <button
                onClick={onSubmit}
                disabled={!canCheckThoughts}
                className="px-6 py-3 bg-[#ffd54f] text-[#735c00] font-bold text-sm rounded-xl hover:bg-[#ffe087] transition-all border-b-4 border-[#ebc23e] active:border-b-0 active:translate-y-1 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-lg">psychology_alt</span>
                <span>{isSubmitted ? '생각 다시 확인하기' : '생각 확인하기'}</span>
              </button>
            </div>

            {/* 피드백 표시 (생각 확인하기 버튼을 누른 후 표시) */}
            {isSubmitted && (
              <div className="mt-2 p-5 bg-[#fbf3e4] rounded-xl border border-[#d0c6ae] text-sm text-[#4d4634] leading-relaxed animate-in fade-in duration-300">
                <div className="flex items-center gap-2 mb-2">
                  <span className="material-symbols-outlined text-[#735c00] text-xl">lightbulb</span>
                  <span className="font-bold text-[#735c00] text-base">탐구 생각 확인하기</span>
                </div>
                <p>
                  같은 자료에 대해서도 AI가 서로 다른 결과를 제시할 수 있어요. 중요한 판단일수록 다른 자료나 정보도 함께 확인하는 것이 좋아요.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Principle & Final Report (5 Cols) */}
        <div className="md:col-span-5 flex flex-col gap-6">
          {/* Principle Definition */}
          <div className="bg-white border border-[#e0e0e0] text-[#1f1b12] rounded-2xl p-6 shadow-sm">
            <h3 className="text-xl font-bold text-[#735c00] mb-2 flex items-center gap-2">
              <span className="material-symbols-outlined">gavel</span>
              나의 AI 활용 원칙
            </h3>
            <p className="text-xs text-[#4d4634] mb-4">
              외계 생명체 분류 미션을 통해 알게 된 AI의 특징을 바탕으로, 앞으로 AI를 사용할 때의 다짐을 적어 보세요.
            </p>

            <div className="bg-[#fbf3e4] rounded-xl p-4 border border-[#d0c6ae]">
              <p className="text-sm font-bold text-[#1f1b12] mb-2">
                "AI의 결과를 볼 때 나는 ______________________________."
              </p>
              <textarea
                value={principle}
                onChange={(e) => onChangePrinciple(e.target.value)}
                placeholder="내가 기억하고 싶은 원칙을 한 문장으로 적어 보세요."
                rows={3}
                className="w-full p-2.5 border-b-2 border-[#ffd54f] bg-transparent text-sm text-[#1f1b12] placeholder:text-[#7f7662] focus:outline-none focus:border-[#735c00] transition-colors resize-none"
              />
            </div>
          </div>

          {/* Final Exploration Report Bento Grid */}
          <div className="bg-[#fbf3e4] border border-[#e0e0e0] rounded-2xl p-6 flex flex-col shadow-sm">
            <div className="flex justify-between items-center border-b border-[#e0e0e0] pb-3 mb-4">
              <h3 className="text-lg font-bold text-[#1f1b12] flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1a237e]">description</span>
                나의 AI 탐사 보고서
              </h3>
              <div className="flex gap-1">
                <span className="w-2 h-2 rounded-full bg-[#d0c6ae]" />
                <span className="w-2 h-2 rounded-full bg-[#d0c6ae]" />
                <span className="w-2 h-2 rounded-full bg-[#d0c6ae]" />
              </div>
            </div>

            {/* Bento Grid */}
            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div className="col-span-1 p-2.5 bg-white border border-[#e0e0e0] rounded-lg">
                <span className="text-[10px] text-[#7f7662] block mb-0.5 font-semibold">처음 예상한 판단</span>
                <span className="font-bold text-[#1f1b12]">{step1ChoiceLabel}</span>
              </div>

              <div className="col-span-1 p-2.5 bg-white border border-[#e0e0e0] rounded-lg">
                <span className="text-[10px] text-[#7f7662] block mb-0.5 font-semibold">AI의 처음 판단</span>
                <span className="font-bold text-[#735c00]">{step1AiDecision}</span>
              </div>

              <div className="col-span-2 p-2.5 bg-white border border-[#e0e0e0] rounded-lg">
                <span className="text-[10px] text-[#7f7662] block mb-0.5 font-semibold">내가 세운 가설</span>
                <span className="font-medium text-[#1f1b12] line-clamp-2">{hypothesisFull}</span>
              </div>

              <div className="col-span-1 p-2.5 bg-white border border-[#e0e0e0] rounded-lg">
                <span className="text-[10px] text-[#7f7662] block mb-0.5 font-semibold">실험 횟수</span>
                <span className="font-black text-sm text-[#735c00]">{experimentCount}회</span>
              </div>

              <div className="col-span-1 p-2.5 bg-white border border-[#e0e0e0] rounded-lg">
                <span className="text-[10px] text-[#7f7662] block mb-0.5 font-semibold">바꾸어 본 학습 데이터</span>
                <span className="font-medium text-[#1f1b12] truncate block">{modifiedDataLog}</span>
              </div>

              <div className="col-span-2 p-2.5 bg-white border border-[#e0e0e0] rounded-lg">
                <span className="text-[10px] text-[#7f7662] block mb-1 font-semibold">실험별 예상과 실제 판단 내역</span>
                {experimentsList.length > 0 ? (
                  <div className="space-y-1">
                    {experimentsList.map((exp) => {
                      const typeLabel =
                        exp.experimentType === 'relabel'
                          ? '출신 행성 표시 바꾸기'
                          : exp.experimentType === 'add'
                          ? '새 데이터 더하기'
                          : exp.experimentType === 'free'
                          ? '자유 구성'
                          : '';
                      return (
                        <div key={exp.id} className="text-[11px] flex items-center justify-between bg-[#fbf3e4] px-2 py-1 rounded">
                          <span className="font-bold text-[#1a237e]">
                            실험 {exp.experimentNumber}회 {typeLabel ? `(${typeLabel})` : ''}
                          </span>
                          <span className="text-[#4d4634]">
                            예상: <strong>{exp.predictedResult || '-'}</strong> → 실제 판단:{' '}
                            <strong className="text-[#ba1a1a]">{exp.result}</strong>
                          </span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <span className="text-[11px] text-[#7f7662]">기록된 실험이 없습니다.</span>
                )}
              </div>

              <div className="col-span-2 p-2.5 bg-white border border-[#e0e0e0] rounded-lg">
                <span className="text-[10px] text-[#7f7662] block mb-0.5 font-semibold">판단 결과의 변화</span>
                <span className="font-bold text-[#1a237e]">{beforeAfterDecision}</span>
              </div>

              <div className="col-span-2 p-2.5 bg-white border-l-4 border-l-[#ffd54f] border-[#e0e0e0] rounded-lg">
                <span className="text-[10px] text-[#7f7662] block mb-0.5 font-semibold">내가 발견한 점</span>
                <span className="font-medium text-[#1f1b12]">{step4Finding}</span>
              </div>

              <div className="col-span-2 p-2.5 bg-white border-l-4 border-l-[#735c00] border-[#e0e0e0] rounded-lg">
                <span className="text-[10px] text-[#7f7662] block mb-0.5 font-semibold">나의 AI 활용 원칙</span>
                <span className="font-medium text-[#1f1b12]">
                  {principle.trim().length > 0 ? principle : '작성하지 않음'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Restart Action Area */}
      <div className="flex justify-center mt-6 pb-12">
        {!showRestartConfirm ? (
          <button
            onClick={() => setShowRestartConfirm(true)}
            className="flex items-center gap-2.5 px-8 py-4 bg-[#ffd54f] text-[#735c00] text-base md:text-lg font-bold rounded-xl hover:bg-[#ffe087] hover:-translate-y-0.5 transition-all duration-200 border-b-4 border-[#ebc23e] active:border-b-0 active:translate-y-1 shadow-md"
          >
            <span className="material-symbols-outlined text-2xl">restart_alt</span>
            <span>처음부터 다시 탐사하기</span>
          </button>
        ) : (
          <div className="p-4 bg-white rounded-2xl border-2 border-[#ffd54f] shadow-lg flex flex-col sm:flex-row items-center gap-4">
            <span className="text-sm font-bold text-[#1f1b12]">
              정말로 모든 탐사 기록을 초기화하고 처음부터 다시 시작할까요?
            </span>
            <div className="flex gap-2">
              <button
                onClick={onRestartAll}
                className="px-4 py-2 bg-[#ba1a1a] text-white rounded-lg text-xs font-bold hover:bg-[#93000a] transition-colors"
              >
                초기화 시작
              </button>
              <button
                onClick={() => setShowRestartConfirm(false)}
                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg text-xs font-bold hover:bg-gray-300 transition-colors"
              >
                취소
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

