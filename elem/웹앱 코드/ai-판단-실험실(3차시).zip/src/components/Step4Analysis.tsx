import React, { useState } from 'react';
import { AlienSvg } from './AlienSvg';
import { TEST_ALIEN } from '../data/aliens';
import { ClassificationResult, ExperimentSnapshot } from '../types';

interface Step4AnalysisProps {
  initialCalculation: ClassificationResult | null;
  experiments: ExperimentSnapshot[];
  q1: string;
  q2: string;
  q3: string;
  q4?: string;
  isRevealed: boolean;
  onChangeQ1: (val: string) => void;
  onChangeQ2: (val: string) => void;
  onChangeQ3: (val: string) => void;
  onChangeQ4?: (val: string) => void;
  onReveal: () => void;
  onNextStep: () => void;
}

export const Step4Analysis: React.FC<Step4AnalysisProps> = ({
  initialCalculation,
  experiments,
  q1,
  q2,
  q3,
  isRevealed,
  onChangeQ1,
  onChangeQ2,
  onChangeQ3,
  onReveal,
  onNextStep,
}) => {
  const [selectedExpIndex, setSelectedExpIndex] = useState<number>(() =>
    Math.max(0, experiments.length - 1)
  );

  const activeIndex =
    selectedExpIndex < experiments.length ? selectedExpIndex : Math.max(0, experiments.length - 1);
  const activeSnapshot: ExperimentSnapshot | undefined = experiments[activeIndex];

  const allFilled =
    q1.trim().length > 0 &&
    q2.trim().length > 0 &&
    q3.trim().length > 0;

  const getExperimentTypeLabel = (snap?: ExperimentSnapshot) => {
    if (!snap) return '';
    if (snap.experimentType === 'relabel') return '실험 1 · 출신 행성 표시 바꾸기';
    if (snap.experimentType === 'add') return '실험 2 · 새 데이터 더하기';
    if (snap.experimentType === 'free') return '실험 3 · 자유 구성';
    return `실험 ${snap.experimentNumber}회차`;
  };

  const formatSnapshotChanges = (snap?: ExperimentSnapshot) => {
    if (!snap) return '기본 학습 데이터 유지';
    const parts: string[] = [];
    if (snap.labelChanges && snap.labelChanges.length > 0) {
      const labelText = snap.labelChanges
        .map((lc) => `${lc.id} (${lc.from}행성 → ${lc.to}행성)`)
        .join(', ');
      parts.push(`출신 행성 표시 변경: ${labelText}`);
    }
    if (snap.addedDataIds && snap.addedDataIds.length > 0) {
      parts.push(`추가한 데이터: ${snap.addedDataIds.join(', ')}`);
    }
    if (parts.length === 0) {
      return '기본 8개 데이터 모두 포함 (데이터 변경 없음)';
    }
    return parts.join(' | ');
  };

  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col gap-6">
      {/* Header */}
      <div className="text-center flex flex-col items-center gap-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#f0e7d9] border border-[#e0e0e0]">
          <span className="w-2 h-2 rounded-full bg-[#735c00] animate-pulse" />
          <span className="text-[11px] font-bold text-[#4d4634] uppercase tracking-wider">
            STEP 04 ANALYSIS
          </span>
        </div>
        <h2 className="text-3xl md:text-4xl font-bold text-[#1f1b12]">
          AI 판단의 특징을 찾아라
        </h2>

        <div className="bg-[#ffd54f]/30 px-6 py-2.5 rounded-full border border-[#ffd54f] inline-flex items-center gap-2">
          <span className="material-symbols-outlined text-[#735c00] text-lg">info</span>
          <span className="text-sm font-bold text-[#735c00]">
            두 실험에서 판단한 생명체는 동일합니다.
          </span>
        </div>

        {/* Small Visual of Test Alien */}
        <div className="p-3 bg-[#fbf3e4] rounded-xl border border-[#e0e0e0] inline-flex items-center gap-3 mt-1 shadow-xs">
          <div className="w-14 h-14 rounded-lg bg-white p-1 border border-[#e0e0e0] flex items-center justify-center">
            <AlienSvg
              color={TEST_ALIEN.color}
              eyes={TEST_ALIEN.eyes}
              antennae={TEST_ALIEN.antennae}
              pattern={TEST_ALIEN.pattern}
              className="w-12 h-12"
            />
          </div>
          <div className="text-left text-xs">
            <div className="font-bold text-[#1f1b12]">판단 대상: 미지의 생명체</div>
            <div className="text-[#7f7662]">보라색 · 눈 1개 · 더듬이 있음 · 줄무늬</div>
          </div>
        </div>

        {/* Experiment Snapshot Selector (if multiple experiments) */}
        {experiments.length > 1 && (
          <div className="flex items-center gap-2 mt-2 bg-[#fbf3e4] p-1.5 rounded-full border border-[#e0e0e0] flex-wrap justify-center">
            <span className="text-[11px] font-bold text-[#7f7662] px-2">비교할 실험:</span>
            {experiments.map((exp, idx) => (
              <button
                key={exp.id}
                onClick={() => setSelectedExpIndex(idx)}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                  activeIndex === idx
                    ? 'bg-[#1a237e] text-white shadow-xs'
                    : 'bg-white text-[#4d4634] hover:bg-[#f0e7d9] border border-[#e0e0e0]'
                }`}
              >
                {getExperimentTypeLabel(exp)} (실험 {exp.experimentNumber}회)
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Comparison Grid: Baseline vs Modified Snapshot */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Experiment A (Baseline) */}
        <div className="bg-white rounded-2xl border border-[#e0e0e0] overflow-hidden flex flex-col shadow-sm">
          <div className="bg-[#fbf3e4] px-5 py-3.5 border-b border-[#e0e0e0] flex justify-between items-center">
            <h3 className="text-sm font-bold text-[#1f1b12]">처음 상태</h3>
            <span className="bg-[#1a237e] text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              Baseline
            </span>
          </div>

          <div className="p-5 flex-1 flex flex-col justify-between gap-4">
            <div className="w-full py-8 bg-[#fff8f0] rounded-xl border border-[#e0e0e0] flex flex-col items-center justify-center text-center">
              <span className="material-symbols-outlined text-4xl text-[#1a237e] opacity-60 mb-2">
                analytics
              </span>
              <div className="text-xs text-[#7f7662] mb-1">AI의 판단 결과</div>
              <div className="text-2xl font-black text-[#1a237e]">
                {initialCalculation ? initialCalculation.decision : 'A행성'}
              </div>
              <div className="text-xs text-[#4d4634] mt-2 bg-white px-3 py-1 rounded-full border border-[#e0e0e0]">
                가장 비슷한 데이터:{' '}
                <strong>
                  {initialCalculation && initialCalculation.topItemIds.length > 0
                    ? initialCalculation.topItemIds.join(', ')
                    : 'A-4'}
                </strong>
                {initialCalculation ? ` (${initialCalculation.topScore}개 일치)` : ''}
              </div>
            </div>

            <div className="text-xs text-[#4d4634] bg-[#fbf3e4] p-3 rounded-lg border border-[#e0e0e0] border-dashed">
              <span className="font-semibold">학습 데이터 상태:</span> 기본 데이터 8개 모두 포함
            </div>
          </div>
        </div>

        {/* Experiment B (Modified Snapshot) */}
        <div className="bg-white rounded-2xl border border-[#e0e0e0] overflow-hidden flex flex-col shadow-sm">
          <div className="bg-[#fbf3e4] px-5 py-3.5 border-b border-[#e0e0e0] flex justify-between items-center">
            <h3 className="text-sm font-bold text-[#1f1b12]">
              선택한 실험 ({getExperimentTypeLabel(activeSnapshot)})
            </h3>
            <span className="bg-[#ba1a1a] text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              Modified
            </span>
          </div>

          <div className="p-5 flex-1 flex flex-col justify-between gap-4">
            <div className="w-full py-8 bg-[#fff8f0] rounded-xl border border-[#e0e0e0] flex flex-col items-center justify-center text-center">
              <span className="material-symbols-outlined text-4xl text-[#ba1a1a] opacity-60 mb-2">
                change_circle
              </span>
              <div className="text-xs text-[#7f7662] mb-1">실험 후 AI 판단</div>
              <div
                className={`text-2xl font-black ${
                  activeSnapshot?.result === 'A행성'
                    ? 'text-[#1a237e]'
                    : activeSnapshot?.result === 'B행성'
                    ? 'text-[#ba1a1a]'
                    : 'text-[#735c00]'
                }`}
              >
                {activeSnapshot ? activeSnapshot.result : '먼저 ‘다시 판단하기’를 눌러 주세요.'}
              </div>
              <div className="text-xs text-[#4d4634] mt-2 bg-white px-3 py-1 rounded-full border border-[#e0e0e0]">
                가장 비슷한 데이터:{' '}
                <strong>
                  {activeSnapshot && activeSnapshot.closestDataIds.length > 0
                    ? activeSnapshot.closestDataIds.join(', ')
                    : '없음'}
                </strong>
                {activeSnapshot ? ` (${activeSnapshot.highestScore}개 일치)` : ''}
              </div>
            </div>

            <div className="text-xs text-[#4d4634] bg-[#fbf3e4] p-3 rounded-lg border border-[#e0e0e0] flex flex-col gap-2">
              <div>
                <span className="font-semibold text-[#1f1b12]">바꾼 학습 데이터:</span>{' '}
                {formatSnapshotChanges(activeSnapshot)}
              </div>
              {activeSnapshot?.predictedResult && (
                <div className="flex items-center gap-1.5 pt-1 border-t border-[#e0e0e0] border-dashed">
                  <span className="font-semibold text-[#735c00]">실험 전 나의 예상:</span>
                  <span className="font-bold text-[#1a237e] bg-white px-2 py-0.5 rounded border border-[#e0e0e0]">
                    {activeSnapshot.predictedResult}
                  </span>
                </div>
              )}
              {activeSnapshot?.observation && activeSnapshot.observation.trim().length > 0 && (
                <div className="pt-1 border-t border-[#e0e0e0] border-dashed">
                  <span className="font-semibold text-[#1f1b12]">실험 중 나의 관찰:</span>{' '}
                  <span className="text-[#4d4634] italic">{activeSnapshot.observation}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Research Journal Module */}
      <div className="bg-white rounded-2xl border border-[#e0e0e0] p-6 md:p-8 shadow-sm">
        <div className="flex items-center gap-2 mb-6 pb-3 border-b border-[#e0e0e0]">
          <span className="material-symbols-outlined text-[#735c00] text-2xl">edit_document</span>
          <h3 className="text-xl font-bold text-[#1f1b12]">연구 일지 작성</h3>
        </div>

        <div className="flex flex-col gap-6">
          {/* Q1 */}
          <div className="flex flex-col gap-2">
            <label htmlFor="q1Anal" className="text-sm font-semibold text-[#1f1b12] flex items-center gap-2">
              <span className="text-[#735c00] font-bold">1.</span>
              실험 1과 실험 2에서 학습 데이터를 각각 어떻게 바꾸었나요?
            </label>
            <textarea
              id="q1Anal"
              value={q1}
              onChange={(e) => onChangeQ1(e.target.value)}
              placeholder="실험 1과 실험 2에서 데이터를 어떻게 바꾸었는지 각각 적어 보세요."
              rows={2}
              className="w-full bg-[#fff8f0] border border-[#e0e0e0] rounded-xl p-3 text-sm focus:outline-none focus:border-[#ffd54f] focus:ring-2 focus:ring-[#ffd54f]/30 transition-all resize-none"
            />
          </div>

          {/* Q2 */}
          <div className="flex flex-col gap-2">
            <label htmlFor="q2Anal" className="text-sm font-semibold text-[#1f1b12] flex items-center gap-2">
              <span className="text-[#735c00] font-bold">2.</span>
              데이터를 바꾼 뒤 AI의 판단은 처음과 비교해 어떻게 되었나요?
            </label>
            <textarea
              id="q2Anal"
              value={q2}
              onChange={(e) => onChangeQ2(e.target.value)}
              placeholder="두 실험에서 AI의 판단이 어떻게 달라졌거나 유지되었는지 비교해 적어 보세요."
              rows={2}
              className="w-full bg-[#fff8f0] border border-[#e0e0e0] rounded-xl p-3 text-sm focus:outline-none focus:border-[#ffd54f] focus:ring-2 focus:ring-[#ffd54f]/30 transition-all resize-none"
            />
          </div>

          {/* Q3 */}
          <div className="flex flex-col gap-2">
            <label htmlFor="q3Anal" className="text-sm font-semibold text-[#1f1b12] flex items-center gap-2">
              <span className="text-[#735c00] font-bold">3.</span>
              두 실험을 통해 학습 데이터와 AI의 판단 사이에 어떤 관계가 있다고 생각하나요?
            </label>
            <textarea
              id="q3Anal"
              value={q3}
              onChange={(e) => onChangeQ3(e.target.value)}
              placeholder="두 실험 결과를 바탕으로 내가 생각한 관계를 적어 보세요."
              rows={3}
              className="w-full bg-[#fff8f0] border border-[#e0e0e0] rounded-xl p-3 text-sm focus:outline-none focus:border-[#ffd54f] focus:ring-2 focus:ring-[#ffd54f]/30 transition-all resize-none"
            />
          </div>

          {/* Reveal Button */}
          {!isRevealed && (
            <div className="flex justify-center mt-2">
              <button
                onClick={onReveal}
                disabled={!allFilled}
                className="px-8 py-3.5 bg-[#ffd54f] text-[#735c00] font-bold text-base rounded-xl hover:bg-[#ffe087] transition-all border-b-4 border-[#ebc23e] active:border-b-0 active:translate-y-1 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-xl">lightbulb</span>
                <span>핵심 내용 확인하기</span>
              </button>
            </div>
          )}
        </div>

        {/* Revealed Core Concept */}
        {isRevealed && (
          <div className="mt-8 p-6 md:p-8 bg-[#ffd54f]/20 border-2 border-[#735c00] rounded-2xl flex flex-col items-center text-center gap-4 animate-in fade-in duration-300 shadow-sm">
            <div className="w-12 h-12 rounded-full bg-[#ffd54f] flex items-center justify-center text-[#735c00] shadow-xs">
              <span className="material-symbols-outlined text-2xl">verified</span>
            </div>

            <h4 className="text-xl md:text-2xl font-bold text-[#1f1b12] max-w-2xl leading-relaxed">
              "이 실험의 AI는 학습 데이터의 특징과 새로운 생명체의 특징을 비교하여 결과를 만들어요.
              <br />
              <span className="text-[#735c00] underline decoration-[#ffd54f] decoration-4">
                학습 데이터의 내용이나 분류 정보가 달라지면 같은 자료에 대한 AI의 판단 결과도 달라질 수 있어요.
              </span>
              "
            </h4>

            <p className="text-xs md:text-sm text-[#4d4634] max-w-xl leading-relaxed">
              같은 생명체 자료라도 AI가 어떤 자료를 배우고, 그 자료가 어떻게 분류되어 있는지에 따라 판단이 달라질 수 있어요.
            </p>

            <button
              onClick={onNextStep}
              className="mt-4 px-8 py-3.5 bg-[#1a237e] text-white font-bold text-base rounded-xl hover:bg-[#27308a] transition-all flex items-center gap-2 shadow-md"
            >
              <span>5단계: 지구 귀환 미션 가기</span>
              <span className="material-symbols-outlined text-lg">arrow_forward</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
