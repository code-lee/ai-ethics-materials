import React from 'react';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-[#ffffff] border-2 border-[#ffd54f] rounded-2xl p-6 max-w-lg w-full shadow-2xl relative">
        <div className="flex items-center justify-between pb-3 border-b border-[#e0e0e0] mb-4">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#735c00] text-2xl">lightbulb</span>
            <h3 className="text-xl font-bold text-[#1f1b12]">이 실험의 AI는?</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#f6edde] hover:bg-[#eae2d3] flex items-center justify-center text-[#4d4634] transition-colors"
          >
            <span className="material-symbols-outlined text-lg">close</span>
          </button>
        </div>

        <div className="space-y-4 text-[#1f1b12] text-sm leading-relaxed">
          <div className="p-4 bg-[#fbf3e4] rounded-xl border border-[#d0c6ae]">
            <p className="font-semibold text-[#735c00] mb-1">💡 학습용 시뮬레이션 안내</p>
            <p className="text-[#4d4634]">
              이 웹앱은 AI의 분류 과정을 쉽게 체험할 수 있도록 단순화한 학습용 시뮬레이션이에요. 실제 AI는 더 많은 데이터와 다양한 방법을 사용할 수 있어요.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-[#1a237e] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-sm">hub</span>
              탐사선 AI의 판단 알고리즘
            </h4>
            <p className="text-[#4d4634]">
              이 실험의 AI는 <strong>4가지 특징(몸 색깔, 눈 개수, 더듬이 유무, 무늬)</strong>을 관찰하여, 새로운 생명체와 특징이 일치할 때마다 <strong>+1점</strong>씩 점수를 매깁니다.
            </p>
            <ul className="list-disc pl-5 space-y-1 text-[#4d4634] text-xs">
              <li>가장 점수가 높은 학습 데이터가 모두 <strong>A행성</strong>이면 → <strong>A행성</strong>으로 판단</li>
              <li>가장 점수가 높은 학습 데이터가 모두 <strong>B행성</strong>이면 → <strong>B행성</strong>으로 판단</li>
              <li>A행성과 B행성의 최고 점수가 같으면 → <strong>판단하기 어려움</strong>으로 결정</li>
            </ul>
            <p className="text-xs text-[#7f7662] pt-1">
              * AI 학습에서는 데이터에 붙어 있는 정답이나 분류 정보를 ‘라벨(Label)’이라고 부르기도 해요.
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-[#ffd54f] text-[#735c00] font-bold rounded-xl hover:bg-[#ffe087] transition-all duration-150 border-b-2 border-[#ebc23e]"
          >
            확인했습니다
          </button>
        </div>
      </div>
    </div>
  );
};
