import React, { useState } from 'react';

interface NavigationProps {
  currentStep: number;
  maxUnlockedStep: number;
  onSelectStep: (step: number) => void;
}

const STEP_ITEMS = [
  { step: 1, label: '미지의 생명체 발견', icon: 'rocket_launch' },
  { step: 2, label: 'AI의 기억 창고', icon: 'database' },
  { step: 3, label: '데이터 실험실', icon: 'science' },
  { step: 4, label: '탐사 결과 분석', icon: 'analytics' },
  { step: 5, label: '지구 귀환 미션', icon: 'public' },
];

export const Navigation: React.FC<NavigationProps> = ({
  currentStep,
  maxUnlockedStep,
  onSelectStep,
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Top Header */}
      <header className="bg-[#fff8f0]/95 backdrop-blur-md border-b border-[#e0e0e0] flex justify-between items-center w-full px-6 h-16 sticky top-0 z-30 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden text-[#4d4634] p-2 -ml-2 rounded-lg hover:bg-[#f0e7d9] transition-colors"
            aria-label="메뉴 열기"
          >
            <span className="material-symbols-outlined">{mobileOpen ? 'close' : 'menu'}</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#1a237e] animate-pulse" />
            <h1 className="text-xl font-bold text-[#735c00] tracking-tight">AI Decision Lab</h1>
            <span className="hidden sm:inline-block text-xs font-semibold px-2 py-0.5 rounded bg-[#f0e7d9] text-[#735c00] border border-[#d0c6ae]">
              AI 판단 실험실
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-medium text-[#4d4634] bg-[#fbf3e4] px-3 py-1.5 rounded-full border border-[#e0e0e0]">
            초등 5~6학년 AI 교육 탐사선
          </span>
        </div>
      </header>

      {/* Mobile Drawer Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/30 backdrop-blur-xs z-40 md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Side Navigation (Mission Control) */}
      <aside
        className={`fixed left-0 top-0 h-screen w-72 bg-[#fbf3e4] border-r border-[#e0e0e0] z-50 flex flex-col p-4 transition-transform duration-200 ease-in-out md:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="mb-6 px-3 pt-2">
          <h2 className="text-2xl font-bold text-[#735c00] flex items-center gap-2">
            <span className="material-symbols-outlined text-[#735c00]">satellite_alt</span>
            AI Decision Lab
          </h2>
          <div className="mt-2 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#1a237e]" />
            <p className="text-[11px] font-bold text-[#7f7662] tracking-widest uppercase">Mission Control</p>
          </div>
          <p className="text-xs text-[#4d4634] mt-1 opacity-80 leading-relaxed">
            AI는 무엇을 바탕으로 판단할까?
          </p>
        </div>

        <nav className="flex-1 space-y-2">
          {STEP_ITEMS.map((item) => {
            const isActive = currentStep === item.step;
            const isLocked = item.step > maxUnlockedStep;

            return (
              <button
                key={item.step}
                disabled={isLocked}
                onClick={() => {
                  if (!isLocked) {
                    onSelectStep(item.step);
                    setMobileOpen(false);
                  }
                }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-left font-semibold text-sm transition-all duration-200 ${
                  isActive
                    ? 'bg-[#ffd54f] text-[#735c00] shadow-sm border border-[#ebc23e]'
                    : !isLocked
                    ? 'text-[#4d4634] hover:bg-[#f0e7d9] hover:text-[#1f1b12] cursor-pointer'
                    : 'text-[#8c8270]/60 bg-transparent opacity-50 cursor-not-allowed select-none'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`material-symbols-outlined ${isActive ? 'fill-1' : ''} ${
                      isLocked ? 'text-[#8c8270]/60' : ''
                    }`}
                  >
                    {item.icon}
                  </span>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold tracking-wider opacity-70 uppercase">
                      Step {item.step}
                    </span>
                    <span className="text-sm font-bold">{item.label}</span>
                  </div>
                </div>

                {isLocked && (
                  <span className="material-symbols-outlined text-sm text-[#8c8270]/70" title="이전 단계를 완료하면 열립니다">
                    lock
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Mission Status Badge */}
        <div className="p-3 bg-[#fff8f0] rounded-xl border border-[#e0e0e0] text-xs text-[#4d4634] flex items-center gap-2">
          <span className="material-symbols-outlined text-sm text-[#006972]">verified_user</span>
          <div>
            <div className="font-bold text-[#1f1b12]">탐사선 정상 가동 중</div>
            <div className="text-[11px] text-[#7f7662]">브라우저 내 실시간 계산</div>
          </div>
        </div>
      </aside>
    </>
  );
};
