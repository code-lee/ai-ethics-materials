import React from 'react';
import { AlienColor, AlienEyes, AlienPattern } from '../types';

interface AlienSvgProps {
  color: AlienColor;
  eyes: AlienEyes;
  antennae: boolean;
  pattern: AlienPattern;
  className?: string;
  showScanner?: boolean;
}

export const AlienSvg: React.FC<AlienSvgProps> = ({
  color,
  eyes,
  antennae,
  pattern,
  className = 'w-full h-full',
  showScanner = false,
}) => {
  const isPurple = color === 'purple';
  const bodyColor = isPurple ? '#9c27b0' : '#4caf50';
  const bodyShadow = isPurple ? '#7b1fa2' : '#388e3c';
  const bellyColor = isPurple ? '#ba68c8' : '#81c784';
  const dotColor = isPurple ? 'rgba(255, 255, 255, 0.4)' : 'rgba(0, 0, 0, 0.2)';
  const stripeColor = isPurple ? 'rgba(255, 255, 255, 0.45)' : 'rgba(0, 0, 0, 0.25)';
  const antennaTipColor = '#ff9800';

  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      <svg
        viewBox="0 0 120 120"
        className="w-full h-full drop-shadow-sm transition-transform duration-300 group-hover:scale-105"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <radialGradient id={`glow-${color}-${eyes}`} cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor={bellyColor} />
            <stop offset="100%" stopColor={bodyColor} />
          </radialGradient>
        </defs>

        {/* Antennae (if present) */}
        {antennae && (
          <g className="transition-all duration-300">
            {/* Left Antenna */}
            <path
              d="M 45 42 Q 32 20 25 24"
              fill="none"
              stroke="#2d3748"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            <circle cx="25" cy="24" r="4.5" fill={antennaTipColor} stroke="#e65100" strokeWidth="1" />
            <circle cx="23.5" cy="22.5" r="1.5" fill="#fff" opacity="0.8" />

            {/* Right Antenna */}
            <path
              d="M 75 42 Q 88 20 95 24"
              fill="none"
              stroke="#2d3748"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            <circle cx="95" cy="24" r="4.5" fill={antennaTipColor} stroke="#e65100" strokeWidth="1" />
            <circle cx="93.5" cy="22.5" r="1.5" fill="#fff" opacity="0.8" />
          </g>
        )}

        {/* Stubby Arms */}
        <path
          d="M 28 66 Q 16 72 24 82 Q 32 80 34 72 Z"
          fill={bodyShadow}
        />
        <path
          d="M 92 66 Q 104 72 96 82 Q 88 80 86 72 Z"
          fill={bodyShadow}
        />

        {/* Main Body (Pear shape) */}
        <path
          d="M 60 34 C 42 34 32 46 30 64 C 28 82 36 98 60 98 C 84 98 92 82 90 64 C 88 46 78 34 60 34 Z"
          fill={`url(#glow-${color}-${eyes})`}
          stroke={bodyShadow}
          strokeWidth="2"
        />

        {/* Belly Patterns */}
        {pattern === 'dots' ? (
          <g fill={dotColor} className="transition-all duration-300">
            <circle cx="48" cy="74" r="3.5" />
            <circle cx="72" cy="74" r="3.5" />
            <circle cx="60" cy="84" r="4" />
            <circle cx="44" cy="88" r="2.5" />
            <circle cx="76" cy="88" r="2.5" />
          </g>
        ) : (
          <g className="transition-all duration-300">
            <line
              x1="40"
              y1="74"
              x2="80"
              y2="74"
              stroke={stripeColor}
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray="9 4"
            />
            <line
              x1="44"
              y1="84"
              x2="76"
              y2="84"
              stroke={stripeColor}
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray="9 4"
            />
          </g>
        )}

        {/* Eyes Configuration */}
        {eyes === 1 && (
          <g>
            {/* Big Central Eye */}
            <circle cx="60" cy="52" r="13" fill="#ffffff" stroke="#2d3748" strokeWidth="1.5" />
            <circle cx="60" cy="52" r="7" fill="#1a202c" />
            <circle cx="60" cy="52" r="4.5" fill={isPurple ? '#4a148c' : '#1b5e20'} />
            <circle cx="60" cy="52" r="2.5" fill="#000000" />
            <circle cx="57.5" cy="49" r="2.2" fill="#ffffff" />
            <circle cx="62" cy="54" r="1" fill="#ffffff" />
          </g>
        )}

        {eyes === 2 && (
          <g>
            {/* Left Eye */}
            <circle cx="48" cy="52" r="8.5" fill="#ffffff" stroke="#2d3748" strokeWidth="1.5" />
            <circle cx="48" cy="52" r="4.5" fill="#1a202c" />
            <circle cx="46.5" cy="50" r="1.5" fill="#ffffff" />

            {/* Right Eye */}
            <circle cx="72" cy="52" r="8.5" fill="#ffffff" stroke="#2d3748" strokeWidth="1.5" />
            <circle cx="72" cy="52" r="4.5" fill="#1a202c" />
            <circle cx="70.5" cy="50" r="1.5" fill="#ffffff" />
          </g>
        )}

        {eyes === 3 && (
          <g>
            {/* Left Eye */}
            <circle cx="42" cy="54" r="6.5" fill="#ffffff" stroke="#2d3748" strokeWidth="1.2" />
            <circle cx="42" cy="54" r="3.5" fill="#1a202c" />
            <circle cx="41" cy="52.5" r="1.2" fill="#ffffff" />

            {/* Middle Top Eye */}
            <circle cx="60" cy="47" r="7" fill="#ffffff" stroke="#2d3748" strokeWidth="1.2" />
            <circle cx="60" cy="47" r="4" fill="#1a202c" />
            <circle cx="58.5" cy="45.5" r="1.3" fill="#ffffff" />

            {/* Right Eye */}
            <circle cx="78" cy="54" r="6.5" fill="#ffffff" stroke="#2d3748" strokeWidth="1.2" />
            <circle cx="78" cy="54" r="3.5" fill="#1a202c" />
            <circle cx="77" cy="52.5" r="1.2" fill="#ffffff" />
          </g>
        )}

        {/* Cute Smile */}
        <path
          d="M 52 64 Q 60 70 68 64"
          fill="none"
          stroke="#2d3748"
          strokeWidth="2"
          strokeLinecap="round"
        />

        {/* Cheek Blushes */}
        <circle cx="38" cy="62" r="3.5" fill={isPurple ? '#e1bee7' : '#c8e6c9'} opacity="0.6" />
        <circle cx="82" cy="62" r="3.5" fill={isPurple ? '#e1bee7' : '#c8e6c9'} opacity="0.6" />
      </svg>

      {/* Target Scanner overlay if requested */}
      {showScanner && (
        <div className="absolute inset-0 pointer-events-none rounded-xl overflow-hidden">
          <div className="w-full h-full border-2 border-[#ffd54f]/70 relative">
            <div className="w-full h-px bg-[#ffd54f] absolute top-1/2 left-0 -translate-y-1/2 shadow-[0_0_8px_rgba(255,213,79,0.8)]" />
            <div className="w-px h-full bg-[#ffd54f] absolute left-1/2 top-0 -translate-x-1/2 shadow-[0_0_8px_rgba(255,213,79,0.8)]" />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#54edfe]/20 to-transparent animate-scan" />
          </div>
        </div>
      )}
    </div>
  );
};
