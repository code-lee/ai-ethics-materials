import React from 'react';
import { AlienSvg } from './AlienSvg';
import { INITIAL_DATASET } from '../data/aliens';
import { HypothesisChangeType } from '../types';

interface Step2MemoryProps {
  q1: string;
  q2: string;
  q3: string[];
  hypothesisChanges: HypothesisChangeType[];
  hypothesisPrediction: string;
  isSaved: boolean;
  onChangeQ1: (val: string) => void;
  onChangeQ2: (val: string) => void;
  onChangeQ3: (val: string[]) => void;
  onChangeHypothesisChanges: (val: HypothesisChangeType[]) => void;
  onChangeHypothesisPrediction: (val: string) => void;
  onSaveHypothesis: () => void;
  onNextStep: () => void;
}

export const Step2Memory: React.FC<Step2MemoryProps> = ({
  q1,
  q2,
  q3 = [],
  hypothesisChanges = [],
  hypothesisPrediction,
  isSaved,
  onChangeQ1,
  onChangeQ2,
  onChangeQ3,
  onChangeHypothesisChanges,
  onChangeHypothesisPrediction,
  onSaveHypothesis,
  onNextStep,
}) => {
  const planetAData = INITIAL_DATASET.filter((d) => d.planet === 'A');
  const planetBData = INITIAL_DATASET.filter((d) => d.planet === 'B');

  const featureOptions = ['몸 색깔', '눈의 수', '더듬이', '무늬'];
  const canSave =
    q1.trim().length > 0 &&
    q2.trim().length > 0 &&
    q3.length >= 1 &&
    hypothesisChanges.length >= 1 &&
    hypothesisPrediction.trim().length > 0;

  const handleToggleQ3Option = (opt: string) => {
    const isSelected = q3.includes(opt);
    if (isSelected) {
      onChangeQ3(q3.filter((item) => item !== opt));
    } else {
      onChangeQ3([...q3, opt]);
    }
  };

  const handleToggleHypothesisChange = (type: HypothesisChangeType) => {
    const isSelected = hypothesisChanges.includes(type);
    if (isSelected) {
      onChangeHypothesisChanges(hypothesisChanges.filter((t) => t !== type));
    } else {
      onChangeHypothesisChanges([...hypothesisChanges, type]);
    }
  };

  // Format selected change types for "나의 가설" summary
  const getChangesSummaryText = () => {
    if (hypothesisChanges.length === 0) return '';
    const hasRelabel = hypothesisChanges.includes('relabel');
    const hasAdd = hypothesisChanges.includes('add');
    if (hasRelabel && hasAdd) {
      return '출신 행성 표시 바꾸기 · 새로운 데이터 더하기';
    }
    if (hasRelabel) {
      return '출신 행성 표시 바꾸기';
    }
    if (hasAdd) {
      return '새로운 데이터 더하기';
    }
    return '';
  };

  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col gap-8">
      {/* Page Header */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2 text-[#735c00]">
          <span className="material-symbols-outlined text-[20px]">memory</span>
          <span className="text-[11px] font-bold uppercase tracking-widest text-[#735c00]">
            STEP 02 DATA ANALYSIS
          </span>
        </div>
        <h2 className="text-3xl md:text-4xl font-bold text-[#1f1b12]">AI는 무엇을 보고 배웠을까?</h2>
        <p className="text-base text-[#4d4634] max-w-3xl leading-relaxed">
          AI가 새로운 생명체를 분류하기 위해 미리 학습한 데이터를 살펴봅시다. 두 행성의 생명체들은 각각 어떤 특징을 가지고 있나요?
        </p>
      </div>

      {/* Observation Grids: Planet A vs Planet B */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 relative">
        {/* Planet A Panel */}
        <section className="flex flex-col gap-4 bg-white/70 p-5 rounded-2xl border border-[#e0e0e0] shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#e0e0e0]">
            <h3 className="text-lg font-bold text-[#1f1b12] flex items-center gap-2">
              <span className="w-3.5 h-3.5 rounded-full bg-[#4c56af]" />
              A행성 학습 데이터
            </h3>
            <span className="text-[11px] font-bold text-[#7f7662] px-2.5 py-1 rounded-md bg-[#f0e7d9]">
              4 RECORDS
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {planetAData.map((item) => (
              <article
                key={item.id}
                className="bg-white border border-[#e0e0e0] rounded-xl p-3.5 flex flex-col gap-2 hover:border-[#ffd54f] hover:shadow-sm transition-all"
              >
                <div className="flex justify-between items-center border-b border-[#e0e0e0] pb-1.5">
                  <span className="text-xs font-black text-[#1a237e] bg-[#f0e7d9] px-2 py-0.5 rounded">
                    {item.id}
                  </span>
                  <span className="text-[10px] text-[#7f7662]">Planet A</span>
                </div>

                <div className="flex gap-3 items-center">
                  <div className="w-20 h-20 rounded-lg bg-[#fbf3e4] shrink-0 flex items-center justify-center p-1 border border-[#e0e0e0]">
                    <AlienSvg
                      color={item.color}
                      eyes={item.eyes}
                      antennae={item.antennae}
                      pattern={item.pattern}
                      className="w-16 h-16"
                    />
                  </div>

                  <ul className="text-xs text-[#4d4634] flex-1 space-y-1">
                    <li className="flex justify-between border-b border-[#e0e0e0] border-dashed pb-0.5 whitespace-nowrap">
                      <span className="text-[#7f7662] shrink-0">몸 색깔</span>
                      <span className="font-bold text-[#1f1b12]">{item.colorLabel}</span>
                    </li>
                    <li className="flex justify-between border-b border-[#e0e0e0] border-dashed pb-0.5 whitespace-nowrap">
                      <span className="text-[#7f7662] shrink-0">눈</span>
                      <span className="font-bold text-[#1f1b12]">{item.eyes}개</span>
                    </li>
                    <li className="flex justify-between border-b border-[#e0e0e0] border-dashed pb-0.5 whitespace-nowrap">
                      <span className="text-[#7f7662] shrink-0">더듬이</span>
                      <span className="font-bold text-[#1f1b12]">{item.antennae ? '있음' : '없음'}</span>
                    </li>
                    <li className="flex justify-between pb-0.5 whitespace-nowrap">
                      <span className="text-[#7f7662] shrink-0">무늬</span>
                      <span className="font-bold text-[#1f1b12]">{item.patternLabel}</span>
                    </li>
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Planet B Panel */}
        <section className="flex flex-col gap-4 bg-white/70 p-5 rounded-2xl border border-[#e0e0e0] shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-[#e0e0e0]">
            <h3 className="text-lg font-bold text-[#1f1b12] flex items-center gap-2">
              <span className="w-3.5 h-3.5 rounded-full bg-[#ba1a1a]" />
              B행성 학습 데이터
            </h3>
            <span className="text-[11px] font-bold text-[#7f7662] px-2.5 py-1 rounded-md bg-[#f0e7d9]">
              4 RECORDS
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {planetBData.map((item) => (
              <article
                key={item.id}
                className="bg-white border border-[#e0e0e0] rounded-xl p-3.5 flex flex-col gap-2 hover:border-[#ffd54f] hover:shadow-sm transition-all"
              >
                <div className="flex justify-between items-center border-b border-[#e0e0e0] pb-1.5">
                  <span className="text-xs font-black text-[#ba1a1a] bg-[#ffdad6] px-2 py-0.5 rounded">
                    {item.id}
                  </span>
                  <span className="text-[10px] text-[#7f7662]">Planet B</span>
                </div>

                <div className="flex gap-3 items-center">
                  <div className="w-20 h-20 rounded-lg bg-[#fbf3e4] shrink-0 flex items-center justify-center p-1 border border-[#e0e0e0]">
                    <AlienSvg
                      color={item.color}
                      eyes={item.eyes}
                      antennae={item.antennae}
                      pattern={item.pattern}
                      className="w-16 h-16"
                    />
                  </div>

                  <ul className="text-xs text-[#4d4634] flex-1 space-y-1">
                    <li className="flex justify-between border-b border-[#e0e0e0] border-dashed pb-0.5 whitespace-nowrap">
                      <span className="text-[#7f7662] shrink-0">몸 색깔</span>
                      <span className="font-bold text-[#1f1b12]">{item.colorLabel}</span>
                    </li>
                    <li className="flex justify-between border-b border-[#e0e0e0] border-dashed pb-0.5 whitespace-nowrap">
                      <span className="text-[#7f7662] shrink-0">눈</span>
                      <span className="font-bold text-[#1f1b12]">{item.eyes}개</span>
                    </li>
                    <li className="flex justify-between border-b border-[#e0e0e0] border-dashed pb-0.5 whitespace-nowrap">
                      <span className="text-[#7f7662] shrink-0">더듬이</span>
                      <span className="font-bold text-[#1f1b12]">{item.antennae ? '있음' : '없음'}</span>
                    </li>
                    <li className="flex justify-between pb-0.5 whitespace-nowrap">
                      <span className="text-[#7f7662] shrink-0">무늬</span>
                      <span className="font-bold text-[#1f1b12]">{item.patternLabel}</span>
                    </li>
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>

      {/* Analysis Questionnaire */}
      <div className="bg-white border border-[#e0e0e0] rounded-2xl p-6 md:p-8 shadow-sm">
        <h3 className="text-xl font-bold text-[#1f1b12] mb-6 flex items-center gap-2">
          <span className="material-symbols-outlined text-[#735c00]">find_in_page</span>
          데이터 분석하기
        </h3>

        <div className="flex flex-col gap-6">
          {/* Q1 */}
          <div className="flex flex-col gap-2">
            <label htmlFor="q1Input" className="text-sm font-semibold text-[#1f1b12] flex items-center gap-1.5">
              <span className="text-[#735c00] font-bold">Q1.</span>
              A행성 생명체에서 자주 보이는 특징은 무엇인가요?
            </label>
            <textarea
              id="q1Input"
              value={q1}
              onChange={(e) => onChangeQ1(e.target.value)}
              placeholder="A행성 데이터에서 발견한 특징을 적어 보세요."
              rows={2}
              className="w-full bg-[#fff8f0] border border-[#e0e0e0] rounded-xl p-3 text-sm text-[#1f1b12] focus:outline-none focus:border-[#ffd54f] focus:ring-2 focus:ring-[#ffd54f]/30 transition-all resize-none"
            />
          </div>

          {/* Q2 */}
          <div className="flex flex-col gap-2">
            <label htmlFor="q2Input" className="text-sm font-semibold text-[#1f1b12] flex items-center gap-1.5">
              <span className="text-[#ba1a1a] font-bold">Q2.</span>
              B행성 생명체에서 자주 보이는 특징은 무엇인가요?
            </label>
            <textarea
              id="q2Input"
              value={q2}
              onChange={(e) => onChangeQ2(e.target.value)}
              placeholder="B행성 데이터에서 발견한 특징을 적어 보세요."
              rows={2}
              className="w-full bg-[#fff8f0] border border-[#e0e0e0] rounded-xl p-3 text-sm text-[#1f1b12] focus:outline-none focus:border-[#ffd54f] focus:ring-2 focus:ring-[#ffd54f]/30 transition-all resize-none"
            />
          </div>

          {/* Q3 - Multiple selection */}
          <div className="flex flex-col gap-3 bg-[#f8f9fa] p-4 rounded-xl border border-[#e0e0e0] border-dashed">
            <div>
              <p className="text-sm font-semibold text-[#1f1b12] flex items-center gap-1.5">
                <span className="text-[#4c56af] font-bold">Q3.</span>
                AI는 어떤 특징을 바탕으로 판단할 것 같나요?
              </p>
              <p className="text-xs text-[#7f7662] mt-0.5">
                * 생각하는 특징을 모두 선택해 보세요 (복수 선택 가능)
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {featureOptions.map((opt) => {
                const isSelected = q3.includes(opt);
                return (
                  <button
                    key={opt}
                    onClick={() => handleToggleQ3Option(opt)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-[#1a237e] text-white shadow-xs border-2 border-[#1a237e]'
                        : 'bg-white text-[#4d4634] border border-[#e0e0e0] hover:border-[#ffd54f] hover:bg-[#fff8f0]'
                    }`}
                  >
                    <span
                      className={`w-4 h-4 rounded flex items-center justify-center text-[10px] ${
                        isSelected ? 'bg-white text-[#1a237e] font-black' : 'border border-[#d0c6ae]'
                      }`}
                    >
                      {isSelected ? '✓' : ''}
                    </span>
                    <span>{opt}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Hypothesis Generation Panel */}
      <div className="bg-[#ffd54f]/15 border-2 border-[#ffd54f] rounded-2xl p-6 md:p-8 flex flex-col gap-6 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-[#ffd54f] rounded-full flex items-center justify-center text-[#735c00] shadow-sm shrink-0">
            <span className="material-symbols-outlined text-2xl">lightbulb</span>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-[#735c00]">가설 세우기</h3>
            <p className="text-sm text-[#4d4634]">
              데이터를 관찰한 내용을 바탕으로 두 가지 질문에 답하며 나의 가설을 세워 보세요.
            </p>
          </div>
        </div>

        {/* Two Question Prompts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Question 1: Multi-select choices */}
          <div className="bg-white p-5 rounded-xl border border-[#e0e0e0] shadow-xs flex flex-col justify-between gap-3">
            <div>
              <label className="text-sm font-bold text-[#1f1b12] flex items-center gap-1.5 mb-1">
                <span className="w-5 h-5 rounded-full bg-[#1a237e] text-white text-xs flex items-center justify-center font-bold">1</span>
                어떤 데이터 변화가 AI의 판단과 관련 있을 것 같나요?
              </label>
              <p className="text-xs text-[#7f7662]">
                * 하나 또는 두 가지 모두 선택할 수 있어요.
              </p>
            </div>

            <div className="flex flex-col gap-2.5 pt-1">
              {/* Option 1: relabel */}
              <button
                type="button"
                onClick={() => handleToggleHypothesisChange('relabel')}
                className={`p-3 rounded-xl text-xs font-bold transition-all text-left flex items-center gap-2.5 ${
                  hypothesisChanges.includes('relabel')
                    ? 'bg-[#1a237e] text-white shadow-xs border-2 border-[#1a237e]'
                    : 'bg-[#fff8f0] text-[#4d4634] border border-[#e0e0e0] hover:border-[#ffd54f] hover:bg-[#fff2e0]'
                }`}
              >
                <span
                  className={`w-4 h-4 rounded flex items-center justify-center text-[10px] shrink-0 ${
                    hypothesisChanges.includes('relabel')
                      ? 'bg-white text-[#1a237e] font-black'
                      : 'border border-[#d0c6ae] bg-white'
                  }`}
                >
                  {hypothesisChanges.includes('relabel') ? '✓' : ''}
                </span>
                <span>출신 행성 표시를 바꾸어 본다.</span>
              </button>

              {/* Option 2: add */}
              <button
                type="button"
                onClick={() => handleToggleHypothesisChange('add')}
                className={`p-3 rounded-xl text-xs font-bold transition-all text-left flex items-center gap-2.5 ${
                  hypothesisChanges.includes('add')
                    ? 'bg-[#1a237e] text-white shadow-xs border-2 border-[#1a237e]'
                    : 'bg-[#fff8f0] text-[#4d4634] border border-[#e0e0e0] hover:border-[#ffd54f] hover:bg-[#fff2e0]'
                }`}
              >
                <span
                  className={`w-4 h-4 rounded flex items-center justify-center text-[10px] shrink-0 ${
                    hypothesisChanges.includes('add')
                      ? 'bg-white text-[#1a237e] font-black'
                      : 'border border-[#d0c6ae] bg-white'
                  }`}
                >
                  {hypothesisChanges.includes('add') ? '✓' : ''}
                </span>
                <span>새로운 데이터를 더해 본다.</span>
              </button>
            </div>
          </div>

          {/* Question 2: Free text prediction */}
          <div className="bg-white p-5 rounded-xl border border-[#e0e0e0] shadow-xs flex flex-col gap-2.5">
            <label htmlFor="hypothesisPredictionInput" className="text-sm font-bold text-[#1f1b12] flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-[#ba1a1a] text-white text-xs flex items-center justify-center font-bold">2</span>
              그런 변화를 주면 AI의 판단은 어떻게 될 것이라고 예상하나요?
            </label>
            <textarea
              id="hypothesisPredictionInput"
              value={hypothesisPrediction}
              onChange={(e) => onChangeHypothesisPrediction(e.target.value)}
              placeholder="나의 예상을 적어 보세요."
              rows={4}
              className="w-full bg-[#fff8f0] border border-[#e0e0e0] rounded-xl p-3 text-sm text-[#1f1b12] focus:outline-none focus:border-[#ffd54f] focus:ring-2 focus:ring-[#ffd54f]/30 transition-all resize-none"
            />
          </div>
        </div>

        {/* My Hypothesis Summary Card */}
        <div className="bg-white p-5 rounded-xl border border-[#d0c6ae] shadow-xs flex flex-col gap-3">
          <div className="flex items-center gap-2 border-b border-[#e0e0e0] pb-2">
            <span className="material-symbols-outlined text-[#735c00] text-lg">science</span>
            <h4 className="text-base font-bold text-[#1f1b12]">나의 가설</h4>
          </div>

          <div className="space-y-2.5 text-sm">
            <div>
              <span className="font-bold text-[#7f7662] block text-xs">변화를 줄 부분</span>
              <div className="font-semibold text-[#1a237e] mt-0.5 bg-[#fbf3e4] px-3 py-2 rounded-lg border border-[#e0e0e0]">
                {hypothesisChanges.length > 0 ? (
                  `→ ${getChangesSummaryText()}`
                ) : (
                  <span className="text-[#7f7662] italic font-normal">
                    질문 1에서 변화를 줄 부분을 선택해 주세요.
                  </span>
                )}
              </div>
            </div>

            <div>
              <span className="font-bold text-[#7f7662] block text-xs">예상</span>
              <div className="font-semibold text-[#ba1a1a] mt-0.5 bg-[#fbf3e4] px-3 py-2 rounded-lg border border-[#e0e0e0]">
                {hypothesisPrediction.trim().length > 0 ? (
                  `→ ${hypothesisPrediction}`
                ) : (
                  <span className="text-[#7f7662] italic font-normal">
                    질문 2에 나의 예상을 적어 보세요.
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-center mt-2">
          <button
            onClick={onSaveHypothesis}
            disabled={!canSave}
            className="px-8 py-3.5 bg-[#ffd54f] text-[#735c00] font-bold text-base rounded-xl hover:bg-[#ffe087] transition-all border-b-4 border-[#ebc23e] active:border-b-0 active:translate-y-1 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <span>{isSaved ? '가설 수정 및 저장' : '가설 저장하고 실험실로 이동'}</span>
            <span className="material-symbols-outlined text-lg">science</span>
          </button>

          {isSaved && (
            <button
              onClick={onNextStep}
              className="px-6 py-3.5 bg-[#1a237e] text-white font-bold text-base rounded-xl hover:bg-[#27308a] transition-all flex items-center justify-center gap-2"
            >
              <span>3단계: 데이터 실험실 가기</span>
              <span className="material-symbols-outlined text-lg">arrow_forward</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
