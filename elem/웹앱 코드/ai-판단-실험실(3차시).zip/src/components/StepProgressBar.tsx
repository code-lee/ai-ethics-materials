import React from 'react';

interface StepProgressBarProps {
  currentStep: number;
  maxUnlockedStep: number;
  onSelectStep: (step: number) => void;
}

export const StepProgressBar: React.FC<StepProgressBarProps> = ({
  currentStep,
  maxUnlockedStep,
  onSelectStep,
}) => {
  const steps = [1, 2, 3, 4, 5];

  return (
    <div className="w-full relative py-2 mb-4">
      {/* Background Track Line */}
      <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-[#e0e0e0] -translate-y-1/2 z-0" />

      {/* Nodes */}
      <div className="relative z-10 flex justify-between items-center w-full px-2">
        {steps.map((step) => {
          const isActive = currentStep === step;
          const isPassed = currentStep > step;
          const isUnlocked = step <= maxUnlockedStep;

          return (
            <button
              key={step}
              disabled={!isUnlocked}
              onClick={() => {
                if (isUnlocked) {
                  onSelectStep(step);
                }
              }}
              className={`flex flex-col items-center gap-1.5 focus:outline-none group ${
                isUnlocked ? 'cursor-pointer' : 'cursor-not-allowed opacity-50'
              }`}
            >
              {isActive ? (
                <div className="w-7 h-7 rounded-full bg-[#ffd54f] border-[3px] border-[#fff8f0] shadow-[0_0_0_2px_#735c00] flex items-center justify-center transition-all duration-200 scale-110">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#735c00]" />
                </div>
              ) : isPassed && isUnlocked ? (
                <div className="w-5 h-5 rounded-full bg-[#735c00] border-2 border-[#fff8f0] flex items-center justify-center transition-all group-hover:scale-110 shadow-xs">
                  <span className="material-symbols-outlined text-[12px] text-white font-bold">check</span>
                </div>
              ) : isUnlocked ? (
                <div className="w-5 h-5 rounded-full bg-[#ebc23e] border-2 border-[#fff8f0] flex items-center justify-center transition-all group-hover:scale-110" />
              ) : (
                <div className="w-5 h-5 rounded-full bg-[#d0c6ae] border-2 border-[#fff8f0] flex items-center justify-center transition-all" />
              )}
              <span
                className={`text-[11px] font-bold tracking-wider uppercase transition-colors flex items-center gap-0.5 ${
                  isActive
                    ? 'text-[#735c00]'
                    : isPassed && isUnlocked
                    ? 'text-[#1f1b12]'
                    : isUnlocked
                    ? 'text-[#7f7662]'
                    : 'text-[#8c8270]/60'
                }`}
              >
                STEP {step}
                {!isUnlocked && (
                  <span className="material-symbols-outlined text-[11px] text-[#8c8270]/70 ml-0.5">
                    lock
                  </span>
                )}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
