import React from 'react';
import { AlienSvg } from './AlienSvg';
import { TEST_ALIEN, INITIAL_DATASET } from '../data/aliens';
import { ClassificationResult } from '../types';

interface Step1DiscoverProps {
  prediction: 'A' | 'B' | 'unknown' | null;
  reason: string;
  isSubmitted: boolean;
  aiResult: ClassificationResult | null;
  onSelectPrediction: (val: 'A' | 'B' | 'unknown') => void;
  onChangeReason: (val: string) => void;
  onSubmit: () => void;
  onNextStep: () => void;
}

export const Step1Discover: React.FC<Step1DiscoverProps> = ({
  prediction,
  reason,
  isSubmitted,
  aiResult,
  onSelectPrediction,
  onChangeReason,
  onSubmit,
  onNextStep,
}) => {
  // Step 1 reference examples (A-1, A-3, B-1, B-3 from INITIAL_DATASET)
  const aPlanets = INITIAL_DATASET.filter((d) => d.id === 'A-1' || d.id === 'A-3');
  const bPlanets = INITIAL_DATASET.filter((d) => d.id === 'B-1' || d.id === 'B-3');

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col gap-6">
      {/* Title Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#f0e7d9] border border-[#e0e0e0] mb-3">
          <span className="w-2 h-2 rounded-full bg-[#1a237e] animate-pulse" />
          <span className="text-[11px] font-bold text-[#4d4634] uppercase tracking-wider">
            STEP 01 MISSION
          </span>
        </div>
        <h2 className="text-3xl md:text-4xl font-bold text-[#1f1b12]">미지의 생명체 발견</h2>
        <p className="text-[#4d4634] mt-2 text-base">
          우주 탐사선 레이더에 정체불명의 새로운 생명체가 포착되었습니다!
        </p>
      </div>

      {/* Main Mission Card */}
      <div className="bg-white rounded-2xl border border-[#e0e0e0] shadow-sm overflow-hidden relative">
        {/* Unknown Alien Display */}
        <div className="p-6 md:p-8 flex flex-col items-center border-b border-[#e0e0e0] border-dashed bg-[#fff8f0]/40">
          <div className="flex items-center gap-2 mb-4">
            <span className="material-symbols-outlined text-[#735c00]">radar</span>
            <h3 className="text-2xl font-bold text-[#1f1b12]">새로운 생명체 포착!</h3>
          </div>

          {/* Alien Target Display with Scanner */}
          <div className="w-56 h-56 md:w-64 md:h-64 relative rounded-2xl border border-[#e0e0e0] bg-[#f8f9fa] p-4 flex items-center justify-center shadow-inner">
            <AlienSvg
              color={TEST_ALIEN.color}
              eyes={TEST_ALIEN.eyes}
              antennae={TEST_ALIEN.antennae}
              pattern={TEST_ALIEN.pattern}
              showScanner={true}
              className="w-44 h-44 md:w-52 md:h-52"
            />
            <div className="absolute bottom-2 left-2 bg-[#1a237e] text-white px-2.5 py-0.5 rounded text-[10px] font-mono tracking-widest uppercase">
              SUBJECT: UNKNOWN-01
            </div>
            <div className="absolute top-2 right-2 bg-white/80 backdrop-blur-xs px-2 py-0.5 rounded text-[11px] font-medium text-[#7f7662] border border-[#e0e0e0]">
              특징 4가지 스캔 완료
            </div>
          </div>

          {/* Test Alien Features summary */}
          <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
            <span className="px-3 py-1 bg-[#f0e7d9] text-[#735c00] rounded-full text-xs font-semibold border border-[#d0c6ae]">
              몸 색깔: {TEST_ALIEN.colorLabel}
            </span>
            <span className="px-3 py-1 bg-[#f0e7d9] text-[#735c00] rounded-full text-xs font-semibold border border-[#d0c6ae]">
              눈: {TEST_ALIEN.eyes}개
            </span>
            <span className="px-3 py-1 bg-[#f0e7d9] text-[#735c00] rounded-full text-xs font-semibold border border-[#d0c6ae]">
              더듬이: {TEST_ALIEN.antennae ? '있음' : '없음'}
            </span>
            <span className="px-3 py-1 bg-[#f0e7d9] text-[#735c00] rounded-full text-xs font-semibold border border-[#d0c6ae]">
              무늬: {TEST_ALIEN.patternLabel}
            </span>
          </div>
        </div>

        {/* 1. 참고 사례 영역 (탐사 기록에서 확인된 생명체 일부) */}
        <div className="p-6 border-b border-[#e0e0e0] bg-[#fffdf9]">
          <div className="text-center mb-4">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#f0e7d9] text-[#735c00] text-xs font-bold mb-1 border border-[#d0c6ae]">
              <span className="material-symbols-outlined text-sm">history_edu</span>
              <span>탐사 기록에서 확인된 생명체 일부</span>
            </div>
            <p className="text-xs text-[#4d4634] font-medium">
              이미 출신 행성이 확인된 생명체들을 살펴보고 미지의 생명체를 예상해 보세요.
            </p>
          </div>

          {/* Comparison Grid: A Planet (A-1, A-3) vs B Planet (B-1, B-3) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl mx-auto">
            {/* A Planet Card */}
            <div className="p-3.5 bg-white rounded-xl border border-[#e0e0e0] shadow-2xs flex flex-col gap-2.5">
              <div className="flex items-center justify-between pb-1.5 border-b border-[#e0e0e0]">
                <span className="text-xs font-bold text-[#1a237e] flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#1a237e]" />
                  A행성 확인 사례
                </span>
                <span className="text-[10px] text-[#7f7662]">2건</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {aPlanets.map((alien) => (
                  <div
                    key={alien.id}
                    className="p-2 bg-[#f8f9fa] rounded-lg border border-[#e0e0e0] flex flex-col items-center text-center"
                  >
                    <div className="w-16 h-16 bg-white rounded-md border border-[#e0e0e0] p-1 flex items-center justify-center mb-1.5">
                      <AlienSvg
                        color={alien.color}
                        eyes={alien.eyes}
                        antennae={alien.antennae}
                        pattern={alien.pattern}
                        className="w-14 h-14"
                      />
                    </div>
                    <span className="text-xs font-black px-1.5 py-0.5 rounded bg-[#e0e0ff] text-[#1a237e] mb-1">
                      {alien.id}
                    </span>
                    <div className="text-[11px] text-[#4d4634] leading-tight space-y-0.5">
                      <div>{alien.colorLabel} · 눈 {alien.eyes}개</div>
                      <div>더듬이 {alien.antennae ? '있음' : '없음'} · {alien.patternLabel}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* B Planet Card */}
            <div className="p-3.5 bg-white rounded-xl border border-[#e0e0e0] shadow-2xs flex flex-col gap-2.5">
              <div className="flex items-center justify-between pb-1.5 border-b border-[#e0e0e0]">
                <span className="text-xs font-bold text-[#ba1a1a] flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#ba1a1a]" />
                  B행성 확인 사례
                </span>
                <span className="text-[10px] text-[#7f7662]">2건</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {bPlanets.map((alien) => (
                  <div
                    key={alien.id}
                    className="p-2 bg-[#f8f9fa] rounded-lg border border-[#e0e0e0] flex flex-col items-center text-center"
                  >
                    <div className="w-16 h-16 bg-white rounded-md border border-[#e0e0e0] p-1 flex items-center justify-center mb-1.5">
                      <AlienSvg
                        color={alien.color}
                        eyes={alien.eyes}
                        antennae={alien.antennae}
                        pattern={alien.pattern}
                        className="w-14 h-14"
                      />
                    </div>
                    <span className="text-xs font-black px-1.5 py-0.5 rounded bg-[#ffdad6] text-[#ba1a1a] mb-1">
                      {alien.id}
                    </span>
                    <div className="text-[11px] text-[#4d4634] leading-tight space-y-0.5">
                      <div>{alien.colorLabel} · 눈 {alien.eyes}개</div>
                      <div>더듬이 {alien.antennae ? '있음' : '없음'} · {alien.patternLabel}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Prediction Question Section */}
        <div className="p-6 md:p-8 bg-[#f8f9fa]/60">
          <h4 className="text-xl font-bold text-center text-[#1f1b12] mb-6">
            탐사 AI는 이 생명체를 어느 행성 출신이라고 판단할까요?
          </h4>

          {/* 3 Option Buttons */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <button
              onClick={() => onSelectPrediction('A')}
              className={`p-5 rounded-xl border flex flex-col items-center gap-3 transition-all duration-200 text-center ${
                prediction === 'A'
                  ? 'border-[#735c00] bg-[#ffd54f]/15 shadow-[0_0_0_2px_#ffd54f]'
                  : 'border-[#e0e0e0] bg-white hover:border-[#ffd54f] hover:bg-[#fff8f0]'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-[#54edfe] flex items-center justify-center text-[#006972]">
                <span className="material-symbols-outlined text-2xl">public</span>
              </div>
              <div>
                <span className="text-base font-bold text-[#1f1b12] block">A행성</span>
                <span className="text-xs text-[#7f7662]">A행성 생명체일 것이다</span>
              </div>
            </button>

            <button
              onClick={() => onSelectPrediction('B')}
              className={`p-5 rounded-xl border flex flex-col items-center gap-3 transition-all duration-200 text-center ${
                prediction === 'B'
                  ? 'border-[#735c00] bg-[#ffd54f]/15 shadow-[0_0_0_2px_#ffd54f]'
                  : 'border-[#e0e0e0] bg-white hover:border-[#ffd54f] hover:bg-[#fff8f0]'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-[#959efd] flex items-center justify-center text-[#27308a]">
                <span className="material-symbols-outlined text-2xl">language</span>
              </div>
              <div>
                <span className="text-base font-bold text-[#1f1b12] block">B행성</span>
                <span className="text-xs text-[#7f7662]">B행성 생명체일 것이다</span>
              </div>
            </button>

            <button
              onClick={() => onSelectPrediction('unknown')}
              className={`p-5 rounded-xl border flex flex-col items-center gap-3 transition-all duration-200 text-center ${
                prediction === 'unknown'
                  ? 'border-[#735c00] bg-[#ffd54f]/15 shadow-[0_0_0_2px_#ffd54f]'
                  : 'border-[#e0e0e0] bg-white hover:border-[#ffd54f] hover:bg-[#fff8f0]'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-[#eae2d3] flex items-center justify-center text-[#4d4634]">
                <span className="material-symbols-outlined text-2xl">question_mark</span>
              </div>
              <div>
                <span className="text-base font-bold text-[#1f1b12] block">잘 모르겠다</span>
                <span className="text-xs text-[#7f7662]">아직 판단하기 어렵다</span>
              </div>
            </button>
          </div>

          {/* Reasoning Input */}
          {prediction && (
            <div className="mt-6 flex flex-col gap-3 p-5 bg-white rounded-xl border border-[#e0e0e0] animate-in fade-in duration-300">
              <label htmlFor="step1Reason" className="text-base font-semibold text-[#1f1b12] flex items-center gap-2">
                <span className="material-symbols-outlined text-[#735c00] text-lg">edit</span>
                그렇게 예상한 까닭을 적어 보세요.
              </label>
              <input
                id="step1Reason"
                type="text"
                value={reason}
                onChange={(e) => onChangeReason(e.target.value)}
                placeholder="그렇게 예상한 까닭을 적어 보세요."
                className="w-full p-3.5 bg-[#fff8f0] border border-[#e0e0e0] rounded-xl text-sm focus:outline-none focus:border-[#ffd54f] focus:ring-2 focus:ring-[#ffd54f]/30 transition-all"
              />

              {!isSubmitted && (
                <div className="flex justify-center mt-3">
                  <button
                    onClick={onSubmit}
                    disabled={reason.trim().length === 0}
                    className="px-8 py-3.5 bg-[#ffd54f] text-[#735c00] font-bold text-base rounded-xl hover:bg-[#ffe087] transition-all duration-150 border-b-4 border-[#ebc23e] active:border-b-0 active:translate-y-1 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    <span>AI의 첫 판단 확인하기</span>
                    <span className="material-symbols-outlined text-lg">arrow_forward</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* AI Result Card (Shown after submit) */}
          {isSubmitted && aiResult && (
            <div className="mt-6 p-6 bg-[#fff8f0] rounded-xl border-2 border-[#ffd54f] animate-in fade-in duration-300 shadow-sm flex flex-col gap-4">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1a237e]">psychology</span>
                <span className="text-xs font-bold text-[#1a237e] uppercase tracking-wider">
                  탐사 AI의 첫 판단
                </span>
              </div>

              <div className="py-4 border-y border-[#e0e0e0] flex items-center justify-center">
                <div className="text-4xl font-black text-[#1a237e]">
                  {aiResult.decision}
                </div>
              </div>

              <div className="p-3.5 bg-white rounded-lg border border-[#e0e0e0] text-center">
                <p className="text-sm font-bold text-[#4d4634]">
                  AI는 무엇을 바탕으로 이런 판단을 했을까요?
                </p>
              </div>

              <div className="mt-2 flex justify-end">
                <button
                  onClick={onNextStep}
                  className="px-6 py-3 bg-[#1a237e] text-white font-bold rounded-xl hover:bg-[#27308a] transition-all flex items-center gap-2 shadow-md"
                >
                  <span>2단계: AI의 기억 창고 열어 보기</span>
                  <span className="material-symbols-outlined text-lg">arrow_forward</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Thought Provoker */}
      <div className="bg-[#f6edde] px-6 py-4 rounded-2xl border border-[#e0e0e0] flex items-center gap-3 text-[#4d4634]">
        <span className="material-symbols-outlined text-[#006972] text-2xl">psychology</span>
        <p className="text-sm font-medium">
          <strong>생각해 보기:</strong> AI는 무엇을 바탕으로 이런 판단을 했을까요?
        </p>
      </div>
    </div>
  );
};
