import { AlienData, ClassificationResult, ScoreDetail } from '../types';

export function classifyAlien(
  testAlien: AlienData,
  dataset: AlienData[],
  labelOverrides?: Record<string, 'A' | 'B'>
): ClassificationResult {
  const activeItems = dataset.filter((item) => item.included);

  if (activeItems.length === 0) {
    return {
      decision: '데이터 없음',
      topScore: 0,
      topItemIds: [],
      topItems: [],
      planetACount: 0,
      planetBCount: 0,
      scoreDetails: [],
      totalActiveCount: 0,
      summaryText: '학습 데이터가 없습니다.',
    };
  }

  const scoreDetails: ScoreDetail[] = activeItems.map((item) => {
    const matchColor = item.color === testAlien.color;
    const matchEyes = item.eyes === testAlien.eyes;
    const matchAntennae = item.antennae === testAlien.antennae;
    const matchPattern = item.pattern === testAlien.pattern;

    let score = 0;
    if (matchColor) score += 1;
    if (matchEyes) score += 1;
    if (matchAntennae) score += 1;
    if (matchPattern) score += 1;

    const effectivePlanet =
      labelOverrides && labelOverrides[item.id] ? labelOverrides[item.id] : item.planet;

    return {
      id: item.id,
      planet: effectivePlanet,
      score,
      matchColor,
      matchEyes,
      matchAntennae,
      matchPattern,
    };
  });

  const maxScore = Math.max(...scoreDetails.map((d) => d.score));
  const topDetails = scoreDetails.filter((d) => d.score === maxScore);
  const topItemIds = topDetails.map((d) => d.id);
  const topItems = activeItems
    .map((item) => {
      const effectivePlanet =
        labelOverrides && labelOverrides[item.id] ? labelOverrides[item.id] : item.planet;
      return { ...item, planet: effectivePlanet };
    })
    .filter((item) => topItemIds.includes(item.id));

  const planetACount = topDetails.filter((d) => d.planet === 'A').length;
  const planetBCount = topDetails.filter((d) => d.planet === 'B').length;

  let decision: ClassificationResult['decision'];
  let summaryText = '';

  if (planetACount > 0 && planetBCount === 0) {
    decision = 'A행성';
    summaryText = `가장 닮은 학습 데이터(${topItemIds.join(', ')})가 모두 A행성 출신이어서 A행성으로 판단했어요.`;
  } else if (planetBCount > 0 && planetACount === 0) {
    decision = 'B행성';
    summaryText = `가장 닮은 학습 데이터(${topItemIds.join(', ')})가 모두 B행성 출신이어서 B행성으로 판단했어요.`;
  } else {
    decision = '판단하기 어려움';
    summaryText = `가장 닮은 학습 데이터에 A행성과 B행성이 같은 점수로 섞여 있어 (${topItemIds.join(', ')}), 어느 쪽인지 명확히 판단하기 어려워요.`;
  }

  return {
    decision,
    topScore: maxScore,
    topItemIds,
    topItems,
    planetACount,
    planetBCount,
    scoreDetails,
    totalActiveCount: activeItems.length,
    summaryText,
  };
}
