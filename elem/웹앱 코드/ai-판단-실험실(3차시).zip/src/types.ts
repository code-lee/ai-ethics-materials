export type AlienColor = 'purple' | 'green';
export type AlienEyes = 1 | 2 | 3;
export type AlienPattern = 'dots' | 'stripes';

export interface AlienData {
  id: string;
  name: string;
  planet: 'A' | 'B';
  color: AlienColor;
  colorLabel: string; // '보라색' | '초록색'
  eyes: AlienEyes;
  antennae: boolean;
  pattern: AlienPattern;
  patternLabel: string; // '점무늬' | '줄무늬'
  included: boolean;
  isExtra?: boolean;
}

export interface ScoreDetail {
  id: string;
  planet: 'A' | 'B';
  score: number;
  matchColor: boolean;
  matchEyes: boolean;
  matchAntennae: boolean;
  matchPattern: boolean;
}

export interface ClassificationResult {
  decision: 'A행성' | 'B행성' | '판단하기 어려움' | '데이터 없음';
  topScore: number;
  topItemIds: string[];
  topItems: AlienData[];
  planetACount: number;
  planetBCount: number;
  scoreDetails: ScoreDetail[];
  totalActiveCount: number;
  summaryText: string;
}

export interface LabelChange {
  id: string;
  from: 'A' | 'B';
  to: 'A' | 'B';
}

export interface ExperimentSnapshot {
  id: string;
  experimentNumber: number;
  experimentType?: 'relabel' | 'add' | 'free';
  timestamp: number;
  includedDataIds: string[];
  excludedDataIds: string[];
  addedDataIds: string[];
  labelChanges?: LabelChange[];
  predictedResult?: 'A행성' | 'B행성' | '판단하기 어려움' | '잘 모르겠다';
  predictionMatched?: boolean;
  result: string;
  highestScore: number;
  closestDataIds: string[];
  changedFromInitial: boolean;
  observation?: string;
}

export type HypothesisChangeType = 'relabel' | 'add';

export interface AppState {
  currentStep: number;
  maxUnlockedStep: number;
  // Step 1
  step1Prediction: 'A' | 'B' | 'unknown' | null;
  step1Reason: string;
  step1Submitted: boolean;
  step1AiResult: ClassificationResult | null;
  
  // Step 2
  step2Q1: string;
  step2Q2: string;
  step2Q3: string[];
  step2HypothesisChanges: HypothesisChangeType[];
  step2HypothesisPrediction: string;
  step2HypothesisChange?: string; // legacy support
  step2HypothesisFeature?: string;
  step2HypothesisOutcome?: string;
  step2Saved: boolean;

  // Step 3
  dataset: AlienData[];
  step3LabelOverrides: Record<string, 'A' | 'B'>;
  hasAddedExtraB5: boolean;
  experimentCount: number;
  experiments: ExperimentSnapshot[];
  step3ActiveTab: 'relabel' | 'add' | 'free';
  step3PendingPrediction: 'A행성' | 'B행성' | '판단하기 어려움' | '잘 모르겠다' | null;
  step3HasCalculatedCurrent: boolean;
  step3Calculation: ClassificationResult | null;
  step3InitialCalculation: ClassificationResult | null;
  step3Observation: string;
  modificationLogs: string[];

  // Step 4
  step4Q1: string;
  step4Q2: string;
  step4Q3: string;
  step4Q4: string;
  step4Revealed: boolean;

  // Step 5
  step5Choice: string | null;
  step5Reason: string;
  step5Principle: string;
  step5Submitted: boolean;
}
