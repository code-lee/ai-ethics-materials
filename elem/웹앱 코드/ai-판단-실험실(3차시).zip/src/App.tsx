import React, { useState, useEffect } from 'react';
import { INITIAL_DATASET, TEST_ALIEN, EXTRA_ALIENS } from './data/aliens';
import { classifyAlien } from './utils/classifier';
import { AlienData, AppState, ExperimentSnapshot, LabelChange, HypothesisChangeType } from './types';
import { Navigation } from './components/Navigation';
import { StepProgressBar } from './components/StepProgressBar';
import { Step1Discover } from './components/Step1Discover';
import { Step2Memory } from './components/Step2Memory';
import { Step3Lab } from './components/Step3Lab';
import { Step4Analysis } from './components/Step4Analysis';
import { Step5Return } from './components/Step5Return';
import { InfoModal } from './components/InfoModal';

const STORAGE_KEY = 'ai_decision_lab_state_v4';

function getInitialState(): AppState {
  const initialCalc = classifyAlien(TEST_ALIEN, INITIAL_DATASET);

  if (typeof window !== 'undefined') {
    const saved = sessionStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed.currentStep === 'number') {
          const experiments: ExperimentSnapshot[] = Array.isArray(parsed.experiments)
            ? parsed.experiments.map((exp: any) => ({
                id: String(exp.id || ''),
                experimentNumber: Number(exp.experimentNumber || 0),
                experimentType:
                  (exp.experimentType as 'relabel' | 'add' | 'free') ||
                  (exp.experimentType === 'remove' ? 'relabel' : 'relabel'),
                timestamp: Number(exp.timestamp || Date.now()),
                includedDataIds: Array.isArray(exp.includedDataIds) ? [...exp.includedDataIds] : [],
                excludedDataIds: Array.isArray(exp.excludedDataIds) ? [...exp.excludedDataIds] : [],
                addedDataIds: Array.isArray(exp.addedDataIds) ? [...exp.addedDataIds] : [],
                labelChanges: Array.isArray(exp.labelChanges) ? [...exp.labelChanges] : [],
                predictedResult: exp.predictedResult,
                predictionMatched: Boolean(exp.predictionMatched),
                result: String(exp.result || ''),
                highestScore: Number(exp.highestScore || 0),
                closestDataIds: Array.isArray(exp.closestDataIds) ? [...exp.closestDataIds] : [],
                changedFromInitial: Boolean(exp.changedFromInitial),
                observation: typeof exp.observation === 'string' ? exp.observation : '',
              }))
            : [];

          const hasRelabel = experiments.some(
            (e) => e.experimentType === 'relabel' && Boolean(e.observation?.trim())
          );
          const hasAdd = experiments.some(
            (e) => e.experimentType === 'add' && Boolean(e.observation?.trim())
          );
          let maxUnlocked =
            typeof parsed.maxUnlockedStep === 'number' ? Math.max(1, parsed.maxUnlockedStep) : 1;
          if (hasRelabel && hasAdd) {
            maxUnlocked = Math.max(maxUnlocked, 4);
          }

          const safeCurrentStep = Math.min(Math.max(1, parsed.currentStep), maxUnlocked);

          // Parse step2Q3 safely into string[]
          let parsedQ3: string[] = [];
          if (Array.isArray(parsed.step2Q3)) {
            parsedQ3 = parsed.step2Q3.filter(
              (x: any) => typeof x === 'string' && x !== '학습 데이터'
            );
          } else if (
            typeof parsed.step2Q3 === 'string' &&
            parsed.step2Q3.length > 0 &&
            parsed.step2Q3 !== '학습 데이터'
          ) {
            parsedQ3 = [parsed.step2Q3];
          }

          // Parse step2HypothesisChanges safely
          let parsedHypothesisChanges: HypothesisChangeType[] = [];
          if (Array.isArray(parsed.step2HypothesisChanges)) {
            parsedHypothesisChanges = parsed.step2HypothesisChanges.filter(
              (c: any) => c === 'relabel' || c === 'add'
            );
          } else if (typeof parsed.step2HypothesisChange === 'string' && parsed.step2HypothesisChange) {
            if (parsed.step2HypothesisChange.includes('표시') || parsed.step2HypothesisChange.includes('relabel')) {
              parsedHypothesisChanges.push('relabel');
            }
            if (parsed.step2HypothesisChange.includes('추가') || parsed.step2HypothesisChange.includes('add') || parsed.step2HypothesisChange.includes('더')) {
              parsedHypothesisChanges.push('add');
            }
          }

          return {
            ...parsed,
            step2Q3: parsedQ3,
            step2HypothesisChanges: parsedHypothesisChanges,
            step2HypothesisPrediction:
              parsed.step2HypothesisPrediction || parsed.step2HypothesisOutcome || '',
            step3ActiveTab:
              parsed.step3ActiveTab === 'remove'
                ? 'relabel'
                : parsed.step3ActiveTab || 'relabel',
            step3LabelOverrides: parsed.step3LabelOverrides || {},
            step3PendingPrediction: parsed.step3PendingPrediction || null,
            step3HasCalculatedCurrent: Boolean(parsed.step3HasCalculatedCurrent),
            step3Observation: parsed.step3Observation || '',
            experiments,
            experimentCount: experiments.length,
            maxUnlockedStep: maxUnlocked,
            currentStep: safeCurrentStep,
          };
        }
      } catch (e) {
        console.error('Failed to parse saved state:', e);
      }
    }
  }

  return {
    currentStep: 1,
    maxUnlockedStep: 1,

    // Step 1
    step1Prediction: null,
    step1Reason: '',
    step1Submitted: false,
    step1AiResult: initialCalc,

    // Step 2
    step2Q1: '',
    step2Q2: '',
    step2Q3: [],
    step2HypothesisChanges: [],
    step2HypothesisPrediction: '',
    step2HypothesisFeature: '',
    step2HypothesisOutcome: '',
    step2Saved: false,

    // Step 3
    dataset: INITIAL_DATASET.map((d) => ({ ...d, included: true })),
    step3LabelOverrides: {},
    hasAddedExtraB5: false,
    experimentCount: 0,
    experiments: [],
    step3ActiveTab: 'relabel',
    step3PendingPrediction: null,
    step3HasCalculatedCurrent: false,
    step3Calculation: initialCalc,
    step3InitialCalculation: initialCalc,
    step3Observation: '',
    modificationLogs: [],

    // Step 4
    step4Q1: '',
    step4Q2: '',
    step4Q3: '',
    step4Q4: '',
    step4Revealed: false,

    // Step 5
    step5Choice: null,
    step5Reason: '',
    step5Principle: '',
    step5Submitted: false,
  };
}

export default function App() {
  const [state, setState] = useState<AppState>(getInitialState);
  const [isInfoOpen, setIsInfoOpen] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState(false);

  // Sync state to sessionStorage
  useEffect(() => {
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('SessionStorage save warning:', e);
    }
  }, [state]);

  // Navigate steps safely
  const handleSelectStep = (step: number) => {
    if (step <= state.maxUnlockedStep) {
      setState((prev) => ({ ...prev, currentStep: step }));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Step 1 Handlers
  const handleSelectPrediction = (val: 'A' | 'B' | 'unknown') => {
    setState((prev) => ({ ...prev, step1Prediction: val }));
  };

  const handleChangeReason = (val: string) => {
    setState((prev) => ({ ...prev, step1Reason: val }));
  };

  const handleSubmitStep1 = () => {
    const calc = classifyAlien(TEST_ALIEN, INITIAL_DATASET);
    setState((prev) => ({
      ...prev,
      step1Submitted: true,
      step1AiResult: calc,
      maxUnlockedStep: Math.max(prev.maxUnlockedStep, 2),
    }));
  };

  // Step 2 Handlers
  const handleSaveHypothesis = () => {
    if (
      state.step2HypothesisChanges.length === 0 ||
      state.step2HypothesisPrediction.trim().length === 0
    ) {
      return;
    }
    setState((prev) => ({
      ...prev,
      step2Saved: true,
      maxUnlockedStep: Math.max(prev.maxUnlockedStep, 3),
      currentStep: 3,
    }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Step 3 Handlers
  const handleSelectStep3Tab = (tab: 'relabel' | 'add' | 'free') => {
    setDuplicateWarning(false);
    const tabSnapshots = state.experiments.filter((e) => e.experimentType === tab);
    const latestSnap = tabSnapshots.length > 0 ? tabSnapshots[tabSnapshots.length - 1] : null;

    if (latestSnap) {
      const labelOverrides: Record<string, 'A' | 'B'> = {};
      if (latestSnap.labelChanges) {
        latestSnap.labelChanges.forEach((lc) => {
          labelOverrides[lc.id] = lc.to as 'A' | 'B';
        });
      }

      const base = INITIAL_DATASET.map((d) => ({
        ...d,
        included: latestSnap.includedDataIds.includes(d.id),
      }));
      const extraIncluded = EXTRA_ALIENS.filter((e) =>
        (latestSnap.addedDataIds || []).includes(e.id)
      ).map((e) => ({ ...e, included: true }));

      const combinedDataset = [...base, ...extraIncluded];
      const calc = classifyAlien(TEST_ALIEN, combinedDataset, labelOverrides);

      setState((prev) => ({
        ...prev,
        step3ActiveTab: tab,
        dataset: combinedDataset,
        step3LabelOverrides: labelOverrides,
        step3PendingPrediction: latestSnap.predictedResult || null,
        step3HasCalculatedCurrent: true,
        step3Calculation: calc,
        step3Observation: latestSnap.observation || '',
      }));
    } else {
      const base = INITIAL_DATASET.map((d) => ({ ...d, included: true }));
      setState((prev) => ({
        ...prev,
        step3ActiveTab: tab,
        dataset: base,
        step3LabelOverrides: {},
        step3PendingPrediction: null,
        step3HasCalculatedCurrent: false,
        step3Calculation: prev.step3InitialCalculation,
        step3Observation: '',
      }));
    }
  };

  const handleChangeLabelOverride = (id: string, newPlanet: 'A' | 'B') => {
    setDuplicateWarning(false);
    setState((prev) => {
      const nextOverrides = { ...prev.step3LabelOverrides, [id]: newPlanet };
      const originalItem = INITIAL_DATASET.find((d) => d.id === id);
      if (originalItem && originalItem.planet === newPlanet) {
        delete nextOverrides[id];
      }
      const log = `${id} 출신 행성 표시를 ${newPlanet}행성으로 변경`;
      return {
        ...prev,
        step3LabelOverrides: nextOverrides,
        step3HasCalculatedCurrent: false,
        step3PendingPrediction: null,
        step3Observation: '',
        modificationLogs: [...prev.modificationLogs, log],
      };
    });
  };

  const handleToggleExtraItem = (extraItem: AlienData) => {
    setDuplicateWarning(false);
    setState((prev) => {
      const existing = prev.dataset.find((d) => d.id === extraItem.id);
      let updated: AlienData[];
      if (existing) {
        updated = prev.dataset.map((d) =>
          d.id === extraItem.id ? { ...d, included: !d.included } : d
        );
      } else {
        updated = [...prev.dataset, { ...extraItem, included: true }];
      }

      const isNowIncluded = existing ? !existing.included : true;
      const log = `${extraItem.id} ${
        isNowIncluded ? '학습 데이터에 추가' : '학습 데이터에서 제외'
      }`;
      return {
        ...prev,
        dataset: updated,
        step3HasCalculatedCurrent: false,
        step3PendingPrediction: null,
        step3Observation: '',
        modificationLogs: [...prev.modificationLogs, log],
      };
    });
  };

  const handleResetTab = () => {
    setDuplicateWarning(false);
    const base = INITIAL_DATASET.map((d) => ({ ...d, included: true }));
    setState((prev) => ({
      ...prev,
      dataset: base,
      step3LabelOverrides: {},
      step3PendingPrediction: null,
      step3HasCalculatedCurrent: false,
      step3Observation: '',
      modificationLogs: [...prev.modificationLogs, `${prev.step3ActiveTab} 실험 초기화`],
    }));
  };

  const handleChangePrediction = (
    pred: 'A행성' | 'B행성' | '판단하기 어려움' | '잘 모르겠다'
  ) => {
    setState((prev) => ({ ...prev, step3PendingPrediction: pred }));
  };

  const handleChangeObservation = (obs: string, snapshotId?: string) => {
    setState((prev) => {
      let updatedExperiments: ExperimentSnapshot[];
      if (snapshotId) {
        updatedExperiments = prev.experiments.map((exp) =>
          exp.id === snapshotId ? { ...exp, observation: obs } : exp
        );
      } else {
        updatedExperiments = prev.experiments.map((exp, idx) =>
          idx === prev.experiments.length - 1 ? { ...exp, observation: obs } : exp
        );
      }

      const hasRelabel = updatedExperiments.some(
        (e) => e.experimentType === 'relabel' && Boolean(e.observation?.trim())
      );
      const hasAdd = updatedExperiments.some(
        (e) => e.experimentType === 'add' && Boolean(e.observation?.trim())
      );
      const newMaxUnlocked =
        hasRelabel && hasAdd ? Math.max(prev.maxUnlockedStep, 4) : prev.maxUnlockedStep;

      return {
        ...prev,
        step3Observation: obs,
        experiments: updatedExperiments,
        maxUnlockedStep: newMaxUnlocked,
      };
    });
  };

  const handleRecalculate = () => {
    if (!state.step3PendingPrediction) return;

    const changedBaseItems = INITIAL_DATASET.filter(
      (d) => state.step3LabelOverrides[d.id] && state.step3LabelOverrides[d.id] !== d.planet
    );
    const changedCount = changedBaseItems.length;
    const addedExtraCount = state.dataset.filter((d) => d.isExtra && d.included).length;

    if (state.step3ActiveTab === 'relabel' && (changedCount < 1 || changedCount > 4)) {
      return;
    }
    if (state.step3ActiveTab === 'add' && addedExtraCount < 1) {
      return;
    }
    if (state.step3ActiveTab === 'free' && changedCount === 0 && addedExtraCount === 0) {
      return;
    }

    // Duplicate check
    const currentOverridesJson = JSON.stringify(state.step3LabelOverrides);
    const currentAddedIds = state.dataset
      .filter((d) => d.isExtra && d.included)
      .map((d) => d.id)
      .sort()
      .join(',');

    const isDuplicate = state.experiments.some((exp) => {
      if (exp.experimentType !== state.step3ActiveTab) return false;
      const expOverrides: Record<string, string> = {};
      (exp.labelChanges || []).forEach((lc) => {
        expOverrides[lc.id] = lc.to;
      });
      const expOverridesJson = JSON.stringify(expOverrides);
      const expAdded = (exp.addedDataIds || []).slice().sort().join(',');
      return expOverridesJson === currentOverridesJson && expAdded === currentAddedIds;
    });

    if (isDuplicate) {
      setDuplicateWarning(true);
      return;
    }

    setDuplicateWarning(false);

    setState((prev) => {
      const newCalc = classifyAlien(
        TEST_ALIEN,
        prev.dataset,
        prev.step3LabelOverrides
      );
      const initialDecision =
        prev.step1AiResult?.decision || prev.step3InitialCalculation?.decision || 'A행성';

      // Included IDs
      const includedIds = prev.dataset.filter((d) => d.included).map((d) => d.id);

      // Added extra dataset IDs
      const addedIds = prev.dataset
        .filter((d) => d.isExtra && d.included)
        .map((d) => d.id);

      // Label changes
      const labelChanges: LabelChange[] = changedBaseItems.map((d) => ({
        id: d.id,
        from: d.planet,
        to: prev.step3LabelOverrides[d.id] || d.planet,
      }));

      const prediction = prev.step3PendingPrediction!;
      const isMatched = newCalc.decision === prediction;

      // Create immutable snapshot
      const snapshot: ExperimentSnapshot = {
        id:
          typeof crypto !== 'undefined' && crypto.randomUUID
            ? crypto.randomUUID()
            : `exp-${Date.now()}-${prev.experiments.length + 1}`,
        experimentNumber: prev.experiments.length + 1,
        experimentType: prev.step3ActiveTab,
        timestamp: Date.now(),
        includedDataIds: [...includedIds],
        excludedDataIds: [],
        addedDataIds: [...addedIds],
        labelChanges,
        predictedResult: prediction,
        predictionMatched: isMatched,
        result: newCalc.decision,
        highestScore: newCalc.topScore,
        closestDataIds: [...newCalc.topItemIds],
        changedFromInitial: newCalc.decision !== initialDecision,
        observation: '',
      };

      const updatedExperiments = [...prev.experiments, snapshot];
      const hasRelabel = updatedExperiments.some(
        (e) => e.experimentType === 'relabel' && Boolean(e.observation?.trim())
      );
      const hasAdd = updatedExperiments.some(
        (e) => e.experimentType === 'add' && Boolean(e.observation?.trim())
      );
      const newMaxUnlocked =
        hasRelabel && hasAdd ? Math.max(prev.maxUnlockedStep, 4) : prev.maxUnlockedStep;

      return {
        ...prev,
        experiments: updatedExperiments,
        experimentCount: updatedExperiments.length,
        step3Calculation: newCalc,
        step3HasCalculatedCurrent: true,
        step3Observation: '',
        maxUnlockedStep: newMaxUnlocked,
      };
    });
  };

  // Step 4 Handlers
  const handleRevealStep4 = () => {
    setState((prev) => ({
      ...prev,
      step4Revealed: true,
      maxUnlockedStep: Math.max(prev.maxUnlockedStep, 5),
    }));
  };

  // Step 5 Handlers
  const handleSelectStep5Choice = (choice: string) => {
    setState((prev) => ({ ...prev, step5Choice: choice }));
  };

  const handleChangeStep5Reason = (val: string) => {
    setState((prev) => ({ ...prev, step5Reason: val }));
  };

  const handleChangeStep5Principle = (val: string) => {
    setState((prev) => ({ ...prev, step5Principle: val }));
  };

  const handleSubmitStep5 = () => {
    setState((prev) => ({ ...prev, step5Submitted: true }));
  };

  const handleRestartAll = () => {
    try {
      sessionStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.error(e);
    }
    const freshState = getInitialState();
    freshState.maxUnlockedStep = 1;
    freshState.experiments = [];
    freshState.experimentCount = 0;
    setState(freshState);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#fff8f0] text-[#1f1b12] flex flex-col font-sans">
      {/* Side Navigation (Mission Control) */}
      <Navigation
        currentStep={state.currentStep}
        maxUnlockedStep={state.maxUnlockedStep}
        onSelectStep={handleSelectStep}
      />

      {/* Main Workspace Area */}
      <main className="flex-1 flex flex-col md:ml-72 bg-lab-grid min-h-[calc(100vh-4rem)]">
        <div className="w-full max-w-6xl mx-auto px-4 md:px-8 py-8 flex-1 flex flex-col gap-6">
          {/* Orbital Progress Bar */}
          <StepProgressBar
            currentStep={state.currentStep}
            maxUnlockedStep={state.maxUnlockedStep}
            onSelectStep={handleSelectStep}
          />

          {/* Current Step Views */}
          {state.currentStep === 1 && (
            <Step1Discover
              prediction={state.step1Prediction}
              reason={state.step1Reason}
              isSubmitted={state.step1Submitted}
              aiResult={state.step1AiResult}
              onSelectPrediction={handleSelectPrediction}
              onChangeReason={handleChangeReason}
              onSubmit={handleSubmitStep1}
              onNextStep={() => handleSelectStep(2)}
            />
          )}

          {state.currentStep === 2 && (
            <Step2Memory
              q1={state.step2Q1}
              q2={state.step2Q2}
              q3={state.step2Q3}
              hypothesisChanges={state.step2HypothesisChanges}
              hypothesisPrediction={state.step2HypothesisPrediction}
              isSaved={state.step2Saved}
              onChangeQ1={(v) => setState((p) => ({ ...p, step2Q1: v }))}
              onChangeQ2={(v) => setState((p) => ({ ...p, step2Q2: v }))}
              onChangeQ3={(v) => setState((p) => ({ ...p, step2Q3: v }))}
              onChangeHypothesisChanges={(v) =>
                setState((p) => ({ ...p, step2HypothesisChanges: v }))
              }
              onChangeHypothesisPrediction={(v) =>
                setState((p) => ({ ...p, step2HypothesisPrediction: v }))
              }
              onSaveHypothesis={handleSaveHypothesis}
              onNextStep={() => handleSelectStep(3)}
            />
          )}

          {state.currentStep === 3 && (
            <Step3Lab
              dataset={state.dataset}
              labelOverrides={state.step3LabelOverrides}
              experiments={state.experiments}
              activeTab={state.step3ActiveTab}
              hasCalculatedCurrent={state.step3HasCalculatedCurrent}
              calculation={state.step3Calculation}
              initialCalculation={state.step3InitialCalculation}
              pendingPrediction={state.step3PendingPrediction}
              currentObservation={state.step3Observation}
              duplicateWarning={duplicateWarning}
              onSelectTab={handleSelectStep3Tab}
              onChangeLabelOverride={handleChangeLabelOverride}
              onToggleExtraItem={handleToggleExtraItem}
              onResetTab={handleResetTab}
              onChangePrediction={handleChangePrediction}
              onChangeObservation={handleChangeObservation}
              onRecalculate={handleRecalculate}
              onNextStep={() => handleSelectStep(4)}
              onOpenInfo={() => setIsInfoOpen(true)}
            />
          )}

          {state.currentStep === 4 && (
            <Step4Analysis
              initialCalculation={state.step3InitialCalculation}
              experiments={state.experiments}
              q1={state.step4Q1}
              q2={state.step4Q2}
              q3={state.step4Q3}
              q4={state.step4Q4}
              isRevealed={state.step4Revealed}
              onChangeQ1={(v) => setState((p) => ({ ...p, step4Q1: v }))}
              onChangeQ2={(v) => setState((p) => ({ ...p, step4Q2: v }))}
              onChangeQ3={(v) => setState((p) => ({ ...p, step4Q3: v }))}
              onChangeQ4={(v) => setState((p) => ({ ...p, step4Q4: v }))}
              onReveal={handleRevealStep4}
              onNextStep={() => handleSelectStep(5)}
            />
          )}

          {state.currentStep === 5 && (
            <Step5Return
              appState={state}
              choice={state.step5Choice}
              reason={state.step5Reason}
              principle={state.step5Principle}
              isSubmitted={state.step5Submitted}
              onSelectChoice={handleSelectStep5Choice}
              onChangeReason={handleChangeStep5Reason}
              onChangePrinciple={handleChangeStep5Principle}
              onSubmit={handleSubmitStep5}
              onRestartAll={handleRestartAll}
            />
          )}
        </div>

        {/* Global Footer */}
        <footer className="w-full py-6 px-8 border-t border-[#e0e0e0] bg-[#fbf3e4]/80 flex flex-col sm:flex-row items-center justify-between text-xs text-[#7f7662] gap-2 mt-auto">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#735c00]">AI Decision Lab (AI 판단 실험실)</span>
            <span>·</span>
            <span>초등학교 5~6학년 AI 원리 체험 교육용</span>
          </div>
          <div>AI 판단 실험실 · AI 분류 원리 학습용 시뮬레이션</div>
        </footer>
      </main>

      {/* Info Modal */}
      <InfoModal isOpen={isInfoOpen} onClose={() => setIsInfoOpen(false)} />
    </div>
  );
}
